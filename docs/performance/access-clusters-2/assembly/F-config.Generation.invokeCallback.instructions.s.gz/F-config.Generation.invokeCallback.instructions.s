stp	x28, x27, [sp, #-0x60]!
stp	x26, x25, [sp, #0x10]
stp	x24, x23, [sp, #0x20]
stp	x22, x21, [sp, #0x30]
stp	x20, x19, [sp, #0x40]
stp	x29, x30, [sp, #0x50]
add	x29, sp, #0x50
sub	sp, sp, #0x5, lsl #12   ; =0x5000
sub	sp, sp, #0x460
mov	x21, x3
mov	x22, x1
mov	x26, x0
ldp	q0, q1, [x2]
stp	q0, q1, [sp, #0x20]
strb	wzr, [sp, #0x40]
add	x0, sp, #0x50
add	x2, sp, #0x20
bl	<_config.Generation.prepareCallback>
ldrh	w8, [sp, #0x58]
cbnz	w8, <_config.Generation.invokeCallback>
add	x20, sp, #0x5, lsl #12  ; =0x5000
add	x20, x20, #0x170
add	x28, sp, #0x2, lsl #12  ; =0x2000
add	x28, x28, #0x8e8
mov	w19, #0x8a8             ; =2216
movk	w19, #0x1, lsl #16
ldr	x8, [x22, x19]
ldr	x27, [x8, #0x20]
mov	x0, x27
mov	w1, #0x1                ; =1
mov	w2, #0x1                ; =1
mov	w3, #0x0                ; =0
mov	x4, #0x0                ; =0
mov	x5, #0x0                ; =0
bl	<_lua_pcallk>
cbz	w0, <_config.Generation.invokeCallback>
str	x26, [sp, #0x10]
mov	x26, x27
ldr	x8, [x22, x19]
ldr	x0, [x8, #0x20]
str	xzr, [sp, #0x28e8]
add	x2, sp, #0x2, lsl #12   ; =0x2000
add	x2, x2, #0x8e8
mov	w1, #-0x1               ; =-1
bl	<_lua_tolstring>
mov	x27, #0x0               ; =0
ldr	x8, [sp, #0x28e8]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
cmp	x0, #0x0
csel	x22, x9, x0, eq
mov	w9, #0x11               ; =17
csel	x23, x9, x8, eq
add	x25, x21, #0x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
str	x8, [sp, #0x28e8]
str	x25, [sp, #0x28f0]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [x28, #0x10]
adrp x19, RELOC_PAGE
add	x19, x19, #RELOC_OFFSET
mov	w20, #0x15              ; =21
add	x1, x19, x27
ldr	x8, [sp, #0x2900]
ldr	x9, [sp, #0x28f8]
sub	x24, x20, x27
add	x10, x8, x24
cmp	x10, x9
b.hi	<_config.Generation.invokeCallback>
ldr	x9, [sp, #0x28f0]
add	x0, x9, x8
mov	x2, x24
bl	<_memcpy>
ldr	x8, [sp, #0x2900]
add	x8, x8, x24
str	x8, [sp, #0x2900]
add	x27, x24, x27
cmp	x27, #0x15
b.lo	<_config.Generation.invokeCallback>
b	<_config.Generation.invokeCallback>
ldr	x8, [sp, #0x28e8]
ldr	x9, [x8]
str	x1, [sp, #0x5170]
str	x24, [sp, #0x5178]
add	x8, sp, #0x5, lsl #12   ; =0x5000
add	x8, x8, #0x1c0
add	x0, sp, #0x2, lsl #12   ; =0x2000
add	x0, x0, #0x8e8
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x170
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x8, sp, #0x5, lsl #12   ; =0x5000
add	x8, x8, #0x170
ldrh	w8, [x8, #0x58]
cbnz	w8, <_config.Generation.invokeCallback>
ldr	x24, [sp, #0x51c0]
add	x27, x24, x27
cmp	x27, #0x15
b.lo	<_config.Generation.invokeCallback>
adrp x8, RELOC_PAGE
ldrb	w4, [x8, #RELOC_OFFSET]
add	x0, sp, #0x2, lsl #12   ; =0x2000
add	x0, x0, #0x8e8
mov	x1, x22
mov	x2, x23
mov	x3, x23
mov	w5, #0x20               ; =32
bl	<_Io.Writer.alignBuffer>
tst	w0, #0xffff
b.eq	<_config.Generation.invokeCallback>
ldr	x9, [sp, #0x2900]
mov	w8, #0x3fd              ; =1021
cmp	x9, #0x3fd
csel	x8, x9, x8, lo
cmp	x9, #0x3fe
b.lo	<_config.Generation.invokeCallback>
ldr	x10, [sp, #0x28f0]
ldr	x19, [sp, #0x10]
ldrsb	w11, [x10, x8]
cmn	w11, #0x41
b.gt	<_config.Generation.invokeCallback>
subs	x8, x8, #0x1
b.eq	<_config.Generation.invokeCallback>
cmp	x8, x9
b.lo	<_config.Generation.invokeCallback>
b	<_config.Generation.invokeCallback>
ldr	x8, [x22, x19]
ldr	x23, [x8, #0x20]
mov	x0, x23
mov	w1, #-0x1               ; =-1
bl	<_lua_absindex>
mov	x24, x0
mov	x0, x23
mov	x1, x24
bl	<_lua_type>
cmp	w0, #0x5
b.ne	<_config.Generation.invokeCallback>
add	x0, sp, #0x2, lsl #12   ; =0x2000
add	x0, x0, #0x8e8
mov	w1, #0x2888             ; =10376
bl	<dyld_stub_binder>
adrp x2, RELOC_PAGE
add	x2, x2, #RELOC_OFFSET
mov	x0, x23
mov	x1, x24
bl	<_lua_getfield>
mov	x0, x23
mov	w1, #-0x1               ; =-1
bl	<_lua_type>
mov	x25, x0
mov	x0, x23
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
cbz	w25, <_config.Generation.invokeCallback>
add	x0, sp, #0x5, lsl #12   ; =0x5000
add	x0, x0, #0x1c0
mov	x1, x22
mov	x2, x24
mov	x3, x21
bl	<_config.Generation.parseReturnedAction>
ldrh	w19, [x20, #0x2d8]
cbnz	w19, <_config.Generation.invokeCallback>
add	x19, sp, #0x2, lsl #12  ; =0x2000
add	x19, x19, #0x8e8
add	x0, sp, #0x2, lsl #12   ; =0x2000
add	x0, x0, #0x8e8
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x1c0
mov	w2, #0x288              ; =648
bl	<_memcpy>
mov	w8, #0x2880             ; =10368
mov	w9, #0x1                ; =1
strb	w9, [x19, x8]
add	x0, sp, #0x60
add	x1, sp, #0x2, lsl #12   ; =0x2000
add	x1, x1, #0x8e8
mov	w2, #0x2888             ; =10376
bl	<_memcpy>
mov	w19, #0x0               ; =0
b	<_config.Generation.invokeCallback>
ldr	x8, [sp, #0x2900]
ldr	x19, [sp, #0x10]
b	<_config.Generation.invokeCallback>
ldr	x19, [sp, #0x10]
add	x9, x25, x8
mov	w10, #0xa6              ; =166
strb	w10, [x9, #0x2]
mov	w10, #0x80e2            ; =32994
strh	w10, [x9]
add	x8, x8, #0x3
str	x8, [x21]
mov	x0, x26
mov	w1, #0x0                ; =0
bl	<_lua_settop>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	x0, x19
mov	w2, #0x2890             ; =10384
bl	<_memcpy>
b	<_config.Generation.invokeCallback>
mov	x24, #0x0               ; =0
add	x23, x21, #0x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
str	x8, [sp, #0x28e8]
str	x23, [sp, #0x28f0]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [x28, #0x10]
adrp x19, RELOC_PAGE
add	x19, x19, #RELOC_OFFSET
mov	w20, #0x39              ; =57
add	x1, x19, x24
ldr	x8, [sp, #0x2900]
ldr	x9, [sp, #0x28f8]
sub	x22, x20, x24
add	x10, x8, x22
cmp	x10, x9
b.hi	<_config.Generation.invokeCallback>
ldr	x9, [sp, #0x28f0]
add	x0, x9, x8
mov	x2, x22
bl	<_memcpy>
ldr	x8, [sp, #0x2900]
add	x8, x8, x22
str	x8, [sp, #0x2900]
add	x24, x22, x24
cmp	x24, #0x39
b.lo	<_config.Generation.invokeCallback>
b	<_config.Generation.invokeCallback>
ldr	x8, [sp, #0x28e8]
ldr	x9, [x8]
str	x1, [sp, #0x5170]
str	x22, [sp, #0x5178]
add	x8, sp, #0x5, lsl #12   ; =0x5000
add	x8, x8, #0x1c0
add	x0, sp, #0x2, lsl #12   ; =0x2000
add	x0, x0, #0x8e8
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x170
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x8, sp, #0x5, lsl #12   ; =0x5000
add	x8, x8, #0x170
ldrh	w8, [x8, #0x58]
cbnz	w8, <_config.Generation.invokeCallback>
ldr	x22, [sp, #0x51c0]
add	x24, x22, x24
cmp	x24, #0x39
b.lo	<_config.Generation.invokeCallback>
ldr	x8, [sp, #0x2900]
str	x8, [x21]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x60
mov	w2, #0x2888             ; =10376
bl	<_memcpy>
mov	w19, #0x2d6             ; =726
b	<_config.Generation.invokeCallback>
stp	x26, x21, [sp, #0x10]
str	x27, [sp, #0x8]
mov	x0, x23
mov	x1, x24
bl	<_lua_rawlen>
mov	w8, #0x10               ; =16
cmp	x0, #0x10
csel	x27, x0, x8, lo
b.ls	<_config.Generation.invokeCallback>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x5170]
str	q1, [sp, #0x5180]
ldr	x8, [x8, #0x20]
str	x8, [sp, #0x5190]
str	x0, [sp, #0x5198]
mov	w8, #0x1                ; =1
add	x21, sp, #0x5, lsl #12  ; =0x5000
add	x21, x21, #0x170
strb	w8, [x20, #0x30]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
str	x8, [sp, #0x51a8]
str	xzr, [sp, #0x51b0]
add	x8, x22, #0x12f, lsl #12 ; =0x12f000
add	x0, x8, #0xdb0
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x170
bl	<_config.UnreportedReaches.add>
b	<_config.Generation.invokeCallback>
add	x21, sp, #0x5, lsl #12  ; =0x5000
add	x21, x21, #0x170
cbz	x0, <_config.Generation.invokeCallback>
mov	x20, #0x0               ; =0
mov	w28, #0x2880            ; =10368
add	x26, sp, #0x2, lsl #12  ; =0x2000
add	x26, x26, #0x8e8
mov	w25, #0x1               ; =1
mov	x0, x23
mov	x1, x24
mov	x2, x25
bl	<_lua_geti>
add	x0, sp, #0x5, lsl #12   ; =0x5000
add	x0, x0, #0x1c0
mov	x1, x22
mov	w2, #-0x1               ; =-1
ldr	x3, [sp, #0x18]
bl	<_config.Generation.parseReturnedAction>
ldrh	w19, [x21, #0x2d8]
cbnz	w19, <_config.Generation.invokeCallback>
mov	w8, #0x288              ; =648
madd	x0, x20, x8, x26
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x1c0
mov	w2, #0x288              ; =648
bl	<_memcpy>
ldrb	w8, [x26, x28]
add	x20, x8, #0x1
strb	w20, [x26, x28]
mov	x0, x23
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
add	x25, x25, #0x1
subs	x27, x27, #0x1
b.ne	<_config.Generation.invokeCallback>
b	<_config.Generation.invokeCallback>
sub	w8, w19, #0x7c
cmp	w8, #0x4
mov	w9, #0x1                ; =1
lsl	w8, w9, w8
mov	w9, #0x19               ; =25
and	w8, w8, w9
ccmp	w8, #0x0, #0x4, ls
b.ne	<_config.Generation.invokeCallback>
mov	x0, x23
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
b	<_config.Generation.invokeCallback>
add	x0, sp, #0x60
add	x1, sp, #0x2, lsl #12   ; =0x2000
add	x1, x1, #0x8e8
mov	w2, #0x2888             ; =10376
bl	<_memcpy>
mov	w19, #0x0               ; =0
ldp	x27, x26, [sp, #0x8]
mov	x0, x27
mov	w1, #0x0                ; =0
bl	<_lua_settop>
mov	w20, #0x2888            ; =10376
add	x1, sp, #0x60
mov	x0, x26
mov	w2, #0x2888             ; =10376
bl	<_memcpy>
strh	w19, [x26, x20]
mov	w8, #0x288a             ; =10378
add	x8, x26, x8
str	wzr, [x8]
strh	wzr, [x8, #0x4]
add	sp, sp, #0x5, lsl #12   ; =0x5000
add	sp, sp, #0x460
ldp	x29, x30, [sp, #0x50]
ldp	x20, x19, [sp, #0x40]
ldp	x22, x21, [sp, #0x30]
ldp	x24, x23, [sp, #0x20]
ldp	x26, x25, [sp, #0x10]
ldp	x28, x27, [sp], #0x60
ret
ldr	x9, [sp, #0x2900]
mov	w8, #0x3fd              ; =1021
cmp	x9, #0x3fd
csel	x8, x9, x8, lo
cmp	x9, #0x3fe
b.lo	<_config.Generation.invokeCallback>
ldr	x10, [sp, #0x28f0]
ldrsb	w11, [x10, x8]
cmn	w11, #0x41
b.gt	<_config.Generation.invokeCallback>
subs	x8, x8, #0x1
b.eq	<_config.Generation.invokeCallback>
cmp	x8, x9
b.lo	<_config.Generation.invokeCallback>
add	x9, x23, x8
mov	w10, #0xa6              ; =166
strb	w10, [x9, #0x2]
mov	w10, #0x80e2            ; =32994
strh	w10, [x9]
add	x8, x8, #0x3
b	<_config.Generation.invokeCallback>
mov	w9, #0x2888             ; =10376
strh	w8, [x26, x9]
b	<_config.Generation.invokeCallback>
sub	w8, w19, #0x7c
cmp	w8, #0x4
b.hi	<_config.Generation.invokeCallback>
mov	w9, #0x1                ; =1
lsl	w8, w9, w8
mov	w9, #0x19               ; =25
tst	w8, w9
b.eq	<_config.Generation.invokeCallback>
add	x0, sp, #0x60
mov	w1, #0x2888             ; =10376
bl	<dyld_stub_binder>
mov	w19, #0x0               ; =0
b	<_config.Generation.invokeCallback>

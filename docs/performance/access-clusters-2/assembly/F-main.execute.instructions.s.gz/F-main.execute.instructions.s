stp	x28, x27, [sp, #-0x60]!
stp	x26, x25, [sp, #0x10]
stp	x24, x23, [sp, #0x20]
stp	x22, x21, [sp, #0x30]
stp	x20, x19, [sp, #0x40]
stp	x29, x30, [sp, #0x50]
add	x29, sp, #0x50
sub	sp, sp, #0x8b, lsl #12  ; =0x8b000
sub	sp, sp, #0x4c0
str	x30, [sp, #0x110]
mov	x22, x2
ldp	x8, x26, [x0]
str	x8, [sp, #0x130]
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
ldp	x19, x8, [x0, #0x10]
str	x8, [sp, #0x148]
add	x25, sp, #0x89, lsl #12 ; =0x89000
add	x25, x25, #0x9b0
ldr	x20, [x0, #0x20]
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
ldur	q0, [x0, #0x28]
ldur	q1, [x0, #0x38]
stp	q0, q1, [sp, #0x190]
ldur	q0, [x0, #0x48]
str	q0, [sp, #0x1b0]
ldr	x8, [x0, #0x58]
str	x8, [sp, #0x1c0]
ldp	q0, q1, [x1]
stp	x1, x0, [sp, #0xe8]
stp	q0, q1, [sp, #0x1d0]
ldr	x8, [x0, #0x58]
str	x8, [sp, #0x220]
ldur	q2, [x0, #0x48]
ldur	q0, [x0, #0x38]
ldur	q1, [x0, #0x28]
stp	q0, q2, [sp, #0x200]
str	q1, [sp, #0x1f0]
stp	x26, x20, [sp, #0x100]
str	x19, [sp, #0x120]
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x17               ; =23
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
add	x0, sp, #0x290
add	x1, sp, #0x1e0
mov	x2, x22
mov	w3, #0x0                ; =0
bl	<_DamageContext.init>
ldrh	w28, [sp, #0x2e8]
cbnz	w28, <_main.execute>
add	x8, sp, #0x2f0
ldp	q0, q1, [sp, #0x2b0]
stp	q0, q1, [sp, #0x250]
ldr	q0, [sp, #0x2d0]
str	q0, [sp, #0x270]
ldr	x9, [sp, #0x2e0]
str	x9, [sp, #0x280]
ldp	q0, q1, [sp, #0x290]
stp	q0, q1, [sp, #0x230]
ldr	x9, [sp, #0x130]
str	x9, [sp, #0x2f0]
str	x26, [sp, #0x2f8]
str	x19, [sp, #0x300]
ldr	x10, [sp, #0x148]
str	x10, [sp, #0x308]
ldr	x9, [sp, #0x1c0]
str	x20, [sp, #0x310]
str	x9, [sp, #0x348]
ldp	q0, q1, [sp, #0x1a0]
stur	q1, [x8, #0x48]
ldr	q1, [sp, #0x190]
stur	q0, [x8, #0x38]
stur	q1, [x8, #0x28]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x350]
str	x26, [sp, #0x360]
str	x19, [sp, #0x368]
str	x10, [sp, #0x370]
str	x20, [sp, #0x378]
ldp	q0, q1, [sp, #0x1f0]
ldr	q2, [sp, #0x210]
ldr	x8, [sp, #0x220]
stp	q1, q2, [sp, #0x390]
str	q0, [sp, #0x380]
add	x9, sp, #0x230
str	x8, [sp, #0x3b0]
str	x9, [sp, #0x3b8]
add	x0, sp, #0x3c0
add	x1, sp, #0x350
bl	<_main.measure__anon>
ldrh	w28, [sp, #0x3e8]
cbnz	w28, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x2f0
add	x2, sp, #0x3c0
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x8, [sp, #0x278]
ldr	x21, [sp, #0x110]
cbz	x8, <_main.execute>
ldr	x1, [sp, #0x270]
ldr	x9, [sp, #0x238]
ldr	x0, [sp, #0x230]
add	x8, x8, x8, lsl #1
lsl	x2, x8, #3
mov	x4, x21
xpaci	x4
ldr	x8, [x9, #0x18]
mov	w3, #0x3                ; =3
blr	x8
ldr	x2, [sp, #0x268]
cbz	x2, <_main.execute>
ldr	x1, [sp, #0x260]
ldr	x8, [sp, #0x238]
ldr	x0, [sp, #0x230]
mov	x4, x21
xpaci	x4
ldr	x8, [x8, #0x18]
mov	w3, #0x0                ; =0
blr	x8
ldr	x8, [sp, #0x258]
cbz	x8, <_main.execute>
ldr	x1, [sp, #0x250]
ldr	x9, [sp, #0x238]
ldr	x0, [sp, #0x230]
lsl	x2, x8, #5
mov	x4, x21
xpaci	x4
ldr	x8, [x9, #0x18]
mov	w3, #0x1                ; =1
blr	x8
ldr	x8, [sp, #0x248]
cbz	x8, <_main.execute>
ldr	x1, [sp, #0x240]
ldr	x9, [sp, #0x238]
ldr	x0, [sp, #0x230]
lsl	x2, x8, #5
mov	x4, x21
xpaci	x4
ldr	x8, [x9, #0x18]
mov	w3, #0x1                ; =1
blr	x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
stp	q0, q1, [sp, #0x3f0]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x410]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x420]
cbnz	x26, <_main.execute>
b	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
stp	q0, q1, [sp, #0x3f0]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x410]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x420]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x19               ; =25
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
add	x0, sp, #0x490
add	x1, sp, #0x1e0
mov	x2, x22
mov	w3, #0x1                ; =1
bl	<_DamageContext.init>
ldrh	w28, [sp, #0x4e8]
cbnz	w28, <_main.execute>
add	x8, sp, #0x4f0
ldr	q0, [sp, #0x4b0]
ldr	q1, [sp, #0x4c0]
str	q0, [sp, #0x450]
str	q1, [sp, #0x460]
ldr	q0, [sp, #0x4d0]
str	q0, [sp, #0x470]
ldr	x9, [sp, #0x4e0]
str	x9, [sp, #0x480]
ldr	q0, [sp, #0x490]
ldr	q1, [sp, #0x4a0]
str	q0, [sp, #0x430]
str	q1, [sp, #0x440]
ldr	x9, [sp, #0x130]
str	x9, [sp, #0x4f0]
str	x26, [sp, #0x4f8]
str	x19, [sp, #0x500]
ldr	x10, [sp, #0x148]
str	x10, [sp, #0x508]
ldr	x9, [sp, #0x1c0]
str	x20, [sp, #0x510]
str	x9, [sp, #0x548]
ldp	q0, q1, [sp, #0x1a0]
stur	q1, [x8, #0x48]
ldr	q1, [sp, #0x190]
stur	q0, [x8, #0x38]
stur	q1, [x8, #0x28]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x550]
str	x26, [sp, #0x560]
str	x19, [sp, #0x568]
str	x10, [sp, #0x570]
str	x20, [sp, #0x578]
ldp	q0, q1, [sp, #0x1f0]
ldr	q2, [sp, #0x210]
ldr	x8, [sp, #0x220]
str	q2, [sp, #0x5a0]
str	q1, [sp, #0x590]
str	q0, [sp, #0x580]
add	x9, sp, #0x430
str	x8, [sp, #0x5b0]
str	x9, [sp, #0x5b8]
add	x0, sp, #0x5c0
add	x1, sp, #0x550
bl	<_main.measure__anon>
ldrh	w28, [sp, #0x5e8]
cbnz	w28, <_main.execute>
add	x0, sp, #0x4f0
add	x1, sp, #0x3f0
add	x2, sp, #0x5c0
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x8, [sp, #0x478]
ldr	x21, [sp, #0x110]
cbz	x8, <_main.execute>
ldr	x1, [sp, #0x470]
ldr	x9, [sp, #0x438]
ldr	x0, [sp, #0x430]
add	x8, x8, x8, lsl #1
lsl	x2, x8, #3
mov	x4, x21
xpaci	x4
ldr	x8, [x9, #0x18]
mov	w3, #0x3                ; =3
blr	x8
ldr	x2, [sp, #0x468]
cbz	x2, <_main.execute>
ldr	x1, [sp, #0x460]
ldr	x8, [sp, #0x438]
ldr	x0, [sp, #0x430]
mov	x4, x21
xpaci	x4
ldr	x8, [x8, #0x18]
mov	w3, #0x0                ; =0
blr	x8
ldr	x8, [sp, #0x458]
cbz	x8, <_main.execute>
ldr	x1, [sp, #0x450]
ldr	x9, [sp, #0x438]
ldr	x0, [sp, #0x430]
lsl	x2, x8, #5
mov	x4, x21
xpaci	x4
ldr	x8, [x9, #0x18]
mov	w3, #0x1                ; =1
blr	x8
ldr	x8, [sp, #0x448]
cbz	x8, <_main.execute>
ldr	x1, [sp, #0x440]
ldr	x9, [sp, #0x438]
ldr	x0, [sp, #0x430]
lsl	x2, x8, #5
mov	x4, x21
xpaci	x4
ldr	x8, [x9, #0x18]
mov	w3, #0x1                ; =1
blr	x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x5f0]
str	q1, [sp, #0x600]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x610]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x620]
cbnz	x26, <_main.execute>
b	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x5f0]
str	q1, [sp, #0x600]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x610]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x620]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x1a               ; =26
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
add	x0, sp, #0x690
add	x1, sp, #0x1e0
mov	x2, x22
mov	w3, #0x2                ; =2
bl	<_DamageContext.init>
ldrh	w28, [sp, #0x6e8]
cbnz	w28, <_main.execute>
add	x8, sp, #0x6f0
ldr	q0, [sp, #0x6b0]
ldr	q1, [sp, #0x6c0]
str	q0, [sp, #0x650]
str	q1, [sp, #0x660]
ldr	q0, [sp, #0x6d0]
str	q0, [sp, #0x670]
ldr	x9, [sp, #0x6e0]
str	x9, [sp, #0x680]
ldr	q0, [sp, #0x690]
ldr	q1, [sp, #0x6a0]
str	q0, [sp, #0x630]
str	q1, [sp, #0x640]
ldr	x9, [sp, #0x130]
str	x9, [sp, #0x6f0]
str	x26, [sp, #0x6f8]
str	x19, [sp, #0x700]
ldr	x10, [sp, #0x148]
str	x10, [sp, #0x708]
ldr	x9, [sp, #0x1c0]
str	x20, [sp, #0x710]
str	x9, [sp, #0x748]
ldp	q0, q1, [sp, #0x1a0]
stur	q1, [x8, #0x48]
ldr	q1, [sp, #0x190]
stur	q0, [x8, #0x38]
stur	q1, [x8, #0x28]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x750]
str	x26, [sp, #0x760]
str	x19, [sp, #0x768]
str	x10, [sp, #0x770]
str	x20, [sp, #0x778]
ldp	q0, q1, [sp, #0x1f0]
ldr	q2, [sp, #0x210]
ldr	x8, [sp, #0x220]
str	q2, [sp, #0x7a0]
str	q1, [sp, #0x790]
str	q0, [sp, #0x780]
add	x9, sp, #0x630
str	x8, [sp, #0x7b0]
str	x9, [sp, #0x7b8]
add	x0, sp, #0x7c0
add	x1, sp, #0x750
bl	<_main.measure__anon>
ldrh	w28, [sp, #0x7e8]
cbnz	w28, <_main.execute>
add	x0, sp, #0x6f0
add	x1, sp, #0x5f0
add	x2, sp, #0x7c0
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x8, [sp, #0x678]
ldr	x21, [sp, #0x110]
cbz	x8, <_main.execute>
ldr	x1, [sp, #0x670]
ldr	x9, [sp, #0x638]
ldr	x0, [sp, #0x630]
add	x8, x8, x8, lsl #1
lsl	x2, x8, #3
mov	x4, x21
xpaci	x4
ldr	x8, [x9, #0x18]
mov	w3, #0x3                ; =3
blr	x8
ldr	x2, [sp, #0x668]
cbz	x2, <_main.execute>
ldr	x1, [sp, #0x660]
ldr	x8, [sp, #0x638]
ldr	x0, [sp, #0x630]
mov	x4, x21
xpaci	x4
ldr	x8, [x8, #0x18]
mov	w3, #0x0                ; =0
blr	x8
ldr	x8, [sp, #0x658]
cbz	x8, <_main.execute>
ldr	x1, [sp, #0x650]
ldr	x9, [sp, #0x638]
ldr	x0, [sp, #0x630]
lsl	x2, x8, #5
mov	x4, x21
xpaci	x4
ldr	x8, [x9, #0x18]
mov	w3, #0x1                ; =1
blr	x8
ldr	x8, [sp, #0x648]
cbz	x8, <_main.execute>
ldr	x1, [sp, #0x640]
ldr	x9, [sp, #0x638]
ldr	x0, [sp, #0x630]
lsl	x2, x8, #5
mov	x4, x21
xpaci	x4
ldr	x8, [x9, #0x18]
mov	w3, #0x1                ; =1
blr	x8
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x18               ; =24
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
add	x20, sp, #0x39, lsl #12 ; =0x39000
add	x20, x20, #0x430
ldp	x27, x19, [sp, #0x1e0]
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
add	x1, sp, #0x1e0
mov	x2, x22
mov	w3, #0x1                ; =1
bl	<_DamageContext.init>
ldrh	w28, [x20, #0x58]
cbnz	w28, <_main.execute>
ldp	x20, x21, [sp, #0x108]
tbnz	wzr, #0x0, <_main.execute>
mov	x26, x21
xpaci	x26
ldr	x8, [x19]
mov	x0, x27
mov	w1, #0x400000           ; =4194304
mov	w2, #0x0                ; =0
mov	x3, x26
blr	x8
cbz	x0, <_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
ldp	q0, q1, [x19, #0x20]
str	q0, [sp, #0x810]
str	q1, [sp, #0x820]
ldr	q0, [x19, #0x40]
str	q0, [sp, #0x830]
ldr	x8, [x19, #0x50]
ldp	q0, q1, [x19]
str	q0, [sp, #0x7f0]
str	q1, [sp, #0x800]
str	x8, [sp, #0x840]
str	x0, [sp, #0x848]
mov	w8, #0x400000           ; =4194304
str	x8, [sp, #0x850]
ldr	q0, [sp, #0x810]
ldr	q1, [sp, #0x800]
ldr	x8, [sp, #0x820]
ldr	x9, [sp, #0x828]
add	x11, sp, #0x29, lsl #12 ; =0x29000
add	x11, x11, #0x3a0
stp	q0, q1, [x11, #0x90]
mov	w10, #0x9a              ; =154
strh	w10, [x11, #0xc8]
stp	x8, x9, [x11, #0xb0]
mov	w8, #0xc                ; =12
str	x8, [x11, #0xc0]
ldr	x2, [sp, #0x830]
ldr	x3, [sp, #0x838]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x29, lsl #12  ; =0x29000
add	x1, x1, #0x430
bl	<_damage.collectSpans__anon>
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x8, [x8]
ldr	x2, [sp, #0x850]
ldr	x1, [sp, #0x848]
ldr	x9, [sp, #0x830]
adrp x10, RELOC_PAGE
ldr	q0, [x10, #RELOC_OFFSET]
str	q0, [x19]
mov	w10, #0x1               ; =1
str	x10, [x19, #0x10]
adrp x10, RELOC_PAGE
ldr	d0, [x10, #RELOC_OFFSET]
mov	w10, #0x9a              ; =154
movk	w10, #0x25, lsl #16
str	d0, [x19, #0x88]
stp	x9, x8, [x19, #0x78]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldr	w9, [x8]
stp	w10, w9, [x19, #0x90]
ldrh	w8, [x8, #0x4]
strh	w8, [x19, #0x98]
stur	xzr, [x19, #0x9a]
stur	wzr, [x19, #0xa2]
movi.2d	v0, #0000000000000000
stur	q0, [x19, #0x68]
stur	q0, [x19, #0x58]
stur	q0, [x19, #0x48]
stur	q0, [x19, #0x38]
stur	q0, [x19, #0x28]
stur	q0, [x19, #0x18]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x3, sp, #0x39, lsl #12  ; =0x39000
add	x3, x3, #0x430
bl	<_schema.messages.pane.encodePaneFrame>
ldrh	w28, [x25, #0x990]
cbnz	w28, <_main.execute>
add	x8, sp, #0x858
ldr	x9, [x25, #0x988]
ldr	x10, [sp, #0x130]
str	x10, [sp, #0x858]
ldr	x13, [sp, #0x100]
str	x13, [sp, #0x860]
ldr	x14, [sp, #0x120]
str	x14, [sp, #0x868]
ldr	x12, [sp, #0x148]
str	x12, [sp, #0x870]
ldp	q0, q1, [sp, #0x190]
stur	q0, [x8, #0x28]
stur	q1, [x8, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x8, #0x48]
ldr	x10, [sp, #0x1c0]
str	x20, [sp, #0x878]
str	x10, [sp, #0x8b0]
adrp x10, RELOC_PAGE
add	x10, x10, #RELOC_OFFSET
mov	w11, #0x18              ; =24
str	x10, [sp, #0x8b8]
str	x11, [sp, #0x8c0]
adrp x10, RELOC_PAGE
add	x10, x10, #RELOC_OFFSET
ldr	q0, [x10]
str	q0, [x8, #0x70]
ldr	x8, [x10, #0x10]
str	x8, [sp, #0x8d8]
str	x9, [sp, #0x8e0]
mov	w8, #0x4240             ; =16960
movk	w8, #0xf, lsl #16
str	x8, [sp, #0x8e8]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x8f0]
str	x13, [sp, #0x900]
str	x14, [sp, #0x908]
str	x12, [sp, #0x910]
str	x20, [sp, #0x918]
ldr	x8, [sp, #0x220]
ldp	q0, q1, [sp, #0x200]
str	q1, [sp, #0x940]
ldr	q1, [sp, #0x1f0]
str	q0, [sp, #0x930]
str	q1, [sp, #0x920]
add	x9, sp, #0x7f0
str	x8, [sp, #0x950]
str	x9, [sp, #0x958]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x8f0
mov	w2, #0x1                ; =1
bl	<_main.timed__anon>
ldrh	w28, [x25, #0x988]
cbnz	w28, <_main.execute>
lsr	x8, x20, #2
str	x8, [sp, #0x160]
mov	w27, #0x1               ; =1
ldr	x2, [x25, #0x980]
ldr	x8, [sp, #0x160]
cmp	x2, x8
lsr	x8, x27, #30
ccmp	x8, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x27, x27, #2
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x8f0
mov	x2, x27
bl	<_main.timed__anon>
ldrh	w28, [x25, #0x988]
cbz	w28, <_main.execute>
add	x0, sp, #0x7f0
bl	<_FrameContext.deinit>
b	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
ldr	x8, [x19, #0x48]
cbz	x8, <_main.execute>
ldr	x1, [x19, #0x40]
ldp	x0, x9, [x19]
add	x8, x8, x8, lsl #1
lsl	x2, x8, #3
mov	x4, x21
xpaci	x4
ldr	x8, [x9, #0x18]
mov	w3, #0x3                ; =3
blr	x8
ldr	x2, [x19, #0x38]
cbz	x2, <_main.execute>
ldr	x1, [x19, #0x30]
ldp	x0, x8, [x19]
mov	x4, x21
xpaci	x4
ldr	x8, [x8, #0x18]
mov	w3, #0x0                ; =0
blr	x8
ldr	x8, [x19, #0x28]
cbz	x8, <_main.execute>
ldr	x1, [x19, #0x20]
ldp	x0, x9, [x19]
lsl	x2, x8, #5
mov	x4, x21
xpaci	x4
ldr	x8, [x9, #0x18]
mov	w3, #0x1                ; =1
blr	x8
ldr	x8, [x19, #0x18]
cbz	x8, <_main.execute>
ldp	x9, x1, [x19, #0x8]
ldr	x0, [x19]
lsl	x2, x8, #5
xpaci	x21
ldr	x8, [x9, #0x18]
mov	w3, #0x1                ; =1
mov	x4, x21
blr	x8
b	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x990]
str	q1, [sp, #0x9a0]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x9b0]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x9c0]
b	<_main.execute>
cmp	x2, #0x0
ccmp	x2, x20, #0x2, ne
b.hs	<_main.execute>
mul	x0, x27, x20
umulh	x1, x27, x20
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x27, x8
csel	x27, x27, x8, hi
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0x8f0
mov	x2, x27
bl	<_main.timed__anon>
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
ldrh	w28, [x8, #0x98]
cbnz	w28, <_main.execute>
add	x20, sp, #0x71, lsl #12 ; =0x71000
add	x20, x20, #0x700
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
ldr	x21, [sp, #0x148]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x8f0
mov	x2, x27
bl	<_main.timed__anon>
ldrh	w28, [x20, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
cbnz	w28, <_main.execute>
ldr	x8, [x8]
udiv	x8, x8, x27
str	x8, [x19], #0x8
subs	x21, x21, #0x1
add	x20, sp, #0x71, lsl #12 ; =0x71000
add	x20, x20, #0x700
b.ne	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
ldr	x10, [x10]
lsr	x11, x20, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
str	x27, [sp, #0x968]
str	x11, [sp, #0x970]
str	x10, [sp, #0x978]
str	x8, [sp, #0x980]
str	x9, [sp, #0x988]
add	x0, sp, #0x858
add	x1, sp, #0x8b8
add	x2, sp, #0x968
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x2, [sp, #0x850]
ldr	x20, [sp, #0x108]
ldr	x19, [sp, #0x120]
cbz	x2, <_main.execute>
ldr	x1, [sp, #0x848]
ldr	x8, [sp, #0x7f8]
ldr	x0, [sp, #0x7f0]
ldr	x8, [x8, #0x18]
mov	w3, #0x0                ; =0
mov	x4, x26
blr	x8
ldr	x8, [sp, #0x838]
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
cbz	x8, <_main.execute>
ldr	x1, [sp, #0x830]
ldr	x9, [sp, #0x7f8]
ldr	x0, [sp, #0x7f0]
add	x8, x8, x8, lsl #1
lsl	x2, x8, #3
ldr	x8, [x9, #0x18]
mov	w3, #0x3                ; =3
mov	x4, x26
blr	x8
ldr	x2, [sp, #0x828]
cbz	x2, <_main.execute>
ldr	x1, [sp, #0x820]
ldr	x8, [sp, #0x7f8]
ldr	x0, [sp, #0x7f0]
ldr	x8, [x8, #0x18]
mov	w3, #0x0                ; =0
mov	x4, x26
blr	x8
ldr	x8, [sp, #0x818]
cbz	x8, <_main.execute>
ldr	x1, [sp, #0x810]
ldr	x9, [sp, #0x7f8]
ldr	x0, [sp, #0x7f0]
lsl	x2, x8, #5
ldr	x8, [x9, #0x18]
mov	w3, #0x1                ; =1
mov	x4, x26
blr	x8
ldr	x8, [sp, #0x808]
cbz	x8, <_main.execute>
ldr	x1, [sp, #0x800]
ldr	x9, [sp, #0x7f8]
ldr	x0, [sp, #0x7f0]
lsl	x2, x8, #5
ldr	x8, [x9, #0x18]
mov	w3, #0x1                ; =1
mov	x4, x26
blr	x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x990]
str	q1, [sp, #0x9a0]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x9b0]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x9c0]
ldr	x26, [sp, #0x100]
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x1a               ; =26
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
lsr	x8, x20, #2
str	x8, [sp, #0x160]
add	x8, sp, #0xad8
ldp	q0, q1, [sp, #0x190]
stur	q0, [x8, #0x28]
ldr	x9, [sp, #0x130]
str	x9, [sp, #0xad8]
str	x26, [sp, #0xae0]
str	x19, [sp, #0xae8]
ldr	x9, [sp, #0x148]
str	x9, [sp, #0xaf0]
stur	q1, [x8, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x8, #0x48]
ldr	x8, [sp, #0x1c0]
str	x20, [sp, #0xaf8]
str	x8, [sp, #0xb30]
adrp x27, RELOC_PAGE
add	x27, x27, #RELOC_OFFSET
mov	w8, #0x1                ; =1
adrp x28, RELOC_PAGE
add	x28, x28, #RELOC_OFFSET
mov	w21, #0x2               ; =2
ldp	x26, x24, [sp, #0x1d0]
str	x24, [sp, #0x150]
mov	x19, x8
ldr	x9, [x24, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
mov	x23, #0x0               ; =0
add	x20, sp, #0x39, lsl #12 ; =0x39000
add	x20, x20, #0x430
ldr	x25, [x20]
mov	x24, x19
add	x0, sp, #0x9d2
mov	x1, x27
mov	w2, #0x106              ; =262
bl	<_memcpy>
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
add	x1, sp, #0x9d2
mov	x2, x28
mov	w3, #0x1e               ; =30
bl	<_InputScanner.feed>
ldrb	w8, [x20]
ldrb	w9, [x20, #0x1]
and	x8, x8, #0x1
tst	w9, #0x1
csel	x9, x21, xzr, ne
add	x8, x23, x8
add	x23, x8, x9
subs	x24, x24, #0x1
b.ne	<_main.execute>
ldr	x24, [sp, #0x150]
ldr	x9, [x24, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
ldr	x9, [x20]
sub	x2, x9, x25
ldr	x8, [sp, #0x160]
cmp	x2, x8
b.hs	<_main.execute>
lsl	x8, x19, #2
lsr	x10, x19, #30
cbz	x10, <_main.execute>
cmp	x9, x25
b.eq	<_main.execute>
ldr	x8, [sp, #0x108]
cmp	x2, x8
b.hs	<_main.execute>
mul	x0, x19, x8
umulh	x1, x19, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x19, x8
csel	x19, x19, x8, hi
str	x22, [sp, #0x160]
ldr	x9, [x24, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
mov	x21, #0x0               ; =0
adrp x27, RELOC_PAGE
add	x27, x27, #RELOC_OFFSET
mov	w20, #0x2               ; =2
mov	x23, x19
adrp x28, RELOC_PAGE
add	x28, x28, #RELOC_OFFSET
add	x24, sp, #0x39, lsl #12 ; =0x39000
add	x24, x24, #0x430
add	x0, sp, #0x9d2
mov	x1, x27
mov	w2, #0x106              ; =262
bl	<_memcpy>
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
add	x1, sp, #0x9d2
mov	x2, x28
mov	w3, #0x1e               ; =30
bl	<_InputScanner.feed>
ldrb	w8, [x24]
ldrb	w9, [x24, #0x1]
and	x8, x8, #0x1
tst	w9, #0x1
csel	x9, x20, xzr, ne
add	x8, x21, x8
add	x21, x8, x9
subs	x23, x23, #0x1
b.ne	<_main.execute>
ldr	x20, [sp, #0x150]
ldr	x9, [x20, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
add	x22, sp, #0x71, lsl #12 ; =0x71000
add	x22, x22, #0x700
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
mov	x21, #0x0               ; =0
adrp x27, RELOC_PAGE
add	x27, x27, #RELOC_OFFSET
mov	w25, #0x2               ; =2
adrp x28, RELOC_PAGE
add	x28, x28, #RELOC_OFFSET
ldr	x9, [x20, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
mov	x23, #0x0               ; =0
ldr	x24, [x22]
mov	x20, x19
add	x0, sp, #0x9d2
mov	x1, x27
mov	w2, #0x106              ; =262
bl	<_memcpy>
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x9d2
mov	x2, x28
mov	w3, #0x1e               ; =30
bl	<_InputScanner.feed>
ldrb	w8, [x22]
ldrb	w9, [x22, #0x1]
and	x8, x8, #0x1
tst	w9, #0x1
csel	x9, x25, xzr, ne
add	x8, x23, x8
add	x23, x8, x9
subs	x20, x20, #0x1
b.ne	<_main.execute>
ldr	x20, [sp, #0x150]
ldr	x9, [x20, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [x22]
sub	x8, x8, x24
udiv	x8, x8, x19
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
str	x8, [x9, x21, lsl #3]
add	x21, x21, #0x1
ldr	x8, [sp, #0x148]
cmp	x21, x8
b.ne	<_main.execute>
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
ldr	x10, [x27]
lsr	x11, x20, #1
add	x12, sp, #0x39, lsl #12 ; =0x39000
add	x12, x12, #0x430
ldr	x11, [x12, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x12, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x12, x9
ldur	x9, [x9, #-0x8]
str	x19, [sp, #0xb38]
str	x11, [sp, #0xb40]
str	x10, [sp, #0xb48]
str	x8, [sp, #0xb50]
str	x9, [sp, #0xb58]
add	x0, sp, #0xad8
add	x1, sp, #0x990
add	x2, sp, #0xb38
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0xb60]
str	q1, [sp, #0xb70]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0xb80]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0xb90]
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
add	x25, sp, #0x89, lsl #12 ; =0x89000
add	x25, x25, #0x9b0
ldp	x26, x20, [sp, #0x100]
ldr	x19, [sp, #0x120]
ldr	x22, [sp, #0x160]
cbnz	x26, <_main.execute>
b	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0xb60]
str	q1, [sp, #0xb70]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0xb80]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0xb90]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x1a               ; =26
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
add	x19, sp, #0xba0
add	x0, sp, #0xba0
mov	w1, #0x4160             ; =16736
bl	<dyld_stub_binder>
mov	x8, #0x0                ; =0
mov	w9, #0x97b5             ; =38837
mov	w10, #0x36              ; =54
adrp x11, RELOC_PAGE
add	x11, x11, #RELOC_OFFSET
add	x12, x19, x8
ubfx	w13, w8, #1, #15
mul	w13, w13, w9
lsr	w13, w13, #20
msub	w13, w13, w10, w8
and	x13, x13, #0xffff
ldrb	w13, [x11, x13]
strb	w13, [x12, #0x159]
add	x8, x8, #0x1
cmp	x8, #0x4, lsl #12       ; =0x4000
b.ne	<_main.execute>
ldr	x8, [sp, #0x130]
str	x8, [sp, #0x4d00]
str	x26, [sp, #0x4d08]
ldr	x10, [sp, #0x120]
str	x10, [sp, #0x4d10]
ldr	x9, [sp, #0x148]
str	x9, [sp, #0x4d18]
ldp	q0, q1, [sp, #0x190]
add	x8, sp, #0x4, lsl #12   ; =0x4000
add	x8, x8, #0xd00
stur	q0, [x8, #0x28]
stur	q1, [x8, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x8, #0x48]
ldr	x8, [sp, #0x1c0]
str	x20, [sp, #0x4d20]
str	x8, [sp, #0x4d58]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x4d60]
str	x26, [sp, #0x4d70]
str	x10, [sp, #0x4d78]
str	x9, [sp, #0x4d80]
str	x20, [sp, #0x4d88]
ldr	x8, [sp, #0x220]
ldp	q0, q1, [sp, #0x200]
str	q1, [sp, #0x4db0]
ldr	q1, [sp, #0x1f0]
str	q0, [sp, #0x4da0]
str	q1, [sp, #0x4d90]
add	x9, sp, #0xba0
str	x8, [sp, #0x4dc0]
str	x9, [sp, #0x4dc8]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x4, lsl #12   ; =0x4000
add	x1, x1, #0xd60
mov	w2, #0x1                ; =1
bl	<_main.timed__anon>
ldrh	w28, [x25, #0x988]
cbnz	w28, <_main.execute>
lsr	x19, x20, #2
mov	w26, #0x1               ; =1
ldr	x2, [x25, #0x980]
cmp	x2, x19
lsr	x8, x26, #30
ccmp	x8, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x26, x26, #2
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x4, lsl #12   ; =0x4000
add	x1, x1, #0xd60
mov	x2, x26
bl	<_main.timed__anon>
ldrh	w28, [x25, #0x988]
cbz	w28, <_main.execute>
b	<_main.execute>
cmp	x2, #0x0
ccmp	x2, x20, #0x2, ne
b.hs	<_main.execute>
mul	x0, x26, x20
umulh	x1, x26, x20
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x26, x8
csel	x26, x26, x8, hi
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0x4, lsl #12   ; =0x4000
add	x1, x1, #0xd60
mov	x2, x26
bl	<_main.timed__anon>
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
ldrh	w28, [x8, #0x98]
cbnz	w28, <_main.execute>
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
ldr	x20, [sp, #0x148]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x4, lsl #12   ; =0x4000
add	x1, x1, #0xd60
mov	x2, x26
bl	<_main.timed__anon>
ldrh	w28, [x21, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
cbnz	w28, <_main.execute>
ldr	x8, [x8]
udiv	x8, x8, x26
str	x8, [x19], #0x8
subs	x20, x20, #0x1
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
b.ne	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
ldr	x10, [x27]
lsr	x11, x20, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
str	x26, [sp, #0x4dd0]
str	x11, [sp, #0x4dd8]
str	x10, [sp, #0x4de0]
str	x8, [sp, #0x4de8]
str	x9, [sp, #0x4df0]
add	x0, sp, #0x4, lsl #12   ; =0x4000
add	x0, x0, #0xd00
add	x1, sp, #0xb60
add	x2, sp, #0x4, lsl #12   ; =0x4000
add	x2, x2, #0xdd0
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
ldp	x26, x20, [sp, #0x100]
ldr	x19, [sp, #0x120]
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x16               ; =22
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
ldr	x8, [x22, #0x138]
ldr	x9, [x22, #0x148]
add	x8, x9, x8
lsr	x8, x8, #1
str	x22, [sp, #0x4df8]
add	x9, sp, #0x4, lsl #12   ; =0x4000
add	x9, x9, #0xd00
strb	wzr, [x9, #0x100]
ldr	x9, [sp, #0x130]
str	x9, [sp, #0x4e08]
str	x26, [sp, #0x4e10]
str	x19, [sp, #0x4e18]
ldr	x11, [sp, #0x148]
str	x11, [sp, #0x4e20]
ldp	q0, q1, [sp, #0x190]
add	x21, sp, #0x4, lsl #12  ; =0x4000
add	x21, x21, #0xe08
stur	q0, [x21, #0x28]
stur	q1, [x21, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x21, #0x48]
ldr	x9, [sp, #0x1c0]
str	x20, [sp, #0x4e28]
str	x9, [sp, #0x4e60]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
mov	w10, #0x16              ; =22
str	x9, [sp, #0x4e68]
str	x10, [sp, #0x4e70]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
ldr	q0, [x9]
str	q0, [x21, #0x70]
ldr	x9, [x9, #0x10]
str	x9, [sp, #0x4e88]
str	x8, [sp, #0x4e90]
mov	w8, #0x4240             ; =16960
movk	w8, #0xf, lsl #16
str	x8, [sp, #0x4e98]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x4ea0]
str	x26, [sp, #0x4eb0]
str	x19, [sp, #0x4eb8]
str	x11, [sp, #0x4ec0]
str	x20, [sp, #0x4ec8]
ldp	q0, q1, [sp, #0x1f0]
ldr	q2, [sp, #0x210]
ldr	x8, [sp, #0x220]
str	q2, [sp, #0x4ef0]
str	q1, [sp, #0x4ee0]
str	q0, [sp, #0x4ed0]
add	x9, sp, #0x4, lsl #12   ; =0x4000
add	x9, x9, #0xdf8
str	x8, [sp, #0x4f00]
str	x9, [sp, #0x4f08]
add	x0, sp, #0x4, lsl #12   ; =0x4000
add	x0, x0, #0xf18
add	x1, sp, #0x4, lsl #12   ; =0x4000
add	x1, x1, #0xea0
bl	<_main.measure__anon>
ldrh	w28, [x21, #0x138]
cbnz	w28, <_main.execute>
add	x0, sp, #0x4, lsl #12   ; =0x4000
add	x0, x0, #0xe08
add	x1, sp, #0x4, lsl #12   ; =0x4000
add	x1, x1, #0xe68
add	x2, sp, #0x4, lsl #12   ; =0x4000
add	x2, x2, #0xf18
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x18               ; =24
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
ldr	x8, [x22, #0x158]
ldr	x9, [x22, #0x168]
add	x8, x9, x8
lsr	x8, x8, #1
str	x22, [sp, #0x4f48]
mov	w9, #0x1                ; =1
add	x10, sp, #0x4, lsl #12  ; =0x4000
add	x10, x10, #0xe08
strb	w9, [x10, #0x148]
ldr	x9, [sp, #0x130]
str	x9, [sp, #0x4f58]
str	x26, [sp, #0x4f60]
str	x19, [sp, #0x4f68]
ldr	x11, [sp, #0x148]
str	x11, [sp, #0x4f70]
ldp	q0, q1, [sp, #0x190]
add	x21, sp, #0x4, lsl #12  ; =0x4000
add	x21, x21, #0xf58
stur	q0, [x21, #0x28]
stur	q1, [x21, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x21, #0x48]
ldr	x9, [sp, #0x1c0]
str	x20, [sp, #0x4f78]
str	x9, [sp, #0x4fb0]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
mov	w10, #0x18              ; =24
str	x9, [sp, #0x4fb8]
str	x10, [sp, #0x4fc0]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
ldr	q0, [x9]
str	q0, [x21, #0x70]
ldr	x9, [x9, #0x10]
str	x9, [sp, #0x4fd8]
str	x8, [sp, #0x4fe0]
mov	w8, #0x4240             ; =16960
movk	w8, #0xf, lsl #16
str	x8, [sp, #0x4fe8]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x4ff0]
str	x26, [sp, #0x5000]
str	x19, [sp, #0x5008]
str	x11, [sp, #0x5010]
str	x20, [sp, #0x5018]
ldp	q0, q1, [sp, #0x1f0]
ldr	q2, [sp, #0x210]
ldr	x8, [sp, #0x220]
str	q2, [sp, #0x5040]
str	q1, [sp, #0x5030]
str	q0, [sp, #0x5020]
add	x9, sp, #0x4, lsl #12   ; =0x4000
add	x9, x9, #0xf48
str	x8, [sp, #0x5050]
str	x9, [sp, #0x5058]
add	x0, sp, #0x5, lsl #12   ; =0x5000
add	x0, x0, #0x68
add	x1, sp, #0x4, lsl #12   ; =0x4000
add	x1, x1, #0xff0
bl	<_main.measure__anon>
ldrh	w28, [x21, #0x138]
cbnz	w28, <_main.execute>
add	x0, sp, #0x4, lsl #12   ; =0x4000
add	x0, x0, #0xf58
add	x1, sp, #0x4, lsl #12   ; =0x4000
add	x1, x1, #0xfb8
add	x2, sp, #0x5, lsl #12   ; =0x5000
add	x2, x2, #0x68
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x19               ; =25
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
mov	x12, x19
add	x19, sp, #0x5, lsl #12  ; =0x5000
add	x19, x19, #0xa8
ldr	x8, [x22, #0x178]
ldr	x9, [x22, #0x188]
add	x8, x9, x8
lsr	x8, x8, #1
str	x22, [sp, #0x5098]
mov	w9, #0x2                ; =2
add	x10, sp, #0x4, lsl #12  ; =0x4000
add	x10, x10, #0xf58
strb	w9, [x10, #0x148]
ldr	x9, [sp, #0x130]
str	x9, [sp, #0x50a8]
str	x26, [sp, #0x50b0]
str	x12, [sp, #0x50b8]
ldr	x11, [sp, #0x148]
str	x11, [sp, #0x50c0]
ldp	q0, q1, [sp, #0x190]
stur	q0, [x19, #0x28]
stur	q1, [x19, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x19, #0x48]
ldr	x9, [sp, #0x1c0]
str	x20, [sp, #0x50c8]
str	x9, [sp, #0x5100]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
mov	w10, #0x19              ; =25
str	x9, [sp, #0x5108]
str	x10, [sp, #0x5110]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
ldr	q0, [x9]
str	q0, [x19, #0x70]
ldr	x9, [x9, #0x10]
str	x9, [sp, #0x5128]
str	x8, [sp, #0x5130]
mov	w8, #0x4240             ; =16960
movk	w8, #0xf, lsl #16
str	x8, [sp, #0x5138]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x5140]
str	x26, [sp, #0x5150]
str	x12, [sp, #0x5158]
str	x11, [sp, #0x5160]
str	x20, [sp, #0x5168]
ldp	q0, q1, [sp, #0x1f0]
ldr	q2, [sp, #0x210]
ldr	x8, [sp, #0x220]
str	q2, [sp, #0x5190]
str	q1, [sp, #0x5180]
str	q0, [sp, #0x5170]
add	x9, sp, #0x5, lsl #12   ; =0x5000
add	x9, x9, #0x98
str	x8, [sp, #0x51a0]
str	x9, [sp, #0x51a8]
add	x0, sp, #0x5, lsl #12   ; =0x5000
add	x0, x0, #0x1b8
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x140
bl	<_main.measure__anon>
ldrh	w28, [x19, #0x138]
cbnz	w28, <_main.execute>
add	x0, sp, #0x5, lsl #12   ; =0x5000
add	x0, x0, #0xa8
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x108
add	x2, sp, #0x5, lsl #12   ; =0x5000
add	x2, x2, #0x1b8
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x19, [sp, #0x120]
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x16               ; =22
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
mov	x13, x19
add	x19, sp, #0x5, lsl #12  ; =0x5000
add	x19, x19, #0x208
ldp	x8, x9, [x22, #0x130]
ldp	x10, x11, [x22, #0x140]
add	x12, x11, x9
lsr	x12, x12, #1
str	x8, [sp, #0x51e8]
str	x9, [sp, #0x51f0]
str	x10, [sp, #0x51f8]
str	x11, [sp, #0x5200]
ldr	x8, [sp, #0x130]
str	x8, [sp, #0x5208]
str	x26, [sp, #0x5210]
str	x13, [sp, #0x5218]
ldr	x10, [sp, #0x148]
str	x10, [sp, #0x5220]
ldp	q0, q1, [sp, #0x190]
ldr	q2, [sp, #0x1b0]
ldr	x8, [sp, #0x1c0]
str	x20, [sp, #0x5228]
str	x8, [sp, #0x5260]
stur	q2, [x19, #0x48]
stur	q1, [x19, #0x38]
stur	q0, [x19, #0x28]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
mov	w9, #0x16               ; =22
str	x8, [sp, #0x5268]
str	x9, [sp, #0x5270]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldr	x9, [x8, #0x10]
ldr	q0, [x8]
str	q0, [x19, #0x70]
str	x9, [sp, #0x5288]
str	x12, [sp, #0x5290]
mov	w8, #0x4240             ; =16960
movk	w8, #0xf, lsl #16
str	x8, [sp, #0x5298]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x52a0]
str	x26, [sp, #0x52b0]
str	x13, [sp, #0x52b8]
str	x10, [sp, #0x52c0]
str	x20, [sp, #0x52c8]
ldp	q0, q1, [sp, #0x1f0]
ldr	q2, [sp, #0x210]
ldr	x8, [sp, #0x220]
str	q2, [sp, #0x52f0]
str	q1, [sp, #0x52e0]
str	q0, [sp, #0x52d0]
add	x9, sp, #0x5, lsl #12   ; =0x5000
add	x9, x9, #0x1e8
str	x8, [sp, #0x5300]
str	x9, [sp, #0x5308]
add	x0, sp, #0x5, lsl #12   ; =0x5000
add	x0, x0, #0x318
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x2a0
bl	<_main.measure__anon>
ldrh	w28, [x19, #0x138]
cbnz	w28, <_main.execute>
add	x0, sp, #0x5, lsl #12   ; =0x5000
add	x0, x0, #0x208
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x268
add	x2, sp, #0x5, lsl #12   ; =0x5000
add	x2, x2, #0x318
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x19, [sp, #0x120]
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x18               ; =24
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
mov	x13, x19
add	x19, sp, #0x5, lsl #12  ; =0x5000
add	x19, x19, #0x368
ldp	x8, x9, [x22, #0x150]
ldp	x10, x11, [x22, #0x160]
add	x12, x11, x9
lsr	x12, x12, #1
str	x8, [sp, #0x5348]
str	x9, [sp, #0x5350]
str	x10, [sp, #0x5358]
str	x11, [sp, #0x5360]
ldr	x8, [sp, #0x130]
str	x8, [sp, #0x5368]
str	x26, [sp, #0x5370]
str	x13, [sp, #0x5378]
ldr	x10, [sp, #0x148]
str	x10, [sp, #0x5380]
ldp	q0, q1, [sp, #0x190]
ldr	q2, [sp, #0x1b0]
ldr	x8, [sp, #0x1c0]
str	x20, [sp, #0x5388]
str	x8, [sp, #0x53c0]
stur	q2, [x19, #0x48]
stur	q1, [x19, #0x38]
stur	q0, [x19, #0x28]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
mov	w9, #0x18               ; =24
str	x8, [sp, #0x53c8]
str	x9, [sp, #0x53d0]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldr	x9, [x8, #0x10]
ldr	q0, [x8]
str	q0, [x19, #0x70]
str	x9, [sp, #0x53e8]
str	x12, [sp, #0x53f0]
mov	w8, #0x4240             ; =16960
movk	w8, #0xf, lsl #16
str	x8, [sp, #0x53f8]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x5400]
str	x26, [sp, #0x5410]
str	x13, [sp, #0x5418]
str	x10, [sp, #0x5420]
str	x20, [sp, #0x5428]
ldp	q0, q1, [sp, #0x1f0]
ldr	q2, [sp, #0x210]
ldr	x8, [sp, #0x220]
str	q2, [sp, #0x5450]
str	q1, [sp, #0x5440]
str	q0, [sp, #0x5430]
add	x9, sp, #0x5, lsl #12   ; =0x5000
add	x9, x9, #0x348
str	x8, [sp, #0x5460]
str	x9, [sp, #0x5468]
add	x0, sp, #0x5, lsl #12   ; =0x5000
add	x0, x0, #0x478
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x400
bl	<_main.measure__anon>
ldrh	w28, [x19, #0x138]
cbnz	w28, <_main.execute>
add	x0, sp, #0x5, lsl #12   ; =0x5000
add	x0, x0, #0x368
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x3c8
add	x2, sp, #0x5, lsl #12   ; =0x5000
add	x2, x2, #0x478
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x19, [sp, #0x120]
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x19               ; =25
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
mov	x13, x19
add	x19, sp, #0x5, lsl #12  ; =0x5000
add	x19, x19, #0x4c8
ldp	x8, x9, [x22, #0x170]
ldp	x10, x11, [x22, #0x180]
add	x12, x11, x9
lsr	x12, x12, #1
str	x8, [sp, #0x54a8]
str	x9, [sp, #0x54b0]
str	x10, [sp, #0x54b8]
str	x11, [sp, #0x54c0]
ldr	x8, [sp, #0x130]
str	x8, [sp, #0x54c8]
str	x26, [sp, #0x54d0]
str	x13, [sp, #0x54d8]
ldr	x10, [sp, #0x148]
str	x10, [sp, #0x54e0]
ldp	q0, q1, [sp, #0x190]
ldr	q2, [sp, #0x1b0]
ldr	x8, [sp, #0x1c0]
str	x20, [sp, #0x54e8]
str	x8, [sp, #0x5520]
stur	q2, [x19, #0x48]
stur	q1, [x19, #0x38]
stur	q0, [x19, #0x28]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
mov	w9, #0x19               ; =25
str	x8, [sp, #0x5528]
str	x9, [sp, #0x5530]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldr	x9, [x8, #0x10]
ldr	q0, [x8]
str	q0, [x19, #0x70]
str	x9, [sp, #0x5548]
str	x12, [sp, #0x5550]
mov	w8, #0x4240             ; =16960
movk	w8, #0xf, lsl #16
str	x8, [sp, #0x5558]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x5560]
str	x26, [sp, #0x5570]
str	x13, [sp, #0x5578]
str	x10, [sp, #0x5580]
str	x20, [sp, #0x5588]
ldp	q0, q1, [sp, #0x1f0]
ldr	q2, [sp, #0x210]
ldr	x8, [sp, #0x220]
str	q2, [sp, #0x55b0]
str	q1, [sp, #0x55a0]
str	q0, [sp, #0x5590]
add	x9, sp, #0x5, lsl #12   ; =0x5000
add	x9, x9, #0x4a8
str	x8, [sp, #0x55c0]
str	x9, [sp, #0x55c8]
add	x0, sp, #0x5, lsl #12   ; =0x5000
add	x0, x0, #0x5d0
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x560
bl	<_main.measure__anon>
ldrh	w28, [x19, #0x130]
cbnz	w28, <_main.execute>
add	x0, sp, #0x5, lsl #12   ; =0x5000
add	x0, x0, #0x4c8
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x528
add	x2, sp, #0x5, lsl #12   ; =0x5000
add	x2, x2, #0x5d0
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x5600]
str	q1, [sp, #0x5610]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x5620]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x5630]
ldr	x19, [sp, #0x120]
cbnz	x26, <_main.execute>
b	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x5600]
str	q1, [sp, #0x5610]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x5620]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x5630]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x15               ; =21
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
add	x22, sp, #0x39, lsl #12 ; =0x39000
add	x22, x22, #0x430
ldp	x26, x19, [sp, #0x1e0]
ldr	x25, [sp, #0x110]
xpaci	x25
ldr	x8, [x19]
mov	x0, x26
mov	w1, #0x3678             ; =13944
movk	w1, #0x1, lsl #16
mov	w2, #0x3                ; =3
mov	x3, x25
blr	x8
cbz	x0, <_main.execute>
mov	x27, x0
ldr	x8, [x19]
mov	x0, x26
mov	w1, #0xa0000            ; =655360
mov	w2, #0x0                ; =0
mov	x3, x25
blr	x8
cbz	x0, <_main.execute>
mov	x28, x0
add	x20, sp, #0x6, lsl #12  ; =0x6000
add	x20, x20, #0x640
mov	x0, x27
mov	w1, #0x7580             ; =30080
bl	<dyld_stub_binder>
str	x28, [x27, #0x7580]
mov	w8, #0x7588             ; =30088
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, x27, x8
mov	w2, #0xc0f0             ; =49392
bl	<_memcpy>
str	x27, [sp, #0x5638]
ldr	x8, [sp, #0x130]
str	x8, [sp, #0x6640]
ldr	x10, [sp, #0x100]
str	x10, [sp, #0x6648]
ldr	x11, [sp, #0x120]
str	x11, [sp, #0x6650]
ldr	x9, [sp, #0x148]
str	x9, [sp, #0x6658]
ldp	q0, q1, [sp, #0x190]
stur	q0, [x20, #0x28]
stur	q1, [x20, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x20, #0x48]
ldr	x20, [sp, #0x108]
ldr	x8, [sp, #0x1c0]
str	x20, [sp, #0x6660]
str	x8, [sp, #0x6698]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x66a0]
str	x10, [sp, #0x66b0]
str	x11, [sp, #0x66b8]
str	x9, [sp, #0x66c0]
str	x20, [sp, #0x66c8]
ldr	x8, [sp, #0x220]
ldp	q0, q1, [sp, #0x200]
str	q1, [sp, #0x66f0]
ldr	q1, [sp, #0x1f0]
str	q0, [sp, #0x66e0]
str	q1, [sp, #0x66d0]
add	x9, sp, #0x5, lsl #12   ; =0x5000
add	x9, x9, #0x638
str	x8, [sp, #0x6700]
str	x9, [sp, #0x6708]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x6, lsl #12   ; =0x6000
add	x1, x1, #0x6a0
mov	w2, #0x1                ; =1
bl	<_main.timed__anon>
add	x8, sp, #0x89, lsl #12  ; =0x89000
add	x8, x8, #0x9b0
ldrh	w28, [x8, #0x988]
cbnz	w28, <_main.execute>
lsr	x20, x20, #2
mov	w27, #0x1               ; =1
add	x21, sp, #0x89, lsl #12 ; =0x89000
add	x21, x21, #0x9b0
ldr	x2, [x21, #0x980]
cmp	x2, x20
lsr	x8, x27, #30
ccmp	x8, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x27, x27, #2
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x6, lsl #12   ; =0x6000
add	x1, x1, #0x6a0
mov	x2, x27
bl	<_main.timed__anon>
ldrh	w28, [x21, #0x988]
cbz	w28, <_main.execute>
add	x0, sp, #0x5, lsl #12   ; =0x5000
add	x0, x0, #0x638
add	x1, sp, #0x1e0
bl	<_main.OutboxContext.deinit>
b	<_main.execute>
cmp	x2, #0x0
ldr	x8, [sp, #0x108]
ccmp	x2, x8, #0x2, ne
b.hs	<_main.execute>
mul	x0, x27, x8
umulh	x1, x27, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x27, x8
csel	x27, x27, x8, hi
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0x6, lsl #12   ; =0x6000
add	x1, x1, #0x6a0
mov	x2, x27
bl	<_main.timed__anon>
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
ldrh	w28, [x8, #0x98]
cbnz	w28, <_main.execute>
add	x23, sp, #0x71, lsl #12 ; =0x71000
add	x23, x23, #0x700
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
add	x20, sp, #0x39, lsl #12 ; =0x39000
add	x20, x20, #0x430
ldr	x21, [sp, #0x148]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x6, lsl #12   ; =0x6000
add	x1, x1, #0x6a0
mov	x2, x27
bl	<_main.timed__anon>
ldrh	w28, [x23, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
cbnz	w28, <_main.execute>
ldr	x8, [x8]
udiv	x8, x8, x27
str	x8, [x20], #0x8
subs	x21, x21, #0x1
add	x23, sp, #0x71, lsl #12 ; =0x71000
add	x23, x23, #0x700
b.ne	<_main.execute>
add	x20, sp, #0x39, lsl #12 ; =0x39000
add	x20, x20, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x21, [sp, #0x148]
mov	x1, x21
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x21, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x21, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
ldr	x10, [x22]
lsr	x11, x21, #1
ldr	x11, [x20, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x20, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x20, x9
ldur	x9, [x9, #-0x8]
str	x27, [sp, #0x6718]
str	x11, [sp, #0x6720]
str	x10, [sp, #0x6728]
str	x8, [sp, #0x6730]
str	x9, [sp, #0x6738]
add	x0, sp, #0x6, lsl #12   ; =0x6000
add	x0, x0, #0x640
add	x1, sp, #0x5, lsl #12   ; =0x5000
add	x1, x1, #0x600
add	x2, sp, #0x6, lsl #12   ; =0x6000
add	x2, x2, #0x718
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x20, [sp, #0x5638]
ldr	x8, [x20, #0x7580]
mov	x1, x20
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
cbz	x8, <_main.execute>
ldr	x9, [x19, #0x18]
mov	x0, x26
mov	x1, x8
mov	w2, #0xa0000            ; =655360
mov	w3, #0x0                ; =0
mov	x4, x25
blr	x9
ldr	x1, [sp, #0x5638]
str	xzr, [x20, #0x7580]
ldr	x8, [x19, #0x18]
mov	x0, x26
mov	w2, #0x3678             ; =13944
movk	w2, #0x1, lsl #16
mov	w3, #0x3                ; =3
mov	x4, x25
blr	x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x6740]
str	q1, [sp, #0x6750]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x6760]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x6770]
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
ldp	x26, x20, [sp, #0x100]
ldr	x19, [sp, #0x120]
cbnz	x26, <_main.execute>
b	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x6740]
str	q1, [sp, #0x6750]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x6760]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x6770]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x14               ; =20
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
sub	x0, x29, #0xb8
mov	w2, #0x6                ; =6
bl	<_chord.parseKey>
ldrh	w28, [x24, #0x2c8]
cbnz	w28, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x1b8
mov	w2, #0x1                ; =1
bl	<_chord.parseKey>
ldrh	w28, [x23, #0xeb0]
cbnz	w28, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	w25, #0x1               ; =1
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0xcc0
mov	w2, #0x1                ; =1
bl	<_chord.parseKey>
ldrh	w28, [x23, #0x9b8]
cbnz	w28, <_main.execute>
ldr	q0, [x23, #0x990]
add	x26, sp, #0x6, lsl #12  ; =0x6000
add	x26, x26, #0x778
add	x27, x26, #0xde9
stur	q0, [x23, #0x28]
ldr	q0, [x23, #0x9a0]
stur	q0, [x23, #0x38]
ldr	x8, [x23, #0x9b0]
str	x8, [x23, #0x48]
ldp	q0, q1, [x24, #0x2a0]
ldr	q2, [x24, #0x2a0]
add	x9, sp, #0x89, lsl #12  ; =0x89000
add	x9, x9, #0x9b0
stp	q0, q1, [x9]
ldr	x8, [x24, #0x2c0]
str	x8, [x9, #0x20]
ldr	x8, [x23, #0xea8]
str	x8, [x9, #0x48]
ldp	q1, q0, [x24]
stur	q0, [x9, #0x38]
stur	q1, [x9, #0x28]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8, #0x60]
add	x30, sp, #0x71, lsl #12 ; =0x71000
add	x30, x30, #0x700
stp	q0, q1, [x30, #0x60]
ldp	q3, q4, [x8, #0x80]
stp	q3, q4, [x30, #0x80]
ldp	q5, q6, [x8, #0x20]
stp	q5, q6, [x30, #0x20]
ldp	q7, q16, [x8, #0x40]
stp	q7, q16, [x30, #0x40]
ldp	q17, q18, [x8]
stp	q17, q18, [x30]
ldp	q19, q20, [x9, #0x20]
stp	q19, q20, [x30, #0x20]
ldr	q21, [x9, #0x40]
ldr	q22, [x30, #0x50]
str	q21, [x30, #0x40]
ldp	q23, q24, [x30, #0x70]
add	x14, sp, #0x39, lsl #12 ; =0x39000
add	x14, x14, #0x430
stp	q0, q23, [x14, #0x60]
ldr	q23, [x30, #0x90]
stp	q24, q23, [x14, #0x80]
ldp	q24, q23, [x9]
stp	q24, q23, [x30]
stp	q19, q20, [x14, #0x20]
stp	q21, q22, [x14, #0x40]
stp	q24, q23, [x14]
ldr	q19, [x24, #0x2b0]
stp	q2, q19, [x23]
ldr	x8, [x24, #0x2c0]
str	x8, [x23, #0x20]
stp	q0, q1, [x30, #0x60]
stp	q3, q4, [x30, #0x80]
stp	q5, q6, [x30, #0x20]
stp	q7, q16, [x30, #0x40]
stp	q17, q18, [x30]
ldp	q1, q2, [x23, #0x20]
stp	q1, q2, [x30, #0x20]
ldr	q3, [x23, #0x40]
str	q3, [x30, #0x40]
ldp	q5, q4, [x23]
stp	q5, q4, [x30]
ldp	q6, q7, [x30, #0x70]
add	x11, sp, #0x29, lsl #12 ; =0x29000
add	x11, x11, #0x3a0
stp	q0, q6, [x11, #0xf0]
ldr	q0, [x30, #0x90]
stp	q7, q0, [x11, #0x110]
stp	q1, q2, [x11, #0xb0]
ldr	q0, [x30, #0x50]
stp	q3, q0, [x11, #0xd0]
stp	q5, q4, [x11, #0x90]
strb	wzr, [x24, #0x260]
strb	wzr, [x24, #0x248]
strb	w25, [x24, #0x294]
strb	wzr, [x24, #0x288]
strb	wzr, [x24, #0x280]
strb	w25, [x24, #0x274]
strb	wzr, [x24, #0x244]
strb	wzr, [x24, #0x238]
strb	w25, [x24, #0x230]
strb	wzr, [x24, #0x224]
strb	wzr, [x24, #0x292]
strb	w25, [x24, #0x290]
strb	wzr, [x24, #0x28c]
strb	wzr, [x24, #0x284]
strb	w25, [x24, #0x27f]
strb	wzr, [x24, #0x27c]
strb	wzr, [x24, #0x278]
strb	w25, [x24, #0x270]
strb	wzr, [x24, #0x25c]
strb	wzr, [x24, #0x242]
strb	w25, [x24, #0x240]
strb	wzr, [x24, #0x23c]
strb	wzr, [x24, #0x234]
strb	w25, [x24, #0x22f]
strb	wzr, [x24, #0x22c]
strb	wzr, [x24, #0x228]
strb	w25, [x24, #0x220]
strb	wzr, [x11, #0x8c]
strb	wzr, [x11, #0x8a]
strb	w25, [x11, #0x89]
mov	w9, #0x2                ; =2
strh	w9, [x14, #0xa60]
strh	w9, [x14, #0xa0]
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
add	x8, x10, #0xa4
ldp	q0, q1, [x11, #0xf0]
ldp	q2, q3, [x11, #0x110]
stp	q2, q3, [x8, #0x80]
stp	q0, q1, [x8, #0x60]
ldp	q0, q1, [x11, #0x90]
stur	q1, [x14, #0xb4]
stur	q0, [x14, #0xa4]
ldp	q0, q1, [x11, #0xb0]
ldp	q2, q3, [x11, #0xd0]
stur	q3, [x14, #0xf4]
stur	q2, [x14, #0xe4]
stur	q1, [x14, #0xd4]
mov	w8, #0x102              ; =258
strh	w8, [x14, #0x144]
add	x8, x10, #0xa40
mov	w11, #0x10000           ; =65536
str	w11, [x14, #0xa40]
mov	w11, #0xa4              ; =164
add	x12, sp, #0x8b, lsl #12 ; =0x8b000
add	x12, x12, #0x3b8
add	x13, sp, #0x71, lsl #12 ; =0x71000
add	x13, x13, #0x700
add	x23, sp, #0x39, lsl #12 ; =0x39000
add	x23, x23, #0x430
stur	q0, [x14, #0xc4]
b	<_main.execute>
strh	w14, [x8, x15, lsl #1]
add	x25, x25, #0x1
ldrh	w28, [x23, #0xa60]
cmp	x25, x28
b.hs	<_main.execute>
ldrh	w14, [x8, x25, lsl #1]
umaddl	x16, w14, w11, x10
mov	x15, x25
b	<_main.execute>
cmp	w1, w2
b.hs	<_main.execute>
strh	w0, [x8, x15, lsl #1]
mov	x15, x17
cbz	x17, <_main.execute>
sub	x17, x15, #0x1
ldrh	w0, [x8, x17, lsl #1]
ldrb	w1, [x16, #0xa0]
umaddl	x3, w0, w11, x10
ldrb	w2, [x3, #0xa0]
cmp	w1, w2
csel	w4, w1, w2, lo
cbz	w4, <_main.execute>
mov	x5, #0x0                ; =0
add	x6, x5, x5, lsl #2
lsl	x6, x6, #3
add	x7, x16, x6
add	x6, x3, x6
ldrb	w19, [x7, #0x26]
ldrb	w20, [x6, #0x26]
ubfx	w21, w19, #3, #1
and	w22, w20, #0x8
cmp	w21, w22, lsr #3
b.ne	<_main.execute>
ubfx	w21, w19, #2, #1
and	w22, w20, #0x4
cmp	w21, w22, lsr #2
b.ne	<_main.execute>
ubfx	w21, w19, #1, #1
and	w22, w20, #0x2
cmp	w21, w22, lsr #1
b.ne	<_main.execute>
and	w21, w19, #0x1
and	w22, w20, #0x1
cmp	w21, w22
b.ne	<_main.execute>
ldrb	w20, [x7, #0x20]
ldrb	w19, [x6, #0x20]
and	w19, w19, #0xf
ands	w20, w20, #0xf
b.ne	<_main.execute>
cmp	w20, w19
b.ne	<_main.execute>
ldur	w19, [x7, #0x21]
str	w19, [x24, #0x200]
ldurb	w7, [x7, #0x25]
strb	w7, [x24, #0x204]
ldur	w19, [x6, #0x21]
str	w19, [x30]
ldurb	w6, [x6, #0x25]
strb	w6, [x30, #0x4]
cmp	w7, w6
csel	w19, w7, w6, lo
cbz	w19, <_main.execute>
mov	x20, #0x0               ; =0
ldrb	w21, [x12, x20]
ldrb	w22, [x13, x20]
cmp	w21, w22
cset	w21, lo
csel	w21, w9, w21, eq
cmp	w21, #0x2
b.ne	<_main.execute>
add	x20, x20, #0x1
cmp	x19, x20
b.ne	<_main.execute>
cmp	w7, w6
b.eq	<_main.execute>
b	<_main.execute>
cmp	w20, w19
b.ne	<_main.execute>
add	x5, x5, #0x1
cmp	x5, x4
b.ne	<_main.execute>
b	<_main.execute>
cbnz	w21, <_main.execute>
b	<_main.execute>
tbz	w20, #0x3, <_main.execute>
tbz	w19, #0x3, <_main.execute>
b	<_main.execute>
tbz	w20, #0x2, <_main.execute>
tbz	w19, #0x2, <_main.execute>
b	<_main.execute>
tbz	w20, #0x1, <_main.execute>
tbz	w19, #0x1, <_main.execute>
b	<_main.execute>
tbnz	w19, #0x0, <_main.execute>
tbnz	w20, #0x0, <_main.execute>
b	<_main.execute>
cmp	w28, #0x2
b.lo	<_main.execute>
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
add	x10, x9, #0xa3e
mov	w11, #0x1               ; =1
mov	w12, #0xa4              ; =164
ldrh	w13, [x10, x11, lsl #1]
ldrh	w14, [x8, x11, lsl #1]
umaddl	x15, w13, w12, x9
umaddl	x16, w14, w12, x9
ldrb	w13, [x15, #0xa0]
ldrb	w14, [x16, #0xa0]
cmp	x13, x14
mov	x17, #0x0               ; =0
csel	x0, x13, x14, lo
cbnz	x0, <_main.execute>
cmp	x17, x13
ccmp	x17, x14, #0x4, ne
b.eq	<_main.execute>
add	x11, x11, #0x1
cmp	x11, x28
b.ne	<_main.execute>
b	<_main.execute>
cmp	w3, w4
b.ne	<_main.execute>
add	x17, x17, #0x1
cmp	x17, x0
b.eq	<_main.execute>
add	x1, x17, x17, lsl #2
lsl	x2, x1, #3
add	x1, x15, x2
add	x2, x16, x2
ldrb	w3, [x1, #0x26]
ldrb	w4, [x2, #0x26]
eor	w3, w4, w3
tst	w3, #0xf
b.ne	<_main.execute>
ldrb	w3, [x1, #0x20]
and	w3, w3, #0xf
ldrb	w4, [x2, #0x20]
and	w4, w4, #0xf
cmp	w3, #0x0
ccmp	w3, w4, #0x0, eq
b.ne	<_main.execute>
ldur	w3, [x1, #0x21]
str	w3, [x24, #0x200]
ldurb	w1, [x1, #0x25]
strb	w1, [x24, #0x204]
ldur	w3, [x2, #0x21]
str	w3, [x30]
ldurb	w2, [x2, #0x25]
strb	w2, [x30, #0x4]
cmp	w1, w2
csel	w3, w1, w2, lo
cbz	w3, <_main.execute>
add	x4, sp, #0x71, lsl #12  ; =0x71000
add	x4, x4, #0x700
add	x5, sp, #0x8b, lsl #12  ; =0x8b000
add	x5, x5, #0x3b8
ldrb	w6, [x5], #0x1
ldrb	w7, [x4], #0x1
cmp	w6, w7
b.ne	<_main.execute>
subs	x3, x3, #0x1
b.ne	<_main.execute>
cmp	w1, w2
b.eq	<_main.execute>
b	<_main.execute>
mov	x17, x0
b	<_main.execute>
add	x19, sp, #0x6, lsl #12  ; =0x6000
add	x19, x19, #0x778
add	x0, x19, #0x288
add	x1, sp, #0x39, lsl #12  ; =0x39000
add	x1, x1, #0x430
mov	w2, #0xa60              ; =2656
bl	<_memcpy>
ldrh	w20, [x23, #0xa62]
sub	x21, x29, #0xb8
strb	wzr, [x21, #0x48]
str	xzr, [sp, #0x6790]
str	xzr, [sp, #0x6788]
add	x0, x19, #0x28
mov	w1, #0x260              ; =608
bl	<dyld_stub_binder>
mov	w8, #0x63               ; =99
str	w8, [x27]
mov	w8, #0x61               ; =97
str	w8, [x27, #0x28]
mov	w8, #0x72               ; =114
str	w8, [x27, #0x50]
mov	w8, #0x67               ; =103
str	w8, [x27, #0x78]
mov	w8, #0x6f               ; =111
str	w8, [x27, #0xa0]
mov	w8, #0x20               ; =32
str	w8, [x27, #0xc8]
mov	w8, #0x65               ; =101
str	w8, [x27, #0x118]
mov	w8, #0x73               ; =115
str	w8, [x27, #0x140]
mov	w8, #0x74               ; =116
str	w8, [x27, #0xf0]
str	w8, [x27, #0x168]
add	x8, x19, #0xdc8
movi.2d	v0, #0000000000000000
stp	q0, q0, [x8]
add	x8, x19, #0xe18
stp	q0, q0, [x8]
add	x8, x19, #0xe68
stp	q0, q0, [x8]
add	x8, x19, #0xeb8
stp	q0, q0, [x8]
add	x8, x19, #0xf08
stp	q0, q0, [x8]
ldr	x8, [x24, #0x2c0]
str	x8, [sp, #0x7770]
ldr	x8, [x24, #0x20]
str	x8, [sp, #0x7740]
mov	w8, #0xca00             ; =51712
movk	w8, #0x3b9a, lsl #16
str	x8, [sp, #0x6798]
strh	w20, [x26, #0xcea]
ldr	x20, [sp, #0x108]
add	x8, x19, #0xcec
stur	q0, [x8, #0x1c]
stp	q0, q0, [x8]
ldrb	w8, [x21, #0x48]
strb	w8, [x26, #0xdb9]
ldrb	w8, [x24, #0x260]
strb	w8, [x26, #0xde8]
ldrb	w8, [x24, #0x248]
strb	w8, [x26, #0xdee]
ldrb	w8, [x24, #0x294]
strb	w8, [x26, #0xdef]
ldrb	w8, [x24, #0x288]
strb	w8, [x26, #0xe10]
ldrb	w8, [x24, #0x280]
strb	w8, [x26, #0xe16]
ldrb	w8, [x24, #0x274]
strb	w8, [x26, #0xe17]
ldrb	w8, [x24, #0x244]
strb	w8, [x26, #0xe38]
ldrb	w8, [x24, #0x238]
strb	w8, [x26, #0xe3e]
ldrb	w8, [x24, #0x230]
strb	w8, [x26, #0xe3f]
ldrb	w8, [x24, #0x224]
strb	w8, [x26, #0xe60]
ldrb	w8, [x24, #0x292]
strb	w8, [x26, #0xe66]
ldrb	w8, [x24, #0x290]
strb	w8, [x26, #0xe67]
ldrb	w8, [x24, #0x28c]
strb	w8, [x26, #0xe88]
ldrb	w8, [x24, #0x284]
strb	w8, [x26, #0xe8e]
ldrb	w8, [x24, #0x27f]
strb	w8, [x26, #0xe8f]
ldrb	w8, [x24, #0x27c]
strb	w8, [x26, #0xeb0]
ldrb	w8, [x24, #0x278]
strb	w8, [x26, #0xeb6]
ldrb	w8, [x24, #0x270]
strb	w8, [x26, #0xeb7]
ldrb	w8, [x24, #0x25c]
strb	w8, [x26, #0xed8]
ldrb	w8, [x24, #0x242]
strb	w8, [x26, #0xede]
ldrb	w8, [x24, #0x240]
strb	w8, [x26, #0xedf]
ldrb	w8, [x24, #0x23c]
strb	w8, [x26, #0xf00]
ldrb	w8, [x24, #0x234]
strb	w8, [x26, #0xf06]
ldrb	w8, [x24, #0x22f]
strb	w8, [x26, #0xf07]
ldrb	w8, [x24, #0x22c]
strb	w8, [x26, #0xf28]
ldrb	w8, [x24, #0x228]
strb	w8, [x26, #0xf2e]
ldrb	w8, [x24, #0x220]
strb	w8, [x26, #0xf2f]
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
ldrb	w8, [x9, #0x8c]
strb	w8, [x26, #0xf50]
mov	w8, #0x1                ; =1
strb	w8, [x26, #0xded]
strb	w8, [x26, #0xe15]
strb	w8, [x26, #0xe3d]
strb	w8, [x26, #0xe65]
strb	w8, [x26, #0xe8d]
strb	w8, [x26, #0xeb5]
strb	w8, [x26, #0xedd]
strb	w8, [x26, #0xf05]
strb	w8, [x26, #0xf2d]
strb	w8, [x26, #0xf55]
ldrb	w8, [x9, #0x8a]
strb	w8, [x26, #0xf56]
ldrb	w8, [x9, #0x89]
ldp	q1, q2, [x24, #0x2a0]
str	q1, [sp, #0x7750]
str	q2, [sp, #0x7760]
strb	w8, [x26, #0xf57]
add	x8, x19, #0xf58
ldr	q1, [sp, #0x7750]
ldr	q2, [sp, #0x7760]
stp	q1, q2, [x8]
ldr	x8, [sp, #0x7770]
str	x8, [sp, #0x76f0]
ldr	x8, [sp, #0x7740]
str	x8, [sp, #0x7718]
str	q0, [x26, #0xdf0]
str	q0, [x26, #0xe00]
str	q0, [x26, #0xe40]
str	q0, [x26, #0xe50]
str	q0, [x26, #0xe90]
str	q0, [x26, #0xea0]
str	q0, [x26, #0xef0]
str	q0, [x26, #0xee0]
str	q0, [x26, #0xf40]
str	q0, [x26, #0xf30]
ldp	q0, q1, [x24]
str	q0, [sp, #0x7720]
str	q1, [sp, #0x7730]
strh	w28, [x26, #0xce8]
strb	wzr, [x26, #0xdb8]
strb	wzr, [x26, #0xdba]
ldr	q0, [sp, #0x7720]
ldr	q1, [sp, #0x7730]
str	q1, [x26, #0xf90]
str	q0, [x26, #0xf80]
ldr	x8, [sp, #0x1c0]
str	x8, [sp, #0x77d8]
ldp	q0, q1, [sp, #0x190]
ldr	q2, [sp, #0x1b0]
add	x8, sp, #0x7, lsl #12   ; =0x7000
add	x8, x8, #0x780
stur	q2, [x8, #0x48]
stur	q1, [x8, #0x38]
stur	q0, [x8, #0x28]
ldr	x8, [sp, #0x220]
str	x8, [sp, #0x7840]
str	x19, [sp, #0x7848]
ldr	x9, [sp, #0x120]
str	x28, [sp, #0x6780]
str	xzr, [sp, #0x6778]
str	x20, [sp, #0x77a0]
str	xzr, [sp, #0x7538]
ldr	x8, [sp, #0x130]
str	x8, [sp, #0x7780]
ldr	x26, [sp, #0x100]
str	x26, [sp, #0x7788]
str	x9, [sp, #0x7790]
ldr	x8, [sp, #0x148]
str	x8, [sp, #0x7798]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x77e0]
str	x26, [sp, #0x77f0]
str	x9, [sp, #0x77f8]
str	x8, [sp, #0x7800]
str	x20, [sp, #0x7808]
ldp	q0, q1, [sp, #0x1f0]
ldr	q2, [sp, #0x210]
str	q2, [sp, #0x7830]
str	q1, [sp, #0x7820]
str	q0, [sp, #0x7810]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0x7e0
mov	w2, #0x1                ; =1
bl	<_main.timed__anon>
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
ldrh	w28, [x23, #0x8]
cbnz	w28, <_main.execute>
lsr	x19, x20, #2
mov	w25, #0x1               ; =1
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
ldr	x2, [x23]
cmp	x2, x19
lsr	x8, x25, #30
ccmp	x8, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x25, x25, #2
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0x7e0
mov	x2, x25
bl	<_main.timed__anon>
ldrh	w28, [x23, #0x8]
cbz	w28, <_main.execute>
b	<_main.execute>
cmp	x2, #0x0
ccmp	x2, x20, #0x2, ne
b.hs	<_main.execute>
mul	x0, x25, x20
umulh	x1, x25, x20
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x25, x8
csel	x25, x25, x8, hi
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0x7e0
mov	x2, x25
bl	<_main.timed__anon>
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
ldrh	w28, [x8, #0x98]
cbnz	w28, <_main.execute>
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
ldr	x20, [sp, #0x148]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0x7e0
mov	x2, x25
bl	<_main.timed__anon>
ldrh	w28, [x21, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
cbnz	w28, <_main.execute>
ldr	x8, [x8]
udiv	x8, x8, x25
str	x8, [x19], #0x8
subs	x20, x20, #0x1
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
b.ne	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
ldr	x10, [x27]
lsr	x11, x20, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
str	x25, [sp, #0x7858]
str	x11, [sp, #0x7860]
str	x10, [sp, #0x7868]
str	x8, [sp, #0x7870]
str	x9, [sp, #0x7878]
add	x0, sp, #0x7, lsl #12   ; =0x7000
add	x0, x0, #0x780
add	x1, sp, #0x6, lsl #12   ; =0x6000
add	x1, x1, #0x740
add	x2, sp, #0x7, lsl #12   ; =0x7000
add	x2, x2, #0x858
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x7880]
str	q1, [sp, #0x7890]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x78a0]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x78b0]
ldr	x20, [sp, #0x108]
ldr	x19, [sp, #0x120]
cbnz	x26, <_main.execute>
b	<_main.execute>
ldr	x8, [x19, #0x18]
mov	x0, x26
mov	x1, x27
mov	w2, #0x3678             ; =13944
movk	w2, #0x1, lsl #16
mov	w3, #0x3                ; =3
mov	x4, x25
blr	x8
mov	w28, #0x1a              ; =26
b	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x7880]
str	q1, [sp, #0x7890]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x78a0]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x78b0]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x15               ; =21
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
mov	w1, #0x408              ; =1032
bl	<dyld_stub_binder>
ldp	q0, q1, [sp, #0x1d0]
ldr	x23, [sp, #0x1e8]
stp	q1, q0, [sp, #0x150]
ldr	x19, [sp, #0x1d8]
ldr	x25, [sp, #0x110]
xpaci	x25
ldr	x8, [x23]
fmov	x22, d1
mov	x0, x22
mov	w1, #0xa3d0             ; =41936
movk	w1, #0x14, lsl #16
mov	w2, #0x4                ; =4
mov	x3, x25
blr	x8
cbz	x0, <_main.execute>
mov	x26, x0
ldr	x8, [x23]
mov	x0, x22
mov	w1, #0x5da0             ; =23968
movk	w1, #0x1, lsl #16
mov	w2, #0x3                ; =3
mov	x3, x25
blr	x8
cbz	x0, <_main.execute>
mov	x20, x0
add	x8, x26, #0x10, lsl #12 ; =0x10000
add	x21, x8, #0x88e
add	x8, x0, #0x15, lsl #12  ; =0x15000
add	x8, x8, #0x59c
mov	w9, #0xd59a             ; =54682
mov	w10, #0xa200            ; =41472
strh	wzr, [x0, x10]
strb	wzr, [x8]
strh	wzr, [x0, x9]
strb	wzr, [x8, #0x801]
stur	x22, [x21, #0x2]
stur	x23, [x21, #0xa]
mov	w8, #0x1                ; =1
stur	x8, [x21, #0x12]
ldr	x8, [x23]
mov	x0, x22
mov	w1, #0x50               ; =80
mov	w2, #0x3                ; =3
mov	x3, x25
blr	x8
cbz	x0, <_main.execute>
mov	x28, x0
ldp	q0, q1, [sp, #0x150]
stp	q1, q0, [x0]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
stur	q0, [x0, #0x28]
mov	w8, #0x4240             ; =16960
movk	w8, #0xf, lsl #16
str	x8, [x0, #0x40]
ldr	x9, [x19, #0x2c0]
fmov	x0, d1
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
stp	x0, x19, [sp, #0xa0]
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [x27]
ldrsw	x9, [x27, #0x8]
cmp	x9, #0x0
csel	x8, xzr, x8, lt
mov	w9, #0x9400             ; =37888
movk	w9, #0x7735, lsl #16
adds	x8, x8, x9
csinv	x8, x8, xzr, lo
str	x8, [x28, #0x48]
str	xzr, [x28, #0x38]
adrp x0, RELOC_PAGE
add	x0, x0, #RELOC_OFFSET
mov	x1, x28
mov	w2, #0x0                ; =0
bl	<_lua_newstate>
cbz	x0, <_main.execute>
add	x8, x26, #0x14a, lsl #12 ; =0x14a000
add	x19, x8, #0x370
str	x20, [sp, #0x160]
mov	w20, #0xfda8            ; =64936
movk	w20, #0x12, lsl #16
str	x0, [x28, #0x20]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	w2, #0x8                ; =8
mov	w3, #0x3e8              ; =1000
bl	<_lua_sethook>
stur	x28, [x21, #0x1a]
ldr	x8, [sp, #0x160]
str	x8, [x26, x20]
mov	w8, #0x8b0              ; =2224
movk	w8, #0x1, lsl #16
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, x26, x8
mov	w2, #0xf4f8             ; =62712
movk	w2, #0x11, lsl #16
bl	<_memcpy>
strb	wzr, [x19, #0x53]
mov	w8, #0xfdb0             ; =64944
movk	w8, #0x12, lsl #16
add	x0, x26, x8
mov	w1, #0x488              ; =1160
bl	<dyld_stub_binder>
stp	xzr, xzr, [x19]
mov	x20, x19
stur	wzr, [x19, #0xf]
str	x28, [x26, #0x400]
mov	w8, #-0x2               ; =-2
str	w8, [x26, #0x408]
mov	w8, #0x1                ; =1
strh	w8, [x26, #0x40c]
mov	w8, #0x2e               ; =46
strb	w8, [x26, #0x48e]
strb	wzr, [x21]
ldr	x28, [x28, #0x20]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
adrp x2, RELOC_PAGE
ldr	x2, [x2, #RELOC_OFFSET]
mov	x0, x28
mov	w3, #0x1                ; =1
bl	<_luaL_requiref>
mov	x0, x28
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
adrp x2, RELOC_PAGE
ldr	x2, [x2, #RELOC_OFFSET]
mov	x0, x28
mov	w3, #0x1                ; =1
bl	<_luaL_requiref>
mov	x0, x28
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
adrp x2, RELOC_PAGE
ldr	x2, [x2, #RELOC_OFFSET]
mov	x0, x28
mov	w3, #0x1                ; =1
bl	<_luaL_requiref>
mov	x0, x28
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
adrp x2, RELOC_PAGE
ldr	x2, [x2, #RELOC_OFFSET]
mov	x0, x28
mov	w3, #0x1                ; =1
bl	<_luaL_requiref>
mov	x0, x28
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
adrp x2, RELOC_PAGE
ldr	x2, [x2, #RELOC_OFFSET]
mov	x0, x28
mov	w3, #0x1                ; =1
bl	<_luaL_requiref>
mov	x0, x28
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
adrp x2, RELOC_PAGE
ldr	x2, [x2, #RELOC_OFFSET]
mov	x0, x28
mov	w3, #0x1                ; =1
bl	<_luaL_requiref>
mov	x0, x28
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
mov	x0, x28
bl	<_lua_pushnil>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	x0, x28
bl	<_lua_setglobal>
mov	x0, x28
bl	<_lua_pushnil>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	x0, x28
bl	<_lua_setglobal>
mov	x0, x28
bl	<_lua_pushnil>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	x0, x28
bl	<_lua_setglobal>
mov	x0, x28
bl	<_lua_pushnil>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	x0, x28
bl	<_lua_setglobal>
mov	x0, x28
bl	<_lua_pushnil>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	x0, x28
bl	<_lua_setglobal>
mov	x0, x28
bl	<_lua_pushnil>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	x0, x28
bl	<_lua_setglobal>
mov	x0, x28
bl	<_lua_pushnil>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	x0, x28
bl	<_lua_setglobal>
mov	x0, x28
bl	<_lua_pushnil>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	x0, x28
bl	<_lua_setglobal>
ldur	x19, [x21, #0x1a]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
stur	q0, [x19, #0x38]
ldp	x0, x8, [x19]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [x27]
ldrsw	x9, [x27, #0x8]
cmp	x9, #0x0
csel	x8, xzr, x8, lt
mov	w9, #0x9400             ; =37888
movk	w9, #0x7735, lsl #16
adds	x8, x8, x9
csinv	x8, x8, xzr, lo
str	x8, [x19, #0x48]
ldur	x19, [x21, #0x1a]
ldr	x0, [x19, #0x20]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
adrp x3, RELOC_PAGE
add	x3, x3, #RELOC_OFFSET
adrp x4, RELOC_PAGE
add	x4, x4, #RELOC_OFFSET
mov	w2, #0x1a59             ; =6745
bl	<_luaL_loadbufferx>
cbz	w0, <_main.execute>
stp	x22, x23, [sp, #0xb8]
str	x26, [sp, #0x150]
str	x25, [sp, #0xb0]
mov	w28, #0x6c              ; =108
b	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x7d60]
str	q1, [sp, #0x7d70]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x7d80]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x7d90]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x19               ; =25
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8, #0x20]
str	q0, [sp, #0x7dc0]
str	q1, [sp, #0x7dd0]
ldp	q0, q1, [x8, #0x40]
str	q0, [sp, #0x7de0]
str	q1, [sp, #0x7df0]
ldp	q0, q1, [x8]
str	q0, [sp, #0x7da0]
str	q1, [sp, #0x7db0]
ldr	x8, [sp, #0x130]
str	x8, [sp, #0x7e00]
str	x26, [sp, #0x7e08]
str	x19, [sp, #0x7e10]
ldr	x9, [sp, #0x148]
str	x9, [sp, #0x7e18]
ldr	x8, [sp, #0x1c0]
str	x20, [sp, #0x7e20]
str	x8, [sp, #0x7e58]
ldp	q0, q1, [sp, #0x1a0]
add	x8, sp, #0x7, lsl #12   ; =0x7000
add	x8, x8, #0xe00
stur	q1, [x8, #0x48]
ldr	q1, [sp, #0x190]
stur	q0, [x8, #0x38]
stur	q1, [x8, #0x28]
ldr	q0, [sp, #0x1d0]
str	q0, [sp, #0x7e60]
str	x26, [sp, #0x7e70]
str	x19, [sp, #0x7e78]
str	x9, [sp, #0x7e80]
str	x20, [sp, #0x7e88]
ldp	q0, q1, [sp, #0x1f0]
ldr	q2, [sp, #0x210]
ldr	x8, [sp, #0x220]
str	q2, [sp, #0x7eb0]
str	q1, [sp, #0x7ea0]
str	q0, [sp, #0x7e90]
add	x9, sp, #0x7, lsl #12   ; =0x7000
add	x9, x9, #0xda0
str	x8, [sp, #0x7ec0]
str	x9, [sp, #0x7ec8]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0xe60
mov	w2, #0x1                ; =1
bl	<_main.timed__anon>
ldrh	w28, [x23, #0x8]
cbnz	w28, <_main.execute>
lsr	x19, x20, #2
mov	w25, #0x1               ; =1
ldr	x2, [x23]
cmp	x2, x19
lsr	x8, x25, #30
ccmp	x8, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x25, x25, #2
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0xe60
mov	x2, x25
bl	<_main.timed__anon>
ldrh	w28, [x23, #0x8]
cbz	w28, <_main.execute>
b	<_main.execute>
cmp	w13, w14
mov	w8, #0x60               ; =96
cinc	w28, w8, ne
b	<_main.execute>
cmp	x2, #0x0
ccmp	x2, x20, #0x2, ne
b.hs	<_main.execute>
mul	x0, x25, x20
umulh	x1, x25, x20
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x25, x8
csel	x25, x25, x8, hi
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0xe60
mov	x2, x25
bl	<_main.timed__anon>
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
ldrh	w28, [x8, #0x98]
cbnz	w28, <_main.execute>
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
ldr	x20, [sp, #0x148]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0xe60
mov	x2, x25
bl	<_main.timed__anon>
ldrh	w28, [x21, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
cbnz	w28, <_main.execute>
ldr	x8, [x8]
udiv	x8, x8, x25
str	x8, [x19], #0x8
subs	x20, x20, #0x1
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
b.ne	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
ldr	x10, [x27]
lsr	x11, x20, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
str	x25, [sp, #0x7ed8]
str	x11, [sp, #0x7ee0]
str	x10, [sp, #0x7ee8]
str	x8, [sp, #0x7ef0]
str	x9, [sp, #0x7ef8]
add	x0, sp, #0x7, lsl #12   ; =0x7000
add	x0, x0, #0xe00
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0xd60
add	x2, sp, #0x7, lsl #12   ; =0x7000
add	x2, x2, #0xed8
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x7f00]
str	q1, [sp, #0x7f10]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x7f20]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x7f30]
ldr	x20, [sp, #0x108]
ldr	x19, [sp, #0x120]
cbnz	x26, <_main.execute>
b	<_main.execute>
add	x23, x23, #0x18
b	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x7f00]
str	q1, [sp, #0x7f10]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x7f20]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x7f30]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x21               ; =33
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0xc08              ; =3080
bl	<_memcpy>
mov	w8, #0x1                ; =1
strb	w8, [x27, #0x8]
str	x8, [x27]
strh	wzr, [x27, #0x10]
mov	w9, #0x100              ; =256
movk	w9, #0x1, lsl #16
str	w9, [x27, #0xbf8]
str	x8, [x27, #0xbe8]
mov	w8, #0x2                ; =2
str	x8, [x27, #0xbf0]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
bl	<_workspace.WorkspaceLayout.split>
ands	w28, w0, #0xffff
b.ne	<_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
bl	<_workspace.WorkspaceLayout.split>
ands	w28, w0, #0xffff
add	x21, sp, #0x7, lsl #12  ; =0x7000
add	x21, x21, #0xe00
b.ne	<_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
bl	<_workspace.WorkspaceLayout.split>
ands	w28, w0, #0xffff
b.ne	<_main.execute>
add	x0, sp, #0x7, lsl #12   ; =0x7000
add	x0, x0, #0xf38
add	x1, sp, #0x39, lsl #12  ; =0x39000
add	x1, x1, #0x430
mov	w2, #0xc08              ; =3080
bl	<_memcpy>
ldp	q0, q1, [sp, #0x190]
add	x9, sp, #0x8, lsl #12   ; =0x8000
add	x9, x9, #0xb40
stur	q0, [x9, #0x28]
ldr	x8, [sp, #0x130]
str	x8, [x21, #0xd40]
str	x26, [x21, #0xd48]
str	x19, [x21, #0xd50]
ldr	x8, [sp, #0x148]
str	x8, [x21, #0xd58]
str	x20, [x21, #0xd60]
stur	q1, [x9, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x9, #0x48]
ldr	x8, [sp, #0x1c0]
str	x8, [x9, #0x58]
lsr	x8, x20, #2
str	x8, [sp, #0x150]
mov	w9, #0x1                ; =1
adrp x20, RELOC_PAGE
add	x20, x20, #RELOC_OFFSET
ldp	x25, x22, [sp, #0x1d0]
add	x28, sp, #0x29, lsl #12 ; =0x29000
add	x28, x28, #0x3a0
str	x22, [sp, #0x160]
mov	x19, x9
ldr	x9, [x22, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x25
mov	w1, #0x1                ; =1
blr	x9
mov	x24, #0x0               ; =0
mov	x23, #0x0               ; =0
ldr	x26, [x27]
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
add	x22, sp, #0x7, lsl #12  ; =0x7000
add	x22, x22, #0xe00
and	x8, x24, #0x3
ldr	x9, [x22, #0xd38]
str	x9, [x21]
ldrb	w2, [x20, x8]
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0xf38
add	x3, sp, #0x71, lsl #12  ; =0x71000
add	x3, x3, #0x700
bl	<_workspace.WorkspaceLayout.focusDirection>
ldrb	w8, [x27, #0x8]
ldr	x9, [x27]
cmp	w8, #0x0
csel	x8, xzr, x9, eq
add	x23, x8, x23
add	x24, x24, #0x1
cmp	x19, x24
b.ne	<_main.execute>
ldr	x22, [sp, #0x160]
ldr	x9, [x22, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x25
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [x27]
sub	x2, x8, x26
ldr	x9, [sp, #0x150]
cmp	x2, x9
b.hs	<_main.execute>
lsl	x9, x19, #2
lsr	x10, x19, #30
cbz	x10, <_main.execute>
cmp	x8, x26
b.eq	<_main.execute>
ldr	x8, [sp, #0x108]
cmp	x2, x8
b.hs	<_main.execute>
mul	x0, x19, x8
umulh	x1, x19, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x19, x8
csel	x19, x19, x8, hi
add	x24, sp, #0x7, lsl #12  ; =0x7000
add	x24, x24, #0xe00
ldr	x9, [x22, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x25
mov	w1, #0x1                ; =1
blr	x9
mov	x23, #0x0               ; =0
mov	x21, #0x0               ; =0
add	x26, sp, #0x71, lsl #12 ; =0x71000
add	x26, x26, #0x700
and	x8, x23, #0x3
ldr	x9, [x24, #0xd38]
str	x9, [x26]
ldrb	w2, [x20, x8]
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0xf38
add	x3, sp, #0x71, lsl #12  ; =0x71000
add	x3, x3, #0x700
bl	<_workspace.WorkspaceLayout.focusDirection>
ldrb	w8, [x27, #0x8]
ldr	x9, [x27]
cmp	w8, #0x0
csel	x8, xzr, x9, eq
add	x21, x8, x21
add	x23, x23, #0x1
cmp	x19, x23
b.ne	<_main.execute>
ldr	x9, [x22, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x25
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
mov	x21, #0x0               ; =0
ldr	x9, [x22, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x25
mov	w1, #0x1                ; =1
blr	x9
mov	x27, #0x0               ; =0
mov	x23, #0x0               ; =0
ldr	x24, [x26]
add	x22, sp, #0x7, lsl #12  ; =0x7000
add	x22, x22, #0xe00
and	x8, x27, #0x3
ldr	x9, [x22, #0xd38]
str	x9, [x28, #0x90]
ldrb	w2, [x20, x8]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0xf38
add	x3, sp, #0x29, lsl #12  ; =0x29000
add	x3, x3, #0x430
bl	<_workspace.WorkspaceLayout.focusDirection>
ldrb	w8, [x26, #0x8]
ldr	x9, [x26]
cmp	w8, #0x0
csel	x8, xzr, x9, eq
add	x23, x8, x23
add	x27, x27, #0x1
cmp	x19, x27
b.ne	<_main.execute>
ldr	x22, [sp, #0x160]
ldr	x9, [x22, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x25
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [x26]
sub	x8, x8, x24
udiv	x8, x8, x19
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
str	x8, [x9, x21, lsl #3]
add	x21, x21, #0x1
ldr	x8, [sp, #0x148]
cmp	x21, x8
b.ne	<_main.execute>
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
ldr	x10, [x27]
lsr	x11, x20, #1
add	x12, sp, #0x39, lsl #12 ; =0x39000
add	x12, x12, #0x430
ldr	x11, [x12, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x12, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x12, x9
ldur	x9, [x9, #-0x8]
add	x12, sp, #0x8, lsl #12  ; =0x8000
add	x12, x12, #0xb40
stp	x19, x11, [x12, #0x60]
stp	x10, x8, [x12, #0x70]
str	x9, [x12, #0x80]
add	x0, sp, #0x8, lsl #12   ; =0x8000
add	x0, x0, #0xb40
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0xf00
add	x2, sp, #0x8, lsl #12   ; =0x8000
add	x2, x2, #0xba0
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
ldr	x26, [sp, #0x100]
ldr	x19, [sp, #0x120]
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x28               ; =40
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
tbnz	wzr, #0x0, <_main.execute>
ldp	x20, x21, [sp, #0x1e0]
ldr	x22, [sp, #0x110]
xpaci	x22
mov	w19, #0x9400            ; =37888
movk	w19, #0x7e, lsl #16
ldr	x8, [x21]
sub	x27, x19, #0x400
mov	x0, x20
mov	x1, x27
mov	w2, #0x0                ; =0
mov	x3, x22
blr	x8
cbz	x0, <_main.execute>
mov	x26, x0
mov	x8, #0x0                ; =0
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
add	x9, x10, #0x38, lsl #12 ; =0x38000
add	x25, x9, #0x2be
add	x9, x10, #0x18, lsl #12 ; =0x18000
add	x28, x9, #0x2b0
mov	x9, #0x4147             ; =16711
movk	x9, #0x7340, lsl #16
movk	x9, #0x7f7d, lsl #32
movk	x9, #0x519, lsl #48
mov	w10, #-0xfb             ; =-251
umulh	x11, x8, x9
sub	w12, w8, w11
add	w11, w11, w12, lsr #1
lsr	w11, w11, #7
madd	w11, w11, w10, w8
strb	w11, [x26, x8]
add	x8, x8, #0x1
cmp	x8, x27
b.ne	<_main.execute>
tbnz	wzr, #0x0, <_main.execute>
ldr	x8, [x21]
mov	x0, x20
mov	w1, #0x9400             ; =37888
movk	w1, #0x7e, lsl #16
mov	w2, #0x0                ; =0
mov	x3, x22
blr	x8
cbz	x0, <_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
stp	x8, x0, [x24]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [x24, #0x10]
mov	w8, #0x2                ; =2
strb	w8, [x24, #0x288]
str	x22, [sp, #0xd0]
stp	x0, x20, [sp, #0xb8]
str	x21, [sp, #0x160]
str	x25, [sp, #0xb0]
cbz	w8, <_main.execute>
cmp	w8, #0x1
b.ne	<_main.execute>
adrp x22, RELOC_PAGE
add	x22, x22, #RELOC_OFFSET
mov	w21, #0xa               ; =10
b	<_main.execute>
ldr	x8, [x23, #0x18]
mov	x0, x22
mov	x1, x28
mov	w2, #0x50               ; =80
mov	w3, #0x3                ; =3
mov	x4, x25
blr	x8
ldr	x8, [x23, #0x18]!
mov	x0, x22
mov	x1, x20
mov	w2, #0x5da0             ; =23968
movk	w2, #0x1, lsl #16
mov	w3, #0x3                ; =3
mov	x4, x25
blr	x8
mov	w28, #0x1a              ; =26
b	<_main.execute>
add	x21, x21, #0x18
b	<_main.execute>
str	x20, [sp, #0x98]
ldr	x0, [x19, #0x20]
mov	w1, #0x0                ; =0
mov	w2, #0x0                ; =0
mov	w3, #0x0                ; =0
mov	x4, #0x0                ; =0
mov	x5, #0x0                ; =0
bl	<_lua_pcallk>
cbz	w0, <_main.execute>
stp	x22, x23, [sp, #0xb8]
str	x26, [sp, #0x150]
str	x25, [sp, #0xb0]
mov	w28, #0x6d              ; =109
str	x21, [sp, #0xd0]
ldur	x8, [x21, #0x1a]
ldr	x0, [x8, #0x20]
str	xzr, [x27]
add	x2, sp, #0x39, lsl #12  ; =0x39000
add	x2, x2, #0x430
mov	w1, #-0x1               ; =-1
bl	<_lua_tolstring>
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
mov	x27, #0x0               ; =0
ldr	x8, [x10]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
cmp	x0, #0x0
csel	x19, x9, x0, eq
mov	w9, #0x11               ; =17
csel	x20, x9, x8, eq
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x430
add	x22, x8, #0x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
stp	x8, x22, [x10]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [x10, #0x10]
adrp x25, RELOC_PAGE
add	x25, x25, #RELOC_OFFSET
mov	w26, #0x24              ; =36
add	x1, x25, x27
add	x24, sp, #0x39, lsl #12 ; =0x39000
add	x24, x24, #0x430
ldp	x9, x8, [x24, #0x10]
sub	x21, x26, x27
add	x10, x8, x21
cmp	x10, x9
b.hi	<_main.execute>
ldr	x9, [x24, #0x8]
add	x0, x9, x8
mov	x2, x21
bl	<_memcpy>
ldr	x8, [x24, #0x18]
add	x8, x8, x21
add	x23, sp, #0x39, lsl #12 ; =0x39000
add	x23, x23, #0x430
str	x8, [x24, #0x18]
add	x27, x21, x27
cmp	x27, #0x24
b.lo	<_main.execute>
b	<_main.execute>
add	x23, sp, #0x39, lsl #12 ; =0x39000
add	x23, x23, #0x430
ldr	x8, [x24]
ldr	x9, [x8]
add	x8, sp, #0x8a, lsl #12  ; =0x8a000
add	x8, x8, #0x330
stp	x1, x21, [x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0x330
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x9, sp, #0x71, lsl #12  ; =0x71000
add	x9, x9, #0x700
ldrh	w8, [x9, #0x8]
cbnz	w8, <_main.execute>
ldr	x21, [x9]
add	x27, x21, x27
cmp	x27, #0x24
b.lo	<_main.execute>
adrp x8, RELOC_PAGE
ldrb	w4, [x8, #RELOC_OFFSET]
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	x1, x19
mov	x2, x20
mov	x3, x20
mov	w5, #0x20               ; =32
bl	<_Io.Writer.alignBuffer>
tst	w0, #0xffff
b.eq	<_main.execute>
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
ldr	x9, [x10, #0x18]
mov	w8, #0x3fd              ; =1021
cmp	x9, #0x3fd
csel	x8, x9, x8, lo
cmp	x9, #0x3fe
b.lo	<_main.execute>
ldr	x10, [x10, #0x8]
ldr	x25, [sp, #0xb0]
ldr	x26, [sp, #0x150]
ldr	x12, [sp, #0xd0]
ldr	x23, [sp, #0xc0]
ldr	x20, [sp, #0x160]
ldrsb	w11, [x10, x8]
cmn	w11, #0x41
b.gt	<_main.execute>
subs	x8, x8, #0x1
b.eq	<_main.execute>
cmp	x8, x9
b.lo	<_main.execute>
b	<_main.execute>
ldr	x8, [x23, #0x18]
ldr	x25, [sp, #0xb0]
ldr	x26, [sp, #0x150]
ldr	x12, [sp, #0xd0]
ldr	x23, [sp, #0xc0]
ldr	x20, [sp, #0x160]
b	<_main.execute>
ldr	x25, [sp, #0xb0]
ldr	x26, [sp, #0x150]
ldr	x12, [sp, #0xd0]
ldr	x23, [sp, #0xc0]
ldr	x20, [sp, #0x160]
add	x9, x22, x8
mov	w10, #0xa6              ; =166
strb	w10, [x9, #0x2]
mov	w10, #0x80e2            ; =32994
strh	w10, [x9]
add	x8, x8, #0x3
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
str	x8, [x9, #0x90]
ldur	x19, [x12, #0x1a]
ldr	x0, [x19, #0x20]
bl	<_lua_close>
ldp	x0, x8, [x19, #0x10]
ldr	x8, [x8, #0x18]
mov	x1, x19
mov	w2, #0x50               ; =80
mov	w3, #0x3                ; =3
mov	x4, x25
blr	x8
ldr	x8, [x23, #0x18]!
ldr	x22, [sp, #0xb8]
mov	x0, x22
mov	x1, x20
mov	w2, #0x5da0             ; =23968
movk	w2, #0x1, lsl #16
mov	w3, #0x3                ; =3
mov	x4, x25
blr	x8
ldr	x8, [x23]
mov	x0, x22
mov	x1, x26
mov	w2, #0xa3d0             ; =41936
movk	w2, #0x14, lsl #16
mov	w3, #0x4                ; =4
mov	x4, x25
blr	x8
b	<_main.execute>
ldur	x8, [x21, #0x1a]
ldr	x28, [x8, #0x20]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	x0, x28
bl	<_lua_getglobal>
mov	x0, x28
mov	w1, #0x0                ; =0
mov	w2, #0x1                ; =1
bl	<_lua_createtable>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	x0, x28
mov	w2, #0x0                ; =0
bl	<_lua_pushcclosure>
adrp x2, RELOC_PAGE
add	x2, x2, #RELOC_OFFSET
mov	x0, x28
mov	w1, #-0x2               ; =-2
bl	<_lua_setfield>
adrp x2, RELOC_PAGE
add	x2, x2, #RELOC_OFFSET
mov	x0, x28
mov	w1, #-0x2               ; =-2
bl	<_lua_setfield>
mov	x0, x28
mov	w1, #0x0                ; =0
bl	<_lua_settop>
ldr	x8, [x26, #0x400]
ldr	x28, [x8, #0x20]
mov	x0, x28
mov	w1, #0x0                ; =0
mov	w2, #0x40               ; =64
bl	<_lua_createtable>
mov	x0, x28
mov	w1, #0xfc19             ; =64537
movk	w1, #0xbfff, lsl #16
bl	<_luaL_ref>
str	w0, [x26, #0x408]
mov	x0, x28
mov	x1, x26
bl	<_lua_pushlightuserdata>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	x0, x28
mov	w2, #0x1                ; =1
bl	<_lua_pushcclosure>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	x0, x28
bl	<_lua_setglobal>
ldur	x19, [x21, #0x1a]
ldr	x0, [x19, #0x20]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
adrp x3, RELOC_PAGE
add	x3, x3, #RELOC_OFFSET
adrp x4, RELOC_PAGE
add	x4, x4, #RELOC_OFFSET
mov	w2, #0x9c               ; =156
bl	<_luaL_loadbufferx>
cbz	w0, <_main.execute>
mov	w28, #0x6c              ; =108
b	<_main.execute>
mov	x21, #0x0               ; =0
mov	w22, #0x1               ; =1
b	<_main.execute>
adrp x22, RELOC_PAGE
add	x22, x22, #RELOC_OFFSET
mov	w21, #0x2               ; =2
str	x28, [sp, #0x150]
cbz	x21, <_main.execute>
mov	x20, #0x0               ; =0
add	x1, x22, x20
ldp	x9, x8, [x24, #0x10]
sub	x25, x21, x20
add	x10, x8, x25
cmp	x10, x9
b.hi	<_main.execute>
ldr	x9, [x24, #0x8]
add	x0, x9, x8
mov	x2, x25
bl	<_memcpy>
ldr	x8, [x24, #0x18]
add	x8, x8, x25
str	x8, [x24, #0x18]
add	x20, x25, x20
cmp	x20, x21
b.lo	<_main.execute>
b	<_main.execute>
ldr	x8, [x24]
ldr	x9, [x8]
str	x1, [x24, #0x200]
str	x25, [x24, #0x208]
sub	x8, x29, #0xb8
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x1b8
add	x1, sp, #0x8b, lsl #12  ; =0x8b000
add	x1, x1, #0x3b8
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w28, [x24, #0x2a8]
cbnz	w28, <_main.execute>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
ldr	x25, [x24, #0x2a0]
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
ldr	x28, [sp, #0x150]
add	x20, x25, x20
cmp	x20, x21
b.lo	<_main.execute>
strb	wzr, [x24, #0x280]
strb	wzr, [x24, #0x260]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
strb	wzr, [x24, #0x248]
add	x0, x8, #0x6
mov	w1, #0x8280             ; =33408
movk	w1, #0x1, lsl #16
bl	<dyld_stub_binder>
add	x20, sp, #0x39, lsl #12 ; =0x39000
add	x20, x20, #0x430
add	x8, x20, #0x18, lsl #12 ; =0x18000
add	x0, x8, #0x2be
mov	w1, #0xff               ; =255
mov	w2, #0x10000            ; =65536
bl	<_memset>
mov	w8, #0x7fff             ; =32767
strh	w8, [x24, #0x294]
mov	w21, #0x2               ; =2
strb	w21, [x24, #0x274]
sub	x8, x29, #0xb8
strb	w21, [x8, #0x48]
add	x0, x20, #0x2a
add	x1, sp, #0x71, lsl #12  ; =0x71000
add	x1, x1, #0x700
mov	w2, #0x8286             ; =33414
movk	w2, #0x1, lsl #16
bl	<_memcpy>
mov	x22, #0x0               ; =0
ldrh	w8, [x24, #0x294]
ldrb	w9, [x24, #0x280]
adrp x10, RELOC_PAGE
add	x10, x10, #RELOC_OFFSET
add	x11, sp, #0x29, lsl #12 ; =0x29000
add	x11, x11, #0x430
add	x12, sp, #0x39, lsl #12 ; =0x39000
add	x12, x12, #0x430
stp	x10, x11, [x12]
adrp x10, RELOC_PAGE
ldr	q0, [x10, #RELOC_OFFSET]
add	x10, sp, #0x8b, lsl #12 ; =0x8b000
add	x10, x10, #0x1b8
str	x10, [x12, #0x20]
mov	w10, #0x1               ; =1
str	w10, [x28]
ldrb	w10, [x24, #0x274]
str	q0, [x12, #0x10]
strh	wzr, [x12, #0x28]
strb	w21, [x28, #0x8]
strh	wzr, [x28, #0xc]
ldr	x11, [sp, #0xb0]
strh	w8, [x11]
mov	x8, #0x4                ; =4
movk	x8, #0x8, lsl #16
movk	x8, #0x4, lsl #48
stur	x8, [x11, #0x2]
strb	w9, [x11, #0xa]
strb	w10, [x11, #0xb]
add	x1, x26, x22
sub	x8, x19, x22
sub	x25, x8, #0x400
add	x20, sp, #0x39, lsl #12 ; =0x39000
add	x20, x20, #0x430
ldp	x9, x8, [x20, #0x10]
add	x10, x8, x25
cmp	x10, x9
b.hi	<_main.execute>
ldr	x9, [x20, #0x8]
add	x0, x9, x8
mov	x2, x25
bl	<_memcpy>
ldr	x8, [x20, #0x18]
add	x8, x8, x25
str	x8, [x20, #0x18]
add	x22, x25, x22
cmp	x22, x27
b.lo	<_main.execute>
b	<_main.execute>
ldr	x8, [x20]
ldr	x9, [x8]
str	x1, [x24, #0x200]
str	x25, [x24, #0x208]
sub	x8, x29, #0xb8
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
add	x1, sp, #0x8b, lsl #12  ; =0x8b000
add	x1, x1, #0x3b8
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w28, [x24, #0x2a8]
cbnz	w28, <_main.execute>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
ldr	x25, [x24, #0x2a0]
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
add	x22, x25, x22
cmp	x22, x27
b.lo	<_main.execute>
add	x21, sp, #0x39, lsl #12 ; =0x39000
add	x21, x21, #0x430
ldr	x8, [x21, #0x10]
sub	x2, x8, #0x8, lsl #12   ; =0x8000
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	x1, #0x0                ; =0
mov	w3, #0x1                ; =1
mov	w4, #0x1                ; =1
bl	<_compress.flate.Compress.rebaseInner>
adrp x19, RELOC_PAGE
add	x19, x19, #RELOC_OFFSET
tst	w0, #0xffff
b.ne	<_main.execute>
add	x20, sp, #0x39, lsl #12 ; =0x39000
add	x20, x20, #0x430
ldr	x0, [x21, #0x20]
ldp	x9, x8, [x0, #0x10]
cmp	x9, x8
b.eq	<_main.execute>
ldr	x12, [sp, #0x150]
ldr	x9, [x0, #0x8]
add	x11, sp, #0x39, lsl #12 ; =0x39000
add	x11, x11, #0x430
ldrb	w10, [x11, #0x28]
and	w10, w10, #0x7f
strb	w10, [x9, x8]
ldr	x8, [x11, #0x20]
ldrb	w9, [x11, #0x29]
tst	w9, #0x7
ldr	x9, [x8, #0x18]
cinc	x9, x9, ne
str	x9, [x8, #0x18]
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
strh	wzr, [x11, #0x28]
ldrb	w8, [x12, #0x8]
ands	w8, w8, #0x3
b.eq	<_main.execute>
ldr	x25, [x9, #0x20]
cmp	w8, #0x2
b.ne	<_main.execute>
mov	x20, #0x0               ; =0
ldr	w8, [x12]
rev	w8, w8
sub	x9, x29, #0xb8
str	w8, [x9, #0x48]
sub	x21, x29, #0x70
mov	w22, #0x4               ; =4
add	x1, x21, x20
ldp	x9, x8, [x25, #0x10]
sub	x28, x22, x20
add	x10, x8, x28
cmp	x10, x9
b.hi	<_main.execute>
ldr	x9, [x25, #0x8]
add	x0, x9, x8
mov	x2, x28
bl	<_memcpy>
ldr	x8, [x25, #0x18]
add	x8, x8, x28
str	x8, [x25, #0x18]
add	x20, x28, x20
cmp	x20, #0x4
b.lo	<_main.execute>
b	<_main.execute>
ldr	x8, [x25]
ldr	x9, [x8]
str	x1, [x24, #0x200]
str	x28, [x24, #0x208]
sub	x8, x29, #0xb8
add	x1, sp, #0x8b, lsl #12  ; =0x8b000
add	x1, x1, #0x3b8
mov	x0, x25
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w28, [x24, #0x2a8]
cbnz	w28, <_main.execute>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
ldr	x28, [x24, #0x2a0]
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
add	x20, x28, x20
cmp	x20, #0x4
b.lo	<_main.execute>
b	<_main.execute>
mov	x20, #0x0               ; =0
ldr	w8, [x12]
mvn	w8, w8
str	w8, [x24, #0x248]
add	x21, sp, #0x8b, lsl #12 ; =0x8b000
add	x21, x21, #0x400
mov	w22, #0x4               ; =4
add	x1, x21, x20
ldp	x9, x8, [x25, #0x10]
sub	x28, x22, x20
add	x10, x8, x28
cmp	x10, x9
b.hi	<_main.execute>
ldr	x9, [x25, #0x8]
add	x0, x9, x8
mov	x2, x28
bl	<_memcpy>
ldr	x8, [x25, #0x18]
add	x8, x8, x28
str	x8, [x25, #0x18]
add	x20, x28, x20
cmp	x20, #0x4
b.lo	<_main.execute>
b	<_main.execute>
ldr	x8, [x25]
ldr	x9, [x8]
str	x1, [x24, #0x200]
str	x28, [x24, #0x208]
sub	x8, x29, #0xb8
add	x1, sp, #0x8b, lsl #12  ; =0x8b000
add	x1, x1, #0x3b8
mov	x0, x25
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w28, [x24, #0x2a8]
cbnz	w28, <_main.execute>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
ldr	x28, [x24, #0x2a0]
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
add	x20, x28, x20
cmp	x20, #0x4
b.lo	<_main.execute>
mov	x20, #0x0               ; =0
ldr	x8, [sp, #0x150]
ldr	w8, [x8, #0x4]
str	w8, [x24, #0x260]
sub	x21, x29, #0xf8
mov	w22, #0x4               ; =4
add	x1, x21, x20
ldp	x9, x8, [x25, #0x10]
sub	x28, x22, x20
add	x10, x8, x28
cmp	x10, x9
b.hi	<_main.execute>
ldr	x9, [x25, #0x8]
add	x0, x9, x8
mov	x2, x28
bl	<_memcpy>
ldr	x8, [x25, #0x18]
add	x8, x8, x28
str	x8, [x25, #0x18]
add	x20, x28, x20
cmp	x20, #0x4
b.lo	<_main.execute>
b	<_main.execute>
ldr	x8, [x25]
ldr	x9, [x8]
str	x1, [x24, #0x200]
str	x28, [x24, #0x208]
sub	x8, x29, #0xb8
add	x1, sp, #0x8b, lsl #12  ; =0x8b000
add	x1, x1, #0x3b8
mov	x0, x25
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w28, [x24, #0x2a8]
cbnz	w28, <_main.execute>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
ldr	x28, [x24, #0x2a0]
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
add	x20, x28, x20
cmp	x20, #0x4
b.lo	<_main.execute>
ldp	q0, q1, [x19]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
stp	q0, q1, [x8]
ldr	x22, [sp, #0xd0]
ldr	x20, [sp, #0xc0]
ldr	x21, [sp, #0x160]
tbnz	wzr, #0x0, <_main.execute>
ldr	x8, [x24, #0x18]
ldr	x9, [x24, #0x8]
str	x9, [sp, #0xb0]
str	x8, [sp, #0x150]
add	x8, x8, #0x2
mov	x9, #-0x5555555555555556 ; =-6148914691236517206
movk	x9, #0xaaab
umulh	x8, x8, x9
lsl	x8, x8, #1
and	x28, x8, #0xfffffffffffffffc
add	x19, x28, #0x30
ldr	x8, [x21]
mov	x0, x20
mov	x1, x19
mov	w2, #0x0                ; =0
mov	x3, x22
blr	x8
cbz	x0, <_main.execute>
mov	x25, x0
str	x19, [sp, #0xa8]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
stp	q0, q1, [x0]
ldur	q0, [x8, #0x1e]
stur	q0, [x0, #0x1e]
adrp x0, RELOC_PAGE
add	x0, x0, #RELOC_OFFSET
add	x1, x25, #0x2e
mov	x2, x28
ldr	x3, [sp, #0xb0]
ldr	x4, [sp, #0x150]
bl	<_base64.Base64Encoder.encode>
add	x8, x25, x28
mov	w9, #0x5c1b             ; =23579
strh	w9, [x8, #0x2e]
adrp x3, RELOC_PAGE
add	x3, x3, #RELOC_OFFSET
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x1d0
add	x2, sp, #0x1e0
bl	<_terminal.Terminal.init>
ldrh	w28, [x23, #0x980]
cbnz	w28, <_main.execute>
add	x0, sp, #0x89, lsl #12  ; =0x89000
add	x0, x0, #0x9b0
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0x330
mov	w2, #0x980              ; =2432
bl	<_memcpy>
add	x19, sp, #0x8a, lsl #12 ; =0x8a000
add	x19, x19, #0xcc0
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0xcc0
add	x1, sp, #0x89, lsl #12  ; =0x89000
add	x1, x1, #0x9b0
bl	<_terminal.Terminal.vtHandler>
add	x8, x19, #0x218
ldr	q0, [sp, #0x1e0]
str	q0, [x8]
mov	w8, #0x1                ; =1
strb	w8, [x23, #0xbb8]
movi.2d	v0, #0000000000000000
str	q0, [x23, #0xbc0]
add	x8, sp, #0xa, lsl #12   ; =0xa000
add	x8, x8, #0xc8
add	x0, x8, #0x980
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0xcc0
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).init>
add	x0, sp, #0xa, lsl #12   ; =0xa000
add	x0, x0, #0xc8
add	x1, sp, #0x89, lsl #12  ; =0x89000
add	x1, x1, #0x9b0
mov	w2, #0x980              ; =2432
bl	<_memcpy>
ldr	q0, [sp, #0x1e0]
add	x21, sp, #0x8, lsl #12  ; =0x8000
add	x21, x21, #0xbc8
str	q0, [x21, #0x29e0]
ldr	x19, [sp, #0x160]
ldr	x8, [x19, #0x18]
mov	x0, x20
ldr	x1, [sp, #0xb8]
mov	w2, #0x9400             ; =37888
movk	w2, #0x7e, lsl #16
mov	w3, #0x0                ; =0
mov	x4, x22
blr	x8
ldr	x8, [x19, #0x18]
mov	x0, x20
mov	x1, x26
mov	x2, x27
mov	w3, #0x0                ; =0
mov	x4, x22
blr	x8
add	x19, sp, #0x8, lsl #12  ; =0x8000
add	x19, x19, #0xbc8
add	x0, sp, #0x8, lsl #12   ; =0x8000
add	x0, x0, #0xbc8
add	x1, sp, #0xa, lsl #12   ; =0xa000
add	x1, x1, #0xc8
mov	w2, #0x14f0             ; =5360
bl	<_memcpy>
add	x8, sp, #0x8, lsl #12   ; =0x8000
add	x8, x8, #0xb40
str	x25, [x8, #0x1578]
ldr	x13, [sp, #0xa8]
str	x13, [x8, #0x1580]
ldr	x8, [sp, #0x130]
str	x8, [x21, #0x29f0]
ldp	x26, x20, [sp, #0x100]
str	x26, [x21, #0x29f8]
ldr	x11, [sp, #0x120]
str	x11, [x21, #0x2a00]
ldr	x10, [sp, #0x148]
str	x10, [x21, #0x2a08]
str	x20, [x21, #0x2a10]
ldp	q0, q1, [sp, #0x190]
add	x12, sp, #0xb, lsl #12  ; =0xb000
add	x12, x12, #0x5b8
stur	q0, [x12, #0x28]
stur	q1, [x12, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x12, #0x48]
ldr	x8, [sp, #0x1c0]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
stp	x8, x9, [x12, #0x58]
mov	w8, #0x28               ; =40
str	x8, [x12, #0x68]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldr	q0, [x8]
ldr	x8, [x8, #0x10]
str	q0, [x12, #0x70]
stp	x8, x13, [x12, #0x80]
mov	w8, #0xe100             ; =57600
movk	w8, #0x5f5, lsl #16
str	x8, [x12, #0x90]
ldr	q0, [sp, #0x1d0]
stp	x26, x11, [x12, #0xa8]
stp	x10, x20, [x12, #0xb8]
ldp	q1, q2, [sp, #0x1f0]
str	q0, [sp, #0xb650]
str	q1, [sp, #0xb680]
ldr	q0, [sp, #0x210]
str	q2, [sp, #0xb690]
str	q0, [sp, #0xb6a0]
ldr	x8, [sp, #0x220]
stp	x8, x19, [x12, #0xf8]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0x650
mov	w2, #0x1                ; =1
bl	<_main.timed__anon>
ldrh	w28, [x23, #0x8]
cbnz	w28, <_main.execute>
lsr	x19, x20, #2
mov	w25, #0x1               ; =1
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
ldr	x2, [x23]
cmp	x2, x19
lsr	x8, x25, #30
ccmp	x8, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x25, x25, #2
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0x650
mov	x2, x25
bl	<_main.timed__anon>
ldrh	w28, [x23, #0x8]
cbz	w28, <_main.execute>
add	x0, sp, #0x8, lsl #12   ; =0x8000
add	x0, x0, #0xbc8
bl	<_KgpIngestContext.deinit>
b	<_main.execute>
ldr	x8, [x21, #0x18]!
mov	x0, x20
ldr	x1, [sp, #0xb8]
mov	w2, #0x9400             ; =37888
movk	w2, #0x7e, lsl #16
mov	w3, #0x0                ; =0
mov	x4, x22
blr	x8
mov	w28, #0x1a              ; =26
ldr	x8, [x21]
mov	x0, x20
mov	x1, x26
mov	x2, x27
mov	w3, #0x0                ; =0
mov	x4, x22
b	<_main.execute>
cmp	x2, #0x0
ccmp	x2, x20, #0x2, ne
b.hs	<_main.execute>
mul	x0, x25, x20
umulh	x1, x25, x20
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x25, x8
csel	x25, x25, x8, hi
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0x650
mov	x2, x25
bl	<_main.timed__anon>
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
ldrh	w28, [x8, #0x98]
cbnz	w28, <_main.execute>
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
ldr	x20, [sp, #0x148]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0x650
mov	x2, x25
bl	<_main.timed__anon>
ldrh	w28, [x21, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
cbnz	w28, <_main.execute>
ldr	x8, [x8]
udiv	x8, x8, x25
str	x8, [x19], #0x8
subs	x20, x20, #0x1
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
b.ne	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
ldr	x10, [x27]
lsr	x11, x20, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
add	x12, sp, #0xb, lsl #12  ; =0xb000
add	x12, x12, #0x5b8
stp	x25, x11, [x12, #0x110]
stp	x10, x8, [x12, #0x120]
str	x9, [x12, #0x130]
add	x0, sp, #0xb, lsl #12   ; =0xb000
add	x0, x0, #0x5b8
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0x618
add	x2, sp, #0xb, lsl #12   ; =0xb000
add	x2, x2, #0x6c8
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
add	x8, sp, #0x8, lsl #12   ; =0x8000
add	x8, x8, #0xbc8
add	x0, x8, #0x980
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).deinit>
add	x20, sp, #0x8, lsl #12  ; =0x8000
add	x20, x20, #0xbc8
ldr	q0, [x20, #0x14e0]
str	q0, [x27]
add	x0, sp, #0x8, lsl #12   ; =0x8000
add	x0, x0, #0xbc8
add	x1, sp, #0x39, lsl #12  ; =0x39000
add	x1, x1, #0x430
bl	<_terminal.Terminal.deinit>
ldr	x2, [x20, #0x14f8]
ldr	x19, [sp, #0x120]
cbz	x2, <_main.execute>
ldr	x1, [x20, #0x14f0]
ldr	x8, [x20, #0x14e8]
ldr	x0, [x20, #0x14e0]
ldr	x8, [x8, #0x18]
mov	w3, #0x0                ; =0
mov	x4, x22
blr	x8
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x2c               ; =44
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbnz	w8, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x2b               ; =43
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbnz	w8, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x2b               ; =43
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
tbnz	wzr, #0x0, <_main.execute>
ldp	x26, x20, [sp, #0x1e0]
ldr	x21, [sp, #0x110]
xpaci	x21
mov	w19, #0x4000            ; =16384
movk	w19, #0x1fa, lsl #16
ldr	x8, [x20]
mov	x0, x26
mov	w1, #0x4000             ; =16384
movk	w1, #0x1fa, lsl #16
mov	w2, #0x0                ; =0
mov	x3, x21
blr	x8
cbz	x0, <_main.execute>
mov	x27, x0
mov	x8, #0x0                ; =0
add	x22, sp, #0xb, lsl #12  ; =0xb000
add	x22, x22, #0x888
mov	x9, #0x4147             ; =16711
movk	x9, #0x7340, lsl #16
movk	x9, #0x7f7d, lsl #32
movk	x9, #0x519, lsl #48
mov	w10, #0xfb              ; =251
mov	x11, x0
mov	w12, #0x4000            ; =16384
movk	w12, #0x1fa, lsl #16
umulh	x13, x8, x9
sub	w14, w8, w13
add	w13, w13, w14, lsr #1
lsr	w13, w13, #7
msub	w13, w13, w10, w8
add	x8, x8, #0x1
strb	w13, [x11], #0x1
subs	x12, x12, #0x1
b.ne	<_main.execute>
ldr	x8, [x20]
mov	x0, x26
mov	w1, #0x1b78             ; =7032
movk	w1, #0x3, lsl #16
mov	w2, #0x3                ; =3
mov	x3, x21
blr	x8
cbz	x0, <_main.execute>
mov	x25, x0
str	x21, [sp, #0x150]
str	x20, [sp, #0x160]
mov	x20, #0x9a              ; =154
movk	x20, #0x25, lsl #16
movk	x20, #0x18, lsl #32
movk	x20, #0x3a, lsl #48
ldp	q0, q1, [sp, #0x1d0]
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
stp	q0, q1, [x21]
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
stp	q0, q1, [x9]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [x9, #0x20]
stp	xzr, x20, [x9, #0x30]
add	x1, sp, #0x39, lsl #12  ; =0x39000
add	x1, x1, #0x430
bl	<_media.Pipeline.init>
tst	w0, #0xffff
b.ne	<_main.execute>
ldp	q0, q1, [x21]
str	q0, [sp, #0xb6f0]
str	q1, [sp, #0xb700]
add	x8, sp, #0xb, lsl #12   ; =0xb000
add	x8, x8, #0x5b8
stp	xzr, xzr, [x8, #0x178]
stp	x27, x19, [x8, #0x158]
stp	x25, xzr, [x8, #0x168]
str	x20, [x8, #0x188]
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
ldr	x26, [sp, #0x100]
ldr	x19, [sp, #0x120]
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x2c               ; =44
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
ldp	q0, q1, [sp, #0x190]
stur	q0, [x22, #0x28]
add	x20, sp, #0xb, lsl #12  ; =0xb000
add	x20, x20, #0x6f0
ldr	x8, [sp, #0x130]
add	x9, sp, #0xb, lsl #12   ; =0xb000
add	x9, x9, #0x5b8
str	x8, [x9, #0x2d0]
str	x26, [x9, #0x2d8]
str	x19, [x9, #0x2e0]
add	x19, sp, #0xb, lsl #12  ; =0xb000
add	x19, x19, #0x5b8
ldr	x8, [sp, #0x148]
str	x8, [x19, #0x2e8]
ldr	x9, [sp, #0x108]
str	x9, [x19, #0x2f0]
stur	q1, [x22, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x22, #0x48]
ldr	x8, [sp, #0x1c0]
str	x8, [x22, #0x58]
lsr	x25, x9, #2
mov	w21, #0x1               ; =1
ldp	x26, x22, [sp, #0x1d0]
ldr	x9, [x22, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
mov	x24, #0x0               ; =0
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x23, [x8]
mov	x27, x21
add	x0, sp, #0xb, lsl #12   ; =0xb000
add	x0, x0, #0x6f0
bl	<_SharedFrameContext.publish>
ands	w28, w0, #0xffff
b.ne	<_main.execute>
add	x0, x20, #0x58
bl	<dyld_stub_binder>
ldr	x8, [x19, #0x180]
add	x24, x8, x24
subs	x27, x27, #0x1
b.ne	<_main.execute>
ldr	x9, [x22, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x8, [x8]
sub	x2, x8, x23
cmp	x2, x25
lsr	x9, x21, #30
ccmp	x9, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x21, x21, #2
b	<_main.execute>
mov	w28, #0x1a              ; =26
mov	x0, x28
add	sp, sp, #0x8b, lsl #12  ; =0x8b000
add	sp, sp, #0x4c0
ldp	x29, x30, [sp, #0x50]
ldp	x20, x19, [sp, #0x40]
ldp	x22, x21, [sp, #0x30]
ldp	x24, x23, [sp, #0x20]
ldp	x26, x25, [sp, #0x10]
ldp	x28, x27, [sp], #0x60
ret
add	x20, x20, #0x18
mov	w28, #0x1a              ; =26
ldr	x8, [x20]
mov	x0, x26
mov	x1, x27
mov	w2, #0x4000             ; =16384
movk	w2, #0x1fa, lsl #16
mov	w3, #0x0                ; =0
mov	x4, x21
b	<_main.execute>
cmp	x8, x23
b.eq	<_main.execute>
ldr	x8, [sp, #0x108]
cmp	x2, x8
b.hs	<_main.execute>
mul	x0, x21, x8
umulh	x1, x21, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x21, x8
csel	x21, x21, x8, hi
ldr	x9, [x22, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
mov	x23, #0x0               ; =0
mov	x24, x21
add	x0, sp, #0xb, lsl #12   ; =0xb000
add	x0, x0, #0x6f0
bl	<_SharedFrameContext.publish>
ands	w28, w0, #0xffff
b.ne	<_main.execute>
add	x0, x20, #0x58
bl	<dyld_stub_binder>
ldr	x8, [x19, #0x180]
add	x23, x8, x23
subs	x24, x24, #0x1
b.ne	<_main.execute>
ldr	x9, [x22, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
add	x19, sp, #0x71, lsl #12 ; =0x71000
add	x19, x19, #0x700
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
mov	x25, #0x0               ; =0
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
ldr	x9, [x22, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
mov	x23, #0x0               ; =0
ldr	x24, [x19]
mov	x19, x21
add	x0, sp, #0xb, lsl #12   ; =0xb000
add	x0, x0, #0x6f0
bl	<_SharedFrameContext.publish>
ands	w28, w0, #0xffff
b.ne	<_main.execute>
add	x0, x20, #0x58
bl	<dyld_stub_binder>
add	x8, sp, #0xb, lsl #12   ; =0xb000
add	x8, x8, #0x5b8
ldr	x8, [x8, #0x180]
add	x23, x8, x23
subs	x19, x19, #0x1
b.ne	<_main.execute>
ldr	x9, [x22, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
add	x19, sp, #0x71, lsl #12 ; =0x71000
add	x19, x19, #0x700
ldr	x8, [x19]
sub	x8, x8, x24
udiv	x8, x8, x21
str	x8, [x27, x25, lsl #3]
add	x25, x25, #0x1
ldr	x8, [sp, #0x148]
cmp	x25, x8
b.ne	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
ldr	x10, [x27]
lsr	x11, x20, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
add	x22, sp, #0xb, lsl #12  ; =0xb000
add	x22, x22, #0x888
stp	x21, x11, [x22, #0x60]
stp	x10, x8, [x22, #0x70]
str	x9, [x22, #0x80]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0xb, lsl #12   ; =0xb000
add	x0, x0, #0x888
add	x2, sp, #0xb, lsl #12   ; =0xb000
add	x2, x2, #0x8e8
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
ldr	x26, [sp, #0x100]
ldr	x19, [sp, #0x120]
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x2b               ; =43
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
ldr	x8, [sp, #0x130]
stp	x8, x26, [x22, #0x88]
ldr	x9, [sp, #0x148]
stp	x19, x9, [x22, #0x98]
mov	x10, x19
ldr	x19, [sp, #0x108]
str	x19, [x22, #0xa8]
ldp	q0, q1, [sp, #0x190]
stp	q0, q1, [x22, #0xb0]
ldr	q0, [sp, #0x1b0]
stur	q0, [x22, #0xd0]
ldr	x8, [sp, #0x1c0]
str	x8, [x22, #0xe0]
ldp	q1, q0, [sp, #0x200]
ldr	q2, [sp, #0x1f0]
str	q0, [sp, #0xb9c0]
str	q1, [sp, #0xb9b0]
ldr	q0, [sp, #0x1d0]
stp	x26, x10, [x22, #0xf8]
stp	x9, x19, [x22, #0x108]
ldr	x8, [sp, #0x220]
str	q0, [sp, #0xb970]
str	q2, [sp, #0xb9a0]
add	x9, sp, #0xb, lsl #12   ; =0xb000
add	x9, x9, #0x6f0
stp	x8, x9, [x22, #0x148]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0x970
mov	w2, #0x1                ; =1
bl	<_main.timed__anon>
ldrh	w28, [x23, #0x8]
cbnz	w28, <_main.execute>
lsr	x20, x19, #2
mov	w26, #0x1               ; =1
ldr	x2, [x23]
cmp	x2, x20
lsr	x8, x26, #30
ccmp	x8, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x26, x26, #2
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0x970
mov	x2, x26
bl	<_main.timed__anon>
ldrh	w28, [x23, #0x8]
cbz	w28, <_main.execute>
add	x0, sp, #0xb, lsl #12   ; =0xb000
add	x0, x0, #0x6f0
bl	<_SharedFrameContext.deinit>
b	<_main.execute>
cmp	x2, #0x0
ldr	x8, [sp, #0x108]
ccmp	x2, x8, #0x2, ne
b.hs	<_main.execute>
mul	x0, x26, x8
umulh	x1, x26, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x26, x8
csel	x26, x26, x8, hi
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0x970
mov	x2, x26
bl	<_main.timed__anon>
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
ldrh	w28, [x8, #0x98]
cbnz	w28, <_main.execute>
add	x22, sp, #0x71, lsl #12 ; =0x71000
add	x22, x22, #0x700
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
ldr	x21, [sp, #0x148]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0x970
mov	x2, x26
bl	<_main.timed__anon>
ldrh	w28, [x22, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
cbnz	w28, <_main.execute>
ldr	x8, [x8]
udiv	x8, x8, x26
str	x8, [x19], #0x8
subs	x21, x21, #0x1
add	x22, sp, #0x71, lsl #12 ; =0x71000
add	x22, x22, #0x700
b.ne	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x21, [sp, #0x148]
mov	x1, x21
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x21, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x21, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
ldr	x10, [x27]
lsr	x11, x21, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
add	x22, sp, #0xb, lsl #12  ; =0xb000
add	x22, x22, #0x888
stp	x26, x11, [x22, #0x158]
stp	x10, x8, [x22, #0x168]
str	x9, [x22, #0x178]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0xb, lsl #12   ; =0xb000
add	x0, x0, #0x910
add	x2, sp, #0xb, lsl #12   ; =0xb000
add	x2, x2, #0x9e0
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x26, [sp, #0x100]
ldr	x19, [sp, #0x120]
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x2b               ; =43
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
ldr	x8, [sp, #0x108]
lsr	x20, x8, #2
ldp	q0, q1, [sp, #0x190]
add	x9, sp, #0xb, lsl #12   ; =0xb000
add	x9, x9, #0xa08
stur	q0, [x9, #0x28]
ldr	x8, [sp, #0x130]
stp	x8, x26, [x22, #0x180]
ldr	x8, [sp, #0x148]
stp	x19, x8, [x22, #0x190]
ldr	x8, [sp, #0x108]
str	x8, [x22, #0x1a0]
stur	q1, [x9, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x9, #0x48]
ldr	x8, [sp, #0x1c0]
str	x8, [x9, #0x58]
mov	w19, #0x1               ; =1
ldp	x26, x21, [sp, #0x1d0]
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
ldr	x9, [x21, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
mov	x25, #0x0               ; =0
add	x27, sp, #0x71, lsl #12 ; =0x71000
add	x27, x27, #0x700
ldr	x22, [x27]
mov	x23, x19
add	x8, sp, #0xb, lsl #12   ; =0xb000
add	x8, x8, #0x5b8
ldp	x1, x2, [x8, #0x158]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
bl	<_media.shared_transfer.freezeSharedPixels>
ldrb	w8, [x27, #0x21]
add	x9, sp, #0x71, lsl #12  ; =0x71000
add	x9, x9, #0x700
cbz	w8, <_main.execute>
ldp	q0, q1, [x9]
stp	q0, q1, [x24, #0x90]
ldrb	w8, [x9, #0x20]
strb	w8, [x24, #0xb0]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x27, sp, #0x71, lsl #12 ; =0x71000
add	x27, x27, #0x700
bl	<dyld_stub_binder>
ldrb	w8, [x24, #0xb0]
add	x25, x25, x8
subs	x23, x23, #0x1
b.ne	<_main.execute>
ldr	x9, [x21, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [x27]
sub	x2, x8, x22
cmp	x2, x20
lsr	x9, x19, #30
ccmp	x9, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x19, x19, #2
b	<_main.execute>
ldr	x0, [x19, #0x20]
mov	w1, #0x0                ; =0
mov	w2, #0x1                ; =1
mov	w3, #0x0                ; =0
mov	x4, #0x0                ; =0
mov	x5, #0x0                ; =0
bl	<_lua_pcallk>
cbz	w0, <_main.execute>
mov	w28, #0x6d              ; =109
ldur	x8, [x21, #0x1a]
ldr	x0, [x8, #0x20]
str	xzr, [x27]
add	x2, sp, #0x39, lsl #12  ; =0x39000
add	x2, x2, #0x430
mov	w1, #-0x1               ; =-1
bl	<_lua_tolstring>
ldr	x8, [x27]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
cmp	x0, #0x0
csel	x1, x9, x0, eq
mov	w9, #0x11               ; =17
csel	x2, x9, x8, eq
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x430
add	x19, x8, #0x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
stp	x8, x19, [x27]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [x27, #0x10]
adrp x8, RELOC_PAGE
ldrb	w4, [x8, #RELOC_OFFSET]
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	x3, x2
mov	w5, #0x20               ; =32
bl	<_Io.Writer.alignBuffer>
ldr	x8, [x27, #0x18]
tst	w0, #0xffff
b.eq	<_main.execute>
mov	w9, #0x3fd              ; =1021
cmp	x8, #0x3fd
csel	x9, x8, x9, lo
cmp	x8, #0x3fe
b.lo	<_main.execute>
ldr	x10, [x27, #0x8]
ldr	x20, [sp, #0x160]
ldrsb	w11, [x10, x9]
cmn	w11, #0x41
b.gt	<_main.execute>
subs	x9, x9, #0x1
b.eq	<_main.execute>
cmp	x9, x8
b.lo	<_main.execute>
b	<_main.execute>
ldr	x20, [sp, #0x160]
b	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0xba90]
str	q1, [sp, #0xbaa0]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0xbab0]
ldr	x8, [x8, #0x30]
add	x9, sp, #0xb, lsl #12   ; =0xb000
add	x9, x9, #0xa08
str	x8, [x9, #0xb8]
add	x19, sp, #0x29, lsl #12 ; =0x29000
add	x19, x19, #0x3a0
ldr	x23, [sp, #0xe8]
b	<_main.execute>
ldr	x20, [sp, #0x160]
add	x8, x19, x9
mov	w10, #0xa6              ; =166
strb	w10, [x8, #0x2]
mov	w10, #0x80e2            ; =32994
strh	w10, [x8]
add	x8, x9, #0x3
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
str	x8, [x9, #0x90]
ldur	x19, [x21, #0x1a]
ldr	x0, [x19, #0x20]
bl	<_lua_close>
ldp	x0, x8, [x19, #0x10]
ldr	x8, [x8, #0x18]
mov	x1, x19
mov	w2, #0x50               ; =80
mov	w3, #0x3                ; =3
mov	x4, x25
blr	x8
ldr	x8, [x23, #0x18]!
b	<_main.execute>
ldur	x8, [x21, #0x1a]
ldr	x19, [x8, #0x20]
mov	x0, x19
mov	w1, #-0x1               ; =-1
bl	<_lua_type>
cmp	w0, #0x5
str	x21, [sp, #0xd0]
stp	x22, x23, [sp, #0xb8]
b.ne	<_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x2, sp, #0x29, lsl #12  ; =0x29000
add	x2, x2, #0x430
mov	x0, x19
bl	<_config.lua_value.ensureOnlyFields>
ands	w28, w0, #0xffff
b.ne	<_main.execute>
adrp x2, RELOC_PAGE
add	x2, x2, #RELOC_OFFSET
mov	x0, x19
mov	w1, #-0x1               ; =-1
bl	<_lua_getfield>
str	wzr, [x27]
add	x2, sp, #0x39, lsl #12  ; =0x39000
add	x2, x2, #0x430
mov	x0, x19
mov	w1, #-0x1               ; =-1
bl	<_lua_tointegerx>
mov	x28, x0
mov	x0, x19
ldr	w19, [x27]
str	x0, [sp, #0x90]
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
cmp	w19, #0x1
b.ne	<_main.execute>
str	x25, [sp, #0xb0]
cmp	x28, #0x2
b.ne	<_main.execute>
adrp x2, RELOC_PAGE
add	x2, x2, #RELOC_OFFSET
ldr	x19, [sp, #0x90]
mov	x0, x19
mov	w1, #-0x1               ; =-1
bl	<_lua_getfield>
mov	x0, x19
mov	w1, #-0x1               ; =-1
bl	<_lua_type>
cbz	w0, <_main.execute>
mov	w8, #0x8b0              ; =2224
movk	w8, #0x1, lsl #16
add	x1, x26, x8
mov	w8, #0xfdb0             ; =64944
movk	w8, #0x12, lsl #16
add	x2, x26, x8
add	x3, sp, #0x29, lsl #12  ; =0x29000
add	x3, x3, #0x430
mov	x0, x19
bl	<_config.plugins.parse>
tst	w0, #0xffff
b.ne	<_main.execute>
mov	x0, x19
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
str	x26, [sp, #0x150]
add	x8, x26, #0x12f, lsl #12 ; =0x12f000
mov	x1, x19
add	x19, x8, #0xcbe
ldp	q1, q0, [x19, #0xa0]
add	x9, sp, #0x8a, lsl #12  ; =0x8a000
add	x9, x9, #0x330
str	q0, [x9, #0xa40]
ldp	q0, q2, [x19, #0xc0]
str	q0, [x9, #0xa50]
str	q2, [x9, #0xa60]
ldp	q2, q0, [x19, #0x60]
str	q0, [x9, #0xa00]
ldp	q0, q3, [x19, #0x80]
str	q0, [x9, #0xa10]
str	q3, [x9, #0xa20]
str	q1, [x9, #0xa30]
ldp	q1, q0, [x19, #0x20]
str	q0, [x9, #0x9c0]
ldp	q0, q3, [x19, #0x40]
str	q0, [x9, #0x9d0]
str	q3, [x9, #0x9e0]
str	q2, [x9, #0x9f0]
ldp	q0, q2, [x19]
str	q0, [x9, #0x990]
str	q2, [x9, #0x9a0]
ldr	x8, [x19, #0xe0]
str	x8, [x9, #0xa70]
str	q1, [x9, #0x9b0]
add	x0, sp, #0x89, lsl #12  ; =0x89000
add	x0, x0, #0x9b0
add	x2, sp, #0x29, lsl #12  ; =0x29000
add	x2, x2, #0x430
add	x3, sp, #0x8a, lsl #12  ; =0x8a000
add	x3, x3, #0xcc0
bl	<_config.ThemeParser.select>
add	x8, sp, #0x89, lsl #12  ; =0x89000
add	x8, x8, #0x9b0
ldrh	w28, [x8]
cbnz	w28, <_main.execute>
add	x9, sp, #0x89, lsl #12  ; =0x89000
add	x9, x9, #0x9b0
ldur	q0, [x9, #0xb2]
ldur	q1, [x9, #0xc2]
ldur	q2, [x9, #0xd2]
stp	q1, q2, [x19, #0xc0]
ldur	x8, [x9, #0xe2]
str	x8, [x19, #0xe0]
ldur	q1, [x9, #0x72]
ldur	q2, [x9, #0x82]
ldur	q3, [x9, #0x92]
stp	q2, q3, [x19, #0x80]
ldur	q2, [x9, #0xa2]
stp	q2, q0, [x19, #0xa0]
ldur	q0, [x9, #0x32]
ldur	q2, [x9, #0x42]
ldur	q3, [x9, #0x52]
stp	q2, q3, [x19, #0x40]
ldur	q2, [x9, #0x62]
stp	q2, q1, [x19, #0x60]
ldur	q1, [x9, #0x2]
ldur	q2, [x9, #0x12]
stp	q1, q2, [x19]
ldur	q1, [x9, #0x22]
stp	q1, q0, [x19, #0x20]
adrp x2, RELOC_PAGE
add	x2, x2, #RELOC_OFFSET
ldr	x19, [sp, #0x90]
mov	x0, x19
mov	w1, #-0x1               ; =-1
bl	<_lua_getfield>
mov	x0, x19
mov	w1, #-0x1               ; =-1
bl	<_lua_type>
cbz	w0, <_main.execute>
add	x1, sp, #0x29, lsl #12  ; =0x29000
add	x1, x1, #0x430
ldr	x0, [sp, #0x150]
bl	<_config.Generation.parseClient>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x19, [sp, #0x90]
mov	x0, x19
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
adrp x2, RELOC_PAGE
add	x2, x2, #RELOC_OFFSET
mov	x0, x19
mov	w1, #-0x1               ; =-1
bl	<_lua_getfield>
mov	x0, x19
mov	w1, #-0x1               ; =-1
bl	<_lua_type>
cbz	w0, <_main.execute>
mov	w19, #0xa77c            ; =42876
movk	w19, #0x12, lsl #16
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
ldr	x8, [sp, #0x150]
add	x1, x8, x19
mov	w2, #0x138              ; =312
bl	<_memcpy>
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x2, sp, #0x29, lsl #12  ; =0x29000
add	x2, x2, #0x430
add	x3, sp, #0x8a, lsl #12  ; =0x8a000
add	x3, x3, #0x330
ldr	x1, [sp, #0x90]
bl	<_config.GuiConfigParser.parse>
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldrh	w28, [x8, #0x138]
cbnz	w28, <_main.execute>
ldr	x8, [sp, #0x150]
add	x0, x8, x19
add	x1, sp, #0x71, lsl #12  ; =0x71000
add	x1, x1, #0x700
mov	w2, #0x138              ; =312
bl	<_memcpy>
ldr	x19, [sp, #0x90]
mov	x0, x19
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
adrp x2, RELOC_PAGE
add	x2, x2, #RELOC_OFFSET
mov	x0, x19
mov	w1, #-0x1               ; =-1
bl	<_lua_getfield>
mov	x0, x19
mov	w1, #-0x1               ; =-1
bl	<_lua_type>
cbz	w0, <_main.execute>
add	x1, sp, #0x29, lsl #12  ; =0x29000
add	x1, x1, #0x430
ldr	x0, [sp, #0x150]
bl	<_config.Generation.parseRuntime>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x19, [sp, #0x90]
mov	x0, x19
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
adrp x2, RELOC_PAGE
add	x2, x2, #RELOC_OFFSET
mov	x0, x19
mov	w1, #-0x1               ; =-1
bl	<_lua_getfield>
mov	x0, x19
mov	w1, #-0x1               ; =-1
bl	<_lua_type>
cbz	w0, <_main.execute>
ldr	x0, [sp, #0x90]
mov	w1, #-0x1               ; =-1
bl	<_lua_type>
cmp	w0, #0x5
b.ne	<_main.execute>
ldr	x19, [sp, #0xd0]
ldur	x8, [x19, #0x1a]
ldr	x24, [x8, #0x20]
mov	x0, x24
mov	w1, #-0x1               ; =-1
bl	<_lua_absindex>
str	w0, [sp, #0x70]
ldr	x8, [sp, #0x98]
ldrb	w26, [x8, #0x53]
ldur	x0, [x19, #0x2]
ldur	x8, [x19, #0xa]
ldr	x8, [x8]
mov	w1, #0xf4f8             ; =62712
movk	w1, #0x11, lsl #16
mov	w2, #0x3                ; =3
ldr	x3, [sp, #0xb0]
blr	x8
str	x0, [sp, #0x88]
cbz	x0, <_main.execute>
ldr	x8, [sp, #0x98]
add	x8, x8, #0x13
str	x8, [sp, #0x68]
mov	x0, x24
bl	<_lua_pushnil>
mov	x0, x24
ldr	w1, [sp, #0x70]
bl	<_lua_next>
cbz	w0, <_main.execute>
cmp	w26, #0x0
ldr	x8, [sp, #0x68]
csinc	x10, x8, xzr, ne
ldr	x9, [sp, #0x150]
add	x8, x9, #0x130, lsl #12 ; =0x130000
add	x8, x8, #0x238
stp	x8, x10, [sp, #0x48]
add	x8, x9, #0x14a, lsl #12 ; =0x14a000
add	x10, x8, #0x238
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldrb	w9, [x8]
str	w9, [sp, #0x60]
ldrb	w8, [x8, #0x1]
str	w8, [sp, #0x58]
sub	x8, x26, #0x1
str	x8, [sp, #0x20]
lsr	x8, x8, #4
stp	x8, x10, [sp, #0x38]
sub	x10, x26, #0x10
sub	x8, x26, #0x4
lsr	x9, x26, #1
str	x9, [sp, #0x10]
and	x9, x9, #0xc
stp	x8, x10, [sp, #0x28]
str	x9, [sp, #0x18]
sub	x8, x8, x9
str	x8, [sp, #0x8]
mov	x0, x24
mov	w1, #-0x2               ; =-2
bl	<_lua_type>
cmp	w0, #0x4
b.ne	<_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
str	xzr, [x8]
add	x2, sp, #0x39, lsl #12  ; =0x39000
add	x2, x2, #0x430
mov	x0, x24
mov	w1, #-0x2               ; =-2
bl	<_lua_tolstring>
mov	x19, x0
cbz	x0, <_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x25, [x8]
b	<_main.execute>
mov	x19, #0x0               ; =0
mov	x25, #0x0               ; =0
cbz	x19, <_main.execute>
sub	x8, x25, #0x41
cmn	x8, #0x40
b.lo	<_main.execute>
mov	x13, x25
mov	x12, x19
mov	x8, #0x0                ; =0
b	<_main.execute>
add	x8, x8, #0x1
cmp	x13, x8
b.eq	<_main.execute>
ldrb	w9, [x12, x8]
sub	w10, w9, #0x30
and	w11, w9, #0xffffffdf
sub	w11, w11, #0x41
cmp	w10, #0xa
ccmp	w11, #0x1a, #0x0, hs
b.lo	<_main.execute>
cmp	w9, #0x5f
b.eq	<_main.execute>
cmp	w9, #0x2d
b.eq	<_main.execute>
b	<_main.execute>
mov	x0, x24
mov	w1, #-0x1               ; =-1
bl	<_lua_type>
cmp	w0, #0x5
b.ne	<_main.execute>
ldr	x8, [sp, #0x98]
ldrb	w8, [x8, #0x53]
cbz	w8, <_main.execute>
cmp	x25, x26
b.ne	<_main.execute>
ldr	x8, [sp, #0x68]
cmp	x19, x8
b.eq	<_main.execute>
mov	x8, x19
ldr	x9, [sp, #0x50]
ldr	x10, [sp, #0x38]
cmp	w26, #0x11
b.hs	<_main.execute>
cmp	w26, #0x3
b.hi	<_main.execute>
ldrb	w8, [x19]
ldr	x9, [sp, #0x68]
ldrb	w9, [x9]
cmp	w8, w9
b.ne	<_main.execute>
ldr	x10, [sp, #0x20]
ldrb	w8, [x19, x10]
ldr	x9, [sp, #0x68]
ldrb	w9, [x9, x10]
cmp	w8, w9
b.ne	<_main.execute>
ldr	x10, [sp, #0x10]
ldrb	w8, [x19, x10]
ldr	x9, [sp, #0x68]
ldrb	w9, [x9, x10]
cmp	w8, w9
b.eq	<_main.execute>
b	<_main.execute>
ldr	q0, [x8], #0x10
ldr	q1, [x9], #0x10
cmeq.16b	v0, v0, v1
mvn.16b	v0, v0
umaxv.16b	b0, v0
fmov	w11, s0
tbnz	w11, #0x0, <_main.execute>
subs	x10, x10, #0x1
b.ne	<_main.execute>
ldr	x9, [sp, #0x30]
ldr	q0, [x19, x9]
ldr	x8, [sp, #0x50]
ldr	q1, [x8, x9]
cmeq.16b	v0, v0, v1
mvn.16b	v0, v0
umaxv.16b	b0, v0
fmov	w8, s0
tbnz	w8, #0x0, <_main.execute>
b	<_main.execute>
ldr	w8, [x19]
ldr	x9, [sp, #0x68]
ldr	w9, [x9]
cmp	w9, w8
b.ne	<_main.execute>
ldr	x10, [sp, #0x28]
ldr	w8, [x19, x10]
ldr	x9, [sp, #0x68]
ldr	w9, [x9, x10]
cmp	w9, w8
b.ne	<_main.execute>
ldr	x10, [sp, #0x18]
ldr	w8, [x19, x10]
ldr	x9, [sp, #0x68]
ldr	w9, [x9, x10]
cmp	w9, w8
b.ne	<_main.execute>
ldr	x10, [sp, #0x8]
ldr	w8, [x19, x10]
ldr	x9, [sp, #0x68]
ldr	w9, [x9, x10]
cmp	w9, w8
b.eq	<_main.execute>
ldr	x21, [sp, #0x150]
mov	w8, #0x8b0              ; =2224
movk	w8, #0x1, lsl #16
add	x1, x21, x8
ldr	x0, [sp, #0x88]
mov	w2, #0xf4f8             ; =62712
movk	w2, #0x11, lsl #16
bl	<_memmove>
ldr	x23, [sp, #0x98]
ldrh	w19, [x23, #0x10]
ldrb	w22, [x23, #0x12]
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w8, #0xfdb0             ; =64944
movk	w8, #0x12, lsl #16
add	x1, x21, x8
mov	w2, #0x488              ; =1160
bl	<_memcpy>
ldp	x25, x20, [x23]
add	x1, sp, #0x29, lsl #12  ; =0x29000
add	x1, x1, #0x430
mov	x0, x21
bl	<_config.Generation.parseProfile>
mov	x28, x0
ldr	x8, [sp, #0xd0]
ldur	x8, [x8, #0x1a]
ldr	x27, [x8, #0x20]
ldrh	w8, [x23, #0x10]
cmp	w8, w19
b.eq	<_main.execute>
ldr	x9, [sp, #0x48]
mov	w10, #0xd0              ; =208
umaddl	x21, w19, w10, x9
sub	x23, x8, x19
ldr	w2, [x21], #0xd0
mov	x0, x27
mov	w1, #0xfc19             ; =64537
movk	w1, #0xbfff, lsl #16
bl	<_luaL_unref>
subs	x23, x23, #0x1
b.ne	<_main.execute>
ldr	x8, [sp, #0x98]
ldrb	w8, [x8, #0x12]
cmp	w8, w22
b.eq	<_main.execute>
ldr	x9, [sp, #0x40]
add	x21, x9, x22, lsl #2
sub	x23, x8, x22
ldr	w2, [x21], #0x4
mov	x0, x27
mov	w1, #0xfc19             ; =64537
movk	w1, #0xbfff, lsl #16
bl	<_luaL_unref>
subs	x23, x23, #0x1
b.ne	<_main.execute>
ldr	x9, [sp, #0x98]
ldp	x8, x9, [x9]
ldr	w10, [sp, #0x60]
tst	w10, #0x1
csel	x2, x9, x8, ne
tst	x2, #0xff00000000
b.eq	<_main.execute>
ldr	w10, [sp, #0x60]
tst	w10, #0x1
csel	x10, x20, x25, ne
tst	x10, #0xff00000000
b.eq	<_main.execute>
cmp	w10, w2
b.eq	<_main.execute>
mov	x0, x27
mov	w1, #0xfc19             ; =64537
movk	w1, #0xbfff, lsl #16
bl	<_luaL_unref>
ldr	x9, [sp, #0x98]
ldp	x8, x9, [x9]
ldr	w10, [sp, #0x58]
tst	w10, #0x1
csel	x2, x9, x8, ne
tst	x2, #0xff00000000
b.eq	<_main.execute>
ldr	w8, [sp, #0x58]
tst	w8, #0x1
csel	x8, x20, x25, ne
tst	x8, #0xff00000000
b.eq	<_main.execute>
cmp	w8, w2
b.eq	<_main.execute>
mov	x0, x27
mov	w1, #0xfc19             ; =64537
movk	w1, #0xbfff, lsl #16
bl	<_luaL_unref>
ldr	x21, [sp, #0x150]
mov	w8, #0x8b0              ; =2224
movk	w8, #0x1, lsl #16
add	x0, x21, x8
ldr	x1, [sp, #0x88]
mov	w2, #0xf4f8             ; =62712
movk	w2, #0x11, lsl #16
bl	<_memmove>
ldr	x23, [sp, #0x98]
strh	w19, [x23, #0x10]
strb	w22, [x23, #0x12]
mov	w8, #0xfdb0             ; =64944
movk	w8, #0x12, lsl #16
add	x0, x21, x8
add	x1, sp, #0x39, lsl #12  ; =0x39000
add	x1, x1, #0x430
mov	w2, #0x488              ; =1160
bl	<_memcpy>
stp	x25, x20, [x23]
tst	w28, #0xffff
b.ne	<_main.execute>
mov	x0, x24
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
mov	x0, x24
ldr	w1, [sp, #0x70]
bl	<_lua_next>
cbnz	w0, <_main.execute>
ldr	x8, [sp, #0x98]
ldrb	w8, [x8, #0x53]
cbz	w8, <_main.execute>
mov	x0, x24
ldr	x1, [sp, #0x68]
mov	x2, x26
bl	<_lua_pushlstring>
mov	x0, x24
ldr	w1, [sp, #0x70]
bl	<_lua_rawget>
mov	x0, x24
mov	w1, #-0x1               ; =-1
bl	<_lua_type>
cmp	w0, #0x5
b.ne	<_main.execute>
add	x1, sp, #0x29, lsl #12  ; =0x29000
add	x1, x1, #0x430
ldr	x0, [sp, #0x150]
bl	<_config.Generation.parseProfile>
mov	x28, x0
b	<_main.execute>
mov	x28, x0
add	x0, sp, #0x230
b	<_main.execute>
add	x0, sp, #0x430
b	<_main.execute>
mov	x28, x0
add	x0, sp, #0x430
b	<_main.execute>
mov	x28, x0
add	x0, sp, #0x630
bl	<_DamageContext.deinit>
b	<_main.execute>
mov	x21, #0x0               ; =0
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x430
add	x20, x8, #0x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
stp	x8, x20, [x27]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [x27, #0x10]
adrp x22, RELOC_PAGE
add	x22, x22, #RELOC_OFFSET
mov	w23, #0x1e              ; =30
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
add	x1, x22, x21
ldp	x9, x8, [x27, #0x10]
sub	x19, x23, x21
add	x10, x8, x19
cmp	x10, x9
b.hi	<_main.execute>
ldr	x9, [x27, #0x8]
add	x0, x9, x8
mov	x2, x19
bl	<_memcpy>
ldr	x8, [x27, #0x18]
add	x8, x8, x19
str	x8, [x27, #0x18]
add	x21, x19, x21
cmp	x21, #0x1e
b.lo	<_main.execute>
b	<_main.execute>
mov	x28, x26
mov	x26, x25
add	x24, sp, #0x39, lsl #12 ; =0x39000
add	x24, x24, #0x430
ldr	x8, [x27]
ldr	x9, [x8]
add	x25, sp, #0x8b, lsl #12 ; =0x8b000
add	x25, x25, #0x1b8
str	x1, [x25, #0x2a0]
str	x19, [x25, #0x2a8]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x1b8
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
sub	x1, x29, #0xb8
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x9, sp, #0x8b, lsl #12  ; =0x8b000
add	x9, x9, #0x1b8
ldrh	w8, [x25, #0x8]
cbnz	w8, <_main.execute>
ldr	x19, [x9]
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
mov	x25, x26
mov	x26, x28
add	x21, x19, x21
cmp	x21, #0x1e
b.lo	<_main.execute>
ldr	x8, [x27, #0x18]
str	x8, [x24, #0x90]
mov	w28, #0x6e              ; =110
b	<_main.execute>
mov	x24, x26
mov	x26, x25
mov	x21, #0x0               ; =0
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x430
add	x20, x8, #0x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
stp	x8, x20, [x27]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [x27, #0x10]
adrp x22, RELOC_PAGE
add	x22, x22, #RELOC_OFFSET
mov	w23, #0x25              ; =37
add	x1, x22, x21
ldp	x9, x8, [x27, #0x10]
sub	x19, x23, x21
add	x10, x8, x19
cmp	x10, x9
b.hi	<_main.execute>
ldr	x9, [x27, #0x8]
add	x0, x9, x8
mov	x2, x19
bl	<_memcpy>
ldr	x8, [x27, #0x18]
add	x8, x8, x19
str	x8, [x27, #0x18]
add	x21, x19, x21
cmp	x21, #0x25
b.lo	<_main.execute>
b	<_main.execute>
add	x28, sp, #0x39, lsl #12 ; =0x39000
add	x28, x28, #0x430
ldr	x8, [x27]
ldr	x9, [x8]
add	x25, sp, #0x8b, lsl #12 ; =0x8b000
add	x25, x25, #0x1b8
str	x1, [x25, #0x2a0]
str	x19, [x25, #0x2a8]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x1b8
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
sub	x1, x29, #0xb8
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x9, sp, #0x8b, lsl #12  ; =0x8b000
add	x9, x9, #0x1b8
ldrh	w8, [x25, #0x8]
cbnz	w8, <_main.execute>
ldr	x19, [x9]
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
add	x21, x19, x21
cmp	x21, #0x25
b.lo	<_main.execute>
ldr	x8, [x27, #0x18]
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
str	x8, [x9, #0x90]
mov	w28, #0x6e              ; =110
mov	x25, x26
mov	x26, x24
b	<_main.execute>
mov	x28, x0
b	<_main.execute>
mov	x28, x0
b	<_main.execute>
mov	x21, #0x0               ; =0
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x430
add	x20, x8, #0x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
stp	x8, x20, [x24]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [x24, #0x10]
adrp x22, RELOC_PAGE
add	x22, x22, #RELOC_OFFSET
mov	w23, #0x16              ; =22
add	x1, x22, x21
ldp	x9, x8, [x24, #0x10]
sub	x19, x23, x21
add	x10, x8, x19
cmp	x10, x9
b.hi	<_main.execute>
ldr	x9, [x24, #0x8]
add	x0, x9, x8
mov	x2, x19
bl	<_memcpy>
ldr	x8, [x24, #0x18]
add	x8, x8, x19
str	x8, [x24, #0x18]
add	x21, x19, x21
cmp	x21, #0x16
b.lo	<_main.execute>
b	<_main.execute>
ldr	x8, [x24]
ldr	x9, [x8]
str	x1, [x24, #0x2a0]
add	x25, sp, #0x8b, lsl #12 ; =0x8b000
add	x25, x25, #0x1b8
str	x19, [x24, #0x2a8]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x1b8
sub	x1, x29, #0xb8
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldrh	w8, [x8, #0x8]
cbnz	w8, <_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x19, [x8]
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x21, x19, x21
cmp	x21, #0x16
b.lo	<_main.execute>
add	x25, sp, #0x8b, lsl #12 ; =0x8b000
add	x25, x25, #0x1b8
cmp	x28, #0x0
cneg	x8, x28, mi
cmp	x8, #0x64
b.lo	<_main.execute>
mov	w9, #0x3f               ; =63
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
mov	w11, #0x64              ; =100
add	x12, sp, #0x39, lsl #12 ; =0x39000
add	x12, x12, #0x430
adrp x13, RELOC_PAGE
add	x13, x13, #RELOC_OFFSET
mov	x14, x8
lsr	x8, x8, #2
umulh	x8, x8, x10
lsr	x8, x8, #2
msub	x15, x8, x11, x14
ldrh	w15, [x13, x15, lsl #1]
strh	w15, [x12, x9]
sub	x9, x9, #0x2
lsr	x14, x14, #4
cmp	x14, #0x270
b.hi	<_main.execute>
add	x9, x9, #0x2
b	<_main.execute>
cmp	x8, x22
b.eq	<_main.execute>
ldr	x8, [sp, #0x108]
cmp	x2, x8
b.hs	<_main.execute>
ldr	x8, [sp, #0x108]
mul	x0, x19, x8
umulh	x1, x19, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x19, x8
csel	x19, x19, x8, hi
ldr	x9, [x21, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
mov	x20, #0x0               ; =0
mov	x22, x19
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
add	x24, sp, #0x71, lsl #12 ; =0x71000
add	x24, x24, #0x700
add	x8, sp, #0xb, lsl #12   ; =0xb000
add	x8, x8, #0x5b8
ldp	x1, x2, [x8, #0x158]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
bl	<_media.shared_transfer.freezeSharedPixels>
ldrb	w8, [x24, #0x21]
add	x9, sp, #0x71, lsl #12  ; =0x71000
add	x9, x9, #0x700
cbz	w8, <_main.execute>
ldp	q0, q1, [x9]
stp	q0, q1, [x23, #0x90]
ldrb	w8, [x9, #0x20]
strb	w8, [x23, #0xb0]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x24, sp, #0x71, lsl #12 ; =0x71000
add	x24, x24, #0x700
bl	<dyld_stub_binder>
ldrb	w8, [x23, #0xb0]
add	x20, x20, x8
subs	x22, x22, #0x1
b.ne	<_main.execute>
ldr	x9, [x21, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
mov	x20, #0x0               ; =0
add	x22, sp, #0x39, lsl #12 ; =0x39000
add	x22, x22, #0x430
ldr	x9, [x21, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
mov	x25, #0x0               ; =0
add	x28, sp, #0x71, lsl #12 ; =0x71000
add	x28, x28, #0x700
ldr	x27, [x28]
mov	x23, x19
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
add	x8, sp, #0xb, lsl #12   ; =0xb000
add	x8, x8, #0x5b8
ldp	x1, x2, [x8, #0x158]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
bl	<_media.shared_transfer.freezeSharedPixels>
ldrb	w8, [x28, #0x21]
add	x9, sp, #0x71, lsl #12  ; =0x71000
add	x9, x9, #0x700
cbz	w8, <_main.execute>
ldp	q0, q1, [x9]
stp	q0, q1, [x24, #0x90]
ldrb	w8, [x9, #0x20]
strb	w8, [x24, #0xb0]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x28, sp, #0x71, lsl #12 ; =0x71000
add	x28, x28, #0x700
bl	<dyld_stub_binder>
ldrb	w8, [x24, #0xb0]
add	x25, x25, x8
subs	x23, x23, #0x1
b.ne	<_main.execute>
ldr	x9, [x21, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x26
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [x28]
sub	x8, x8, x27
udiv	x8, x8, x19
str	x8, [x22, x20, lsl #3]
add	x20, x20, #0x1
ldr	x8, [sp, #0x148]
cmp	x20, x8
b.ne	<_main.execute>
add	x20, sp, #0x39, lsl #12 ; =0x39000
add	x20, x20, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x21, [sp, #0x148]
mov	x1, x21
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x21, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x21, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
ldr	x10, [x27]
lsr	x11, x21, #1
ldr	x11, [x20, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x20, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x20, x9
ldur	x9, [x9, #-0x8]
add	x12, sp, #0xb, lsl #12  ; =0xb000
add	x12, x12, #0xa08
stp	x19, x11, [x12, #0x60]
stp	x10, x8, [x12, #0x70]
str	x9, [x12, #0x80]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0xb, lsl #12   ; =0xb000
add	x0, x0, #0xa08
add	x2, sp, #0xb, lsl #12   ; =0xb000
add	x2, x2, #0xa68
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
ldr	x26, [sp, #0x100]
b.ne	<_main.execute>
add	x8, sp, #0xb, lsl #12   ; =0xb000
add	x8, x8, #0x5b8
ldr	x25, [x8, #0x168]
add	x8, x25, #0x31, lsl #12 ; =0x31000
mov	w9, #0x1b71             ; =7025
movk	w9, #0x3, lsl #16
ldrb	w10, [x8, #0xb72]
cbz	w10, <_main.execute>
ldrb	w10, [x25, x9]
mov	w11, #0x318             ; =792
movk	w11, #0x1, lsl #16
and	x10, x10, #0x1
umaddl	x10, w10, w11, x25
mov	w11, #0x1818            ; =6168
movk	w11, #0x1, lsl #16
strh	wzr, [x10, x11]
str	xzr, [x10, #0x1510]
str	xzr, [x10, #0x1508]
strh	wzr, [x25, x9]
ldrb	w8, [x8, #0xb73]
add	x19, sp, #0x29, lsl #12 ; =0x29000
add	x19, x19, #0x3a0
ldr	x23, [sp, #0xe8]
ldr	x21, [sp, #0x160]
tbz	w8, #0x0, <_main.execute>
add	x0, x25, #0x980
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).deinit>
ldr	q0, [x25, #0x14e0]
str	q0, [x27]
add	x1, sp, #0x39, lsl #12  ; =0x39000
add	x1, x1, #0x430
mov	x0, x25
bl	<_terminal.Terminal.deinit>
add	x20, sp, #0xb, lsl #12  ; =0xb000
add	x20, x20, #0x5b8
ldp	x0, x8, [x20, #0x148]
ldr	x1, [x20, #0x168]
ldr	x8, [x8, #0x18]
mov	w2, #0x1b78             ; =7032
movk	w2, #0x3, lsl #16
mov	w3, #0x3                ; =3
ldr	x22, [sp, #0x150]
mov	x4, x22
blr	x8
ldr	x2, [x20, #0x160]
cbz	x2, <_main.execute>
ldp	x8, x1, [x20, #0x150]
ldr	x0, [x20, #0x148]
ldr	x8, [x8, #0x18]
mov	w3, #0x0                ; =0
mov	x4, x22
blr	x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0xba90]
str	q1, [sp, #0xbaa0]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0xbab0]
ldr	x8, [x8, #0x30]
add	x9, sp, #0xb, lsl #12   ; =0xb000
add	x9, x9, #0xa08
str	x8, [x9, #0xb8]
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x26               ; =38
mov	x3, #0x0                ; =0
mov	x4, x26
ldr	x5, [sp, #0x120]
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
ldr	x21, [sp, #0x1e8]
ldr	x26, [sp, #0x1e0]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_FT_Init_FreeType>
cbz	w0, <_main.execute>
mov	w28, #0x92              ; =146
b	<_main.execute>
add	x0, sp, #0xb, lsl #12   ; =0xb000
add	x0, x0, #0x6f0
bl	<_SharedFrameContext.deinit>
mov	w28, #0x420             ; =1056
b	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0xbc60]
str	q1, [sp, #0xbc70]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0xbc80]
ldr	x8, [x8, #0x30]
add	x9, sp, #0xb, lsl #12   ; =0xb000
add	x9, x9, #0xb60
str	x8, [x9, #0x130]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x18               ; =24
mov	x3, #0x0                ; =0
mov	x4, x26
ldr	x5, [sp, #0x120]
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
add	x19, sp, #0x8a, lsl #12 ; =0x8a000
add	x19, x19, #0x330
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
adrp x3, RELOC_PAGE
add	x3, x3, #RELOC_OFFSET
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x1d0
add	x2, sp, #0x1e0
bl	<_terminal.Terminal.init>
ldrh	w28, [x19, #0x980]
cbnz	w28, <_main.execute>
add	x0, sp, #0x89, lsl #12  ; =0x89000
add	x0, x0, #0x9b0
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0x330
mov	w2, #0x980              ; =2432
bl	<_memcpy>
adrp x25, RELOC_PAGE
add	x25, x25, #RELOC_OFFSET
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0xcc0
mov	x1, x25
mov	w2, #0x4f0              ; =1264
bl	<_memcpy>
tbnz	wzr, #0x0, <_main.execute>
ldp	x21, x22, [sp, #0x1e0]
ldr	x20, [sp, #0x110]
xpaci	x20
mov	w19, #0xc840            ; =51264
movk	w19, #0x2, lsl #16
ldr	x8, [x22]
mov	x0, x21
mov	w1, #0xc840             ; =51264
movk	w1, #0x2, lsl #16
mov	w2, #0x1                ; =1
mov	x3, x20
blr	x8
cbz	x0, <_main.execute>
stp	x22, x21, [sp, #0x48]
str	x20, [sp, #0x110]
mov	x8, #0x0                ; =0
add	x26, sp, #0x29, lsl #12 ; =0x29000
add	x26, x26, #0x430
sub	x9, x29, #0xb8
add	x10, x9, #0x40
add	x9, x9, #0x3f
stp	x9, x10, [sp, #0x58]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
ldp	q0, q1, [x9]
add	x9, x0, x8
stp	q0, q1, [x9]
add	x8, x8, #0x20
cmp	x19, x8
b.ne	<_main.execute>
str	x0, [sp, #0x40]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x89, lsl #12  ; =0x89000
add	x1, x1, #0x9b0
bl	<_terminal.Terminal.vtStream>
add	x19, sp, #0x29, lsl #12 ; =0x29000
add	x19, x19, #0x430
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0x71, lsl #12  ; =0x71000
add	x1, x1, #0x700
mov	w2, #0xb60              ; =2912
bl	<_memcpy>
mov	x9, #0x0                ; =0
adrp x8, RELOC_PAGE
ldrb	w8, [x8, #RELOC_OFFSET]
str	w8, [sp, #0x68]
add	x8, x19, #0xb0f
str	x8, [sp, #0xb0]
adrp x8, RELOC_PAGE
ldr	w8, [x8, #RELOC_OFFSET]
str	w8, [sp, #0xb8]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
add	x8, x8, #0x4
str	x8, [sp, #0x160]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [sp, #0x70]
adrp x22, RELOC_PAGE
add	x22, x22, #RELOC_OFFSET
mov	w27, #0x2               ; =2
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [sp, #0xc0]
mov	x20, #0x0               ; =0
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
str	x8, [x24, #0x200]
mov	x19, x9
str	x24, [x24, #0x208]
ldr	q0, [sp, #0x70]
str	q0, [x24, #0x210]
add	x21, x9, #0x1
add	x1, x22, x20
ldr	x8, [x24, #0x218]
sub	x25, x27, x20
add	x9, x8, x25
ldr	x10, [x24, #0x210]
cmp	x9, x10
b.hi	<_main.execute>
ldr	x9, [x24, #0x208]
add	x0, x9, x8
mov	x2, x25
bl	<_memcpy>
ldr	x8, [x24, #0x218]
add	x8, x8, x25
str	x8, [x24, #0x218]
add	x20, x25, x20
cmp	x20, #0x2
b.lo	<_main.execute>
b	<_main.execute>
ldr	x8, [x24, #0x200]
ldr	x9, [x8]
sub	x8, x29, #0xb8
stp	x1, x25, [x8, #0x48]
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x3b8
sub	x1, x29, #0x70
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w28, [x24, #0x2a8]
cbnz	w28, <_main.execute>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
ldr	x25, [x24, #0x2a0]
adrp x22, RELOC_PAGE
add	x22, x22, #RELOC_OFFSET
mov	w27, #0x2               ; =2
add	x20, x25, x20
cmp	x20, #0x2
b.lo	<_main.execute>
cmp	x19, #0x8
b.hi	<_main.execute>
orr	w8, w21, #0x30
strb	w8, [x24, #0x2e0]
ldr	x1, [sp, #0x60]
mov	w2, #0x1                ; =1
b	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldrh	w8, [x8, x21, lsl #1]
sub	x9, x29, #0xb8
sturh	w8, [x9, #0x3f]
ldr	x1, [sp, #0x58]
mov	w2, #0x2                ; =2
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x3b8
mov	x3, x2
ldr	w4, [sp, #0x68]
mov	w5, #0x20               ; =32
bl	<_Io.Writer.alignBuffer>
tst	w0, #0xffff
b.ne	<_main.execute>
mov	x20, #0x0               ; =0
adrp x22, RELOC_PAGE
add	x22, x22, #RELOC_OFFSET
mov	w28, #0x8               ; =8
add	x1, x22, x20
eor	x25, x20, #0x3
ldr	x8, [x24, #0x218]
ldr	x9, [x24, #0x210]
add	x10, x8, x25
cmp	x10, x9
b.hi	<_main.execute>
ldr	x9, [x24, #0x208]
add	x0, x9, x8
mov	x2, x25
bl	<_memcpy>
ldr	x8, [x24, #0x218]
add	x8, x8, x25
str	x8, [x24, #0x218]
add	x20, x25, x20
cmp	x20, #0x3
b.lo	<_main.execute>
b	<_main.execute>
mov	x22, x21
ldr	x8, [x24, #0x200]
ldr	x9, [x8]
sub	x21, x29, #0xb8
stp	x1, x25, [x21, #0x48]
sub	x8, x29, #0xb8
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x3b8
sub	x1, x29, #0x70
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w28, [x21, #0x8]
cbnz	w28, <_main.execute>
sub	x8, x29, #0xb8
ldr	x25, [x8]
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
mov	x21, x22
adrp x22, RELOC_PAGE
add	x22, x22, #RELOC_OFFSET
mov	w28, #0x8               ; =8
add	x20, x25, x20
cmp	x20, #0x3
b.lo	<_main.execute>
str	x21, [sp, #0x88]
mov	w20, #0x8               ; =8
b	<_main.execute>
add	x19, x19, #0x3
cmp	x20, #0x93
add	x20, x20, #0x8
b.hs	<_main.execute>
mov	x8, #-0x3333333333333334 ; =-3689348814741910324
movk	x8, #0xcccd
umulh	x8, x19, x8
lsr	x8, x8, #2
add	x8, x8, x8, lsl #2
sub	x8, x19, x8
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
add	x8, x9, x8, lsl #4
ldr	x21, [x8, #0x8]
cbz	x21, <_main.execute>
mov	x22, #0x0               ; =0
ldr	x27, [x8]
add	x1, x27, x22
ldr	x8, [x24, #0x218]
sub	x25, x21, x22
add	x9, x8, x25
ldr	x10, [x24, #0x210]
cmp	x9, x10
b.hi	<_main.execute>
ldr	x9, [x24, #0x208]
add	x0, x9, x8
mov	x2, x25
bl	<_memcpy>
ldr	x8, [x24, #0x218]
add	x8, x8, x25
str	x8, [x24, #0x218]
add	x22, x25, x22
cmp	x22, x21
b.lo	<_main.execute>
b	<_main.execute>
ldr	x8, [x24, #0x200]
ldr	x9, [x8]
sub	x24, x29, #0xb8
stp	x1, x25, [x24, #0x48]
sub	x8, x29, #0xb8
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x3b8
sub	x1, x29, #0x70
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w28, [x24, #0x8]
cbnz	w28, <_main.execute>
sub	x8, x29, #0xb8
ldr	x25, [x8]
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
mov	w28, #0x8               ; =8
add	x22, x25, x22
cmp	x22, x21
b.lo	<_main.execute>
mov	x21, #0x0               ; =0
mov	x8, #0x2493             ; =9363
movk	x8, #0x9249, lsl #16
movk	x8, #0x4924, lsl #32
movk	x8, #0x2492, lsl #48
umulh	x8, x19, x8
sub	x9, x19, x8
add	x8, x8, x9, lsr #1
lsr	x8, x8, #2
sub	x8, x8, x8, lsl #3
cmn	x19, x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
csel	x22, x9, x8, eq
mov	w8, #0xc                ; =12
csel	x27, x8, x28, eq
add	x1, x22, x21
ldr	x8, [x24, #0x218]
sub	x25, x27, x21
add	x9, x8, x25
ldr	x10, [x24, #0x210]
cmp	x9, x10
b.hi	<_main.execute>
ldr	x9, [x24, #0x208]
add	x0, x9, x8
mov	x2, x25
bl	<_memcpy>
ldr	x8, [x24, #0x218]
add	x8, x8, x25
str	x8, [x24, #0x218]
add	x21, x25, x21
cmp	x21, x27
b.lo	<_main.execute>
b	<_main.execute>
ldr	x8, [x24, #0x200]
ldr	x9, [x8]
sub	x24, x29, #0xb8
stp	x1, x25, [x24, #0x48]
sub	x8, x29, #0xb8
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x3b8
sub	x1, x29, #0x70
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w28, [x24, #0x8]
cbnz	w28, <_main.execute>
sub	x8, x29, #0xb8
ldr	x25, [x8]
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
mov	w28, #0x8               ; =8
add	x21, x25, x21
cmp	x21, x27
b.lo	<_main.execute>
b	<_main.execute>
mov	x10, #0x0               ; =0
ldr	x2, [x24, #0x218]
ldr	x8, [x24, #0x208]
stp	x2, x8, [sp, #0x90]
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
b	<_main.execute>
ldr	x10, [sp, #0xa8]
ldr	x8, [sp, #0x150]
add	x10, x8, x10
ldr	x2, [sp, #0x90]
cmp	x10, x2
b.hs	<_main.execute>
sub	x8, x2, x10
cmp	x8, #0x1, lsl #12       ; =0x1000
mov	w9, #0x1000             ; =4096
csel	x8, x8, x9, lo
str	x8, [sp, #0x150]
ldr	x8, [sp, #0x98]
add	x8, x8, x10
str	x8, [sp, #0xd0]
ldrb	w8, [x23, #0xbec]
str	x10, [sp, #0xa8]
mov	x28, #0x0               ; =0
cbnz	w8, <_main.execute>
ldr	x8, [sp, #0x150]
subs	x19, x8, x28
b.ls	<_main.execute>
ldrb	w8, [x23, #0xb9e]
mov	x20, #0x0               ; =0
ands	w8, w8, #0xf
b.eq	<_main.execute>
ldr	x9, [sp, #0xd0]
add	x21, x9, x28
subs	x2, x19, x20
b.ls	<_main.execute>
cmp	w8, #0x5
b.eq	<_main.execute>
cmp	w8, #0x3
b.eq	<_main.execute>
cmp	w8, #0x1
b.ne	<_main.execute>
ldrb	w8, [x21, x20]
cmp	w8, #0x5b
b.ne	<_main.execute>
mov	w8, #0x3                ; =3
strb	w8, [x26, #0xb0e]
b	<_main.execute>
ldrb	w1, [x21, x20]
cmp	w1, #0x3b
b.ne	<_main.execute>
mov	w8, #0x5                ; =5
strb	w8, [x26, #0xb0e]
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
strh	wzr, [x8, #0xb6c]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
mov	w9, #0x1                ; =1
strb	w9, [x8, #0xba4]
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, x21, x20
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).consumeCsiParams>
add	x20, x0, x20
cmp	x20, x19
b.hs	<_main.execute>
ldrb	w8, [x23, #0xb9e]
and	w8, w8, #0xf
cmp	w8, #0x5
b.ne	<_main.execute>
add	x1, x21, x20
b	<_main.execute>
add	x1, x21, x20
cmp	w8, #0xd
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).consumeApcString>
add	x20, x0, x20
cmp	x20, x19
b.hs	<_main.execute>
ldrb	w1, [x21, x20]
cmp	w1, #0x9c
b.eq	<_main.execute>
cmp	w1, #0x1b
b.ne	<_main.execute>
add	x8, x27, #0xb13
strh	wzr, [x8]
strb	wzr, [x26, #0xada]
strh	wzr, [x26, #0xad8]
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
strh	wzr, [x8, #0xb9c]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
strb	wzr, [x8, #0xba5]
mov	w8, #0x1                ; =1
strb	w8, [x26, #0xb0e]
b	<_main.execute>
ldrb	w1, [x1]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).nextNonUtf8>
add	x20, x20, #0x1
ldrb	w8, [x23, #0xb9e]
ands	w8, w8, #0xf
b.ne	<_main.execute>
b	<_main.execute>
sub	w8, w1, #0x30
cmp	w8, #0xa
b.hs	<_main.execute>
mov	w9, #0x5                ; =5
strb	w9, [x26, #0xb0e]
and	w8, w8, #0xff
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
strh	w8, [x9, #0xb9c]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
mov	w8, #0x1                ; =1
strb	w8, [x9, #0xba5]
b	<_main.execute>
and	w8, w1, #0xfc
cmp	w8, #0x3c
b.ne	<_main.execute>
mov	w8, #0x5                ; =5
strb	w8, [x26, #0xb0e]
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
ldrb	w8, [x9, #0xba3]
cmp	x8, #0x3
b.ls	<_main.execute>
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
bl	<_log.scoped(.parser).warn__anon>
b	<_main.execute>
strb	wzr, [x26, #0xb0e]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
sub	w8, w1, #0x40
cmp	w8, #0x3f
b.hs	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).csiDispatchFinal>
b	<_main.execute>
ldr	x10, [sp, #0xb0]
strb	w1, [x10, x8]
ldrb	w8, [x9, #0xba3]
add	w8, w8, #0x1
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
strb	w8, [x9, #0xba3]
b	<_main.execute>
strh	w8, [x24, #0x230]
lsr	w8, w8, #16
strb	w8, [x24, #0x232]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0x8b, lsl #12  ; =0x8b000
add	x1, x1, #0x3e8
bl	<_terminal.stream_terminal.Handler.vt__anon>
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
tbz	w25, #0x0, <_main.execute>
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
ldrb	w8, [x24, #0xbec]
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x28, x28, #0x1
cbz	w8, <_main.execute>
ldr	x9, [sp, #0x150]
cmp	x9, x28
b.eq	<_main.execute>
ldr	x9, [sp, #0xd0]
ldrb	w20, [x9, x28]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
ldrb	w21, [x9, w20, uxtw]
add	x11, sp, #0x29, lsl #12 ; =0x29000
add	x11, x11, #0x3a0
ldr	w9, [x11, #0xbe8]
lsl	w9, w9, #6
strh	w9, [x26, #0xb58]
ubfx	w9, w9, #16, #5
strb	w9, [x26, #0xb5a]
ldr	w9, [x11, #0xbe8]
and	w22, w20, #0x3f
orr	w10, w9, w22
ubfx	w9, w9, #16, #5
strb	w9, [x26, #0xb5a]
strh	w10, [x26, #0xb58]
and	x19, x21, #0xf
add	x8, x19, w8, uxtw
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
ldrb	w8, [x9, x8]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
strb	w8, [x11, #0xbec]
cbz	w8, <_main.execute>
cmp	w8, #0xc
b.ne	<_main.execute>
strb	wzr, [x26, #0xb5a]
strh	wzr, [x26, #0xb58]
strb	wzr, [x23, #0xbec]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x3e0
ldr	w1, [sp, #0xb8]
strb	wzr, [x24, #0x228]
b	<_main.execute>
ldr	w8, [x23, #0xbe8]
strh	w8, [x24, #0x224]
ubfx	w9, w8, #16, #5
strb	w9, [x24, #0x226]
and	w8, w8, #0xffff
orr	w1, w8, w9, lsl #16
mov	w8, #0x1                ; =1
strb	w8, [x24, #0x220]
strb	wzr, [x26, #0xb5a]
strh	wzr, [x26, #0xb58]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x3d8
ldrb	w25, [x8]
and	w8, w1, #0x1fffff
cmp	w8, #0xf
b.ls	<_main.execute>
cmp	w8, #0x1b
b.ne	<_main.execute>
mov	w8, #0x1                ; =1
strb	w8, [x26, #0xb0e]
add	x8, x27, #0xb13
strh	wzr, [x8]
strb	wzr, [x26, #0xada]
strh	wzr, [x26, #0xad8]
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
strh	wzr, [x24, #0xb9c]
strb	wzr, [x24, #0xba5]
tbnz	w25, #0x0, <_main.execute>
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
ldrb	w8, [x24, #0xbec]
b	<_main.execute>
mov	w9, #0x1                ; =1
strb	w9, [x24, #0x22c]
tbnz	w9, #0x0, <_main.execute>
add	x11, sp, #0x8b, lsl #12 ; =0x8b000
add	x11, x11, #0x1b8
cbz	w8, <_main.execute>
add	x10, sp, #0x29, lsl #12 ; =0x29000
add	x10, x10, #0x3a0
ldr	w9, [x10, #0xbe8]
lsl	w9, w9, #6
strh	w9, [x26, #0xb58]
ubfx	w9, w9, #16, #5
strb	w9, [x26, #0xb5a]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
ldr	w9, [x10, #0xbe8]
orr	w9, w9, w22
b	<_main.execute>
add	x10, sp, #0x8b, lsl #12 ; =0x8b000
add	x10, x10, #0x1b8
and	w8, w1, #0xf
cmp	w8, #0x8
b.le	<_main.execute>
cmp	w8, #0xc
b.gt	<_main.execute>
sub	w9, w8, #0xa
cmp	w9, #0x3
b.hs	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
and	w9, w21, #0xf
mov	w10, #0xff              ; =255
lsr	w9, w10, w9
and	w9, w9, w20
strh	w9, [x26, #0xb58]
ubfx	w9, w9, #16, #5
strb	w9, [x26, #0xb5a]
mov	w9, w8
add	x9, x9, w19, uxtw
adrp x10, RELOC_PAGE
add	x10, x10, #RELOC_OFFSET
ldrb	w9, [x10, x9]
strb	w9, [x23, #0xbec]
cbz	w9, <_main.execute>
cmp	w9, #0xc
b.ne	<_main.execute>
cmp	w8, #0x0
strb	wzr, [x26, #0xb5a]
cset	w8, eq
strh	wzr, [x26, #0xb58]
strb	wzr, [x23, #0xbec]
strb	w8, [x11, #0x23c]
ldr	w1, [sp, #0xb8]
b	<_main.execute>
ldr	w8, [x23, #0xbe8]
add	x10, sp, #0x8b, lsl #12 ; =0x8b000
add	x10, x10, #0x1b8
strh	w8, [x10, #0x238]
ubfx	w9, w8, #16, #5
strb	w9, [x10, #0x23a]
and	w8, w8, #0xffff
orr	w1, w8, w9, lsl #16
add	x11, sp, #0x8b, lsl #12 ; =0x8b000
add	x11, x11, #0x1b8
mov	w8, #0x1                ; =1
strb	w8, [x10, #0x234]
strb	wzr, [x26, #0xb5a]
strh	wzr, [x26, #0xb58]
and	w8, w1, #0x1fffff
cmp	w8, #0xf
b.ls	<_main.execute>
cmp	w8, #0x1b
b.ne	<_main.execute>
mov	w8, #0x1                ; =1
strb	w8, [x26, #0xb0e]
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
add	x8, x27, #0xb13
strh	wzr, [x8]
strb	wzr, [x26, #0xada]
strh	wzr, [x26, #0xad8]
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
strh	wzr, [x24, #0xb9c]
strb	wzr, [x24, #0xba5]
b	<_main.execute>
mov	w8, #0x1                ; =1
strb	w8, [x11, #0x240]
b	<_main.execute>
add	x9, sp, #0x8b, lsl #12  ; =0x8b000
add	x9, x9, #0x1b8
strh	w8, [x9, #0x244]
lsr	w8, w8, #16
strb	w8, [x9, #0x246]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0x8b, lsl #12  ; =0x8b000
add	x1, x1, #0x3fc
bl	<_terminal.stream_terminal.Handler.vt__anon>
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
b	<_main.execute>
cmp	w8, #0x4
b.gt	<_main.execute>
cmp	w8, #0x3
b.lo	<_main.execute>
b	<_main.execute>
cmp	w8, #0xd
b.eq	<_main.execute>
cmp	w8, #0xe
b.eq	<_main.execute>
cmp	w8, #0xf
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
cmp	w8, #0x5
b.eq	<_main.execute>
cmp	w8, #0x7
b.eq	<_main.execute>
cmp	w8, #0x8
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
cmp	w8, #0x9
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
mov	w1, #0x1                ; =1
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
strb	w1, [x10, #0x22f]
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x3e7
bl	<_terminal.stream.logUnsupportedOnce__anon>
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
tbnz	w25, #0x0, <_main.execute>
b	<_main.execute>
and	w8, w1, #0xf
cmp	w8, #0x8
b.le	<_main.execute>
cmp	w8, #0xc
b.gt	<_main.execute>
sub	w9, w8, #0xa
cmp	w9, #0x3
b.hs	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
cmp	w8, #0x4
b.gt	<_main.execute>
cmp	w8, #0x3
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
b.lo	<_main.execute>
b	<_main.execute>
cmp	w8, #0xd
b.eq	<_main.execute>
cmp	w8, #0xe
b.eq	<_main.execute>
cmp	w8, #0xf
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
cmp	w8, #0x5
b.eq	<_main.execute>
cmp	w8, #0x7
b.eq	<_main.execute>
cmp	w8, #0x8
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
cmp	w8, #0x9
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
mov	w1, #0x1                ; =1
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
strb	w1, [x11, #0x242]
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x3fa
bl	<_terminal.stream.logUnsupportedOnce__anon>
b	<_main.execute>
mov	x20, x19
add	x10, x20, x28
ldr	x8, [sp, #0x150]
subs	x20, x8, x10
b.ls	<_main.execute>
mov	x8, #0x0                ; =0
ldr	x9, [sp, #0xd0]
str	x10, [sp, #0xa0]
add	x28, x9, x10
b	<_main.execute>
mov	x19, x25
add	x8, x19, x22
cmp	x8, x20
b.hs	<_main.execute>
ldrb	w9, [x28, x8]
cmp	w9, #0x1b
b.ne	<_main.execute>
mov	w9, #0x1                ; =1
strb	w9, [x26, #0xb0e]
add	x9, x27, #0xb13
strh	wzr, [x9]
strb	wzr, [x26, #0xada]
strh	wzr, [x26, #0xad8]
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
strh	wzr, [x9, #0xb9c]
strb	wzr, [x9, #0xba5]
add	x22, x8, #0x1
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
ldrb	w8, [x9, #0xb9e]
mov	x19, #0x0               ; =0
ands	w8, w8, #0xf
b.eq	<_main.execute>
add	x21, x28, x22
sub	x25, x20, x22
subs	x2, x25, x19
b.ls	<_main.execute>
cmp	w8, #0x5
b.eq	<_main.execute>
cmp	w8, #0x3
b.eq	<_main.execute>
cmp	w8, #0x1
b.ne	<_main.execute>
ldrb	w8, [x21, x19]
cmp	w8, #0x5b
b.ne	<_main.execute>
mov	w8, #0x3                ; =3
strb	w8, [x26, #0xb0e]
b	<_main.execute>
ldrb	w1, [x21, x19]
cmp	w1, #0x3b
b.ne	<_main.execute>
mov	w8, #0x5                ; =5
strb	w8, [x26, #0xb0e]
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
strh	wzr, [x8, #0xb6c]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
mov	w9, #0x1                ; =1
strb	w9, [x8, #0xba4]
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, x21, x19
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).consumeCsiParams>
add	x19, x0, x19
cmp	x19, x25
b.hs	<_main.execute>
ldrb	w8, [x23, #0xb9e]
and	w8, w8, #0xf
cmp	w8, #0x5
b.ne	<_main.execute>
add	x1, x21, x19
b	<_main.execute>
add	x1, x21, x19
cmp	w8, #0xd
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).consumeApcString>
add	x19, x0, x19
cmp	x19, x25
b.hs	<_main.execute>
ldrb	w1, [x21, x19]
cmp	w1, #0x9c
b.eq	<_main.execute>
cmp	w1, #0x1b
b.ne	<_main.execute>
add	x8, x27, #0xb13
strh	wzr, [x8]
strb	wzr, [x26, #0xada]
strh	wzr, [x26, #0xad8]
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
strh	wzr, [x8, #0xb9c]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
strb	wzr, [x8, #0xba5]
mov	w8, #0x1                ; =1
strb	w8, [x26, #0xb0e]
b	<_main.execute>
ldrb	w1, [x1]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).nextNonUtf8>
add	x19, x19, #0x1
ldrb	w8, [x23, #0xb9e]
ands	w8, w8, #0xf
b.ne	<_main.execute>
b	<_main.execute>
sub	w8, w1, #0x30
cmp	w8, #0xa
b.hs	<_main.execute>
mov	w9, #0x5                ; =5
strb	w9, [x26, #0xb0e]
and	w8, w8, #0xff
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
strh	w8, [x9, #0xb9c]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
mov	w8, #0x1                ; =1
strb	w8, [x9, #0xba5]
b	<_main.execute>
and	w8, w1, #0xfc
cmp	w8, #0x3c
b.ne	<_main.execute>
mov	w8, #0x5                ; =5
strb	w8, [x26, #0xb0e]
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
ldrb	w8, [x9, #0xba3]
cmp	x8, #0x3
b.ls	<_main.execute>
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
bl	<_log.scoped(.parser).warn__anon>
b	<_main.execute>
strb	wzr, [x26, #0xb0e]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
sub	w8, w1, #0x40
cmp	w8, #0x3f
b.hs	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).csiDispatchFinal>
b	<_main.execute>
ldr	x10, [sp, #0xb0]
strb	w1, [x10, x8]
ldrb	w8, [x9, #0xba3]
add	w8, w8, #0x1
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
strb	w8, [x9, #0xba3]
b	<_main.execute>
mov	x8, x20
ldr	x9, [sp, #0xa0]
add	x22, x8, x9
ldrb	w8, [x23, #0xb9e]
and	w8, w8, #0xf
cmp	w8, #0x0
ldr	x8, [sp, #0x150]
ccmp	x22, x8, #0x2, eq
b.hs	<_main.execute>
ldr	x8, [sp, #0x150]
sub	x2, x8, x22
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x400
ldr	x8, [sp, #0xd0]
add	x1, x8, x22
add	x3, sp, #0x39, lsl #12  ; =0x39000
add	x3, x3, #0x430
bl	<_simd.vt.utf8DecodeUntilControlSeq>
ldr	x25, [x24, #0x248]
ldr	x19, [x24, #0x250]
add	x28, sp, #0x39, lsl #12 ; =0x39000
add	x28, x28, #0x430
movi.4s	v2, #0xf
cbz	x19, <_main.execute>
mov	x20, #0x0               ; =0
b	<_main.execute>
ldr	q1, [sp, #0xc0]
and.16b	v0, v0, v1
addv.8h	h0, v0
fmov	w10, s0
and	w10, w10, #0xff
mvn	w10, w10
rbit	w10, w10
clz	w10, w10
add	x9, x10, x9
sub	x21, x9, #0x8
sub	x9, x21, x20
str	x8, [x24, #0x260]
str	x9, [x24, #0x268]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
sub	x1, x29, #0xf8
bl	<_terminal.stream_terminal.Handler.vt__anon>
mov	x20, x21
cmp	x21, x19
movi.4s	v2, #0xf
b.hs	<_main.execute>
add	x8, x28, x20, lsl #2
ldr	w1, [x8]
cmp	w1, #0x10
b.lo	<_main.execute>
add	x21, x20, #0x1
ldr	x9, [sp, #0x160]
add	x10, x9, x20, lsl #2
add	x9, x21, #0x8
cmp	x9, x19
b.hi	<_main.execute>
ldp	q0, q1, [x10], #0x20
cmhi.4s	v1, v1, v2
cmhi.4s	v0, v0, v2
uzp1.8h	v0, v0, v1
uminv.8h	h1, v0
fmov	w11, s1
mov	x21, x9
tbnz	w11, #0x0, <_main.execute>
b	<_main.execute>
cmp	x21, x19
b.hs	<_main.execute>
ldr	w9, [x28, x21, lsl #2]
cmp	w9, #0x10
b.lo	<_main.execute>
add	x21, x21, #0x1
cmp	x19, x21
b.ne	<_main.execute>
mov	x21, x19
b	<_main.execute>
add	x9, sp, #0x8b, lsl #12  ; =0x8b000
add	x9, x9, #0x1b8
cmp	w1, #0x8
b.le	<_main.execute>
cmp	w1, #0xc
b.gt	<_main.execute>
sub	w8, w1, #0xa
cmp	w8, #0x3
b.hs	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
cmp	w1, #0x4
b.gt	<_main.execute>
cmp	w1, #0x3
b.lo	<_main.execute>
b	<_main.execute>
cmp	w1, #0xd
b.eq	<_main.execute>
cmp	w1, #0xe
b.eq	<_main.execute>
cmp	w1, #0xf
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
cmp	w1, #0x5
b.eq	<_main.execute>
cmp	w1, #0x7
b.eq	<_main.execute>
cmp	w1, #0x8
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
cmp	w1, #0x9
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
mov	w1, #0x1                ; =1
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
strb	w1, [x9, #0x25c]
sub	x0, x29, #0xfc
bl	<_terminal.stream.logUnsupportedOnce__anon>
add	x21, x20, #0x1
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
add	x28, sp, #0x39, lsl #12 ; =0x39000
add	x28, x28, #0x430
mov	x20, x21
cmp	x21, x19
movi.4s	v2, #0xf
b.lo	<_main.execute>
add	x9, x25, x22
ldr	x8, [sp, #0x150]
subs	x20, x8, x9
b.ls	<_main.execute>
ldr	x8, [sp, #0xd0]
str	x9, [sp, #0xa0]
add	x28, x8, x9
ldrb	w8, [x28]
cmp	w8, #0x1b
b.ne	<_main.execute>
mov	x8, #0x0                ; =0
b	<_main.execute>
mov	x25, x21
add	x8, x25, x22
cmp	x8, x20
b.hs	<_main.execute>
ldrb	w9, [x28, x8]
cmp	w9, #0x1b
b.ne	<_main.execute>
mov	w9, #0x1                ; =1
strb	w9, [x26, #0xb0e]
add	x9, x27, #0xb13
strh	wzr, [x9]
strb	wzr, [x26, #0xada]
strh	wzr, [x26, #0xad8]
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
strh	wzr, [x9, #0xb9c]
strb	wzr, [x9, #0xba5]
add	x22, x8, #0x1
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
ldrb	w8, [x9, #0xb9e]
mov	x25, #0x0               ; =0
ands	w8, w8, #0xf
b.eq	<_main.execute>
add	x19, x28, x22
sub	x21, x20, x22
subs	x2, x21, x25
b.ls	<_main.execute>
cmp	w8, #0x5
b.eq	<_main.execute>
cmp	w8, #0x3
b.eq	<_main.execute>
cmp	w8, #0x1
b.ne	<_main.execute>
ldrb	w8, [x19, x25]
cmp	w8, #0x5b
b.ne	<_main.execute>
mov	w8, #0x3                ; =3
strb	w8, [x26, #0xb0e]
b	<_main.execute>
ldrb	w1, [x19, x25]
cmp	w1, #0x3b
b.ne	<_main.execute>
mov	w8, #0x5                ; =5
strb	w8, [x26, #0xb0e]
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
strh	wzr, [x8, #0xb6c]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
mov	w9, #0x1                ; =1
strb	w9, [x8, #0xba4]
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, x19, x25
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).consumeCsiParams>
add	x25, x0, x25
cmp	x25, x21
b.hs	<_main.execute>
ldrb	w8, [x23, #0xb9e]
and	w8, w8, #0xf
cmp	w8, #0x5
b.ne	<_main.execute>
add	x1, x19, x25
b	<_main.execute>
add	x1, x19, x25
cmp	w8, #0xd
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).consumeApcString>
add	x25, x0, x25
cmp	x25, x21
b.hs	<_main.execute>
ldrb	w1, [x19, x25]
cmp	w1, #0x9c
b.eq	<_main.execute>
cmp	w1, #0x1b
b.ne	<_main.execute>
add	x8, x27, #0xb13
strh	wzr, [x8]
strb	wzr, [x26, #0xada]
strh	wzr, [x26, #0xad8]
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
strh	wzr, [x8, #0xb9c]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
strb	wzr, [x8, #0xba5]
mov	w8, #0x1                ; =1
strb	w8, [x26, #0xb0e]
b	<_main.execute>
ldrb	w1, [x1]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).nextNonUtf8>
add	x25, x25, #0x1
ldrb	w8, [x23, #0xb9e]
ands	w8, w8, #0xf
b.ne	<_main.execute>
b	<_main.execute>
sub	w8, w1, #0x30
cmp	w8, #0xa
b.hs	<_main.execute>
mov	w9, #0x5                ; =5
strb	w9, [x26, #0xb0e]
and	w8, w8, #0xff
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
strh	w8, [x9, #0xb9c]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
mov	w8, #0x1                ; =1
strb	w8, [x9, #0xba5]
b	<_main.execute>
and	w8, w1, #0xfc
cmp	w8, #0x3c
b.ne	<_main.execute>
mov	w8, #0x5                ; =5
strb	w8, [x26, #0xb0e]
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
ldrb	w8, [x9, #0xba3]
cmp	x8, #0x3
b.ls	<_main.execute>
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
bl	<_log.scoped(.parser).warn__anon>
b	<_main.execute>
strb	wzr, [x26, #0xb0e]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
sub	w8, w1, #0x40
cmp	w8, #0x3f
b.hs	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).csiDispatchFinal>
b	<_main.execute>
ldr	x10, [sp, #0xb0]
strb	w1, [x10, x8]
ldrb	w8, [x9, #0xba3]
add	w8, w8, #0x1
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
strb	w8, [x9, #0xba3]
b	<_main.execute>
add	x8, x22, x25
ldr	x9, [sp, #0x150]
sub	x25, x9, x8
ldr	x9, [sp, #0x98]
ldr	x10, [sp, #0xa8]
add	x9, x9, x10
add	x28, x9, x8
b	<_main.execute>
mov	w9, #0x1                ; =1
strb	w9, [x24, #0x27c]
tbz	w9, #0x0, <_main.execute>
subs	x25, x25, #0x1
b.eq	<_main.execute>
ldrb	w19, [x28], #0x1
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldrb	w20, [x8, x19]
add	x11, sp, #0x29, lsl #12 ; =0x29000
add	x11, x11, #0x3a0
ldrb	w9, [x11, #0xbec]
cbz	w9, <_main.execute>
ldr	w8, [x11, #0xbe8]
lsl	w8, w8, #6
strh	w8, [x26, #0xb58]
ubfx	w8, w8, #16, #5
strb	w8, [x26, #0xb5a]
ldr	w8, [x11, #0xbe8]
and	w10, w19, #0x3f
orr	w8, w8, w10
b	<_main.execute>
and	w8, w20, #0xf
mov	w10, #0xff              ; =255
lsr	w8, w10, w8
and	w8, w8, w19
strh	w8, [x26, #0xb58]
ubfx	w8, w8, #16, #5
strb	w8, [x26, #0xb5a]
and	x22, x20, #0xf
add	x8, x9, x22
adrp x10, RELOC_PAGE
add	x10, x10, #RELOC_OFFSET
ldrb	w8, [x10, x8]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
strb	w8, [x11, #0xbec]
cbz	w8, <_main.execute>
cmp	w8, #0xc
b.ne	<_main.execute>
cmp	w9, #0x0
strb	wzr, [x26, #0xb5a]
cset	w8, eq
strh	wzr, [x26, #0xb58]
strb	wzr, [x23, #0xbec]
strb	w8, [x24, #0x278]
sub	x8, x29, #0xe0
ldr	w1, [sp, #0xb8]
b	<_main.execute>
ldr	w8, [x23, #0xbe8]
strh	w8, [x24, #0x274]
ubfx	w9, w8, #16, #5
strb	w9, [x24, #0x276]
and	w8, w8, #0xffff
orr	w1, w8, w9, lsl #16
mov	w8, #0x1                ; =1
strb	w8, [x24, #0x270]
strb	wzr, [x26, #0xb5a]
strh	wzr, [x26, #0xb58]
sub	x8, x29, #0xe8
ldrb	w21, [x8]
and	w8, w1, #0x1fffff
cmp	w8, #0xf
b.ls	<_main.execute>
cmp	w8, #0x1b
b.ne	<_main.execute>
mov	w8, #0x1                ; =1
strb	w8, [x26, #0xb0e]
add	x8, x27, #0xb13
strh	wzr, [x8]
strb	wzr, [x26, #0xada]
strh	wzr, [x26, #0xad8]
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
strh	wzr, [x8, #0xb9c]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
strb	wzr, [x8, #0xba5]
tbnz	w21, #0x0, <_main.execute>
b	<_main.execute>
strh	w8, [x24, #0x280]
lsr	w8, w8, #16
strb	w8, [x24, #0x282]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
sub	x1, x29, #0xd8
bl	<_terminal.stream_terminal.Handler.vt__anon>
tbnz	w21, #0x0, <_main.execute>
add	x11, sp, #0x8b, lsl #12 ; =0x8b000
add	x11, x11, #0x1b8
ldrb	w8, [x23, #0xbec]
b	<_main.execute>
and	w8, w1, #0xf
cmp	w8, #0x8
b.le	<_main.execute>
cmp	w8, #0xc
b.gt	<_main.execute>
sub	w9, w8, #0xa
cmp	w9, #0x3
b.hs	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
tbnz	w21, #0x0, <_main.execute>
b	<_main.execute>
add	x11, sp, #0x8b, lsl #12 ; =0x8b000
add	x11, x11, #0x1b8
cbz	w8, <_main.execute>
add	x10, sp, #0x29, lsl #12 ; =0x29000
add	x10, x10, #0x3a0
ldr	w9, [x10, #0xbe8]
lsl	w9, w9, #6
strh	w9, [x26, #0xb58]
ubfx	w9, w9, #16, #5
strb	w9, [x26, #0xb5a]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
ldr	w9, [x10, #0xbe8]
and	w10, w19, #0x3f
orr	w9, w9, w10
b	<_main.execute>
and	w9, w20, #0xf
mov	w10, #0xff              ; =255
lsr	w9, w10, w9
and	w9, w9, w19
strh	w9, [x26, #0xb58]
ubfx	w9, w9, #16, #5
strb	w9, [x26, #0xb5a]
mov	w9, w8
add	x9, x9, w22, uxtw
adrp x10, RELOC_PAGE
add	x10, x10, #RELOC_OFFSET
ldrb	w9, [x10, x9]
strb	w9, [x23, #0xbec]
cbz	w9, <_main.execute>
cmp	w9, #0xc
b.ne	<_main.execute>
cmp	w8, #0x0
strb	wzr, [x26, #0xb5a]
cset	w8, eq
strh	wzr, [x26, #0xb58]
strb	wzr, [x23, #0xbec]
strb	w8, [x11, #0x28c]
ldr	w1, [sp, #0xb8]
b	<_main.execute>
ldr	w8, [x23, #0xbe8]
add	x10, sp, #0x8b, lsl #12 ; =0x8b000
add	x10, x10, #0x1b8
strh	w8, [x10, #0x288]
ubfx	w9, w8, #16, #5
strb	w9, [x10, #0x28a]
and	w8, w8, #0xffff
orr	w1, w8, w9, lsl #16
mov	w8, #0x1                ; =1
strb	w8, [x10, #0x284]
strb	wzr, [x26, #0xb5a]
strh	wzr, [x26, #0xb58]
and	w8, w1, #0x1fffff
cmp	w8, #0xf
b.ls	<_main.execute>
cmp	w8, #0x1b
b.ne	<_main.execute>
mov	w8, #0x1                ; =1
strb	w8, [x26, #0xb0e]
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
add	x8, x27, #0xb13
strh	wzr, [x8]
strb	wzr, [x26, #0xada]
strh	wzr, [x26, #0xad8]
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
strh	wzr, [x8, #0xb9c]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
strb	wzr, [x8, #0xba5]
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
b	<_main.execute>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
mov	w8, #0x1                ; =1
strb	w8, [x24, #0x290]
b	<_main.execute>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
strh	w8, [x24, #0x294]
lsr	w8, w8, #16
strb	w8, [x24, #0x296]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
sub	x1, x29, #0xc4
bl	<_terminal.stream_terminal.Handler.vt__anon>
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
b	<_main.execute>
cmp	w8, #0x4
b.gt	<_main.execute>
cmp	w8, #0x3
b.lo	<_main.execute>
b	<_main.execute>
cmp	w8, #0xd
b.eq	<_main.execute>
cmp	w8, #0xe
b.eq	<_main.execute>
cmp	w8, #0xf
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
bl	<_terminal.stream_terminal.Handler.vt__anon>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
tbnz	w21, #0x0, <_main.execute>
b	<_main.execute>
cmp	w8, #0x5
b.eq	<_main.execute>
cmp	w8, #0x7
b.eq	<_main.execute>
cmp	w8, #0x8
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
tbnz	w21, #0x0, <_main.execute>
b	<_main.execute>
cmp	w8, #0x9
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
mov	w1, #0x1                ; =1
bl	<_terminal.stream_terminal.Handler.vt__anon>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
tbnz	w21, #0x0, <_main.execute>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
tbnz	w21, #0x0, <_main.execute>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
bl	<_terminal.stream_terminal.Handler.vt__anon>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
tbnz	w21, #0x0, <_main.execute>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
tbnz	w21, #0x0, <_main.execute>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
tbnz	w21, #0x0, <_main.execute>
b	<_main.execute>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
strb	w1, [x24, #0x27f]
sub	x0, x29, #0xd9
bl	<_terminal.stream.logUnsupportedOnce__anon>
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
tbnz	w21, #0x0, <_main.execute>
b	<_main.execute>
and	w8, w1, #0xf
cmp	w8, #0x8
b.le	<_main.execute>
cmp	w8, #0xc
b.gt	<_main.execute>
sub	w9, w8, #0xa
cmp	w9, #0x3
b.hs	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
cmp	w8, #0x4
b.gt	<_main.execute>
cmp	w8, #0x3
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
b.lo	<_main.execute>
b	<_main.execute>
cmp	w8, #0xd
b.eq	<_main.execute>
cmp	w8, #0xe
b.eq	<_main.execute>
cmp	w8, #0xf
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
cmp	w8, #0x5
b.eq	<_main.execute>
cmp	w8, #0x7
b.eq	<_main.execute>
cmp	w8, #0x8
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
cmp	w8, #0x9
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x430
b.ne	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
mov	w1, #0x1                ; =1
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream_terminal.Handler.vt__anon>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
b	<_main.execute>
strb	w1, [x24, #0x292]
sub	x0, x29, #0xc6
bl	<_terminal.stream.logUnsupportedOnce__anon>
b	<_main.execute>
ldrb	w8, [x23, #0xbe0]
cbz	w8, <_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
ldr	x1, [sp, #0x98]
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).trackContinuation>
ldr	x9, [sp, #0x88]
cmp	x9, #0x25
adrp x22, RELOC_PAGE
add	x22, x22, #RELOC_OFFSET
mov	w27, #0x2               ; =2
b.ne	<_main.execute>
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0xcc0
add	x1, sp, #0x1e0
add	x2, sp, #0x89, lsl #12  ; =0x89000
add	x2, x2, #0x9b0
bl	<_terminal.render.RenderState.update>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	q0, [sp, #0x1e0]
str	q0, [sp, #0xcb90]
add	x19, sp, #0xc, lsl #12  ; =0xc000
add	x19, x19, #0xb90
add	x0, x19, #0x10
add	x1, sp, #0x89, lsl #12  ; =0x89000
add	x1, x1, #0x9b0
mov	w2, #0x980              ; =2432
bl	<_memcpy>
add	x0, x19, #0x990
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0xcc0
mov	w2, #0x4f0              ; =1264
bl	<_memcpy>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).deinit>
add	x20, sp, #0xb, lsl #12  ; =0xb000
add	x20, x20, #0xca0
add	x0, sp, #0xb, lsl #12   ; =0xb000
add	x0, x0, #0xca0
add	x1, sp, #0xc, lsl #12   ; =0xc000
add	x1, x1, #0xb90
mov	w2, #0xe80              ; =3712
bl	<_memcpy>
add	x19, x20, #0xe80
add	x9, sp, #0xb, lsl #12   ; =0xb000
add	x9, x9, #0xb60
ldr	x8, [sp, #0x40]
str	x8, [x9, #0xfc0]
mov	w8, #0x1642             ; =5698
str	x8, [x9, #0xfc8]
ldp	x8, x10, [sp, #0x48]
str	x10, [x9, #0xfd0]
str	x8, [x9, #0xfd8]
adrp x8, RELOC_PAGE
ldr	d0, [x8, #RELOC_OFFSET]
str	d0, [x9, #0xfe0]
mov	w8, #0x9a               ; =154
movk	w8, #0x25, lsl #16
str	w8, [x9, #0xfe8]
add	x10, sp, #0xb, lsl #12  ; =0xb000
add	x10, x10, #0xca0
strb	wzr, [x10, #0xeec]
ldr	x8, [sp, #0x130]
str	x8, [x10, #0x1d70]
ldp	x8, x9, [sp, #0x100]
str	x8, [x10, #0x1d78]
ldr	x8, [sp, #0x120]
str	x8, [x10, #0x1d80]
ldr	x8, [sp, #0x148]
str	x8, [x10, #0x1d88]
str	x9, [x10, #0x1d90]
ldp	q0, q1, [sp, #0x190]
add	x10, sp, #0xd, lsl #12  ; =0xd000
add	x10, x10, #0xa10
stur	q0, [x10, #0x28]
stur	q1, [x10, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x10, #0x48]
ldr	x8, [sp, #0x1c0]
str	x8, [x10, #0x58]
add	x22, sp, #0x39, lsl #12 ; =0x39000
add	x22, x22, #0x430
lsr	x8, x9, #2
str	x8, [sp, #0xa8]
add	x25, x20, #0x10
add	x26, x20, #0x990
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
mov	w9, #0x1                ; =1
ldp	q1, q0, [x8]
stp	q0, q1, [sp, #0x150]
mov	w28, #0x13be            ; =5054
ldp	x10, x8, [sp, #0x1d0]
str	x10, [sp, #0xd0]
str	x8, [sp, #0xc0]
mov	x24, x9
ldr	x8, [sp, #0xc0]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x0, [sp, #0xd0]
mov	w1, #0x1                ; =1
blr	x9
mov	x23, #0x0               ; =0
add	x20, sp, #0x39, lsl #12 ; =0x39000
add	x20, x20, #0x430
ldr	x8, [x20]
stp	x8, x24, [sp, #0xb0]
add	x27, sp, #0x71, lsl #12 ; =0x71000
add	x27, x27, #0x700
add	x21, sp, #0xb, lsl #12  ; =0xb000
add	x21, x21, #0xca0
ldr	w8, [x21, #0xea0]
lsl	x8, x8, #32
str	x8, [x20, #0x38]
stp	x19, x25, [x20]
str	x26, [x20, #0x10]
ldp	q0, q1, [sp, #0x150]
stur	q1, [x22, #0x18]
stur	q0, [x22, #0x28]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x39, lsl #12  ; =0x39000
add	x1, x1, #0x430
bl	<_blit.blit>
ldrh	w8, [x27]
ldr	x9, [x21, #0xe80]
ldrb	w9, [x9, x28]
add	x8, x23, x8
add	x23, x8, x9
subs	x24, x24, #0x1
b.ne	<_main.execute>
ldr	x8, [sp, #0xc0]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x0, [sp, #0xd0]
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [x20]
ldp	x9, x10, [sp, #0xa8]
sub	x2, x8, x10
cmp	x2, x9
b.hs	<_main.execute>
ldr	x10, [sp, #0xb8]
lsl	x9, x10, #2
lsr	x10, x10, #30
cbz	x10, <_main.execute>
ldr	x9, [sp, #0xb0]
cmp	x8, x9
b.eq	<_main.execute>
ldr	x8, [sp, #0x108]
cmp	x2, x8
b.hs	<_main.execute>
ldr	x8, [sp, #0x108]
ldr	x20, [sp, #0xb8]
mul	x0, x20, x8
umulh	x1, x20, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x20, x8
csel	x20, x20, x8, hi
str	x20, [sp, #0xb8]
ldr	x8, [sp, #0xc0]
ldr	x9, [x8, #0x2c0]
add	x22, sp, #0x39, lsl #12 ; =0x39000
add	x22, x22, #0x430
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x0, [sp, #0xd0]
mov	w1, #0x1                ; =1
blr	x9
mov	x21, #0x0               ; =0
mov	w23, #0x13be            ; =5054
ldr	x24, [sp, #0xb8]
add	x20, sp, #0x39, lsl #12 ; =0x39000
add	x20, x20, #0x430
add	x27, sp, #0x71, lsl #12 ; =0x71000
add	x27, x27, #0x700
add	x28, sp, #0xb, lsl #12  ; =0xb000
add	x28, x28, #0xca0
ldr	w8, [x28, #0xea0]
lsl	x8, x8, #32
str	x8, [x20, #0x38]
stp	x19, x25, [x20]
str	x26, [x20, #0x10]
ldp	q0, q1, [sp, #0x150]
stur	q1, [x22, #0x18]
stur	q0, [x22, #0x28]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x39, lsl #12  ; =0x39000
add	x1, x1, #0x430
bl	<_blit.blit>
ldrh	w8, [x27]
ldr	x9, [x28, #0xe80]
ldrb	w9, [x9, x23]
add	x8, x21, x8
add	x21, x8, x9
subs	x24, x24, #0x1
b.ne	<_main.execute>
add	x20, sp, #0xb, lsl #12  ; =0xb000
add	x20, x20, #0xca0
ldr	x8, [sp, #0xc0]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x0, [sp, #0xd0]
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
str	xzr, [sp, #0xb0]
add	x22, sp, #0x71, lsl #12 ; =0x71000
add	x22, x22, #0x700
mov	w21, #0x13be            ; =5054
ldr	x8, [sp, #0xc0]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x0, [sp, #0xd0]
mov	w1, #0x1                ; =1
blr	x9
mov	x23, #0x0               ; =0
add	x27, sp, #0x71, lsl #12 ; =0x71000
add	x27, x27, #0x700
ldr	x8, [x27]
str	x8, [sp, #0xa8]
ldr	x20, [sp, #0xb8]
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
add	x28, sp, #0xb, lsl #12  ; =0xb000
add	x28, x28, #0xca0
ldr	w8, [x28, #0xea0]
lsl	x8, x8, #32
str	x8, [x27, #0x38]
stp	x19, x25, [x27]
str	x26, [x27, #0x10]
ldp	q0, q1, [sp, #0x150]
stur	q1, [x22, #0x18]
stur	q0, [x22, #0x28]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0x71, lsl #12  ; =0x71000
add	x1, x1, #0x700
bl	<_blit.blit>
ldrh	w8, [x24, #0x90]
ldr	x9, [x28, #0xe80]
ldrb	w9, [x9, x21]
add	x8, x23, x8
add	x23, x8, x9
subs	x20, x20, #0x1
b.ne	<_main.execute>
add	x20, sp, #0xb, lsl #12  ; =0xb000
add	x20, x20, #0xca0
ldr	x8, [sp, #0xc0]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x0, [sp, #0xd0]
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [x27]
ldp	x9, x10, [sp, #0xa8]
sub	x8, x8, x9
ldr	x9, [sp, #0xb8]
udiv	x8, x8, x9
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
str	x8, [x9, x10, lsl #3]
add	x10, x10, #0x1
ldr	x8, [sp, #0x148]
str	x10, [sp, #0xb0]
cmp	x10, x8
b.ne	<_main.execute>
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x19, [sp, #0x148]
mov	x1, x19
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x19, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x19, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
ldr	x10, [x10]
lsr	x11, x19, #1
add	x12, sp, #0x39, lsl #12 ; =0x39000
add	x12, x12, #0x430
ldr	x11, [x12, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x12, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x12, x9
ldur	x9, [x9, #-0x8]
add	x12, sp, #0xd, lsl #12  ; =0xd000
add	x12, x12, #0xa10
ldr	x13, [sp, #0xb8]
stp	x13, x11, [x12, #0x60]
stp	x10, x8, [x12, #0x70]
str	x9, [x12, #0x80]
add	x0, sp, #0xd, lsl #12   ; =0xd000
add	x0, x0, #0xa10
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0xc60
add	x2, sp, #0xd, lsl #12   ; =0xd000
add	x2, x2, #0xa70
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x8, [x20, #0xe88]
cbz	x8, <_main.execute>
add	x10, sp, #0xb, lsl #12  ; =0xb000
add	x10, x10, #0xca0
ldr	x1, [x10, #0xe80]
ldr	x9, [x10, #0xe98]
ldr	x0, [x10, #0xe90]
lsl	x2, x8, #5
ldr	x8, [x9, #0x18]
mov	w3, #0x1                ; =1
ldr	x4, [sp, #0x110]
blr	x8
ldr	q0, [sp, #0xbca0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
str	q0, [x8]
add	x1, sp, #0x71, lsl #12  ; =0x71000
add	x1, x1, #0x700
mov	x0, x26
bl	<_terminal.render.RenderState.deinit>
ldr	q0, [sp, #0xbca0]
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
str	q0, [x27]
add	x1, sp, #0x39, lsl #12  ; =0x39000
add	x1, x1, #0x430
mov	x0, x25
bl	<_terminal.Terminal.deinit>
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
ldr	x26, [sp, #0x100]
ldr	x23, [sp, #0xe8]
mov	x22, #0x0               ; =0
mov	w8, #0x4a60             ; =19040
add	x9, sp, #0x24, lsl #12  ; =0x24000
add	x9, x9, #0x700
add	x8, x9, x8
str	x8, [sp, #0x98]
mov	w8, #0x25b8             ; =9656
add	x8, x9, x8
str	x8, [sp, #0x88]
add	x8, sp, #0x12, lsl #12  ; =0x12000
add	x8, x8, #0xa80
add	x8, x8, #0x11, lsl #12  ; =0x11000
str	x8, [sp, #0x90]
mov	w20, #0x1               ; =1
adrp x25, RELOC_PAGE
add	x25, x25, #RELOC_OFFSET
mov	w19, #0x18              ; =24
adrp x21, RELOC_PAGE
add	x21, x21, #RELOC_OFFSET
b	<_main.execute>
tbz	w20, #0x0, <_main.execute>
mov	w20, #0x0               ; =0
add	x25, x25, #0x38
mov	w22, #0x1               ; =1
cbz	x26, <_main.execute>
ldp	x1, x2, [x25]
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	x3, #0x0                ; =0
mov	x4, x26
ldr	x5, [sp, #0x120]
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
madd	x3, x22, x19, x21
ldr	x0, [sp, #0xf0]
mov	x1, x23
mov	x2, x25
bl	<_main.executeIdleDelivery>
tst	w0, #0xffff
b.ne	<_main.execute>
tbnz	w20, #0x0, <_main.execute>
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x1b               ; =27
mov	x3, #0x0                ; =0
mov	x4, x26
ldr	x19, [sp, #0x120]
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbnz	w8, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x19               ; =25
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbnz	w8, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x23               ; =35
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbnz	w8, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x1d               ; =29
mov	x3, #0x0                ; =0
mov	x4, x26
mov	x5, x19
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
add	x0, sp, #0xd, lsl #12   ; =0xd000
add	x0, x0, #0xa98
add	x1, sp, #0x1d0
add	x2, sp, #0x1e0
bl	<_ClientEventContext.init>
tst	w0, #0xffff
ldr	x19, [sp, #0x108]
b.ne	<_main.execute>
add	x25, sp, #0x8a, lsl #12 ; =0x8a000
add	x25, x25, #0x330
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x1b               ; =27
mov	x3, #0x0                ; =0
mov	x4, x26
ldr	x5, [sp, #0x120]
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbnz	w8, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x19               ; =25
mov	x3, #0x0                ; =0
mov	x4, x26
ldr	x5, [sp, #0x120]
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
add	x21, sp, #0x39, lsl #12 ; =0x39000
add	x21, x21, #0x430
ldr	x8, [sp, #0x130]
add	x11, sp, #0x12, lsl #12 ; =0x12000
add	x11, x11, #0x738
stp	x8, x26, [x11, #0x88]
ldr	x10, [sp, #0x120]
ldr	x9, [sp, #0x148]
stp	x10, x9, [x11, #0x98]
str	x19, [x11, #0xa8]
ldp	q0, q1, [sp, #0x190]
stp	q0, q1, [x11, #0xb0]
ldr	q0, [sp, #0x1b0]
stur	q0, [x11, #0xd0]
ldr	x8, [sp, #0x1c0]
str	x8, [x11, #0xe0]
ldr	q0, [sp, #0x1d0]
stur	q0, [x11, #0xe8]
stp	x26, x10, [x11, #0xf8]
stp	x9, x19, [x11, #0x108]
ldr	x8, [sp, #0x220]
str	x8, [x11, #0x148]
ldp	q0, q1, [sp, #0x200]
add	x9, sp, #0x12, lsl #12  ; =0x12000
add	x9, x9, #0x820
stp	q0, q1, [x9, #0x40]
ldr	q1, [sp, #0x1f0]
str	q1, [x9, #0x30]
add	x8, sp, #0xd, lsl #12   ; =0xd000
add	x8, x8, #0xa98
str	x8, [x9, #0x68]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x12, lsl #12  ; =0x12000
add	x1, x1, #0x820
mov	w2, #0x1                ; =1
bl	<_main.timed__anon>
ldrh	w28, [x25, #0x8]
cbnz	w28, <_main.execute>
ldr	x8, [sp, #0x108]
lsr	x19, x8, #2
mov	w23, #0x1               ; =1
add	x20, sp, #0x8a, lsl #12 ; =0x8a000
add	x20, x20, #0x330
ldr	x2, [x20]
cmp	x2, x19
lsr	x8, x23, #30
ccmp	x8, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x23, x23, #2
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x12, lsl #12  ; =0x12000
add	x1, x1, #0x820
mov	x2, x23
bl	<_main.timed__anon>
ldrh	w28, [x20, #0x8]
cbz	w28, <_main.execute>
b	<_main.execute>
ldr	x0, [x19, #0x90]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x4, sp, #0x71, lsl #12  ; =0x71000
add	x4, x4, #0x700
mov	w2, #0x2dec             ; =11756
movk	w2, #0x4, lsl #16
mov	x3, #0x0                ; =0
bl	<_FT_New_Memory_Face>
add	x20, sp, #0x29, lsl #12 ; =0x29000
add	x20, x20, #0x3a0
cbz	w0, <_main.execute>
mov	w28, #0x93              ; =147
b	<_main.execute>
mov	w28, #0x1a              ; =26
b	<_main.execute>
add	x19, sp, #0x71, lsl #12 ; =0x71000
add	x19, x19, #0x700
ldr	x0, [x19]
mov	w1, #0x6963             ; =26979
movk	w1, #0x756e, lsl #16
bl	<_FT_Select_Charmap>
mov	x8, x0
ldr	x0, [x19]
cbz	w8, <_main.execute>
mov	w28, #0x94              ; =148
b	<_main.execute>
mov	x23, x21
add	x22, sp, #0x8a, lsl #12 ; =0x8a000
add	x22, x22, #0x330
bl	<_hb_ft_font_create_referenced>
cbz	x0, <_main.execute>
mov	x25, x0
bl	<_hb_buffer_create>
cbz	x0, <_main.execute>
ldr	x9, [x20, #0x90]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x8, [x8]
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
stp	x9, x8, [x10]
stp	x25, x0, [x10, #0x10]
add	x21, sp, #0x39, lsl #12 ; =0x39000
add	x21, x21, #0x430
strh	wzr, [x10, #0x20]
mov	w19, #0xf               ; =15
mov	x0, x8
mov	w1, #0x0                ; =0
mov	w2, #0xf                ; =15
bl	<_FT_Set_Pixel_Sizes>
cbz	w0, <_main.execute>
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
bl	<_Rasterizer.deinit>
mov	w28, #0x98              ; =152
b	<_main.execute>
add	x0, sp, #0xd, lsl #12   ; =0xd000
add	x0, x0, #0xa98
add	x1, sp, #0x1d0
add	x2, sp, #0x1e0
bl	<_ClientEventContext.init>
tst	w0, #0xffff
ldr	x19, [sp, #0x108]
b.ne	<_main.execute>
ldr	x8, [sp, #0x130]
add	x28, sp, #0xd, lsl #12  ; =0xd000
add	x28, x28, #0xa10
str	x8, [x28, #0x4d28]
str	x26, [x28, #0x4d30]
ldr	x8, [sp, #0x120]
str	x8, [x28, #0x4d38]
ldr	x8, [sp, #0x148]
str	x8, [x28, #0x4d40]
str	x19, [x28, #0x4d48]
ldp	q0, q1, [sp, #0x190]
add	x10, sp, #0x12, lsl #12 ; =0x12000
add	x10, x10, #0x738
stur	q0, [x10, #0x28]
stur	q1, [x10, #0x38]
ldr	q0, [sp, #0x1b0]
lsr	x8, x19, #2
str	x8, [sp, #0xa0]
add	x8, sp, #0xd, lsl #12   ; =0xd000
add	x8, x8, #0xa98
add	x8, x8, #0x178
str	x8, [sp, #0xf0]
stur	q0, [x10, #0x48]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldr	x9, [sp, #0x1c0]
str	x9, [x10, #0x58]
ldp	x22, x10, [sp, #0x1d0]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
mov	w26, #0x2588            ; =9608
movk	w26, #0x27, lsl #16
mov	w21, #0x8942            ; =35138
movk	w21, #0x14, lsl #16
ldp	q1, q0, [x8]
str	q1, [sp, #0x150]
str	q0, [sp, #0x110]
ldr	w8, [x9]
str	w8, [sp, #0xe8]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [sp, #0xd0]
mov	w19, #0x2580            ; =9600
movk	w19, #0x27, lsl #16
mov	w27, #0x2180            ; =8576
movk	w27, #0x27, lsl #16
mov	w8, #0x1                ; =1
str	x8, [sp, #0x160]
ldrh	w8, [x9, #0x4]
str	w8, [sp, #0xc0]
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
str	x22, [sp, #0xa8]
str	x10, [sp, #0xb8]
ldr	x9, [x10, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x22
mov	w1, #0x1                ; =1
blr	x9
mov	x20, #0x0               ; =0
mov	x22, #0x0               ; =0
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x8, [x8]
str	x8, [sp, #0xb0]
ldr	x8, [x28, #0x22f0]
b	<_main.execute>
ldr	x8, [x28, #0x22f0]
add	x22, x8, x22
add	x20, x20, #0x1
ldr	x9, [sp, #0x160]
cmp	x20, x9
b.eq	<_main.execute>
add	x10, sp, #0x89, lsl #12 ; =0x89000
add	x10, x10, #0x9b0
ldr	q1, [sp, #0x150]
ldr	q0, [sp, #0x110]
stp	q1, q0, [x10]
mov	x9, #0x4ec5             ; =20165
movk	x9, #0xc4ec, lsl #16
movk	x9, #0xec4e, lsl #32
movk	x9, #0x4ec4, lsl #48
umulh	x9, x20, x9
lsr	w9, w9, #3
mov	w11, #0x1a              ; =26
msub	w9, w9, w11, w20
add	w9, w9, #0x61
strb	w9, [x10, #0xe]
add	x9, x8, #0x1
str	x9, [x28, #0x22f0]
ldp	x1, x2, [x28, #0x1f0]
mov	x10, #-0x3333333333333334 ; =-3689348814741910324
movk	x10, #0xcccd
umulh	x10, x20, x10
lsr	x10, x10, #6
add	x11, sp, #0x89, lsl #12 ; =0x89000
add	x11, x11, #0x9b0
str	x11, [x24]
mov	w11, #0x1               ; =1
str	x11, [x24, #0x8]
mov	w12, #0x50              ; =80
msub	w10, w10, w12, w20
str	w10, [x24, #0x10]
stp	x11, x9, [x23, #0x90]
str	x8, [x23, #0xa0]
mov	w8, #0x50               ; =80
movk	w8, #0x18, lsl #16
str	w8, [x23, #0x120]
ldr	w8, [sp, #0xe8]
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x430
stur	w8, [x9, #0x94]
ldr	w8, [sp, #0xc0]
sturh	w8, [x9, #0x98]
stur	xzr, [x9, #0x9a]
stur	wzr, [x9, #0xa2]
movi.2d	v0, #0000000000000000
stur	q0, [x9, #0x68]
stur	q0, [x9, #0x58]
stur	q0, [x9, #0x48]
stur	q0, [x9, #0x38]
stur	q0, [x9, #0x28]
stur	q0, [x9, #0x18]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x1b8
str	x8, [x23, #0x108]
ldr	q0, [sp, #0xd0]
str	q0, [x23, #0x110]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0xcc0
add	x3, sp, #0x29, lsl #12  ; =0x29000
add	x3, x3, #0x430
bl	<_schema.messages.pane.encodePaneFrame>
add	x8, sp, #0x8a, lsl #12  ; =0x8a000
add	x8, x8, #0x330
ldrh	w28, [x8, #0x9a0]
cbnz	w28, <_main.execute>
ldr	x1, [x8, #0x990]
ldr	x25, [x8, #0x998]
ldr	x23, [sp, #0xf0]
mov	x0, x23
mov	x2, x25
bl	<_schema.messages.messages.decodeServerInto>
tst	w0, #0xffff
b.ne	<_main.execute>
add	x8, sp, #0xd, lsl #12   ; =0xd000
add	x8, x8, #0xa10
str	x25, [x8, #0x22e0]
str	xzr, [x8, #0x22e8]
ldr	x1, [x8, #0xa8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
str	x23, [x8]
strh	wzr, [x8, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
strb	wzr, [x8, #0x440]
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x3b8
add	x2, sp, #0x71, lsl #12  ; =0x71000
add	x2, x2, #0x700
bl	<_execution.Client.update>
ldrh	w28, [x24, #0x200]
cbnz	w28, <_main.execute>
ldrb	w8, [x24, #0x203]
cbnz	w8, <_main.execute>
add	x23, sp, #0xd, lsl #12  ; =0xd000
add	x23, x23, #0xa10
ldr	x0, [x23, #0xa8]
bl	<_execution.Client.flush>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x1, [x23, #0xa8]
add	x8, x1, x26
ldr	x9, [x8]
add	x28, sp, #0xd, lsl #12  ; =0xd000
add	x28, x28, #0xa10
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
cbz	x9, <_main.execute>
add	x25, sp, #0x8a, lsl #12 ; =0x8a000
add	x25, x25, #0x330
ldr	x10, [x1, x19]
add	x11, x1, x10, lsl #5
add	x11, x11, x27
ldr	q0, [x11]
str	q0, [x25]
ldr	q0, [x11, #0x10]
str	q0, [x25, #0x10]
add	w10, w10, #0x1
and	x10, x10, #0x1f
str	x10, [x1, x19]
sub	x9, x9, #0x1
str	x9, [x8]
add	x0, sp, #0xd, lsl #12   ; =0xd000
add	x0, x0, #0xa98
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0x330
bl	<_ClientEventContext.startJob>
ldr	x1, [x28, #0xa8]
add	x8, x1, x26
ldr	x9, [x8]
cbnz	x9, <_main.execute>
add	x25, sp, #0x8a, lsl #12 ; =0x8a000
add	x25, x25, #0x330
ldrb	w8, [x1, x21]
cmp	w8, #0x1
b.eq	<_main.execute>
b	<_main.execute>
add	x25, sp, #0x8a, lsl #12 ; =0x8a000
add	x25, x25, #0x330
ldrb	w8, [x1, x21]
tbz	w8, #0x0, <_main.execute>
sub	x0, x29, #0xb8
adrp x2, RELOC_PAGE
add	x2, x2, #RELOC_OFFSET
bl	<_execution.Client.update>
sub	x8, x29, #0xb8
ldrh	w28, [x8]
cbnz	w28, <_main.execute>
add	x23, sp, #0xd, lsl #12  ; =0xd000
add	x23, x23, #0xa10
ldr	x0, [x23, #0xa8]
bl	<_execution.Client.flush>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x1, [x23, #0xa8]
add	x8, x1, x26
ldr	x9, [x8]
add	x28, sp, #0xd, lsl #12  ; =0xd000
add	x28, x28, #0xa10
add	x23, sp, #0x29, lsl #12 ; =0x29000
add	x23, x23, #0x3a0
cbz	x9, <_main.execute>
add	x25, sp, #0x8a, lsl #12 ; =0x8a000
add	x25, x25, #0x330
ldr	x10, [x1, x19]
add	x11, x1, x10, lsl #5
add	x11, x11, x27
ldr	q0, [x11]
str	q0, [x25]
ldr	q0, [x11, #0x10]
str	q0, [x25, #0x10]
add	w10, w10, #0x1
and	x10, x10, #0x1f
str	x10, [x1, x19]
sub	x9, x9, #0x1
str	x9, [x8]
add	x0, sp, #0xd, lsl #12   ; =0xd000
add	x0, x0, #0xa98
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0x330
bl	<_ClientEventContext.startJob>
ldr	x1, [x28, #0xa8]
add	x8, x1, x26
ldr	x9, [x8]
cbnz	x9, <_main.execute>
b	<_main.execute>
ldr	x8, [x28, #0x22f8]
add	x20, x8, x22
ldr	x8, [sp, #0xb8]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x22, [sp, #0xa8]
mov	x0, x22
mov	w1, #0x1                ; =1
blr	x9
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x8, [x8]
ldr	x9, [sp, #0xb0]
sub	x2, x8, x9
ldr	x9, [sp, #0xa0]
cmp	x2, x9
b.hs	<_main.execute>
ldr	x9, [sp, #0x160]
lsr	x9, x9, #30
cbnz	x9, <_main.execute>
ldr	x8, [sp, #0x160]
lsl	x8, x8, #2
str	x8, [sp, #0x160]
ldr	x10, [sp, #0xb8]
b	<_main.execute>
mov	w9, #0x41               ; =65
cmp	x8, #0x9
b.hi	<_main.execute>
sub	x9, x9, #0x1
orr	w8, w8, #0x30
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
strb	w8, [x10, x9]
tbz	x28, #0x3f, <_main.execute>
b	<_main.execute>
adrp x10, RELOC_PAGE
add	x10, x10, #RELOC_OFFSET
sub	x9, x9, #0x2
ldrh	w8, [x10, x8, lsl #1]
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
strh	w8, [x10, x9]
tbz	x28, #0x3f, <_main.execute>
sub	x9, x9, #0x1
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	w10, #0x2d              ; =45
strb	w10, [x8, x9]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	w10, #0x41              ; =65
sub	x2, x10, x9
adrp x10, RELOC_PAGE
ldrb	w4, [x10, #RELOC_OFFSET]
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x1b8
add	x1, x8, x9
mov	x3, x2
mov	w5, #0x20               ; =32
bl	<_Io.Writer.alignBuffer>
tst	w0, #0xffff
b.ne	<_main.execute>
mov	x21, #0x0               ; =0
adrp x22, RELOC_PAGE
add	x22, x22, #RELOC_OFFSET
mov	w23, #0x15              ; =21
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x1, x22, x21
ldp	x9, x8, [x24, #0x10]
sub	x19, x23, x21
add	x10, x8, x19
cmp	x10, x9
b.hi	<_main.execute>
ldr	x9, [x24, #0x8]
add	x0, x9, x8
mov	x2, x19
bl	<_memcpy>
ldr	x8, [x24, #0x18]
add	x8, x8, x19
str	x8, [x24, #0x18]
add	x21, x19, x21
cmp	x21, #0x15
b.lo	<_main.execute>
b	<_main.execute>
ldr	x8, [x24]
ldr	x9, [x8]
str	x1, [x24, #0x2a0]
add	x25, sp, #0x8b, lsl #12 ; =0x8b000
add	x25, x25, #0x1b8
str	x19, [x24, #0x2a8]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x1b8
sub	x1, x29, #0xb8
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldrh	w8, [x8, #0x8]
cbnz	w8, <_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x19, [x8]
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x21, x19, x21
cmp	x21, #0x15
b.lo	<_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
add	x19, x8, #0x40
mov	w8, #0x32               ; =50
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
strb	w8, [x9, #0x40]
mov	w21, #0x1               ; =1
add	x9, sp, #0x8b, lsl #12  ; =0x8b000
add	x9, x9, #0x1b8
ldp	x9, x8, [x9, #0x10]
cmp	x8, x9
b.lo	<_main.execute>
add	x22, sp, #0x8b, lsl #12 ; =0x8b000
add	x22, x22, #0x1b8
ldr	x8, [x22]
ldr	x9, [x8]
str	x19, [x22, #0x200]
str	x21, [x22, #0x208]
sub	x8, x29, #0xb8
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x1b8
add	x1, sp, #0x8b, lsl #12  ; =0x8b000
add	x1, x1, #0x3b8
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x25, sp, #0x8b, lsl #12 ; =0x8b000
add	x25, x25, #0x1b8
ldrh	w8, [x22, #0x2a8]
cbnz	w8, <_main.execute>
ldr	x8, [x25, #0x2a0]
cbz	x8, <_main.execute>
ldr	x8, [x25, #0x18]
b	<_main.execute>
add	x11, sp, #0x8b, lsl #12 ; =0x8b000
add	x11, x11, #0x1b8
ldr	x9, [x11, #0x8]
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
ldrb	w10, [x10, #0x40]
strb	w10, [x9, x8]
ldr	x8, [x11, #0x18]
add	x8, x8, #0x1
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
str	x8, [x9, #0x90]
mov	w28, #0x6f              ; =111
ldr	x25, [sp, #0xb0]
b	<_main.execute>
ldr	x8, [sp, #0x98]
ldrb	w2, [x8, #0x53]
cbz	x2, <_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
ldr	x26, [sp, #0x150]
add	x8, x26, #0x14a, lsl #12 ; =0x14a000
add	x1, x8, #0x383
bl	<_config.Diagnostic.set__anon>
ldr	x0, [sp, #0x90]
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
mov	w28, #0x90              ; =144
b	<_main.execute>
mov	w28, #0x95              ; =149
b	<_main.execute>
add	x25, sp, #0x8a, lsl #12 ; =0x8a000
add	x25, x25, #0x330
cmp	x2, #0x0
ldr	x8, [sp, #0x108]
ccmp	x2, x8, #0x2, ne
b.hs	<_main.execute>
ldr	x8, [sp, #0x108]
mul	x0, x23, x8
umulh	x1, x23, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x23, x8
csel	x23, x23, x8, hi
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0x12, lsl #12  ; =0x12000
add	x1, x1, #0x820
mov	x2, x23
bl	<_main.timed__anon>
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
ldrh	w28, [x8, #0x98]
cbnz	w28, <_main.execute>
add	x22, sp, #0x71, lsl #12 ; =0x71000
add	x22, x22, #0x700
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
ldr	x20, [sp, #0x148]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x12, lsl #12  ; =0x12000
add	x1, x1, #0x820
mov	x2, x23
bl	<_main.timed__anon>
ldrh	w28, [x22, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
cbnz	w28, <_main.execute>
ldr	x8, [x8]
udiv	x8, x8, x23
str	x8, [x19], #0x8
subs	x20, x20, #0x1
add	x22, sp, #0x71, lsl #12 ; =0x71000
add	x22, x22, #0x700
b.ne	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
ldr	x10, [x21]
lsr	x11, x20, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
add	x12, sp, #0x12, lsl #12 ; =0x12000
add	x12, x12, #0x820
stp	x23, x11, [x12, #0x70]
stp	x10, x8, [x12, #0x80]
str	x9, [x12, #0x90]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x12, lsl #12  ; =0x12000
add	x0, x0, #0x7c0
add	x2, sp, #0x12, lsl #12  ; =0x12000
add	x2, x2, #0x890
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
ldp	x26, x19, [sp, #0x100]
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x23               ; =35
mov	x3, #0x0                ; =0
mov	x4, x26
ldr	x5, [sp, #0x120]
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
add	x8, sp, #0xd, lsl #12   ; =0xd000
add	x8, x8, #0xa10
ldr	x9, [x8, #0xa8]
mov	w10, #0x4768            ; =18280
movk	w10, #0xc, lsl #16
add	x8, x9, #0xc3, lsl #12  ; =0xc3000
add	x11, x8, #0x368
mov	w8, #0x48               ; =72
mov	x12, #0x100000000       ; =4294967296
ldrb	w13, [x11]
cbz	w13, <_main.execute>
ldur	x13, [x11, #-0x40]
cmp	x13, x12
b.eq	<_main.execute>
add	x11, x11, #0x48
subs	x8, x8, #0x1
b.ne	<_main.execute>
mov	w28, #0x19e             ; =414
b	<_main.execute>
mov	x21, #0x0               ; =0
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x430
add	x20, x8, #0x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
add	x23, sp, #0x39, lsl #12 ; =0x39000
add	x23, x23, #0x430
stp	x8, x20, [x23]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [x23, #0x10]
adrp x22, RELOC_PAGE
add	x22, x22, #RELOC_OFFSET
add	x1, x22, x21
eor	x19, x21, #0x1f
ldp	x9, x8, [x23, #0x10]
add	x10, x8, x19
cmp	x10, x9
b.hi	<_main.execute>
ldr	x9, [x23, #0x8]
add	x0, x9, x8
mov	x2, x19
bl	<_memcpy>
ldr	x8, [x23, #0x18]
add	x8, x8, x19
str	x8, [x23, #0x18]
add	x21, x19, x21
cmp	x21, #0x1f
b.lo	<_main.execute>
b	<_main.execute>
add	x24, sp, #0x39, lsl #12 ; =0x39000
add	x24, x24, #0x430
ldr	x8, [x23]
ldr	x9, [x8]
add	x23, sp, #0x8b, lsl #12 ; =0x8b000
add	x23, x23, #0x1b8
str	x1, [x23, #0x2a0]
str	x19, [x23, #0x2a8]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x1b8
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
sub	x1, x29, #0xb8
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x9, sp, #0x8b, lsl #12  ; =0x8b000
add	x9, x9, #0x1b8
ldrh	w8, [x23, #0x8]
cbnz	w8, <_main.execute>
ldr	x19, [x9]
add	x23, sp, #0x39, lsl #12 ; =0x39000
add	x23, x23, #0x430
add	x21, x19, x21
cmp	x21, #0x1f
b.lo	<_main.execute>
ldr	x8, [x23, #0x18]
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
str	x8, [x9, #0x90]
ldr	x0, [sp, #0x90]
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
mov	w28, #0x6e              ; =110
b	<_main.execute>
mov	x0, x25
bl	<_hb_font_destroy>
mov	w28, #0x96              ; =150
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x0, [x8]
bl	<_FT_Done_Face>
ldr	x0, [x20, #0x90]
bl	<_FT_Done_FreeType>
b	<_main.execute>
ldr	x0, [sp, #0x90]
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
ldr	x26, [sp, #0x150]
b	<_main.execute>
mov	x0, x25
bl	<_hb_ft_font_changed>
strh	w19, [x21, #0x20]
tbnz	wzr, #0x0, <_main.execute>
mov	w19, #0x5800            ; =22528
movk	w19, #0x2, lsl #16
ldr	x25, [sp, #0x110]
xpaci	x25
ldr	x8, [x23]
mov	x0, x26
mov	w1, #0x5800             ; =22528
movk	w1, #0x2, lsl #16
mov	w2, #0x0                ; =0
mov	x3, x25
blr	x8
cbz	x0, <_main.execute>
mov	x26, x0
mov	w1, #0x20               ; =32
mov	w2, #0x5800             ; =22528
movk	w2, #0x2, lsl #16
bl	<_memset>
ldr	q0, [sp, #0x1e0]
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
ldr	x8, [x9, #0x20]
add	x13, sp, #0xb, lsl #12  ; =0xb000
add	x13, x13, #0xa08
str	x8, [x13, #0x148]
ldp	q2, q1, [x9]
add	x21, sp, #0x39, lsl #12 ; =0x39000
add	x21, x21, #0x430
str	q1, [sp, #0xbb40]
str	q0, [sp, #0xbb20]
str	q2, [sp, #0xbb30]
str	q0, [sp, #0xbad0]
str	q2, [sp, #0xbae0]
str	q1, [sp, #0xbaf0]
stp	x8, x26, [x13, #0xf8]
str	x19, [x13, #0x108]
ldr	x8, [sp, #0x130]
ldp	x11, x10, [sp, #0x100]
stp	x8, x11, [x13, #0x158]
ldr	x12, [sp, #0x120]
ldr	x9, [sp, #0x148]
stp	x12, x9, [x13, #0x168]
str	x10, [x13, #0x178]
ldp	q0, q1, [sp, #0x190]
ldr	q2, [sp, #0x1b0]
ldr	x8, [sp, #0x1c0]
add	x23, sp, #0xb, lsl #12  ; =0xb000
add	x23, x23, #0xa08
str	x8, [x13, #0x1b0]
add	x13, sp, #0xb, lsl #12  ; =0xb000
add	x13, x13, #0xb60
stur	q2, [x13, #0x48]
stur	q1, [x13, #0x38]
stur	q0, [x13, #0x28]
ldr	q0, [sp, #0x1d0]
stp	x11, x12, [x13, #0x70]
stp	x9, x10, [x13, #0x80]
ldp	q1, q2, [sp, #0x1f0]
ldr	q3, [sp, #0x210]
ldr	x8, [sp, #0x220]
str	q3, [sp, #0xbc10]
str	q2, [sp, #0xbc00]
str	q0, [sp, #0xbbc0]
str	q1, [sp, #0xbbf0]
add	x9, sp, #0xb, lsl #12   ; =0xb000
add	x9, x9, #0xad0
stp	x8, x9, [x13, #0xc0]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0xbc0
mov	w2, #0x1                ; =1
bl	<_main.timed__anon>
ldrh	w28, [x22, #0x8]
cbnz	w28, <_main.execute>
ldr	x8, [sp, #0x108]
lsr	x19, x8, #2
mov	w26, #0x1               ; =1
add	x22, sp, #0x8a, lsl #12 ; =0x8a000
add	x22, x22, #0x330
ldr	x2, [x22]
cmp	x2, x19
lsr	x8, x26, #30
ccmp	x8, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x26, x26, #2
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0xbc0
mov	x2, x26
bl	<_main.timed__anon>
ldrh	w28, [x22, #0x8]
cbz	w28, <_main.execute>
add	x0, sp, #0xb, lsl #12   ; =0xb000
add	x0, x0, #0xad0
bl	<_main.TextRasterContext.deinit>
b	<_main.execute>
mov	w8, #0x1                ; =1
strb	w8, [x11]
mov	x12, #0x100000000       ; =4294967296
stur	x12, [x11, #-0x40]
adrp x12, RELOC_PAGE
add	x12, x12, #RELOC_OFFSET
ldp	q0, q1, [x12]
stur	q0, [x11, #-0x38]
stur	q1, [x11, #-0x28]
ldr	q0, [x12, #0x20]
stur	q0, [x11, #-0x18]
ldr	x12, [x12, #0x30]
stur	x12, [x11, #-0x8]
ldr	x11, [x9, x10]
add	x11, x11, #0x1
str	x11, [x9, x10]
ldr	x10, [sp, #0x130]
add	x11, sp, #0x12, lsl #12 ; =0x12000
add	x11, x11, #0x820
ldr	x9, [sp, #0x100]
stp	x10, x9, [x11, #0x98]
ldr	x10, [sp, #0x120]
ldr	x9, [sp, #0x148]
stp	x10, x9, [x11, #0xa8]
ldr	x10, [sp, #0x108]
str	x10, [x11, #0xb8]
ldp	q0, q1, [sp, #0x190]
ldr	q2, [sp, #0x1b0]
ldr	x9, [sp, #0x1c0]
str	x9, [x11, #0xf0]
stp	q1, q2, [x11, #0xd0]
stur	q0, [x11, #0xc0]
lsr	x9, x10, #2
str	x9, [sp, #0xf0]
ldp	x19, x24, [sp, #0x1d0]
add	x20, sp, #0x39, lsl #12 ; =0x39000
add	x20, x20, #0x430
mov	w21, #0x3368            ; =13160
movk	w21, #0xc, lsl #16
mov	w22, #0x4768            ; =18280
movk	w22, #0xc, lsl #16
add	x28, sp, #0x180
add	x23, sp, #0x39, lsl #12 ; =0x39000
add	x23, x23, #0x430
str	x19, [sp, #0x110]
str	x24, [sp, #0x160]
b	<_main.execute>
ldr	x24, [sp, #0x160]
ldr	x9, [x24, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x19, [sp, #0x110]
mov	x0, x19
mov	w1, #0x1                ; =1
blr	x9
add	x23, sp, #0x39, lsl #12 ; =0x39000
add	x23, x23, #0x430
ldr	x9, [x23]
lsl	x8, x26, #2
ldr	x11, [sp, #0x150]
sub	x2, x9, x11
ldr	x10, [sp, #0xf0]
cmp	x2, x10
lsr	x10, x26, #30
ccmp	x10, #0x0, #0x0, lo
b.ne	<_main.execute>
mov	x26, x8
ldr	x9, [x24, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x19
mov	w1, #0x1                ; =1
blr	x9
mov	x8, #0x0                ; =0
mov	x27, #0x0               ; =0
add	x14, sp, #0x39, lsl #12 ; =0x39000
add	x14, x14, #0x430
ldr	x9, [x23]
str	x9, [sp, #0x150]
b	<_main.execute>
mov	x10, #0x0               ; =0
add	x27, x10, x27
str	x9, [x14]
str	x20, [sp, #0x180]
add	x8, x8, #0x1
cmp	x8, x26
b.eq	<_main.execute>
add	x9, sp, #0xd, lsl #12   ; =0xd000
add	x9, x9, #0xa10
ldr	x9, [x9, #0xa8]
add	x10, x9, x21
ldr	x11, [x9, x22]
mov	w12, #0x48              ; =72
b	<_main.execute>
sub	x11, x11, #0x1
add	x10, x10, #0x48
subs	x12, x12, #0x1
b.eq	<_main.execute>
cbz	x11, <_main.execute>
ldrb	w13, [x10]
cbz	w13, <_main.execute>
ldurb	w13, [x10, #-0x8]
and	w13, w13, #0x1c
cmp	w13, #0x8
b.ne	<_main.execute>
mov	w10, #0x1               ; =1
b	<_main.execute>
cmp	x9, x11
b.eq	<_main.execute>
ldr	x8, [sp, #0x108]
cmp	x2, x8
b.hs	<_main.execute>
ldr	x8, [sp, #0x108]
mul	x0, x26, x8
umulh	x1, x26, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x26, x8
csel	x26, x26, x8, hi
ldr	x8, [sp, #0x160]
ldr	x9, [x8, #0x2c0]
add	x20, sp, #0x39, lsl #12 ; =0x39000
add	x20, x20, #0x430
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x0, [sp, #0x110]
mov	w1, #0x1                ; =1
blr	x9
mov	x8, #0x0                ; =0
mov	x19, #0x0               ; =0
mov	w9, #0x3368             ; =13160
movk	w9, #0xc, lsl #16
mov	w10, #0x4768            ; =18280
movk	w10, #0xc, lsl #16
add	x11, sp, #0x178
add	x17, sp, #0x39, lsl #12 ; =0x39000
add	x17, x17, #0x430
add	x0, sp, #0xd, lsl #12   ; =0xd000
add	x0, x0, #0xa10
b	<_main.execute>
mov	x13, #0x0               ; =0
add	x19, x13, x19
str	x12, [x17]
str	x20, [sp, #0x178]
add	x8, x8, #0x1
cmp	x8, x26
b.eq	<_main.execute>
ldr	x12, [x0, #0xa8]
add	x13, x12, x9
ldr	x14, [x12, x10]
mov	w15, #0x48              ; =72
b	<_main.execute>
add	x13, x13, #0x48
subs	x15, x15, #0x1
b.eq	<_main.execute>
cbz	x14, <_main.execute>
ldrb	w16, [x13]
cbz	w16, <_main.execute>
ldurb	w16, [x13, #-0x8]
and	w16, w16, #0x1c
cmp	w16, #0x8
b.eq	<_main.execute>
sub	x14, x14, #0x1
b	<_main.execute>
mov	w13, #0x1               ; =1
b	<_main.execute>
add	x23, sp, #0xd, lsl #12  ; =0xd000
add	x23, x23, #0xa10
ldr	x8, [sp, #0x160]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x20, [sp, #0x110]
mov	x0, x20
mov	w1, #0x1                ; =1
blr	x9
add	x24, sp, #0x71, lsl #12 ; =0x71000
add	x24, x24, #0x700
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
str	xzr, [sp, #0x150]
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
mov	w22, #0x3368            ; =13160
movk	w22, #0xc, lsl #16
mov	w28, #0x4768            ; =18280
movk	w28, #0xc, lsl #16
add	x19, sp, #0x170
b	<_main.execute>
ldr	x8, [sp, #0x160]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x20, [sp, #0x110]
mov	x0, x20
mov	w1, #0x1                ; =1
add	x24, sp, #0x71, lsl #12 ; =0x71000
add	x24, x24, #0x700
blr	x9
ldr	x8, [x24]
ldr	x9, [sp, #0xf0]
sub	x8, x8, x9
udiv	x8, x8, x26
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
ldr	x10, [sp, #0x150]
str	x8, [x9, x10, lsl #3]
add	x10, x10, #0x1
ldr	x8, [sp, #0x148]
str	x10, [sp, #0x150]
cmp	x10, x8
b.eq	<_main.execute>
ldr	x8, [sp, #0x160]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
mov	x0, x20
mov	w1, #0x1                ; =1
blr	x9
mov	x8, #0x0                ; =0
mov	x27, #0x0               ; =0
ldr	x9, [x24]
str	x9, [sp, #0xf0]
add	x14, sp, #0x71, lsl #12 ; =0x71000
add	x14, x14, #0x700
b	<_main.execute>
mov	x10, #0x0               ; =0
add	x27, x10, x27
str	x9, [x14]
str	x21, [sp, #0x170]
add	x8, x8, #0x1
cmp	x8, x26
b.eq	<_main.execute>
ldr	x9, [x23, #0xa8]
add	x10, x9, x22
ldr	x11, [x9, x28]
mov	w12, #0x48              ; =72
b	<_main.execute>
add	x10, x10, #0x48
subs	x12, x12, #0x1
b.eq	<_main.execute>
cbz	x11, <_main.execute>
ldrb	w13, [x10]
cbz	w13, <_main.execute>
ldurb	w13, [x10, #-0x8]
and	w13, w13, #0x1c
cmp	w13, #0x8
b.eq	<_main.execute>
sub	x11, x11, #0x1
b	<_main.execute>
mov	w10, #0x1               ; =1
b	<_main.execute>
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x19, [sp, #0x148]
mov	x1, x19
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x19, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x19, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
ldr	x10, [x10]
lsr	x11, x19, #1
add	x12, sp, #0x39, lsl #12 ; =0x39000
add	x12, x12, #0x430
ldr	x11, [x12, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x12, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x12, x9
ldur	x9, [x9, #-0x8]
add	x12, sp, #0x12, lsl #12 ; =0x12000
add	x12, x12, #0x820
stp	x26, x11, [x12, #0xf8]
stp	x10, x8, [x12, #0x108]
str	x9, [x12, #0x118]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x12, lsl #12  ; =0x12000
add	x0, x0, #0x8b8
add	x2, sp, #0x12, lsl #12  ; =0x12000
add	x2, x2, #0x918
bl	<_main.ResultWriter.write>
ldr	x8, [x23, #0xa8]
mov	w9, #0x4768             ; =18280
movk	w9, #0xc, lsl #16
add	x10, x8, #0xc3, lsl #12 ; =0xc3000
add	x10, x10, #0x328
tst	w0, #0xffff
b.ne	<_main.execute>
mov	w11, #0x48              ; =72
mov	x12, #0x100000000       ; =4294967296
b	<_main.execute>
add	x10, x10, #0x48
subs	x11, x11, #0x1
b.eq	<_main.execute>
ldrb	w13, [x10, #0x40]
cbz	w13, <_main.execute>
ldr	x13, [x10]
cmp	x13, x12
b.ne	<_main.execute>
str	xzr, [x10, #0x40]
movi.2d	v0, #0000000000000000
stp	q0, q0, [x10, #0x20]
stp	q0, q0, [x10]
ldr	x10, [x8, x9]
sub	x10, x10, #0x1
str	x10, [x8, x9]
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
ldp	x26, x19, [sp, #0x100]
cbz	x26, <_main.execute>
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x1d               ; =29
mov	x3, #0x0                ; =0
mov	x4, x26
ldr	x5, [sp, #0x120]
bl	<_mem.findPos__anon>
ldrb	w8, [x27, #0x8]
cbz	w8, <_main.execute>
ldr	x8, [sp, #0x130]
add	x11, sp, #0x12, lsl #12 ; =0x12000
add	x11, x11, #0x820
stp	x8, x26, [x11, #0x120]
ldr	x10, [sp, #0x120]
ldr	x9, [sp, #0x148]
stp	x10, x9, [x11, #0x130]
str	x19, [x11, #0x140]
ldp	q0, q1, [sp, #0x190]
add	x11, sp, #0x12, lsl #12 ; =0x12000
add	x11, x11, #0x940
stur	q0, [x11, #0x28]
stur	q1, [x11, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x11, #0x48]
ldr	x8, [sp, #0x1c0]
str	x8, [x11, #0x58]
ldr	q0, [sp, #0x1d0]
str	q0, [x11, #0x60]
stp	x26, x10, [x11, #0x70]
stp	x9, x19, [x11, #0x80]
ldr	x8, [sp, #0x220]
ldp	q0, q1, [sp, #0x200]
stp	q0, q1, [x11, #0xa0]
ldr	q1, [sp, #0x1f0]
str	q1, [x11, #0x90]
add	x9, sp, #0xd, lsl #12   ; =0xd000
add	x9, x9, #0xa98
stp	x8, x9, [x11, #0xc0]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x12, lsl #12  ; =0x12000
add	x1, x1, #0x9a0
mov	w2, #0x1                ; =1
bl	<_main.timed__anon>
ldrh	w28, [x25, #0x8]
cbnz	w28, <_main.execute>
ldr	x8, [sp, #0x108]
lsr	x19, x8, #2
mov	w25, #0x1               ; =1
add	x20, sp, #0x8a, lsl #12 ; =0x8a000
add	x20, x20, #0x330
ldr	x2, [x20]
cmp	x2, x19
lsr	x8, x25, #30
ccmp	x8, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x25, x25, #2
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x12, lsl #12  ; =0x12000
add	x1, x1, #0x9a0
mov	x2, x25
bl	<_main.timed__anon>
ldrh	w28, [x20, #0x8]
cbz	w28, <_main.execute>
b	<_main.execute>
add	x22, sp, #0x8a, lsl #12 ; =0x8a000
add	x22, x22, #0x330
cmp	x2, #0x0
ldr	x8, [sp, #0x108]
ccmp	x2, x8, #0x2, ne
b.hs	<_main.execute>
ldr	x8, [sp, #0x108]
mul	x0, x25, x8
umulh	x1, x25, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x25, x8
csel	x25, x25, x8, hi
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0x12, lsl #12  ; =0x12000
add	x1, x1, #0x9a0
mov	x2, x25
bl	<_main.timed__anon>
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x3a0
ldrh	w28, [x8, #0x98]
cbnz	w28, <_main.execute>
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
ldr	x20, [sp, #0x148]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x12, lsl #12  ; =0x12000
add	x1, x1, #0x9a0
mov	x2, x25
bl	<_main.timed__anon>
ldrh	w28, [x21, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
cbnz	w28, <_main.execute>
ldr	x8, [x8]
udiv	x8, x8, x25
str	x8, [x19], #0x8
subs	x20, x20, #0x1
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
b.ne	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
ldr	x10, [x10]
lsr	x11, x20, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
add	x12, sp, #0x12, lsl #12 ; =0x12000
add	x12, x12, #0x940
stp	x25, x11, [x12, #0xd8]
stp	x10, x8, [x12, #0xe8]
str	x9, [x12, #0xf8]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x12, lsl #12  ; =0x12000
add	x0, x0, #0x940
add	x2, sp, #0x12, lsl #12  ; =0x12000
add	x2, x2, #0xa18
bl	<_main.ResultWriter.write>
mov	x28, x0
and	w19, w0, #0xffff
add	x0, sp, #0xd, lsl #12   ; =0xd000
add	x0, x0, #0xa98
bl	<_ClientEventContext.deinit>
cbnz	w19, <_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
add	x9, sp, #0x12, lsl #12  ; =0x12000
add	x9, x9, #0x940
stp	q0, q1, [x9, #0x100]
ldr	q0, [x8, #0x20]
str	q0, [x9, #0x120]
ldr	x8, [x8, #0x30]
str	x8, [x9, #0x130]
ldr	x8, [sp, #0x100]
cbnz	x8, <_main.execute>
b	<_main.execute>
mov	w28, #0x1a0             ; =416
b	<_main.execute>
ldr	x0, [sp, #0x90]
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
mov	w28, #0x1a              ; =26
ldr	x25, [sp, #0xb0]
ldr	x26, [sp, #0x150]
ldr	x21, [sp, #0xd0]
ldp	x22, x23, [sp, #0xb8]
ldr	x20, [sp, #0x160]
b	<_main.execute>
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
bl	<_Rasterizer.deinit>
mov	w28, #0x1a              ; =26
b	<_main.execute>
mov	x20, #0x0               ; =0
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x430
add	x26, x8, #0x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
add	x23, sp, #0x39, lsl #12 ; =0x39000
add	x23, x23, #0x430
stp	x8, x26, [x23]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [x23, #0x10]
adrp x21, RELOC_PAGE
add	x21, x21, #RELOC_OFFSET
mov	w22, #0x16              ; =22
add	x1, x21, x20
ldp	x9, x8, [x23, #0x10]
sub	x28, x22, x20
add	x10, x8, x28
cmp	x10, x9
b.hi	<_main.execute>
ldr	x9, [x23, #0x8]
add	x0, x9, x8
mov	x2, x28
bl	<_memcpy>
ldr	x8, [x23, #0x18]
add	x8, x8, x28
str	x8, [x23, #0x18]
add	x20, x28, x20
cmp	x20, #0x16
b.lo	<_main.execute>
b	<_main.execute>
ldr	x8, [x23]
ldr	x9, [x8]
add	x23, sp, #0x8b, lsl #12 ; =0x8b000
add	x23, x23, #0x1b8
str	x1, [x23, #0x2a0]
str	x28, [x23, #0x2a8]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x1b8
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
sub	x1, x29, #0xb8
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x9, sp, #0x8b, lsl #12  ; =0x8b000
add	x9, x9, #0x1b8
ldrh	w8, [x23, #0x8]
cbnz	w8, <_main.execute>
ldr	x28, [x9]
add	x23, sp, #0x39, lsl #12 ; =0x39000
add	x23, x23, #0x430
add	x20, x28, x20
cmp	x20, #0x16
b.lo	<_main.execute>
adrp x8, RELOC_PAGE
ldrb	w4, [x8, #RELOC_OFFSET]
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	x1, x19
mov	x2, x25
mov	x3, x25
mov	w5, #0x20               ; =32
bl	<_Io.Writer.alignBuffer>
tst	w0, #0xffff
b.ne	<_main.execute>
adrp x20, RELOC_PAGE
add	x20, x20, #RELOC_OFFSET
mov	w21, #0x1               ; =1
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
ldp	x9, x8, [x9, #0x10]
cmp	x8, x9
b.lo	<_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x8, [x8]
ldr	x9, [x8]
add	x22, sp, #0x8b, lsl #12 ; =0x8b000
add	x22, x22, #0x1b8
str	x20, [x22, #0x2a0]
str	x21, [x22, #0x2a8]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x1b8
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
sub	x1, x29, #0xb8
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x9, sp, #0x8b, lsl #12  ; =0x8b000
add	x9, x9, #0x1b8
ldrh	w8, [x22, #0x8]
cbnz	w8, <_main.execute>
ldr	x8, [x9]
cbz	x8, <_main.execute>
b	<_main.execute>
add	x0, sp, #0xd, lsl #12   ; =0xd000
add	x0, x0, #0xa98
bl	<_ClientEventContext.deinit>
add	x22, sp, #0x8a, lsl #12 ; =0x8a000
add	x22, x22, #0x330
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
add	x9, sp, #0x12, lsl #12  ; =0x12000
add	x9, x9, #0x940
stp	q0, q1, [x9, #0x100]
ldr	q0, [x8, #0x20]
str	q0, [x9, #0x120]
ldr	x8, [x8, #0x30]
str	x8, [x9, #0x130]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x1b               ; =27
mov	x3, #0x0                ; =0
ldr	x4, [sp, #0x100]
ldr	x5, [sp, #0x120]
bl	<_mem.findPos__anon>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldrb	w8, [x8, #0x8]
cbz	w8, <_main.execute>
ldr	q0, [sp, #0x1d0]
mov	w8, #0x1800             ; =6144
movk	w8, #0x1, lsl #16
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
str	q0, [x19, x8]
add	x8, x19, #0x11, lsl #12 ; =0x11000
add	x0, x8, #0x810
mov	w1, #0x238              ; =568
bl	<dyld_stub_binder>
add	x8, x19, #0x11, lsl #12 ; =0x11000
add	x8, x8, #0xaa0
str	xzr, [x8, #0x40]
movi.2d	v0, #0000000000000000
stp	q0, q0, [x8, #0x20]
stp	q0, q0, [x8]
mov	w8, #0x1                ; =1
add	x20, sp, #0x71, lsl #12 ; =0x71000
add	x20, x20, #0x700
strb	w8, [x20]
add	x21, sp, #0x29, lsl #12 ; =0x29000
add	x21, x21, #0x3a0
strb	wzr, [x21, #0x90]
add	x8, x19, #0x11, lsl #12 ; =0x11000
add	x8, x8, #0xa48
stp	q0, q0, [x8]
stp	q0, q0, [x8, #0x20]
str	q0, [x8, #0x40]
str	xzr, [x8, #0x50]
add	x19, sp, #0x12, lsl #12 ; =0x12000
add	x19, x19, #0xa80
add	x0, sp, #0x12, lsl #12  ; =0x12000
add	x0, x0, #0xa80
add	x1, sp, #0x39, lsl #12  ; =0x39000
add	x1, x1, #0x430
mov	w2, #0x1b28             ; =6952
movk	w2, #0x1, lsl #16
bl	<_memcpy>
ldrb	w8, [x20]
add	x20, sp, #0x29, lsl #12 ; =0x29000
add	x20, x20, #0x3a0
ldrb	w9, [x21, #0x90]
ldr	x10, [sp, #0x90]
strb	w8, [x10, #0xb28]
strb	w9, [x10, #0xb29]
str	xzr, [x10, #0xb30]
ldr	x8, [sp, #0x130]
add	x13, sp, #0x24, lsl #12 ; =0x24000
add	x13, x13, #0x5c0
ldp	x11, x10, [sp, #0x100]
stp	x8, x11, [x13]
ldr	x12, [sp, #0x120]
ldr	x9, [sp, #0x148]
stp	x12, x9, [x13, #0x10]
str	x10, [x13, #0x20]
ldp	q0, q1, [sp, #0x190]
ldr	q2, [sp, #0x1b0]
ldr	x8, [sp, #0x1c0]
str	x8, [x13, #0x58]
stur	q2, [x13, #0x48]
stur	q1, [x13, #0x38]
stur	q0, [x13, #0x28]
ldr	q0, [sp, #0x1d0]
str	q0, [x13, #0x60]
stp	x11, x12, [x13, #0x70]
stp	x9, x10, [x13, #0x80]
ldp	q0, q1, [sp, #0x1f0]
ldr	q2, [sp, #0x210]
ldr	x8, [sp, #0x220]
stp	q1, q2, [x13, #0xa0]
str	q0, [x13, #0x90]
stp	x8, x19, [x13, #0xc0]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x24, lsl #12  ; =0x24000
add	x1, x1, #0x620
mov	w2, #0x1                ; =1
bl	<_main.timed__anon>
ldrh	w28, [x22, #0x8]
cbnz	w28, <_main.execute>
ldr	x8, [sp, #0x108]
lsr	x19, x8, #2
mov	w25, #0x1               ; =1
add	x21, sp, #0x8a, lsl #12 ; =0x8a000
add	x21, x21, #0x330
ldr	x2, [x21]
cmp	x2, x19
lsr	x8, x25, #30
ccmp	x8, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x25, x25, #2
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, sp, #0x24, lsl #12  ; =0x24000
add	x1, x1, #0x620
mov	x2, x25
bl	<_main.timed__anon>
ldrh	w28, [x21, #0x8]
cbz	w28, <_main.execute>
add	x0, sp, #0x12, lsl #12  ; =0x12000
add	x0, x0, #0xa80
bl	<_InboxContext.deinit>
b	<_main.execute>
add	x22, sp, #0x8a, lsl #12 ; =0x8a000
add	x22, x22, #0x330
cmp	x2, #0x0
ldr	x8, [sp, #0x108]
ccmp	x2, x8, #0x2, ne
b.hs	<_main.execute>
ldr	x8, [sp, #0x108]
mul	x0, x25, x8
umulh	x1, x25, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x25, x8
csel	x25, x25, x8, hi
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0x24, lsl #12  ; =0x24000
add	x1, x1, #0x620
mov	x2, x25
bl	<_main.timed__anon>
ldrh	w28, [x20, #0x98]
cbnz	w28, <_main.execute>
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
ldr	x20, [sp, #0x148]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x24, lsl #12  ; =0x24000
add	x1, x1, #0x620
mov	x2, x25
bl	<_main.timed__anon>
ldrh	w28, [x21, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
cbnz	w28, <_main.execute>
ldr	x8, [x8]
udiv	x8, x8, x25
str	x8, [x19], #0x8
subs	x20, x20, #0x1
add	x21, sp, #0x71, lsl #12 ; =0x71000
add	x21, x21, #0x700
b.ne	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
ldr	x10, [x10]
lsr	x11, x20, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
add	x12, sp, #0x24, lsl #12 ; =0x24000
add	x12, x12, #0x5c0
stp	x25, x11, [x12, #0xd8]
stp	x10, x8, [x12, #0xe8]
str	x9, [x12, #0xf8]
add	x0, sp, #0x24, lsl #12  ; =0x24000
add	x0, x0, #0x5c0
add	x1, sp, #0x12, lsl #12  ; =0x12000
add	x1, x1, #0xa40
add	x2, sp, #0x24, lsl #12  ; =0x24000
add	x2, x2, #0x698
bl	<_main.ResultWriter.write>
mov	x28, x0
and	w19, w0, #0xffff
add	x0, sp, #0x12, lsl #12  ; =0x12000
add	x0, x0, #0xa80
bl	<_InboxContext.deinit>
cbnz	w19, <_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
add	x9, sp, #0x24, lsl #12  ; =0x24000
add	x9, x9, #0x5c0
stp	q0, q1, [x9, #0x100]
ldr	q0, [x8, #0x20]
str	q0, [x9, #0x120]
ldr	x8, [x8, #0x30]
str	x8, [x9, #0x130]
ldr	x8, [sp, #0x100]
cbnz	x8, <_main.execute>
b	<_main.execute>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
add	x9, sp, #0x24, lsl #12  ; =0x24000
add	x9, x9, #0x5c0
stp	q0, q1, [x9, #0x100]
ldr	q0, [x8, #0x20]
str	q0, [x9, #0x120]
ldr	x8, [x8, #0x30]
str	x8, [x9, #0x130]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	w2, #0x23               ; =35
mov	x3, #0x0                ; =0
ldr	x4, [sp, #0x100]
ldr	x5, [sp, #0x120]
bl	<_mem.findPos__anon>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldrb	w8, [x8, #0x8]
cbz	w8, <_main.execute>
add	x20, sp, #0x24, lsl #12 ; =0x24000
add	x20, x20, #0x700
add	x0, sp, #0x24, lsl #12  ; =0x24000
add	x0, x0, #0x700
add	x1, sp, #0x1d0
add	x2, sp, #0x1e0
bl	<_ClientEventContext.init>
tst	w0, #0xffff
b.ne	<_main.execute>
mov	w19, #0x1               ; =1
ldr	x13, [sp, #0x88]
strb	w19, [x13, #0x99]
mov	w8, #0x2278             ; =8824
add	x12, sp, #0x24, lsl #12 ; =0x24000
add	x12, x12, #0x5c0
ldr	x9, [x12, #0x2440]
str	x9, [x12, #0x23b8]
add	x9, x9, #0x1
str	x9, [x12, #0x2440]
adrp x9, RELOC_PAGE
ldrb	w9, [x9, #RELOC_OFFSET]
str	xzr, [x12, #0x2448]
mov	w10, #0x4a72            ; =19058
add	x10, x20, x10
mov	w11, #0x616c            ; =24940
movk	w11, #0x7470, lsl #16
str	w11, [x10]
mov	w11, #0x706f            ; =28783
strh	w11, [x10, #0x4]
mov	w10, #0x6               ; =6
ldr	x11, [sp, #0x98]
strb	w10, [x11]
strb	wzr, [x13, #0x66]
add	x10, sp, #0x24, lsl #12 ; =0x24000
add	x10, x10, #0x700
mov	w11, #0x37c8            ; =14280
strb	wzr, [x10, x11]
strb	wzr, [x13, #0xff]
and	w9, w9, #0x1
strb	w9, [x13, #0x77]
strb	wzr, [x13, #0x88]
strb	wzr, [x13, #0xaa]
strb	wzr, [x13, #0xbb]
strb	wzr, [x13, #0xcc]
sturh	wzr, [x13, #0xdd]
strh	wzr, [x13]
strh	wzr, [x13, #0x44]
strh	wzr, [x13, #0x22]
str	xzr, [x12, #0x2670]
str	xzr, [x12, #0x25e8]
str	xzr, [x12, #0x2560]
str	xzr, [x12, #0x24d8]
ldr	x9, [x12, #0x24d0]
add	x9, x9, #0x1
add	x21, sp, #0x24, lsl #12 ; =0x24000
add	x21, x21, #0x5c0
str	x9, [x12, #0x24d0]
adrp x2, RELOC_PAGE
add	x2, x2, #RELOC_OFFSET
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0x330
add	x1, x20, x8
mov	w4, #0x0                ; =0
bl	<_machines.Machines.add>
ldrh	w28, [x22]
cbnz	w28, <_main.execute>
mov	x8, #0x0                ; =0
mov	x12, #0x0               ; =0
ldrb	w9, [x22, #0x2]
ldr	x10, [sp, #0x98]
strb	w9, [x10, #0x238]
adrp x10, RELOC_PAGE
add	x10, x10, #RELOC_OFFSET
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
ldr	q0, [x10]
ldr	x10, [x10, #0x10]
adrp x11, RELOC_PAGE
add	x11, x11, #RELOC_OFFSET
movi.2s	v1, #0x1, lsl #16
add	x13, x9, x8
strh	w12, [x13, #0xd4]
add	x12, x12, #0x1
stp	x12, x19, [x13]
str	q0, [x13, #0x10]
strh	w19, [x13, #0xee]
stur	xzr, [x13, #0xe2]
stur	xzr, [x13, #0xda]
stp	x10, x11, [x13, #0x20]
stp	xzr, x11, [x13, #0x30]
stp	xzr, x11, [x13, #0x40]
stp	xzr, x11, [x13, #0x50]
stp	xzr, x11, [x13, #0x60]
stp	xzr, x11, [x13, #0x70]
stp	xzr, x11, [x13, #0x80]
stur	s1, [x13, #0xea]
stp	xzr, x11, [x13, #0x90]
str	wzr, [x13, #0xd0]
stp	xzr, xzr, [x13, #0xa0]
stp	x11, xzr, [x13, #0xb0]
stur	wzr, [x13, #0xd6]
add	x8, x8, #0xf0
stp	x11, xzr, [x13, #0xc0]
cmp	x12, #0x40
b.ne	<_main.execute>
ldr	x8, [x21, #0x160]
mov	w9, #0x1                ; =1
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
add	x11, sp, #0x29, lsl #12 ; =0x29000
add	x11, x11, #0x3a0
stp	x9, x10, [x11, #0x90]
mov	w9, #0x40               ; =64
str	x9, [x11, #0xa0]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x8, x8, #0xbf, lsl #12  ; =0xbf000
add	x1, x8, #0xb8
add	x2, sp, #0x29, lsl #12  ; =0x29000
add	x2, x2, #0x430
bl	<_agents.agent_snapshot.reconcile>
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldrh	w28, [x8, #0x630]
cbnz	w28, <_main.execute>
add	x19, sp, #0x24, lsl #12 ; =0x24000
add	x19, x19, #0x700
add	x0, sp, #0x24, lsl #12  ; =0x24000
add	x0, x0, #0x700
bl	<_ClientEventContext.summarizeMachine>
ldr	x8, [sp, #0x130]
add	x9, sp, #0x24, lsl #12  ; =0x24000
add	x9, x9, #0x5c0
str	x8, [x9, #0x4de0]
ldr	x8, [sp, #0x100]
str	x8, [x9, #0x4de8]
ldr	x8, [sp, #0x120]
str	x8, [x9, #0x4df0]
ldr	x8, [sp, #0x148]
str	x8, [x9, #0x4df8]
ldr	x8, [sp, #0x108]
str	x8, [x9, #0x4e00]
ldp	q0, q1, [sp, #0x190]
add	x10, sp, #0x29, lsl #12 ; =0x29000
add	x10, x10, #0x3a0
stur	q0, [x10, #0x28]
stur	q1, [x10, #0x38]
ldr	q0, [sp, #0x1b0]
lsr	x8, x8, #2
str	x8, [sp, #0xb0]
add	x8, x19, #0x178
str	x8, [sp, #0x110]
stur	q0, [x10, #0x48]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldr	x9, [sp, #0x1c0]
str	x9, [x10, #0x58]
ldp	x10, x9, [sp, #0x1d0]
str	x10, [sp, #0xd0]
str	x9, [sp, #0xc0]
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
mov	w20, #0x2588            ; =9608
movk	w20, #0x27, lsl #16
mov	w27, #0x8942            ; =35138
movk	w27, #0x14, lsl #16
ldp	q1, q0, [x8]
stp	q0, q1, [sp, #0x120]
ldr	w8, [x9]
str	w8, [sp, #0x100]
adrp x25, RELOC_PAGE
add	x25, x25, #RELOC_OFFSET
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [sp, #0xf0]
mov	w21, #0x2580            ; =9600
movk	w21, #0x27, lsl #16
mov	w19, #0x2180            ; =8576
movk	w19, #0x27, lsl #16
mov	w8, #0x1                ; =1
str	x8, [sp, #0x150]
ldrh	w8, [x9, #0x4]
str	w8, [sp, #0xe8]
ldr	x8, [sp, #0xc0]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x0, [sp, #0xd0]
mov	w1, #0x1                ; =1
blr	x9
mov	x22, #0x0               ; =0
str	xzr, [sp, #0x160]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x8, [x8]
str	x8, [sp, #0xb8]
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
add	x28, sp, #0x24, lsl #12 ; =0x24000
add	x28, x28, #0x5c0
b	<_main.execute>
add	x28, sp, #0x24, lsl #12 ; =0x24000
add	x28, x28, #0x5c0
add	x26, sp, #0x8a, lsl #12 ; =0x8a000
add	x26, x26, #0x330
ldr	x23, [x28, #0x23a8]
add	x0, sp, #0x24, lsl #12  ; =0x24000
add	x0, x0, #0x700
bl	<_ClientEventContext.summarizeMachine>
ldr	x8, [x28, #0x24d0]
ldr	x9, [sp, #0x160]
add	x9, x23, x9
add	x8, x9, x8
str	x8, [sp, #0x160]
add	x22, x22, #0x1
ldr	x8, [sp, #0x150]
cmp	x22, x8
b.eq	<_main.execute>
add	x9, sp, #0x89, lsl #12  ; =0x89000
add	x9, x9, #0x9b0
ldp	q0, q1, [sp, #0x120]
stp	q1, q0, [x9]
mov	x8, #0x4ec5             ; =20165
movk	x8, #0xc4ec, lsl #16
movk	x8, #0xec4e, lsl #32
movk	x8, #0x4ec4, lsl #48
umulh	x8, x22, x8
lsr	w8, w8, #3
mov	w10, #0x1a              ; =26
msub	w8, w8, w10, w22
add	w8, w8, #0x61
strb	w8, [x9, #0xe]
ldr	x8, [x28, #0x23a8]
add	x9, x8, #0x1
str	x9, [x28, #0x23a8]
ldr	x1, [x28, #0x2a8]
mov	x10, #-0x3333333333333334 ; =-3689348814741910324
movk	x10, #0xcccd
umulh	x10, x22, x10
lsr	x10, x10, #6
ldr	x2, [x28, #0x2b0]
mov	w11, #0x50              ; =80
msub	w10, w10, w11, w22
add	x11, sp, #0x8b, lsl #12 ; =0x8b000
add	x11, x11, #0x1b8
add	x12, sp, #0x89, lsl #12 ; =0x89000
add	x12, x12, #0x9b0
str	x12, [x11]
mov	w12, #0x1               ; =1
str	x12, [x11, #0x8]
str	w10, [x11, #0x10]
stp	x12, x9, [x24, #0x90]
str	x8, [x24, #0xa0]
mov	w8, #0x50               ; =80
movk	w8, #0x18, lsl #16
str	w8, [x24, #0x120]
ldr	w8, [sp, #0x100]
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x430
stur	w8, [x9, #0x94]
ldr	w8, [sp, #0xe8]
sturh	w8, [x9, #0x98]
stur	xzr, [x9, #0x9a]
stur	wzr, [x9, #0xa2]
movi.2d	v0, #0000000000000000
stur	q0, [x9, #0x68]
stur	q0, [x9, #0x58]
stur	q0, [x9, #0x48]
stur	q0, [x9, #0x38]
stur	q0, [x9, #0x28]
stur	q0, [x9, #0x18]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x1b8
str	x8, [x24, #0x108]
ldr	q0, [sp, #0xf0]
str	q0, [x24, #0x110]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0xcc0
add	x3, sp, #0x29, lsl #12  ; =0x29000
add	x3, x3, #0x430
bl	<_schema.messages.pane.encodePaneFrame>
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
ldrh	w28, [x23, #0x9a0]
cbnz	w28, <_main.execute>
ldr	x1, [x23, #0x990]
ldr	x26, [x23, #0x998]
ldr	x24, [sp, #0x110]
mov	x0, x24
mov	x2, x26
bl	<_schema.messages.messages.decodeServerInto>
tst	w0, #0xffff
b.ne	<_main.execute>
add	x8, sp, #0x24, lsl #12  ; =0x24000
add	x8, x8, #0x5c0
str	x26, [x8, #0x2398]
add	x26, sp, #0x24, lsl #12 ; =0x24000
add	x26, x26, #0x5c0
str	xzr, [x26, #0x23a0]
ldr	x1, [x26, #0x160]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
str	x24, [x8]
strh	wzr, [x8, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
strb	wzr, [x8, #0x440]
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x3b8
add	x2, sp, #0x71, lsl #12  ; =0x71000
add	x2, x2, #0x700
bl	<_execution.Client.update>
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x1b8
ldrh	w28, [x8, #0x200]
cbnz	w28, <_main.execute>
ldrb	w8, [x8, #0x203]
cbnz	w8, <_main.execute>
ldr	x0, [x26, #0x160]
bl	<_execution.Client.flush>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x1, [x26, #0x160]
add	x8, x1, x20
ldr	x9, [x8]
cbz	x9, <_main.execute>
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
ldr	x10, [x1, x21]
add	x11, x1, x10, lsl #5
add	x11, x11, x19
ldr	q0, [x11]
str	q0, [x23]
ldr	q0, [x11, #0x10]
str	q0, [x23, #0x10]
add	w10, w10, #0x1
and	x10, x10, #0x1f
str	x10, [x1, x21]
sub	x9, x9, #0x1
str	x9, [x8]
add	x0, sp, #0x24, lsl #12  ; =0x24000
add	x0, x0, #0x700
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0x330
bl	<_ClientEventContext.startJob>
ldr	x1, [x26, #0x160]
add	x8, x1, x20
ldr	x9, [x8]
cbnz	x9, <_main.execute>
b	<_main.execute>
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
ldrb	w8, [x1, x27]
cmp	w8, #0x1
b.eq	<_main.execute>
b	<_main.execute>
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
ldrb	w8, [x1, x27]
tbz	w8, #0x0, <_main.execute>
sub	x0, x29, #0xb8
mov	x2, x25
bl	<_execution.Client.update>
sub	x8, x29, #0xb8
ldrh	w28, [x8]
cbnz	w28, <_main.execute>
ldr	x0, [x26, #0x160]
bl	<_execution.Client.flush>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x1, [x26, #0x160]
add	x8, x1, x20
ldr	x9, [x8]
cbz	x9, <_main.execute>
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
ldr	x10, [x1, x21]
add	x11, x1, x10, lsl #5
add	x11, x11, x19
ldr	q0, [x11]
str	q0, [x23]
ldr	q0, [x11, #0x10]
str	q0, [x23, #0x10]
add	w10, w10, #0x1
and	x10, x10, #0x1f
str	x10, [x1, x21]
sub	x9, x9, #0x1
str	x9, [x8]
add	x0, sp, #0x24, lsl #12  ; =0x24000
add	x0, x0, #0x700
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0x330
bl	<_ClientEventContext.startJob>
ldr	x1, [x26, #0x160]
add	x8, x1, x20
ldr	x9, [x8]
cbnz	x9, <_main.execute>
b	<_main.execute>
ldr	x8, [x28, #0x23b0]
ldr	x9, [sp, #0x160]
add	x22, x8, x9
ldr	x8, [sp, #0xc0]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x0, [sp, #0xd0]
mov	w1, #0x1                ; =1
blr	x9
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x8, [x8]
ldp	x9, x10, [sp, #0xb0]
sub	x2, x8, x10
cmp	x2, x9
b.hs	<_main.execute>
ldr	x9, [sp, #0x150]
lsr	x9, x9, #30
cbnz	x9, <_main.execute>
ldr	x8, [sp, #0x150]
lsl	x8, x8, #2
str	x8, [sp, #0x150]
b	<_main.execute>
mov	x28, x0
b	<_main.execute>
mov	w28, #0x0               ; =0
b	<_main.execute>
add	x11, sp, #0x39, lsl #12 ; =0x39000
add	x11, x11, #0x430
ldr	x9, [x11, #0x8]
mov	w10, #0x27              ; =39
strb	w10, [x9, x8]
ldr	x8, [x11, #0x18]
add	x8, x8, #0x1
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
str	x8, [x9, #0x90]
mov	x0, x24
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
mov	w28, #0x6e              ; =110
b	<_main.execute>
ldr	x9, [x24, #0x18]
mov	w8, #0x3fd              ; =1021
cmp	x9, #0x3fd
csel	x8, x9, x8, lo
cmp	x9, #0x3fe
b.lo	<_main.execute>
ldr	x10, [x24, #0x8]
ldrsb	w11, [x10, x8]
cmn	w11, #0x41
b.gt	<_main.execute>
subs	x8, x8, #0x1
b.eq	<_main.execute>
cmp	x8, x9
b.lo	<_main.execute>
add	x9, x20, x8
mov	w10, #0xa6              ; =166
strb	w10, [x9, #0x2]
mov	w10, #0x80e2            ; =32994
strh	w10, [x9]
add	x8, x8, #0x3
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
mov	x25, x26
mov	x26, x28
b	<_main.execute>
ldr	x9, [sp, #0xb0]
cmp	x8, x9
b.eq	<_main.execute>
ldr	x8, [sp, #0x108]
cmp	x2, x8
b.hs	<_main.execute>
ldr	x8, [sp, #0x108]
ldr	x19, [sp, #0x160]
mul	x0, x19, x8
umulh	x1, x19, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x19, x8
csel	x19, x19, x8, hi
str	x19, [sp, #0x160]
ldr	x8, [sp, #0xb8]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x0, [sp, #0xa8]
mov	w1, #0x1                ; =1
blr	x9
mov	x20, #0x0               ; =0
mov	x19, #0x0               ; =0
mov	x21, #-0x3333333333333334 ; =-3689348814741910324
movk	x21, #0xcccd
mov	w22, #0x50              ; =80
mov	w23, #0x1a              ; =26
ldr	x24, [sp, #0x160]
umulh	x8, x20, x21
lsr	x8, x8, #6
msub	x3, x8, x22, x20
mov	x8, #0x4ec5             ; =20165
movk	x8, #0xc4ec, lsl #16
movk	x8, #0xec4e, lsl #32
movk	x8, #0x4ec4, lsl #48
umulh	x8, x20, x8
lsr	w8, w8, #3
msub	w8, w8, w23, w20
add	x9, sp, #0x71, lsl #12  ; =0x71000
add	x9, x9, #0x700
ldr	q1, [sp, #0x150]
ldr	q0, [sp, #0x110]
stp	q1, q0, [x9]
add	w8, w8, #0x61
strb	w8, [x9, #0xe]
add	x0, sp, #0xd, lsl #12   ; =0xd000
add	x0, x0, #0xa98
add	x1, sp, #0x71, lsl #12  ; =0x71000
add	x1, x1, #0x700
mov	w2, #0x1                ; =1
bl	<_ClientEventContext.receiveFrame>
tst	w0, #0xffff
b.ne	<_main.execute>
add	x8, sp, #0xd, lsl #12   ; =0xd000
add	x8, x8, #0xa10
ldr	x8, [x8, #0x22f0]
add	x19, x8, x19
add	x20, x20, #0x1
subs	x24, x24, #0x1
b.ne	<_main.execute>
add	x8, sp, #0xd, lsl #12   ; =0xd000
add	x8, x8, #0xa10
ldr	x8, [x8, #0x22f8]
add	x19, x8, x19
ldr	x8, [sp, #0xb8]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x0, [sp, #0xa8]
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
str	xzr, [sp, #0xb0]
mov	w21, #0x2588            ; =9608
movk	w21, #0x27, lsl #16
mov	w19, #0x8942            ; =35138
movk	w19, #0x14, lsl #16
mov	w26, #0x2580            ; =9600
movk	w26, #0x27, lsl #16
mov	w27, #0x2180            ; =8576
movk	w27, #0x27, lsl #16
ldr	x8, [sp, #0xb8]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x0, [sp, #0xa8]
mov	w1, #0x1                ; =1
blr	x9
mov	x20, #0x0               ; =0
mov	x22, #0x0               ; =0
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x8, [x8]
str	x8, [sp, #0xa0]
add	x8, sp, #0xd, lsl #12   ; =0xd000
add	x8, x8, #0xa10
ldr	x8, [x8, #0x22f0]
b	<_main.execute>
add	x25, sp, #0x8a, lsl #12 ; =0x8a000
add	x25, x25, #0x330
add	x8, sp, #0xd, lsl #12   ; =0xd000
add	x8, x8, #0xa10
ldr	x8, [x8, #0x22f0]
add	x22, x8, x22
add	x20, x20, #0x1
ldr	x9, [sp, #0x160]
cmp	x20, x9
b.eq	<_main.execute>
add	x10, sp, #0x89, lsl #12 ; =0x89000
add	x10, x10, #0x9b0
ldr	q1, [sp, #0x150]
ldr	q0, [sp, #0x110]
stp	q1, q0, [x10]
mov	x9, #0x4ec5             ; =20165
movk	x9, #0xc4ec, lsl #16
movk	x9, #0xec4e, lsl #32
movk	x9, #0x4ec4, lsl #48
umulh	x9, x20, x9
lsr	w9, w9, #3
mov	w11, #0x1a              ; =26
msub	w9, w9, w11, w20
add	w9, w9, #0x61
strb	w9, [x10, #0xe]
add	x9, x8, #0x1
add	x10, sp, #0xd, lsl #12  ; =0xd000
add	x10, x10, #0xa10
str	x9, [x10, #0x22f0]
ldp	x1, x2, [x10, #0x1f0]
mov	x10, #-0x3333333333333334 ; =-3689348814741910324
movk	x10, #0xcccd
umulh	x10, x20, x10
lsr	x10, x10, #6
add	x11, sp, #0x8b, lsl #12 ; =0x8b000
add	x11, x11, #0x1b8
add	x12, sp, #0x89, lsl #12 ; =0x89000
add	x12, x12, #0x9b0
str	x12, [x11]
mov	w12, #0x1               ; =1
str	x12, [x11, #0x8]
mov	w13, #0x50              ; =80
msub	w10, w10, w13, w20
add	x23, sp, #0x8b, lsl #12 ; =0x8b000
add	x23, x23, #0x1b8
str	w10, [x11, #0x10]
add	x10, sp, #0x29, lsl #12 ; =0x29000
add	x10, x10, #0x3a0
stp	x12, x9, [x10, #0x90]
str	x8, [x10, #0xa0]
mov	w8, #0x50               ; =80
movk	w8, #0x18, lsl #16
str	w8, [x10, #0x120]
ldr	w8, [sp, #0xe8]
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x430
stur	w8, [x9, #0x94]
ldr	w8, [sp, #0xc0]
sturh	w8, [x9, #0x98]
stur	xzr, [x9, #0x9a]
stur	wzr, [x9, #0xa2]
movi.2d	v0, #0000000000000000
stur	q0, [x9, #0x68]
stur	q0, [x9, #0x58]
stur	q0, [x9, #0x48]
stur	q0, [x9, #0x38]
stur	q0, [x9, #0x28]
stur	q0, [x9, #0x18]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x1b8
str	x8, [x10, #0x108]
ldr	q0, [sp, #0xd0]
str	q0, [x10, #0x110]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0xcc0
add	x3, sp, #0x29, lsl #12  ; =0x29000
add	x3, x3, #0x430
bl	<_schema.messages.pane.encodePaneFrame>
ldrh	w28, [x25, #0x9a0]
cbnz	w28, <_main.execute>
add	x8, sp, #0x8a, lsl #12  ; =0x8a000
add	x8, x8, #0x330
ldr	x1, [x8, #0x990]
ldr	x25, [x8, #0x998]
ldr	x0, [sp, #0xf0]
mov	x2, x25
bl	<_schema.messages.messages.decodeServerInto>
tst	w0, #0xffff
b.ne	<_main.execute>
add	x8, sp, #0xd, lsl #12   ; =0xd000
add	x8, x8, #0xa10
str	x25, [x8, #0x22e0]
str	xzr, [x8, #0x22e8]
add	x24, sp, #0xd, lsl #12  ; =0xd000
add	x24, x24, #0xa10
ldr	x1, [x8, #0xa8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x9, [sp, #0xf0]
str	x9, [x8]
strh	wzr, [x8, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
strb	wzr, [x8, #0x440]
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x3b8
add	x2, sp, #0x71, lsl #12  ; =0x71000
add	x2, x2, #0x700
bl	<_execution.Client.update>
ldrh	w28, [x23, #0x200]
cbnz	w28, <_main.execute>
ldrb	w8, [x23, #0x203]
cbnz	w8, <_main.execute>
ldr	x0, [x24, #0xa8]
bl	<_execution.Client.flush>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x1, [x24, #0xa8]
add	x8, x1, x21
ldr	x9, [x8]
cbz	x9, <_main.execute>
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
add	x24, sp, #0xd, lsl #12  ; =0xd000
add	x24, x24, #0xa10
ldr	x10, [x1, x26]
add	x11, x1, x10, lsl #5
add	x11, x11, x27
ldr	q0, [x11]
str	q0, [x23]
ldr	q0, [x11, #0x10]
str	q0, [x23, #0x10]
add	w10, w10, #0x1
and	x10, x10, #0x1f
str	x10, [x1, x26]
sub	x9, x9, #0x1
str	x9, [x8]
add	x0, sp, #0xd, lsl #12   ; =0xd000
add	x0, x0, #0xa98
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0x330
bl	<_ClientEventContext.startJob>
ldr	x1, [x24, #0xa8]
add	x8, x1, x21
ldr	x9, [x8]
cbnz	x9, <_main.execute>
b	<_main.execute>
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
ldrb	w8, [x1, x19]
cmp	w8, #0x1
adrp x25, RELOC_PAGE
add	x25, x25, #RELOC_OFFSET
b.eq	<_main.execute>
b	<_main.execute>
ldrb	w8, [x1, x19]
tbz	w8, #0x0, <_main.execute>
sub	x0, x29, #0xb8
mov	x2, x25
bl	<_execution.Client.update>
sub	x8, x29, #0xb8
ldrh	w28, [x8]
cbnz	w28, <_main.execute>
add	x24, sp, #0xd, lsl #12  ; =0xd000
add	x24, x24, #0xa10
ldr	x0, [x24, #0xa8]
bl	<_execution.Client.flush>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x1, [x24, #0xa8]
add	x8, x1, x21
ldr	x9, [x8]
add	x24, sp, #0xd, lsl #12  ; =0xd000
add	x24, x24, #0xa10
cbz	x9, <_main.execute>
ldr	x10, [x1, x26]
add	x11, x1, x10, lsl #5
add	x11, x11, x27
ldr	q0, [x11]
str	q0, [x23]
ldr	q0, [x11, #0x10]
str	q0, [x23, #0x10]
add	w10, w10, #0x1
and	x10, x10, #0x1f
str	x10, [x1, x26]
sub	x9, x9, #0x1
str	x9, [x8]
add	x0, sp, #0xd, lsl #12   ; =0xd000
add	x0, x0, #0xa98
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0x330
bl	<_ClientEventContext.startJob>
ldr	x1, [x24, #0xa8]
add	x8, x1, x21
ldr	x9, [x8]
cbnz	x9, <_main.execute>
b	<_main.execute>
add	x8, sp, #0xd, lsl #12   ; =0xd000
add	x8, x8, #0xa10
ldr	x8, [x8, #0x22f8]
add	x20, x8, x22
ldr	x8, [sp, #0xb8]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x0, [sp, #0xa8]
mov	w1, #0x1                ; =1
blr	x9
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x8, [x8]
ldr	x9, [sp, #0xa0]
sub	x8, x8, x9
ldr	x9, [sp, #0x160]
udiv	x8, x8, x9
ldr	x9, [sp, #0xb0]
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
str	x8, [x10, x9, lsl #3]
add	x9, x9, #0x1
ldr	x8, [sp, #0x148]
str	x9, [sp, #0xb0]
cmp	x9, x8
b.ne	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
ldr	x10, [x10]
lsr	x11, x20, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
add	x12, sp, #0x12, lsl #12 ; =0x12000
add	x12, x12, #0x738
ldr	x13, [sp, #0x160]
stp	x13, x11, [x12, #0x60]
stp	x10, x8, [x12, #0x70]
str	x9, [x12, #0x80]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x0, sp, #0x12, lsl #12  ; =0x12000
add	x0, x0, #0x738
add	x2, sp, #0x12, lsl #12  ; =0x12000
add	x2, x2, #0x798
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
ldp	x26, x19, [sp, #0x100]
cbnz	x26, <_main.execute>
b	<_main.execute>
mov	w28, #0x212             ; =530
b	<_main.execute>
mov	x28, x0
add	x0, sp, #0xd, lsl #12   ; =0xd000
add	x0, x0, #0xa98
bl	<_ClientEventContext.deinit>
b	<_main.execute>
cmp	x2, #0x0
ldr	x8, [sp, #0x108]
ccmp	x2, x8, #0x2, ne
b.hs	<_main.execute>
ldr	x8, [sp, #0x108]
mul	x0, x26, x8
umulh	x1, x26, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x26, x8
csel	x26, x26, x8, hi
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0xbc0
mov	x2, x26
bl	<_main.timed__anon>
ldrh	w28, [x20, #0x98]
cbnz	w28, <_main.execute>
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
ldr	x20, [sp, #0x148]
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0xbc0
mov	x2, x26
bl	<_main.timed__anon>
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldrh	w28, [x8, #0x8]
cbnz	w28, <_main.execute>
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x8, [x8]
udiv	x8, x8, x26
str	x8, [x19], #0x8
subs	x20, x20, #0x1
b.ne	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
ldr	x10, [x21]
lsr	x11, x20, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
add	x12, sp, #0xb, lsl #12  ; =0xb000
add	x12, x12, #0xb60
stp	x26, x11, [x12, #0xd8]
stp	x10, x8, [x12, #0xe8]
add	x19, sp, #0xb, lsl #12  ; =0xb000
add	x19, x19, #0xb60
str	x9, [x12, #0xf8]
add	x0, sp, #0xb, lsl #12   ; =0xb000
add	x0, x0, #0xb60
add	x1, sp, #0xb, lsl #12   ; =0xb000
add	x1, x1, #0xa90
add	x2, sp, #0xb, lsl #12   ; =0xb000
add	x2, x2, #0xc38
bl	<_main.ResultWriter.write>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x2, [x23, #0x108]
cbz	x2, <_main.execute>
add	x9, sp, #0xb, lsl #12   ; =0xb000
add	x9, x9, #0xa08
ldr	x1, [x9, #0x100]
ldp	x0, x8, [x9, #0xc8]
ldr	x8, [x8, #0x18]
mov	w3, #0x0                ; =0
mov	x4, x25
blr	x8
add	x20, sp, #0xb, lsl #12  ; =0xb000
add	x20, x20, #0xa08
ldr	x0, [x20, #0xf0]
bl	<_hb_buffer_destroy>
ldr	x0, [x20, #0xe8]
bl	<_hb_font_destroy>
ldr	x0, [x20, #0xe0]
bl	<_FT_Done_Face>
ldr	x0, [x20, #0xd8]
bl	<_FT_Done_FreeType>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0xbc60]
str	q1, [sp, #0xbc70]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0xbc80]
ldr	x8, [x8, #0x30]
str	x8, [x19, #0x130]
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
ldr	x26, [sp, #0x100]
ldr	x23, [sp, #0xe8]
cbnz	x26, <_main.execute>
b	<_main.execute>
ldr	x8, [x0]
ldr	x8, [x8, #0x18]
mov	x1, #0x0                ; =0
mov	w2, #0x1                ; =1
blr	x8
tst	w0, #0xffff
b.eq	<_main.execute>
mov	x28, x0
ldp	q1, q0, [x19]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
stp	q1, q0, [x8]
ldr	x21, [sp, #0x160]
ldr	x8, [x21, #0x18]!
ldp	x1, x20, [sp, #0xb8]
mov	x0, x20
mov	w2, #0x9400             ; =37888
movk	w2, #0x7e, lsl #16
mov	w3, #0x0                ; =0
ldr	x22, [sp, #0xd0]
mov	x4, x22
blr	x8
b	<_main.execute>
ldr	x9, [x25, #0x18]
mov	w8, #0x3fd              ; =1021
cmp	x9, #0x3fd
csel	x8, x9, x8, lo
cmp	x9, #0x3fe
b.lo	<_main.execute>
ldr	x10, [x25, #0x8]
ldrsb	w11, [x10, x8]
cmn	w11, #0x41
b.gt	<_main.execute>
subs	x8, x8, #0x1
b.eq	<_main.execute>
cmp	x8, x9
b.lo	<_main.execute>
add	x9, x20, x8
mov	w10, #0xa6              ; =166
strb	w10, [x9, #0x2]
mov	w10, #0x80e2            ; =32994
strh	w10, [x9]
add	x8, x8, #0x3
b	<_main.execute>
ldr	x9, [x28, #0x18]
mov	w8, #0x3fd              ; =1021
cmp	x9, #0x3fd
csel	x8, x9, x8, lo
cmp	x9, #0x3fe
b.lo	<_main.execute>
ldr	x10, [x28, #0x8]
ldrsb	w11, [x10, x8]
cmn	w11, #0x41
b.gt	<_main.execute>
subs	x8, x8, #0x1
b.eq	<_main.execute>
cmp	x8, x9
b.lo	<_main.execute>
add	x9, x20, x8
mov	w10, #0xa6              ; =166
strb	w10, [x9, #0x2]
mov	w10, #0x80e2            ; =32994
strh	w10, [x9]
add	x8, x8, #0x3
b	<_main.execute>
mov	w28, #0x0               ; =0
b	<_main.execute>
mov	x28, x0
ldr	x20, [sp, #0x160]
ldr	x8, [x20, #0x18]!
mov	x0, x26
mov	x1, x25
mov	w2, #0x1b78             ; =7032
movk	w2, #0x3, lsl #16
mov	w3, #0x3                ; =3
ldr	x21, [sp, #0x150]
mov	x4, x21
blr	x8
b	<_main.execute>
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
ldr	x1, [sp, #0x68]
mov	x2, x26
bl	<_config.Diagnostic.set__anon>
mov	w28, #0x90              ; =144
b	<_main.execute>
mov	x28, x0
b	<_main.execute>
mov	x0, x24
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
mov	x20, #0x0               ; =0
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x430
add	x19, x8, #0x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
stp	x8, x19, [x9]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [x9, #0x10]
adrp x21, RELOC_PAGE
add	x21, x21, #RELOC_OFFSET
mov	w22, #0x2a              ; =42
add	x1, x21, x20
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
ldp	x9, x8, [x9, #0x10]
sub	x28, x22, x20
add	x10, x8, x28
cmp	x10, x9
b.hi	<_main.execute>
add	x23, sp, #0x39, lsl #12 ; =0x39000
add	x23, x23, #0x430
ldr	x9, [x23, #0x8]
add	x0, x9, x8
mov	x2, x28
bl	<_memcpy>
ldr	x8, [x23, #0x18]
add	x8, x8, x28
str	x8, [x23, #0x18]
add	x20, x28, x20
cmp	x20, #0x2a
b.lo	<_main.execute>
b	<_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x8, [x8]
ldr	x9, [x8]
add	x23, sp, #0x8b, lsl #12 ; =0x8b000
add	x23, x23, #0x1b8
str	x1, [x23, #0x2a0]
str	x28, [x23, #0x2a8]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x1b8
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
sub	x1, x29, #0xb8
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x9, sp, #0x8b, lsl #12  ; =0x8b000
add	x9, x9, #0x1b8
ldrh	w8, [x23, #0x8]
cbnz	w8, <_main.execute>
ldr	x28, [x9]
add	x20, x28, x20
cmp	x20, #0x2a
b.lo	<_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x8, [x8, #0x18]
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x3a0
str	x8, [x9, #0x90]
mov	w28, #0x6e              ; =110
b	<_main.execute>
ldr	x21, [sp, #0x160]
ldr	x8, [x21, #0x18]!
mov	x0, x20
mov	x1, x25
ldr	x2, [sp, #0xa8]
mov	w3, #0x0                ; =0
mov	x4, x22
blr	x8
ldr	x8, [x21]
mov	x0, x20
ldr	x1, [sp, #0xb8]
mov	w2, #0x9400             ; =37888
movk	w2, #0x7e, lsl #16
mov	w3, #0x0                ; =0
b	<_main.execute>
mov	x28, x0
b	<_main.execute>
mov	x20, #0x0               ; =0
add	x8, sp, #0x29, lsl #12  ; =0x29000
add	x8, x8, #0x430
add	x26, x8, #0x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
stp	x8, x26, [x9]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [x9, #0x10]
adrp x21, RELOC_PAGE
add	x21, x21, #RELOC_OFFSET
mov	w22, #0x9               ; =9
add	x1, x21, x20
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
ldp	x9, x8, [x9, #0x10]
sub	x28, x22, x20
add	x10, x8, x28
cmp	x10, x9
b.hi	<_main.execute>
add	x23, sp, #0x39, lsl #12 ; =0x39000
add	x23, x23, #0x430
ldr	x9, [x23, #0x8]
add	x0, x9, x8
mov	x2, x28
bl	<_memcpy>
ldr	x8, [x23, #0x18]
add	x8, x8, x28
str	x8, [x23, #0x18]
add	x20, x28, x20
cmp	x20, #0x9
b.lo	<_main.execute>
b	<_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x8, [x8]
ldr	x9, [x8]
add	x23, sp, #0x8b, lsl #12 ; =0x8b000
add	x23, x23, #0x1b8
str	x1, [x23, #0x2a0]
str	x28, [x23, #0x2a8]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x1b8
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
sub	x1, x29, #0xb8
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x9, sp, #0x8b, lsl #12  ; =0x8b000
add	x9, x9, #0x1b8
ldrh	w8, [x23, #0x8]
cbnz	w8, <_main.execute>
ldr	x28, [x9]
add	x20, x28, x20
cmp	x20, #0x9
b.lo	<_main.execute>
adrp x8, RELOC_PAGE
ldrb	w4, [x8, #RELOC_OFFSET]
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
mov	x1, x19
mov	x2, x25
mov	x3, x25
mov	w5, #0x20               ; =32
bl	<_Io.Writer.alignBuffer>
tst	w0, #0xffff
b.ne	<_main.execute>
mov	x20, #0x0               ; =0
adrp x21, RELOC_PAGE
add	x21, x21, #RELOC_OFFSET
mov	w22, #0x11              ; =17
add	x1, x21, x20
add	x9, sp, #0x39, lsl #12  ; =0x39000
add	x9, x9, #0x430
ldp	x9, x8, [x9, #0x10]
sub	x28, x22, x20
add	x10, x8, x28
cmp	x10, x9
b.hi	<_main.execute>
add	x23, sp, #0x39, lsl #12 ; =0x39000
add	x23, x23, #0x430
ldr	x9, [x23, #0x8]
add	x0, x9, x8
mov	x2, x28
bl	<_memcpy>
ldr	x8, [x23, #0x18]
add	x8, x8, x28
str	x8, [x23, #0x18]
add	x20, x28, x20
cmp	x20, #0x11
b.lo	<_main.execute>
b	<_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x8, [x8]
ldr	x9, [x8]
add	x23, sp, #0x8b, lsl #12 ; =0x8b000
add	x23, x23, #0x1b8
str	x1, [x23, #0x2a0]
str	x28, [x23, #0x2a8]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x1b8
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
sub	x1, x29, #0xb8
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
add	x9, sp, #0x8b, lsl #12  ; =0x8b000
add	x9, x9, #0x1b8
ldrh	w8, [x23, #0x8]
cbnz	w8, <_main.execute>
ldr	x28, [x9]
add	x20, x28, x20
cmp	x20, #0x11
b.lo	<_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x8, [x8, #0x18]
b	<_main.execute>
mov	x0, x24
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
mov	x0, x24
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
ldr	x21, [sp, #0xd0]
ldur	x0, [x21, #0x2]
ldur	x8, [x21, #0xa]
ldr	x8, [x8, #0x18]
ldr	x1, [sp, #0x88]
mov	w2, #0xf4f8             ; =62712
movk	w2, #0x11, lsl #16
mov	w3, #0x3                ; =3
ldr	x25, [sp, #0xb0]
mov	x4, x25
blr	x8
ldr	x0, [sp, #0x90]
mov	w1, #-0x2               ; =-2
bl	<_lua_settop>
tst	w28, #0xffff
ldr	x26, [sp, #0x150]
ldp	x22, x23, [sp, #0xb8]
ldr	x20, [sp, #0x160]
b.ne	<_main.execute>
add	x8, x26, #0x12a, lsl #12 ; =0x12a000
add	x19, x8, #0x778
add	x8, x26, #0x106, lsl #12 ; =0x106000
add	x8, x8, #0x76c
mov	w10, #0x1               ; =1
strb	w10, [x19]
ldrh	w10, [x8, #0x8]
strh	w10, [x8, #0xa]
add	x9, x26, #0x104, lsl #12 ; =0x104000
ldr	w9, [x9, #0x1768]
str	w9, [x8]
add	x8, x26, #0x12a, lsl #12 ; =0x12a000
add	x8, x8, #0x8b4
ldp	q0, q1, [x8]
add	x9, sp, #0x8a, lsl #12  ; =0x8a000
stp	q0, q1, [x9, #0x330]!
ldr	x8, [x8, #0x20]
str	x8, [x9, #0x20]
add	x8, x26, #0xcf, lsl #12 ; =0xcf000
add	x27, x8, #0xf60
ldrh	w20, [x19, #0x166]
add	x21, sp, #0x39, lsl #12 ; =0x39000
add	x21, x21, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0x330
bl	<_config.default_bindings.load>
mov	w8, #0x8fc8             ; =36808
ldrh	w8, [x21, x8]
cbnz	w8, <_main.execute>
add	x22, sp, #0x71, lsl #12 ; =0x71000
add	x22, x22, #0x700
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
add	x1, sp, #0x39, lsl #12  ; =0x39000
add	x1, x1, #0x430
mov	w2, #0x8fc8             ; =36808
bl	<_memcpy>
cbz	w20, <_main.execute>
mov	x9, #0x0                ; =0
mov	w10, #0x358             ; =856
mov	x8, x20
add	x7, sp, #0x8a, lsl #12  ; =0x8a000
add	x7, x7, #0x330
add	x21, sp, #0x89, lsl #12 ; =0x89000
add	x21, x21, #0x9b0
b	<_main.execute>
add	x9, x9, #0x1
cmp	x9, #0x2b
b.eq	<_main.execute>
mov	x11, #0x0               ; =0
madd	x13, x9, x10, x22
add	x12, x13, #0x288
ldrb	w13, [x13, #0x350]
madd	x17, x11, x10, x27
ldrb	w14, [x17, #0x350]
cmp	x14, x13
mov	x15, #0x0               ; =0
csel	x16, x14, x13, lo
cbz	x16, <_main.execute>
add	x17, x17, #0x288
b	<_main.execute>
cmp	w2, w3
b.ne	<_main.execute>
add	x15, x15, #0x1
cmp	x15, x16
b.eq	<_main.execute>
add	x0, x15, x15, lsl #2
lsl	x1, x0, #3
add	x0, x17, x1
add	x1, x12, x1
ldrb	w2, [x0, #0x26]
ldrb	w3, [x1, #0x26]
eor	w2, w3, w2
tst	w2, #0xf
b.ne	<_main.execute>
ldrb	w2, [x0, #0x20]
and	w2, w2, #0xf
ldrb	w3, [x1, #0x20]
and	w3, w3, #0xf
cmp	w2, #0x0
ccmp	w2, w3, #0x0, eq
b.ne	<_main.execute>
ldur	w2, [x0, #0x21]
str	w2, [x7, #0x990]
ldurb	w0, [x0, #0x25]
strb	w0, [x7, #0x994]
ldur	w2, [x1, #0x21]
str	w2, [x21]
ldurb	w1, [x1, #0x25]
strb	w1, [x21, #0x4]
cmp	w0, w1
csel	w2, w0, w1, lo
cbz	w2, <_main.execute>
add	x3, sp, #0x89, lsl #12  ; =0x89000
add	x3, x3, #0x9b0
add	x4, sp, #0x8a, lsl #12  ; =0x8a000
add	x4, x4, #0xcc0
ldrb	w5, [x4], #0x1
ldrb	w6, [x3], #0x1
cmp	w5, w6
b.ne	<_main.execute>
subs	x2, x2, #0x1
b.ne	<_main.execute>
cmp	w0, w1
b.eq	<_main.execute>
b	<_main.execute>
mov	x15, x16
cmp	x15, x14
ccmp	x15, x13, #0x4, ne
b.eq	<_main.execute>
add	x11, x11, #0x1
cmp	x11, x20
b.ne	<_main.execute>
add	x8, x8, #0x1
b	<_main.execute>
cmp	x8, #0x101
b.lo	<_main.execute>
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
ldp	q0, q1, [x9]
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
stp	q0, q1, [x10]
ldr	x9, [x9, #0x20]
stp	x9, x8, [x10, #0x20]
mov	w8, #0x1                ; =1
strb	w8, [x10, #0x30]
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
stp	x8, xzr, [x10, #0x38]
ldr	x8, [sp, #0x150]
mov	w9, #0xfdb0             ; =64944
movk	w9, #0x12, lsl #16
add	x0, x8, x9
add	x1, sp, #0x39, lsl #12  ; =0x39000
add	x1, x1, #0x430
bl	<_config.UnreportedReaches.add>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
add	x26, x8, #0x2, lsl #12  ; =0x2000
ldrh	w8, [x19, #0x166]
cbz	w8, <_main.execute>
ldr	x9, [sp, #0x150]
add	x9, x9, #0x130, lsl #12 ; =0x130000
add	x9, x9, #0x238
str	x9, [sp, #0xc0]
and	x28, x8, #0x7
cmp	w8, #0x8
b.hs	<_main.execute>
str	xzr, [sp, #0x98]
cbz	x28, <_main.execute>
mov	w8, #0x358              ; =856
ldr	x9, [sp, #0x150]
ldr	x10, [sp, #0x98]
madd	x8, x10, x8, x9
add	x8, x8, #0xcf, lsl #12  ; =0xcf000
add	x19, x8, #0xf68
mov	w20, #0xd0              ; =208
b	<_main.execute>
add	x19, x19, #0x358
subs	x28, x28, #0x1
b.eq	<_main.execute>
ldrb	w8, [x19, #0x278]
and	w8, w8, #0x3e
cmp	w8, #0x1c
b.ne	<_main.execute>
ldr	w8, [x19]
ldr	x9, [sp, #0xc0]
umaddl	x21, w8, w20, x9
ldrb	w8, [x19, #0x348]
add	x8, x8, x8, lsl #2
lsl	x2, x8, #3
add	x0, x21, #0x4
add	x1, x19, #0x280
bl	<_memcpy>
ldrb	w8, [x19, #0x348]
strb	w8, [x21, #0xcd]
b	<_main.execute>
ldr	x8, [sp, #0xd0]
ldur	x8, [x8, #0x1a]
ldr	x0, [x8, #0x20]
mov	w1, #0x0                ; =0
bl	<_lua_settop>
add	x19, sp, #0x7, lsl #12  ; =0x7000
add	x19, x19, #0x8b8
ldr	q0, [x27]
add	x8, sp, #0x7, lsl #12   ; =0x7000
add	x8, x8, #0x7c1
stur	q0, [x8, #0xff]
add	x0, x19, #0x18
mov	w1, #0x408              ; =1032
bl	<dyld_stub_binder>
ldp	q0, q1, [sp, #0x190]
add	x9, sp, #0x7, lsl #12   ; =0x7000
add	x9, x9, #0xcd8
stur	q0, [x9, #0x28]
ldr	x8, [sp, #0x150]
str	x8, [sp, #0x78b8]
ldr	x8, [sp, #0x130]
str	x8, [sp, #0x7cd8]
ldr	x8, [sp, #0x100]
str	x8, [sp, #0x7ce0]
ldr	x8, [sp, #0x120]
str	x8, [sp, #0x7ce8]
ldr	x8, [sp, #0x148]
str	x8, [sp, #0x7cf0]
stur	q1, [x9, #0x38]
ldr	q0, [sp, #0x1b0]
stur	q0, [x9, #0x48]
ldr	x8, [sp, #0x1c0]
add	x21, sp, #0x29, lsl #12 ; =0x29000
add	x21, x21, #0x430
ldr	x9, [sp, #0x108]
lsr	x22, x9, #2
str	x9, [sp, #0x7cf8]
str	x8, [sp, #0x7d30]
mov	w20, #0x1               ; =1
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldr	q0, [x8]
str	q0, [sp, #0x160]
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x3a0
ldr	x24, [sp, #0xa0]
ldr	x8, [sp, #0xa8]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x24
mov	w1, #0x1                ; =1
blr	x9
mov	x23, #0x0               ; =0
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x25, [x8]
mov	x24, x20
ldr	x1, [sp, #0x78b8]
ldur	q0, [x19, #0x8]
str	q0, [x27, #0x90]
ldr	q0, [sp, #0x160]
stur	q0, [x21, #0x10]
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
add	x2, sp, #0x29, lsl #12  ; =0x29000
add	x2, x2, #0x430
add	x3, x19, #0x18
bl	<_config.Generation.invokeCallback>
ldrh	w28, [x26, #0x888]
cbnz	w28, <_main.execute>
ldrb	w8, [x26, #0x880]
add	x23, x23, x8
subs	x24, x24, #0x1
add	x27, sp, #0x29, lsl #12 ; =0x29000
add	x27, x27, #0x3a0
b.ne	<_main.execute>
ldp	x24, x8, [sp, #0xa0]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x24
mov	w1, #0x1                ; =1
blr	x9
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x8, [x8]
sub	x2, x8, x25
cmp	x2, x22
lsr	x9, x20, #30
ccmp	x9, #0x0, #0x0, lo
b.ne	<_main.execute>
lsl	x20, x20, #2
b	<_main.execute>
add	x24, sp, #0x29, lsl #12 ; =0x29000
add	x24, x24, #0x3a0
cmp	x8, x25
b.eq	<_main.execute>
ldr	x8, [sp, #0x108]
cmp	x2, x8
b.hs	<_main.execute>
ldr	x8, [sp, #0x108]
mul	x0, x20, x8
umulh	x1, x20, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x20, x8
csel	x20, x20, x8, hi
ldp	x0, x8, [sp, #0xa0]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	w1, #0x1                ; =1
blr	x9
mov	x21, #0x0               ; =0
add	x22, sp, #0x29, lsl #12 ; =0x29000
add	x22, x22, #0x430
mov	x23, x20
ldr	x1, [sp, #0x78b8]
ldur	q0, [x19, #0x8]
str	q0, [x24, #0x90]
ldr	q0, [sp, #0x160]
stur	q0, [x22, #0x10]
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
add	x2, sp, #0x29, lsl #12  ; =0x29000
add	x2, x2, #0x430
add	x3, x19, #0x18
bl	<_config.Generation.invokeCallback>
ldrh	w28, [x26, #0x888]
cbnz	w28, <_main.execute>
ldrb	w8, [x26, #0x880]
add	x21, x21, x8
subs	x23, x23, #0x1
b.ne	<_main.execute>
ldp	x24, x27, [sp, #0xa0]
ldr	x9, [x27, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x24
mov	w1, #0x1                ; =1
blr	x9
add	x28, sp, #0x29, lsl #12 ; =0x29000
add	x28, x28, #0x3a0
add	x25, sp, #0x39, lsl #12 ; =0x39000
add	x25, x25, #0x430
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
mov	x21, #0x0               ; =0
add	x22, sp, #0x29, lsl #12 ; =0x29000
add	x22, x22, #0x430
ldr	x9, [x27, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x24
mov	w1, #0x1                ; =1
blr	x9
mov	x23, #0x0               ; =0
ldr	x8, [x25]
str	x8, [sp, #0x150]
mov	x25, x20
ldr	x1, [sp, #0x78b8]
ldur	q0, [x19, #0x8]
str	q0, [x28, #0x90]
ldr	q0, [sp, #0x160]
stur	q0, [x22, #0x10]
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
add	x2, sp, #0x29, lsl #12  ; =0x29000
add	x2, x2, #0x430
add	x3, x19, #0x18
bl	<_config.Generation.invokeCallback>
ldrh	w28, [x26, #0x888]
cbnz	w28, <_main.execute>
ldrb	w8, [x26, #0x880]
add	x23, x23, x8
subs	x25, x25, #0x1
add	x28, sp, #0x29, lsl #12 ; =0x29000
add	x28, x28, #0x3a0
b.ne	<_main.execute>
ldp	x24, x27, [sp, #0xa0]
ldr	x9, [x27, #0x2c0]
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
mov	x0, x24
mov	w1, #0x1                ; =1
blr	x9
add	x25, sp, #0x39, lsl #12 ; =0x39000
add	x25, x25, #0x430
ldr	x8, [x25]
ldr	x9, [sp, #0x150]
sub	x8, x8, x9
udiv	x8, x8, x20
add	x9, sp, #0x71, lsl #12  ; =0x71000
add	x9, x9, #0x700
str	x8, [x9, x21, lsl #3]
add	x21, x21, #0x1
ldr	x8, [sp, #0x148]
cmp	x21, x8
b.ne	<_main.execute>
add	x19, sp, #0x71, lsl #12 ; =0x71000
add	x19, x19, #0x700
add	x0, sp, #0x71, lsl #12  ; =0x71000
add	x0, x0, #0x700
ldr	x21, [sp, #0x148]
mov	x1, x21
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x21, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x21, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
add	x10, sp, #0x71, lsl #12 ; =0x71000
add	x10, x10, #0x700
ldr	x10, [x10]
lsr	x11, x21, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
str	x20, [sp, #0x7d38]
str	x11, [sp, #0x7d40]
str	x10, [sp, #0x7d48]
str	x8, [sp, #0x7d50]
str	x9, [sp, #0x7d58]
add	x0, sp, #0x7, lsl #12   ; =0x7000
add	x0, x0, #0xcd8
add	x1, sp, #0x7, lsl #12   ; =0x7000
add	x1, x1, #0x880
add	x2, sp, #0x7, lsl #12   ; =0x7000
add	x2, x2, #0xd38
bl	<_main.ResultWriter.write>
ldr	x26, [sp, #0x78b8]
tst	w0, #0xffff
b.ne	<_main.execute>
mov	w19, #0xfda8            ; =64936
movk	w19, #0x12, lsl #16
add	x8, x26, #0x10, lsl #12 ; =0x10000
add	x20, x8, #0x890
ldr	x27, [x20, #0x18]
ldr	x0, [x27, #0x20]
bl	<_lua_close>
ldp	x0, x8, [x27, #0x10]
ldr	x8, [x8, #0x18]
mov	x1, x27
mov	w2, #0x50               ; =80
mov	w3, #0x3                ; =3
ldr	x21, [sp, #0xb0]
mov	x4, x21
blr	x8
ldp	x0, x8, [x20]
ldr	x1, [x26, x19]
ldr	x8, [x8, #0x18]
mov	w2, #0x5da0             ; =23968
movk	w2, #0x1, lsl #16
mov	w3, #0x3                ; =3
mov	x4, x21
blr	x8
ldp	x0, x8, [x20]
ldr	x8, [x8, #0x18]
mov	x1, x26
mov	w2, #0xa3d0             ; =41936
movk	w2, #0x14, lsl #16
mov	w3, #0x4                ; =4
mov	x4, x21
blr	x8
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldp	q0, q1, [x8]
str	q0, [sp, #0x7d60]
str	q1, [sp, #0x7d70]
ldr	q0, [x8, #0x20]
str	q0, [sp, #0x7d80]
ldr	x8, [x8, #0x30]
str	x8, [sp, #0x7d90]
add	x27, sp, #0x39, lsl #12 ; =0x39000
add	x27, x27, #0x430
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
ldp	x26, x20, [sp, #0x100]
ldr	x19, [sp, #0x120]
cbnz	x26, <_main.execute>
b	<_main.execute>
ldr	x0, [sp, #0x78b8]
bl	<_main.LuaCallbackContext.deinit>
b	<_main.execute>
mov	x19, #0x0               ; =0
lsr	x8, x8, #3
mov	w9, #0x1ac0             ; =6848
umull	x8, w8, w9
stp	x8, xzr, [sp, #0x90]
ldr	x9, [sp, #0x150]
add	x8, x9, #0xd0, lsl #12  ; =0xd0000
add	x8, x8, #0x1e0
str	x8, [sp, #0x88]
add	x8, x9, #0xcf, lsl #12  ; =0xcf000
add	x8, x8, #0xf68
str	x8, [sp, #0xb8]
add	x8, x9, #0xd0, lsl #12  ; =0xd0000
add	x10, x8, #0x2b0
add	x8, x9, #0xd0, lsl #12  ; =0xd0000
add	x8, x8, #0x1e8
stp	x10, x8, [sp, #0x58]
add	x8, x9, #0xd0, lsl #12  ; =0xd0000
add	x10, x8, #0x538
add	x8, x9, #0xd0, lsl #12  ; =0xd0000
add	x11, x8, #0x608
add	x8, x9, #0xd0, lsl #12  ; =0xd0000
add	x8, x8, #0x540
stp	x11, x8, [sp, #0x48]
add	x8, x9, #0xd0, lsl #12  ; =0xd0000
add	x8, x8, #0x890
stp	x8, x10, [sp, #0x68]
add	x8, x9, #0xd0, lsl #12  ; =0xd0000
add	x25, x8, #0x960
add	x8, x9, #0xd0, lsl #12  ; =0xd0000
add	x8, x8, #0x898
str	x8, [sp, #0x40]
add	x8, x9, #0xd1, lsl #12  ; =0xd1000
add	x8, x8, #0xa28
str	x8, [sp, #0x160]
mov	w20, #0xd0              ; =208
b	<_main.execute>
ldr	x8, [sp, #0x98]
add	x8, x8, #0x8
str	x8, [sp, #0x98]
mov	w8, #0x1ac0             ; =6848
add	x19, x19, x8
ldr	x8, [sp, #0x90]
cmp	x8, x19
b.eq	<_main.execute>
ldr	x8, [sp, #0x160]
add	x22, x8, x19
prfm	pldl1keep, [x22, #0x278]
ldr	x8, [sp, #0x88]
ldrb	w8, [x8, x19]
and	w8, w8, #0x3e
prfm	pldl1keep, [x22, #0x348]
cmp	w8, #0x1c
b.ne	<_main.execute>
prfm	pldl1keep, [x22]
ldp	x8, x9, [sp, #0xb8]
ldr	w8, [x8, x19]
umaddl	x21, w8, w20, x9
ldr	x23, [sp, #0x58]
ldrb	w8, [x23, x19]
add	x8, x8, x8, lsl #2
lsl	x2, x8, #3
add	x0, x21, #0x4
ldr	x8, [sp, #0x60]
add	x1, x8, x19
bl	<_memcpy>
ldrb	w8, [x23, x19]
strb	w8, [x21, #0xcd]
add	x8, x22, #0x6a0
add	x9, x22, #0x5d0
prfm	pldl1keep, [x9]
ldr	x9, [sp, #0x70]
ldrb	w9, [x9, x19]
and	w9, w9, #0x3e
prfm	pldl1keep, [x8]
cmp	w9, #0x1c
b.ne	<_main.execute>
ldp	x8, x9, [sp, #0xb8]
add	x8, x8, x19
ldr	w8, [x8, #0x358]
umaddl	x21, w8, w20, x9
ldr	x23, [sp, #0x48]
ldrb	w8, [x23, x19]
add	x8, x8, x8, lsl #2
lsl	x2, x8, #3
add	x0, x21, #0x4
ldr	x8, [sp, #0x50]
add	x1, x8, x19
bl	<_memcpy>
ldrb	w8, [x23, x19]
strb	w8, [x21, #0xcd]
add	x8, x22, #0x9f8
add	x9, x22, #0x928
prfm	pldl1keep, [x9]
ldr	x9, [sp, #0x68]
ldrb	w9, [x9, x19]
and	w9, w9, #0x3e
prfm	pldl1keep, [x8]
cmp	w9, #0x1c
b.ne	<_main.execute>
ldp	x8, x9, [sp, #0xb8]
add	x8, x8, x19
ldr	w8, [x8, #0x6b0]
umaddl	x21, w8, w20, x9
ldrb	w8, [x25, x19]
add	x8, x8, x8, lsl #2
lsl	x2, x8, #3
add	x0, x21, #0x4
ldr	x8, [sp, #0x40]
add	x1, x8, x19
bl	<_memcpy>
ldrb	w8, [x25, x19]
strb	w8, [x21, #0xcd]
add	x8, x22, #0xd50
add	x9, x22, #0xc80
ldr	x10, [sp, #0x160]
add	x21, x10, x19
sub	x10, x21, #0xe40
prfm	pldl1keep, [x9]
ldrb	w9, [x10]
and	w9, w9, #0x3e
prfm	pldl1keep, [x8]
cmp	w9, #0x1c
b.ne	<_main.execute>
ldp	x8, x9, [sp, #0xb8]
add	x8, x8, x19
ldr	w8, [x8, #0xa08]
umaddl	x23, w8, w20, x9
sub	x24, x21, #0xd70
ldrb	w8, [x24]
sub	x1, x21, #0xe38
add	x8, x8, x8, lsl #2
lsl	x2, x8, #3
add	x0, x23, #0x4
bl	<_memcpy>
ldrb	w8, [x24]
strb	w8, [x23, #0xcd]
mov	w8, #0x10a8             ; =4264
add	x8, x22, x8
add	x9, x22, #0xfd8
sub	x10, x21, #0xae8
prfm	pldl1keep, [x9]
ldrb	w9, [x10]
and	w9, w9, #0x3e
prfm	pldl1keep, [x8]
cmp	w9, #0x1c
b.ne	<_main.execute>
ldp	x8, x9, [sp, #0xb8]
add	x8, x8, x19
ldr	w8, [x8, #0xd60]
umaddl	x21, w8, w20, x9
ldr	x8, [sp, #0x160]
add	x8, x8, x19
sub	x23, x8, #0xa18
ldrb	w9, [x23]
sub	x1, x8, #0xae0
add	x8, x9, x9, lsl #2
lsl	x2, x8, #3
add	x0, x21, #0x4
bl	<_memcpy>
ldrb	w8, [x23]
strb	w8, [x21, #0xcd]
mov	w8, #0x1400             ; =5120
add	x8, x22, x8
mov	w9, #0x1330             ; =4912
add	x9, x22, x9
ldr	x10, [sp, #0x160]
add	x21, x10, x19
sub	x10, x21, #0x790
prfm	pldl1keep, [x9]
ldrb	w9, [x10]
and	w9, w9, #0x3e
prfm	pldl1keep, [x8]
cmp	w9, #0x1c
b.ne	<_main.execute>
ldp	x8, x9, [sp, #0xb8]
add	x8, x8, x19
ldr	w8, [x8, #0x10b8]
umaddl	x23, w8, w20, x9
sub	x24, x21, #0x6c0
ldrb	w8, [x24]
sub	x1, x21, #0x788
add	x8, x8, x8, lsl #2
lsl	x2, x8, #3
add	x0, x23, #0x4
bl	<_memcpy>
ldrb	w8, [x24]
strb	w8, [x23, #0xcd]
mov	w8, #0x1758             ; =5976
add	x8, x22, x8
mov	w9, #0x1688             ; =5768
add	x9, x22, x9
sub	x10, x21, #0x438
prfm	pldl1keep, [x9]
ldrb	w9, [x10]
and	w9, w9, #0x3e
prfm	pldl1keep, [x8]
cmp	w9, #0x1c
b.ne	<_main.execute>
ldp	x8, x9, [sp, #0xb8]
add	x8, x8, x19
ldr	w8, [x8, #0x1410]
umaddl	x21, w8, w20, x9
ldr	x8, [sp, #0x160]
add	x8, x8, x19
sub	x23, x8, #0x368
ldrb	w9, [x23]
sub	x1, x8, #0x430
add	x8, x9, x9, lsl #2
lsl	x2, x8, #3
add	x0, x21, #0x4
bl	<_memcpy>
ldrb	w8, [x23]
strb	w8, [x21, #0xcd]
mov	w8, #0x19e0             ; =6624
add	x8, x22, x8
ldr	x9, [sp, #0x160]
add	x21, x9, x19
prfm	pldl1keep, [x8]
ldurb	w8, [x21, #-0xe0]
and	w8, w8, #0x3e
cmp	w8, #0x1c
b.ne	<_main.execute>
mov	w8, #0x1ab0             ; =6832
add	x8, x22, x8
ldp	x9, x10, [sp, #0xb8]
add	x9, x9, x19
ldr	w9, [x9, #0x1768]
umaddl	x22, w9, w20, x10
prfm	pldl1keep, [x8]
ldurb	w8, [x21, #-0x10]
sub	x1, x21, #0xd8
add	x8, x8, x8, lsl #2
lsl	x2, x8, #3
add	x0, x22, #0x4
bl	<_memcpy>
ldurb	w8, [x21, #-0x10]
strb	w8, [x22, #0xcd]
b	<_main.execute>
ldr	x9, [x24, #0x18]
mov	w8, #0x3fd              ; =1021
cmp	x9, #0x3fd
csel	x8, x9, x8, lo
cmp	x9, #0x3fe
b.lo	<_main.execute>
ldr	x10, [x24, #0x8]
ldrsb	w11, [x10, x8]
cmn	w11, #0x41
b.gt	<_main.execute>
subs	x8, x8, #0x1
b.eq	<_main.execute>
cmp	x8, x9
b.lo	<_main.execute>
add	x9, x20, x8
mov	w10, #0xa6              ; =166
strb	w10, [x9, #0x2]
mov	w10, #0x80e2            ; =32994
strh	w10, [x9]
add	x8, x8, #0x3
b	<_main.execute>
ldr	x9, [sp, #0xb8]
cmp	x8, x9
b.eq	<_main.execute>
ldr	x8, [sp, #0x108]
cmp	x2, x8
b.hs	<_main.execute>
ldr	x8, [sp, #0x108]
ldr	x19, [sp, #0x150]
mul	x0, x19, x8
umulh	x1, x19, x8
mov	x3, #0x0                ; =0
bl	<_compiler_rt.udivmod.__udivti3>
mov	w8, #0x40000000         ; =1073741824
cmp	x0, x8
csel	x9, x0, x8, lo
cmp	x1, #0x0
csel	x8, x9, x8, eq
cmp	x19, x8
csel	x19, x19, x8, hi
str	x19, [sp, #0x150]
ldr	x8, [sp, #0xc0]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x0, [sp, #0xd0]
mov	w1, #0x1                ; =1
blr	x9
mov	x20, #0x0               ; =0
mov	x19, #0x0               ; =0
mov	x21, #-0x3333333333333334 ; =-3689348814741910324
movk	x21, #0xcccd
mov	w22, #0x50              ; =80
mov	w25, #0x1a              ; =26
ldr	x27, [sp, #0x150]
umulh	x8, x20, x21
lsr	x8, x8, #6
msub	x3, x8, x22, x20
mov	x8, #0x4ec5             ; =20165
movk	x8, #0xc4ec, lsl #16
movk	x8, #0xec4e, lsl #32
movk	x8, #0x4ec4, lsl #48
umulh	x8, x20, x8
lsr	w8, w8, #3
msub	w8, w8, w25, w20
add	x9, sp, #0x71, lsl #12  ; =0x71000
add	x9, x9, #0x700
ldp	q0, q1, [sp, #0x120]
stp	q1, q0, [x9]
add	w8, w8, #0x61
add	x24, sp, #0x71, lsl #12 ; =0x71000
add	x24, x24, #0x700
strb	w8, [x9, #0xe]
add	x0, sp, #0x24, lsl #12  ; =0x24000
add	x0, x0, #0x700
add	x1, sp, #0x71, lsl #12  ; =0x71000
add	x1, x1, #0x700
mov	w2, #0x1                ; =1
bl	<_ClientEventContext.receiveFrame>
tst	w0, #0xffff
b.ne	<_main.execute>
add	x28, sp, #0x24, lsl #12 ; =0x24000
add	x28, x28, #0x5c0
ldr	x23, [x28, #0x23a8]
add	x0, sp, #0x24, lsl #12  ; =0x24000
add	x0, x0, #0x700
bl	<_ClientEventContext.summarizeMachine>
add	x10, sp, #0x24, lsl #12 ; =0x24000
add	x10, x10, #0x5c0
ldr	x8, [x28, #0x24d0]
add	x9, x23, x19
add	x19, x9, x8
add	x20, x20, #0x1
subs	x27, x27, #0x1
b.ne	<_main.execute>
ldr	x8, [x10, #0x23b0]
add	x19, x8, x19
ldr	x8, [sp, #0xc0]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x0, [sp, #0xd0]
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [sp, #0x148]
cbz	x8, <_main.execute>
str	xzr, [sp, #0x108]
mov	w20, #0x2588            ; =9608
movk	w20, #0x27, lsl #16
mov	w21, #0x8942            ; =35138
movk	w21, #0x14, lsl #16
mov	w19, #0x2580            ; =9600
movk	w19, #0x27, lsl #16
mov	w27, #0x2180            ; =8576
movk	w27, #0x27, lsl #16
ldr	x8, [sp, #0xc0]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x0, [sp, #0xd0]
mov	w1, #0x1                ; =1
blr	x9
mov	x22, #0x0               ; =0
str	xzr, [sp, #0x160]
ldr	x8, [x24]
str	x8, [sp, #0xb8]
b	<_main.execute>
add	x25, sp, #0x24, lsl #12 ; =0x24000
add	x25, x25, #0x5c0
ldr	x23, [x25, #0x23a8]
add	x0, sp, #0x24, lsl #12  ; =0x24000
add	x0, x0, #0x700
bl	<_ClientEventContext.summarizeMachine>
add	x10, sp, #0x24, lsl #12 ; =0x24000
add	x10, x10, #0x5c0
ldr	x8, [x25, #0x24d0]
ldr	x9, [sp, #0x160]
add	x9, x23, x9
add	x8, x9, x8
str	x8, [sp, #0x160]
add	x22, x22, #0x1
ldr	x8, [sp, #0x150]
cmp	x22, x8
b.eq	<_main.execute>
add	x9, sp, #0x89, lsl #12  ; =0x89000
add	x9, x9, #0x9b0
ldp	q0, q1, [sp, #0x120]
stp	q1, q0, [x9]
mov	x8, #0x4ec5             ; =20165
movk	x8, #0xc4ec, lsl #16
movk	x8, #0xec4e, lsl #32
movk	x8, #0x4ec4, lsl #48
umulh	x8, x22, x8
lsr	w8, w8, #3
mov	w10, #0x1a              ; =26
msub	w8, w8, w10, w22
add	w8, w8, #0x61
strb	w8, [x9, #0xe]
add	x11, sp, #0x24, lsl #12 ; =0x24000
add	x11, x11, #0x5c0
ldr	x8, [x11, #0x23a8]
add	x9, x8, #0x1
str	x9, [x11, #0x23a8]
ldr	x1, [x11, #0x2a8]
mov	x10, #-0x3333333333333334 ; =-3689348814741910324
movk	x10, #0xcccd
umulh	x10, x22, x10
lsr	x10, x10, #6
ldr	x2, [x11, #0x2b0]
mov	w11, #0x50              ; =80
msub	w10, w10, w11, w22
add	x11, sp, #0x8b, lsl #12 ; =0x8b000
add	x11, x11, #0x1b8
add	x12, sp, #0x89, lsl #12 ; =0x89000
add	x12, x12, #0x9b0
str	x12, [x11]
mov	w12, #0x1               ; =1
str	x12, [x11, #0x8]
add	x23, sp, #0x8b, lsl #12 ; =0x8b000
add	x23, x23, #0x1b8
str	w10, [x11, #0x10]
add	x10, sp, #0x29, lsl #12 ; =0x29000
add	x10, x10, #0x3a0
stp	x12, x9, [x10, #0x90]
str	x8, [x10, #0xa0]
mov	w8, #0x50               ; =80
movk	w8, #0x18, lsl #16
str	w8, [x10, #0x120]
ldr	w8, [sp, #0x100]
add	x9, sp, #0x29, lsl #12  ; =0x29000
add	x9, x9, #0x430
stur	w8, [x9, #0x94]
ldr	w8, [sp, #0xe8]
sturh	w8, [x9, #0x98]
stur	xzr, [x9, #0x9a]
stur	wzr, [x9, #0xa2]
movi.2d	v0, #0000000000000000
stur	q0, [x9, #0x68]
stur	q0, [x9, #0x58]
stur	q0, [x9, #0x48]
stur	q0, [x9, #0x38]
stur	q0, [x9, #0x28]
stur	q0, [x9, #0x18]
add	x8, sp, #0x8b, lsl #12  ; =0x8b000
add	x8, x8, #0x1b8
str	x8, [x10, #0x108]
ldr	q0, [sp, #0xf0]
str	q0, [x10, #0x110]
add	x0, sp, #0x8a, lsl #12  ; =0x8a000
add	x0, x0, #0xcc0
add	x3, sp, #0x29, lsl #12  ; =0x29000
add	x3, x3, #0x430
bl	<_schema.messages.pane.encodePaneFrame>
ldrh	w28, [x26, #0x9a0]
cbnz	w28, <_main.execute>
add	x8, sp, #0x8a, lsl #12  ; =0x8a000
add	x8, x8, #0x330
ldr	x1, [x8, #0x990]
add	x26, sp, #0x8a, lsl #12 ; =0x8a000
add	x26, x26, #0x330
ldr	x24, [x8, #0x998]
ldr	x0, [sp, #0x110]
mov	x2, x24
bl	<_schema.messages.messages.decodeServerInto>
tst	w0, #0xffff
b.ne	<_main.execute>
add	x8, sp, #0x24, lsl #12  ; =0x24000
add	x8, x8, #0x5c0
str	x24, [x8, #0x2398]
str	xzr, [x8, #0x23a0]
add	x25, sp, #0x24, lsl #12 ; =0x24000
add	x25, x25, #0x5c0
ldr	x1, [x8, #0x160]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x9, [sp, #0x110]
str	x9, [x8]
add	x24, sp, #0x71, lsl #12 ; =0x71000
add	x24, x24, #0x700
strh	wzr, [x8, #0x8]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
strb	wzr, [x8, #0x440]
add	x0, sp, #0x8b, lsl #12  ; =0x8b000
add	x0, x0, #0x3b8
add	x2, sp, #0x71, lsl #12  ; =0x71000
add	x2, x2, #0x700
bl	<_execution.Client.update>
ldrh	w28, [x23, #0x200]
cbnz	w28, <_main.execute>
ldrb	w8, [x23, #0x203]
cbnz	w8, <_main.execute>
ldr	x0, [x25, #0x160]
bl	<_execution.Client.flush>
tst	w0, #0xffff
b.eq	<_main.execute>
b	<_main.execute>
ldr	x10, [x1, x19]
add	x11, x1, x10, lsl #5
add	x11, x11, x27
ldr	q0, [x11]
add	x12, sp, #0x8a, lsl #12 ; =0x8a000
add	x12, x12, #0x330
str	q0, [x12]
ldr	q0, [x11, #0x10]
add	x26, sp, #0x8a, lsl #12 ; =0x8a000
add	x26, x26, #0x330
str	q0, [x12, #0x10]
add	w10, w10, #0x1
and	x10, x10, #0x1f
str	x10, [x1, x19]
sub	x9, x9, #0x1
str	x9, [x8]
add	x0, sp, #0x24, lsl #12  ; =0x24000
add	x0, x0, #0x700
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0x330
bl	<_ClientEventContext.startJob>
ldr	x1, [x25, #0x160]
add	x8, x1, x20
ldr	x9, [x8]
cbnz	x9, <_main.execute>
ldrb	w8, [x1, x21]
cmp	w8, #0x1
b.eq	<_main.execute>
b	<_main.execute>
add	x25, sp, #0x24, lsl #12 ; =0x24000
add	x25, x25, #0x5c0
add	x26, sp, #0x8a, lsl #12 ; =0x8a000
add	x26, x26, #0x330
ldrb	w8, [x1, x21]
tbz	w8, #0x0, <_main.execute>
sub	x0, x29, #0xb8
adrp x2, RELOC_PAGE
add	x2, x2, #RELOC_OFFSET
bl	<_execution.Client.update>
sub	x8, x29, #0xb8
ldrh	w28, [x8]
cbnz	w28, <_main.execute>
ldr	x0, [x25, #0x160]
bl	<_execution.Client.flush>
tst	w0, #0xffff
b.ne	<_main.execute>
ldr	x1, [x25, #0x160]
add	x8, x1, x20
ldr	x9, [x8]
cbz	x9, <_main.execute>
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
add	x25, sp, #0x24, lsl #12 ; =0x24000
add	x25, x25, #0x5c0
ldr	x10, [x1, x19]
add	x11, x1, x10, lsl #5
add	x11, x11, x27
ldr	q0, [x11]
str	q0, [x23]
ldr	q0, [x11, #0x10]
str	q0, [x23, #0x10]
add	w10, w10, #0x1
and	x10, x10, #0x1f
str	x10, [x1, x19]
sub	x9, x9, #0x1
str	x9, [x8]
add	x0, sp, #0x24, lsl #12  ; =0x24000
add	x0, x0, #0x700
add	x1, sp, #0x8a, lsl #12  ; =0x8a000
add	x1, x1, #0x330
bl	<_ClientEventContext.startJob>
ldr	x1, [x25, #0x160]
add	x8, x1, x20
ldr	x9, [x8]
cbnz	x9, <_main.execute>
b	<_main.execute>
ldr	x8, [x10, #0x23b0]
ldr	x9, [sp, #0x160]
add	x22, x8, x9
ldr	x8, [sp, #0xc0]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0x71, lsl #12  ; =0x71000
add	x8, x8, #0x700
ldr	x0, [sp, #0xd0]
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [x24]
ldr	x9, [sp, #0xb8]
sub	x8, x8, x9
ldr	x9, [sp, #0x150]
udiv	x8, x8, x9
ldr	x9, [sp, #0x108]
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
str	x8, [x10, x9, lsl #3]
add	x9, x9, #0x1
ldr	x8, [sp, #0x148]
str	x9, [sp, #0x108]
cmp	x9, x8
b.ne	<_main.execute>
add	x19, sp, #0x39, lsl #12 ; =0x39000
add	x19, x19, #0x430
add	x0, sp, #0x39, lsl #12  ; =0x39000
add	x0, x0, #0x430
ldr	x20, [sp, #0x148]
mov	x1, x20
bl	<_sort.heap__anon>
mov	w8, #0x5f               ; =95
mov	x9, #0x63               ; =99
madd	x8, x20, x8, x9
lsr	x8, x8, #2
mov	x10, #0xf5c3            ; =62915
movk	x10, #0x5c28, lsl #16
movk	x10, #0xc28f, lsl #32
movk	x10, #0x28f5, lsl #48
umulh	x8, x8, x10
mov	w11, #0x63              ; =99
madd	x9, x20, x11, x9
lsr	x9, x9, #2
umulh	x9, x9, x10
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
ldr	x10, [x10]
lsr	x11, x20, #1
ldr	x11, [x19, x11, lsl #3]
lsl	x8, x8, #1
and	x8, x8, #0x1ffffffffffffff8
add	x8, x19, x8
ldur	x8, [x8, #-0x8]
lsl	x9, x9, #1
and	x9, x9, #0x1ffffffffffffff8
add	x9, x19, x9
ldur	x9, [x9, #-0x8]
add	x12, sp, #0x29, lsl #12 ; =0x29000
add	x12, x12, #0x3a0
ldr	x13, [sp, #0x150]
stp	x13, x11, [x12, #0x60]
stp	x10, x8, [x12, #0x70]
str	x9, [x12, #0x80]
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x3a0
add	x1, sp, #0x24, lsl #12  ; =0x24000
add	x1, x1, #0x6c0
add	x2, sp, #0x29, lsl #12  ; =0x29000
add	x2, x2, #0x400
bl	<_main.ResultWriter.write>
mov	x28, x0
b	<_main.execute>
mov	w28, #0x212             ; =530
add	x0, sp, #0x24, lsl #12  ; =0x24000
add	x0, x0, #0x700
bl	<_ClientEventContext.deinit>
b	<_main.execute>
ldr	x20, [sp, #0x160]
b	<_main.execute>
mov	x28, x0
add	x0, sp, #0x29, lsl #12  ; =0x29000
add	x0, x0, #0x430
bl	<_terminal.stream.Stream(terminal.stream_terminal.Handler).deinit>
ldp	x8, x0, [sp, #0x48]
ldr	x8, [x8, #0x18]
ldr	x1, [sp, #0x40]
mov	w2, #0xc840             ; =51264
movk	w2, #0x2, lsl #16
mov	w3, #0x1                ; =1
ldr	x4, [sp, #0x110]
blr	x8
add	x25, sp, #0x8a, lsl #12 ; =0x8a000
add	x25, x25, #0xcc0
add	x1, sp, #0x1e0
mov	x0, x25
bl	<_terminal.render.RenderState.deinit>
add	x0, sp, #0x89, lsl #12  ; =0x89000
add	x0, x0, #0x9b0
add	x1, sp, #0x1e0
bl	<_terminal.Terminal.deinit>
b	<_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x9, [x8, #0x18]
mov	w8, #0x3fd              ; =1021
cmp	x9, #0x3fd
csel	x8, x9, x8, lo
cmp	x9, #0x3fe
b.lo	<_main.execute>
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
ldr	x10, [x10, #0x8]
ldrsb	w11, [x10, x8]
cmn	w11, #0x41
b.gt	<_main.execute>
subs	x8, x8, #0x1
b.eq	<_main.execute>
cmp	x8, x9
b.lo	<_main.execute>
b	<_main.execute>
mov	x28, x0
b	<_main.execute>
mov	x28, x0
b	<_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x9, [x8, #0x18]
mov	w8, #0x3fd              ; =1021
cmp	x9, #0x3fd
csel	x8, x9, x8, lo
cmp	x9, #0x3fe
b.lo	<_main.execute>
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
ldr	x10, [x10, #0x8]
ldrsb	w11, [x10, x8]
cmn	w11, #0x41
b.gt	<_main.execute>
subs	x8, x8, #0x1
b.eq	<_main.execute>
cmp	x8, x9
b.lo	<_main.execute>
add	x9, x26, x8
mov	w10, #0xa6              ; =166
strb	w10, [x9, #0x2]
mov	w10, #0x80e2            ; =32994
strh	w10, [x9]
add	x8, x8, #0x3
b	<_main.execute>
add	x8, sp, #0x39, lsl #12  ; =0x39000
add	x8, x8, #0x430
ldr	x9, [x8, #0x18]
mov	w8, #0x3fd              ; =1021
cmp	x9, #0x3fd
csel	x8, x9, x8, lo
cmp	x9, #0x3fe
b.lo	<_main.execute>
add	x10, sp, #0x39, lsl #12 ; =0x39000
add	x10, x10, #0x430
ldr	x10, [x10, #0x8]
ldrsb	w11, [x10, x8]
cmn	w11, #0x41
b.gt	<_main.execute>
subs	x8, x8, #0x1
b.eq	<_main.execute>
cmp	x8, x9
b.lo	<_main.execute>
add	x9, x19, x8
mov	w10, #0xa6              ; =166
strb	w10, [x9, #0x2]
mov	w10, #0x80e2            ; =32994
strh	w10, [x9]
add	x8, x8, #0x3
b	<_main.execute>
mov	x28, x0
mov	w11, #0x48              ; =72
mov	x12, #0x100000000       ; =4294967296
b	<_main.execute>
add	x10, x10, #0x48
subs	x11, x11, #0x1
b.eq	<_main.execute>
ldrb	w13, [x10, #0x40]
cbz	w13, <_main.execute>
ldr	x13, [x10]
cmp	x13, x12
b.ne	<_main.execute>
str	xzr, [x10, #0x40]
movi.2d	v0, #0000000000000000
stp	q0, q0, [x10, #0x20]
stp	q0, q0, [x10]
ldr	x10, [x8, x9]
sub	x10, x10, #0x1
str	x10, [x8, x9]
b	<_main.execute>
mov	x28, x0
mov	x0, x26
bl	<_main.LuaCallbackContext.deinit>
b	<_main.execute>
mov	x28, x0
add	x0, sp, #0xb, lsl #12   ; =0xb000
add	x0, x0, #0xca0
bl	<_BlitContext.deinit>
b	<_main.execute>
mov	x28, x0
b	<_main.execute>
ldr	x0, [x20, #0x20]
ldr	x8, [x0, #0x18]
add	x24, sp, #0x8b, lsl #12 ; =0x8b000
add	x24, x24, #0x1b8
add	x23, sp, #0x8a, lsl #12 ; =0x8a000
add	x23, x23, #0x330
b	<_main.execute>

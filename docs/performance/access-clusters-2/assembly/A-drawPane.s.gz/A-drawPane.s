
/tmp/telar-access-clusters-2.QhXJGE/A/bin/telar-dod-probe:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010012e400 <_render.TerminalRenderer.drawPane>:
10012e400:     	stp	d15, d14, [sp, #-0xa0]!
10012e404:     	stp	d13, d12, [sp, #0x10]
10012e408:     	stp	d11, d10, [sp, #0x20]
10012e40c:     	stp	d9, d8, [sp, #0x30]
10012e410:     	stp	x28, x27, [sp, #0x40]
10012e414:     	stp	x26, x25, [sp, #0x50]
10012e418:     	stp	x24, x23, [sp, #0x60]
10012e41c:     	stp	x22, x21, [sp, #0x70]
10012e420:     	stp	x20, x19, [sp, #0x80]
10012e424:     	stp	x29, x30, [sp, #0x90]
10012e428:     	add	x29, sp, #0x90
10012e42c:     	sub	sp, sp, #0x3, lsl #12   ; =0x3000
10012e430:     	sub	sp, sp, #0x9b0
10012e434:     	str	x30, [sp, #0x188]
10012e438:     	mov	x23, x1
10012e43c:     	str	x0, [sp, #0x278]
10012e440:     	add	x8, x0, #0x12, lsl #12  ; =0x12000
10012e444:     	add	x3, x8, #0x8d8
10012e448:     	ldr	x8, [x1]
10012e44c:     	ldr	x5, [x1, #0x18]
10012e450:     	ubfx	x10, x5, #32, #16
10012e454:     	ldrh	w9, [x8, #0x50]
10012e458:     	cmp	w10, w9
10012e45c:     	str	x10, [sp, #0x38]
10012e460:     	csel	w4, w10, w9, lo
10012e464:     	ldr	x12, [x8, #0x10]
10012e468:     	ldp	x10, x13, [x3]
10012e46c:     	sub	x14, x10, #0x50
10012e470:     	cmp	x13, #0x2
10012e474:     	b.lo	0x10012e5a4 <_render.TerminalRenderer.drawPane+0x1a4>
10012e478:     	mov	x11, #0x0               ; =0
10012e47c:     	mov	w15, #0x50              ; =80
10012e480:     	mov	w16, #0x2               ; =2
10012e484:     	mov	w17, #-0x40000000       ; =-1073741824
10012e488:     	mov	x0, x13
10012e48c:     	lsr	x1, x0, #1
10012e490:     	sub	x0, x0, x1
10012e494:     	add	x1, x1, x11
10012e498:     	mul	x2, x1, x15
10012e49c:     	ldr	x2, [x14, x2]
10012e4a0:     	cmp	x12, x2
10012e4a4:     	cset	w2, lo
10012e4a8:     	csel	w2, w16, w2, eq
10012e4ac:     	add	w2, w17, w2, lsl #30
10012e4b0:     	asr	w2, w2, #30
10012e4b4:     	cmp	w2, #0x0
10012e4b8:     	csel	x11, x1, x11, lt
10012e4bc:     	cmp	x0, #0x1
10012e4c0:     	b.hi	0x10012e48c <_render.TerminalRenderer.drawPane+0x8c>
10012e4c4:     	cmp	x11, x13
10012e4c8:     	b.hs	0x10012e4f4 <_render.TerminalRenderer.drawPane+0xf4>
10012e4cc:     	mov	w15, #0x50              ; =80
10012e4d0:     	mul	x15, x11, x15
10012e4d4:     	ldr	x15, [x10, x15]
10012e4d8:     	cmp	x12, x15
10012e4dc:     	cset	w15, lo
10012e4e0:     	mov	w16, #0x2               ; =2
10012e4e4:     	csel	w15, w16, w15, eq
10012e4e8:     	sub	w15, w15, #0x1
10012e4ec:     	ubfx	x15, x15, #1, #1
10012e4f0:     	add	x11, x15, x11
10012e4f4:     	cmp	x13, #0x2
10012e4f8:     	b.lo	0x10012e5b4 <_render.TerminalRenderer.drawPane+0x1b4>
10012e4fc:     	mov	x15, #0x0               ; =0
10012e500:     	mov	w16, #0x50              ; =80
10012e504:     	mov	w17, #0x2               ; =2
10012e508:     	mov	x0, x13
10012e50c:     	lsr	x1, x0, #1
10012e510:     	sub	x0, x0, x1
10012e514:     	add	x1, x1, x15
10012e518:     	mul	x2, x1, x16
10012e51c:     	ldr	x2, [x14, x2]
10012e520:     	cmp	x12, x2
10012e524:     	cset	w2, lo
10012e528:     	csel	w2, w17, w2, eq
10012e52c:     	cmp	w2, #0x1
10012e530:     	csel	x15, x15, x1, eq
10012e534:     	cmp	x0, #0x1
10012e538:     	b.hi	0x10012e50c <_render.TerminalRenderer.drawPane+0x10c>
10012e53c:     	cmp	x15, x13
10012e540:     	b.hs	0x10012e568 <_render.TerminalRenderer.drawPane+0x168>
10012e544:     	mov	w13, #0x50              ; =80
10012e548:     	mul	x13, x15, x13
10012e54c:     	ldr	x13, [x10, x13]
10012e550:     	cmp	x12, x13
10012e554:     	cset	w12, lo
10012e558:     	mov	w13, #0x2               ; =2
10012e55c:     	csel	w12, w13, w12, eq
10012e560:     	cmp	w12, #0x1
10012e564:     	cinc	x15, x15, ne
10012e568:     	str	x5, [sp, #0x40]
10012e56c:     	lsr	x26, x5, #48
10012e570:     	ldrh	w21, [x8, #0x52]
10012e574:     	mov	w12, #0x50              ; =80
10012e578:     	madd	x24, x11, x12, x10
10012e57c:     	sub	x25, x15, x11
10012e580:     	ldrb	w10, [x23, #0x40]
10012e584:     	ldrb	w12, [x23, #0x44]
10012e588:     	cbz	w10, 0x10012e594 <_render.TerminalRenderer.drawPane+0x194>
10012e58c:     	ldrb	w10, [x23, #0x3c]
10012e590:     	tbz	w10, #0x0, 0x10012e5c4 <_render.TerminalRenderer.drawPane+0x1c4>
10012e594:     	ldrh	w11, [x8, #0x100]
10012e598:     	ldrh	w10, [x8, #0x102]
10012e59c:     	add	x13, x8, #0x104
10012e5a0:     	b	0x10012e60c <_render.TerminalRenderer.drawPane+0x20c>
10012e5a4:     	mov	x11, #0x0               ; =0
10012e5a8:     	cmp	x11, x13
10012e5ac:     	b.lo	0x10012e4cc <_render.TerminalRenderer.drawPane+0xcc>
10012e5b0:     	b	0x10012e4f4 <_render.TerminalRenderer.drawPane+0xf4>
10012e5b4:     	mov	x15, #0x0               ; =0
10012e5b8:     	cmp	x15, x13
10012e5bc:     	b.lo	0x10012e544 <_render.TerminalRenderer.drawPane+0x144>
10012e5c0:     	b	0x10012e568 <_render.TerminalRenderer.drawPane+0x168>
10012e5c4:     	ldr	w10, [x23, #0x28]
10012e5c8:     	ldr	w11, [x8, #0xfc]
10012e5cc:     	subs	w10, w10, w11
10012e5d0:     	b.lo	0x10012e5fc <_render.TerminalRenderer.drawPane+0x1fc>
10012e5d4:     	cmp	w10, w21
10012e5d8:     	b.hs	0x10012e5fc <_render.TerminalRenderer.drawPane+0x1fc>
10012e5dc:     	ldrh	w11, [x23, #0x2c]
10012e5e0:     	mov	w13, #0x1               ; =1
10012e5e4:     	add	x14, sp, #0x2, lsl #12  ; =0x2000
10012e5e8:     	add	x14, x14, #0x2e0
10012e5ec:     	strb	w13, [x14]
10012e5f0:     	add	x13, sp, #0x2, lsl #12  ; =0x2000
10012e5f4:     	add	x13, x13, #0x2e0
10012e5f8:     	b	0x10012e60c <_render.TerminalRenderer.drawPane+0x20c>
10012e5fc:     	mov	w11, #0x0               ; =0
10012e600:     	mov	w10, #0x0               ; =0
10012e604:     	adrp	x13, 0x100537000 <___anon_12840+0x13d14>
10012e608:     	add	x13, x13, #0x524
10012e60c:     	mov	w15, #0x0               ; =0
10012e610:     	mov	w14, #0x1               ; =1
10012e614:     	str	w14, [sp, #0xe4]
10012e618:     	tbnz	w12, #0x0, 0x10012e67c <_render.TerminalRenderer.drawPane+0x27c>
10012e61c:     	ldrb	w12, [x23, #0x22]
10012e620:     	tbz	w12, #0x0, 0x10012e67c <_render.TerminalRenderer.drawPane+0x27c>
10012e624:     	ldrb	w12, [x13]
10012e628:     	tbz	w12, #0x0, 0x10012e67c <_render.TerminalRenderer.drawPane+0x27c>
10012e62c:     	mov	x20, x15
10012e630:     	cmp	w11, w4
10012e634:     	b.hs	0x10012e6a4 <_render.TerminalRenderer.drawPane+0x2a4>
10012e638:     	cmp	w26, w21
10012e63c:     	csel	w12, w26, w21, lo
10012e640:     	cmp	w12, w10, uxth
10012e644:     	b.ls	0x10012e684 <_render.TerminalRenderer.drawPane+0x284>
10012e648:     	cbz	w11, 0x10012e698 <_render.TerminalRenderer.drawPane+0x298>
10012e64c:     	str	wzr, [sp, #0xe4]
10012e650:     	and	x12, x10, #0xffff
10012e654:     	umull	x9, w12, w9
10012e658:     	mov	w12, w11
10012e65c:     	ldr	x8, [x8, #0x30]
10012e660:     	add	x8, x8, x9, lsl #5
10012e664:     	add	x8, x8, x12, lsl #5
10012e668:     	ldrb	w8, [x8, #0x1f]
10012e66c:     	cmp	w8, #0x0
10012e670:     	cset	w8, eq
10012e674:     	sub	w15, w11, w8
10012e678:     	b	0x10012e6a0 <_render.TerminalRenderer.drawPane+0x2a0>
10012e67c:     	mov	x20, x15
10012e680:     	b	0x10012e6a4 <_render.TerminalRenderer.drawPane+0x2a4>
10012e684:     	mov	w15, #0x0               ; =0
10012e688:     	mov	w20, #0x0               ; =0
10012e68c:     	mov	w8, #0x1                ; =1
10012e690:     	str	w8, [sp, #0xe4]
10012e694:     	b	0x10012e6a4 <_render.TerminalRenderer.drawPane+0x2a4>
10012e698:     	mov	w15, #0x0               ; =0
10012e69c:     	str	wzr, [sp, #0xe4]
10012e6a0:     	mov	x20, x10
10012e6a4:     	str	w15, [sp, #0x74]
10012e6a8:     	str	x4, [sp, #0x120]
10012e6ac:     	str	x3, [sp, #0x270]
10012e6b0:     	ldr	x0, [sp, #0x278]
10012e6b4:     	ldr	x22, [x0, #0xfe8]
10012e6b8:     	mov	x1, x23
10012e6bc:     	mov	x2, x24
10012e6c0:     	mov	x3, x25
10012e6c4:     	mov	w4, #0x0                ; =0
10012e6c8:     	bl	0x10012e0b8 <_render.TerminalRenderer.pushImages>
10012e6cc:     	ands	w0, w0, #0xffff
10012e6d0:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
10012e6d4:     	stp	x25, x24, [sp, #0x88]
10012e6d8:     	ldr	x10, [sp, #0x278]
10012e6dc:     	add	x8, x10, #0x16, lsl #12 ; =0x16000
10012e6e0:     	add	x9, x8, #0x9cc
10012e6e4:     	add	x8, x10, #0x11, lsl #12 ; =0x11000
10012e6e8:     	add	x8, x8, #0x620
10012e6ec:     	str	x8, [sp, #0x170]
10012e6f0:     	ldr	x8, [sp, #0x188]
10012e6f4:     	xpaci	x8
10012e6f8:     	str	x8, [sp, #0x188]
10012e6fc:     	cmp	w26, w21
10012e700:     	str	x26, [sp, #0x78]
10012e704:     	csel	w8, w26, w21, lo
10012e708:     	mov	x21, x9
10012e70c:     	str	x23, [sp, #0x258]
10012e710:     	str	x8, [sp, #0x128]
10012e714:     	str	x9, [sp, #0x260]
10012e718:     	cbz	w8, 0x10013322c <_render.TerminalRenderer.drawPane+0x4e2c>
10012e71c:     	add	x8, x21, #0x17c
10012e720:     	str	x8, [sp, #0x240]
10012e724:     	add	x8, x21, #0x1ac
10012e728:     	str	x8, [sp, #0x208]
10012e72c:     	ldr	x8, [sp, #0x278]
10012e730:     	add	x8, x8, #0x16, lsl #12  ; =0x16000
10012e734:     	add	x8, x8, #0xba6
10012e738:     	str	x8, [sp, #0x1c0]
10012e73c:     	add	x25, sp, #0x4e0
10012e740:     	adrp	x8, 0x1001fe000 <__ZL19_hb_ucd_dm2_u64_map+0xb10>
10012e744:     	cbz	x22, 0x10013245c <_render.TerminalRenderer.drawPane+0x405c>
10012e748:     	str	xzr, [sp, #0x108]
10012e74c:     	mov	x28, #0x0               ; =0
10012e750:     	add	x9, sp, #0xee0
10012e754:     	sub	x10, x29, #0xb0
10012e758:     	sub	x11, x29, #0xc8
10012e75c:     	add	x12, sp, #0x2, lsl #12  ; =0x2000
10012e760:     	add	x12, x12, #0x2e0
10012e764:     	orr	x12, x12, #0x4
10012e768:     	str	x12, [sp, #0x80]
10012e76c:     	orr	x9, x9, #0x4
10012e770:     	str	x9, [sp, #0xd8]
10012e774:     	orr	x9, x10, #0x4
10012e778:     	str	x9, [sp, #0x8]
10012e77c:     	orr	x10, x11, #0x4
10012e780:     	ldr	x9, [sp, #0x278]
10012e784:     	add	x9, x9, #0xffa
10012e788:     	str	x9, [sp, #0xf8]
10012e78c:     	adrp	x9, 0x100537000 <___anon_12840+0x13d14>
10012e790:     	ldr	x9, [x9, #0x528]
10012e794:     	str	x9, [sp, #0xb8]
10012e798:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012e79c:     	add	x9, x9, #0x900
10012e7a0:     	add	x9, x9, #0x38
10012e7a4:     	str	x9, [sp, #0x1b0]
10012e7a8:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012e7ac:     	add	x9, x9, #0x730
10012e7b0:     	orr	x9, x9, #0xe
10012e7b4:     	stp	x10, x9, [sp, #0x20]
10012e7b8:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012e7bc:     	add	x9, x9, #0x8e0
10012e7c0:     	orr	x9, x9, #0xe
10012e7c4:     	str	x9, [sp, #0xe8]
10012e7c8:     	add	x9, sp, #0x3d0
10012e7cc:     	orr	x9, x9, #0xe
10012e7d0:     	str	x9, [sp, #0x150]
10012e7d4:     	mov	w26, #0x6               ; =6
10012e7d8:     	ldr	q0, [x8, #0xaf0]
10012e7dc:     	str	q0, [sp, #0x130]
10012e7e0:     	and	w8, w20, #0xffff
10012e7e4:     	str	w8, [sp, #0x34]
10012e7e8:     	mov	w27, #0xffff            ; =65535
10012e7ec:     	ldr	w8, [sp, #0xe4]
10012e7f0:     	tbz	w8, #0x0, 0x10012e7fc <_render.TerminalRenderer.drawPane+0x3fc>
10012e7f4:     	mov	w13, #0x0               ; =0
10012e7f8:     	b	0x10012e834 <_render.TerminalRenderer.drawPane+0x434>
10012e7fc:     	ldr	w8, [sp, #0x34]
10012e800:     	cmp	w8, w28, uxth
10012e804:     	adrp	x8, 0x100596000 <___anon_29692+0x370>
10012e808:     	add	x8, x8, #0xd40
10012e80c:     	b.ne	0x10012e830 <_render.TerminalRenderer.drawPane+0x430>
10012e810:     	add	x8, sp, #0x2, lsl #12   ; =0x2000
10012e814:     	add	x8, x8, #0x2e0
10012e818:     	ldr	w9, [sp, #0x74]
10012e81c:     	strh	w9, [x8]
10012e820:     	mov	w9, #0x1                ; =1
10012e824:     	strb	w9, [x8, #0x2]
10012e828:     	add	x8, sp, #0x2, lsl #12   ; =0x2000
10012e82c:     	add	x8, x8, #0x2e0
10012e830:     	ldr	w13, [x8]
10012e834:     	ldr	x22, [sp, #0x270]
10012e838:     	mov	x8, #0x0                ; =0
10012e83c:     	mov	x1, #0x0                ; =0
10012e840:     	ubfx	w9, w13, #16, #8
10012e844:     	str	w9, [sp, #0x280]
10012e848:     	ldr	x9, [x23]
10012e84c:     	ldrh	w20, [x23, #0x18]
10012e850:     	ldrh	w16, [x23, #0x1a]
10012e854:     	ldrh	w10, [x23, #0x1c]
10012e858:     	ldrh	w17, [x9, #0x50]
10012e85c:     	cmp	w10, w17
10012e860:     	csel	w24, w10, w17, lo
10012e864:     	mul	x10, x28, x17
10012e868:     	ldr	x0, [x9, #0x30]
10012e86c:     	add	x10, x0, x10, lsl #5
10012e870:     	str	x10, [sp, #0x298]
10012e874:     	add	w12, w16, w28, uxth
10012e878:     	ldr	x10, [sp, #0x170]
10012e87c:     	ldrh	w11, [x10, #0x48]
10012e880:     	ldr	x10, [x10]
10012e884:     	and	w14, w28, #0xffff
10012e888:     	str	w14, [sp, #0x190]
10012e88c:     	and	w7, w13, #0xffff
10012e890:     	ubfiz	x13, x24, #6, #32
10012e894:     	sub	x14, x13, #0x40
10012e898:     	ubfiz	x15, x7, #6, #32
10012e89c:     	str	x16, [sp, #0x230]
10012e8a0:     	add	x16, x28, x16
10012e8a4:     	mul	x16, x16, x11
10012e8a8:     	lsl	x16, x16, #6
10012e8ac:     	add	x16, x16, x20, lsl #6
10012e8b0:     	add	x16, x10, x16
10012e8b4:     	ldr	x2, [sp, #0x108]
10012e8b8:     	madd	x17, x2, x17, x0
10012e8bc:     	str	x17, [sp, #0xf0]
10012e8c0:     	cmp	x13, x8
10012e8c4:     	b.eq	0x10012eb48 <_render.TerminalRenderer.drawPane+0x748>
10012e8c8:     	mov	x0, x1
10012e8cc:     	ldrb	w2, [x23, #0x40]
10012e8d0:     	mov	x1, x17
10012e8d4:     	cbz	w2, 0x10012e9d8 <_render.TerminalRenderer.drawPane+0x5d8>
10012e8d8:     	ldrb	w2, [x23, #0x38]
10012e8dc:     	mov	x1, x17
10012e8e0:     	cbz	w2, 0x10012e9d8 <_render.TerminalRenderer.drawPane+0x5d8>
10012e8e4:     	ldr	w1, [x23, #0x28]
10012e8e8:     	ldr	x2, [x23, #0x30]
10012e8ec:     	ldrb	w4, [x23, #0x3d]
10012e8f0:     	ldr	w3, [x9, #0xfc]
10012e8f4:     	ldr	w5, [sp, #0x190]
10012e8f8:     	add	w3, w3, w5
10012e8fc:     	tbz	w4, #0x0, 0x10012e94c <_render.TerminalRenderer.drawPane+0x54c>
10012e900:     	cmp	w2, w1
10012e904:     	csel	w4, w2, w1, lo
10012e908:     	csel	w1, w2, w1, hi
10012e90c:     	cmp	w3, w4
10012e910:     	ccmp	w3, w1, #0x2, hs
10012e914:     	mov	x1, x17
10012e918:     	b.hi	0x10012e9d8 <_render.TerminalRenderer.drawPane+0x5d8>
10012e91c:     	ldr	q0, [x17]
10012e920:     	str	q0, [sp, #0x22e0]
10012e924:     	ldr	q0, [x17, #0x10]
10012e928:     	str	q0, [sp, #0x22f0]
10012e92c:     	add	x2, sp, #0x2, lsl #12   ; =0x2000
10012e930:     	add	x2, x2, #0x2e0
10012e934:     	ldrh	w1, [x2]
10012e938:     	eor	w1, w1, #0x10
10012e93c:     	strh	w1, [x2]
10012e940:     	add	x1, sp, #0x2, lsl #12   ; =0x2000
10012e944:     	add	x1, x1, #0x2e0
10012e948:     	b	0x10012e9d8 <_render.TerminalRenderer.drawPane+0x5d8>
10012e94c:     	ldr	w4, [x23, #0x2c]
10012e950:     	lsr	x6, x2, #32
10012e954:     	cmp	w1, w2
10012e958:     	b.lo	0x10012e970 <_render.TerminalRenderer.drawPane+0x570>
10012e95c:     	cmp	w1, w2
10012e960:     	b.ne	0x10012e98c <_render.TerminalRenderer.drawPane+0x58c>
10012e964:     	and	w5, w4, #0xffff
10012e968:     	cmp	w5, w6, uxth
10012e96c:     	b.hs	0x10012e98c <_render.TerminalRenderer.drawPane+0x58c>
10012e970:     	mov	x5, x4
10012e974:     	mov	x4, x6
10012e978:     	mov	x6, x1
10012e97c:     	mov	x1, x17
10012e980:     	cmp	w3, w6
10012e984:     	b.hs	0x10012e9a4 <_render.TerminalRenderer.drawPane+0x5a4>
10012e988:     	b	0x10012e9d8 <_render.TerminalRenderer.drawPane+0x5d8>
10012e98c:     	mov	x5, x6
10012e990:     	mov	x6, x2
10012e994:     	mov	x2, x1
10012e998:     	mov	x1, x17
10012e99c:     	cmp	w3, w6
10012e9a0:     	b.lo	0x10012e9d8 <_render.TerminalRenderer.drawPane+0x5d8>
10012e9a4:     	and	w1, w0, #0xffff
10012e9a8:     	cmp	w1, w5, uxth
10012e9ac:     	ccmp	w3, w6, #0x0, lo
10012e9b0:     	mov	x1, x17
10012e9b4:     	b.eq	0x10012e9d8 <_render.TerminalRenderer.drawPane+0x5d8>
10012e9b8:     	mov	x1, x17
10012e9bc:     	cmp	w2, w3
10012e9c0:     	b.lo	0x10012e9d8 <_render.TerminalRenderer.drawPane+0x5d8>
10012e9c4:     	b.ne	0x10012e91c <_render.TerminalRenderer.drawPane+0x51c>
10012e9c8:     	and	w1, w0, #0xffff
10012e9cc:     	cmp	w1, w4, uxth
10012e9d0:     	mov	x1, x17
10012e9d4:     	b.ls	0x10012e91c <_render.TerminalRenderer.drawPane+0x51c>
10012e9d8:     	add	x2, x16, x8
10012e9dc:     	ldrb	w2, [x2, #0x3a]
10012e9e0:     	ldr	w3, [sp, #0x280]
10012e9e4:     	cbz	w3, 0x10012e9f4 <_render.TerminalRenderer.drawPane+0x5f4>
10012e9e8:     	cmp	x15, x8
10012e9ec:     	cset	w3, eq
10012e9f0:     	eor	w2, w3, w2
10012e9f4:     	tbnz	w2, #0x0, 0x10012eadc <_render.TerminalRenderer.drawPane+0x6dc>
10012e9f8:     	add	x3, x16, x8
10012e9fc:     	ldrb	w2, [x3, #0x3b]
10012ea00:     	cmp	x14, x8
10012ea04:     	cset	w4, eq
10012ea08:     	eor	w2, w4, w2
10012ea0c:     	tbnz	w2, #0x0, 0x10012eadc <_render.TerminalRenderer.drawPane+0x6dc>
10012ea10:     	ldrb	w2, [x1, #0x1f]
10012ea14:     	cmp	w2, #0x1
10012ea18:     	csinc	w2, w2, wzr, hi
10012ea1c:     	sub	w4, w24, w0
10012ea20:     	and	w4, w4, #0xffff
10012ea24:     	cmp	w2, w4
10012ea28:     	csel	w2, w2, w4, lo
10012ea2c:     	ldrb	w3, [x3, #0x38]
10012ea30:     	cmp	w3, #0x1
10012ea34:     	b.ne	0x10012eadc <_render.TerminalRenderer.drawPane+0x6dc>
10012ea38:     	ldrh	w3, [x21, #0x4]
10012ea3c:     	ldr	x4, [sp, #0x240]
10012ea40:     	ldr	x5, [x4]
10012ea44:     	add	w4, w20, w0
10012ea48:     	and	w4, w4, #0xffff
10012ea4c:     	madd	w4, w3, w4, w5
10012ea50:     	ucvtf	s0, w4
10012ea54:     	add	x6, x16, x8
10012ea58:     	ldr	s1, [x6, #0x8]
10012ea5c:     	fcmp	s1, s0
10012ea60:     	b.ne	0x10012eadc <_render.TerminalRenderer.drawPane+0x6dc>
10012ea64:     	ldrh	w4, [x21, #0x6]
10012ea68:     	lsr	x5, x5, #32
10012ea6c:     	madd	w5, w4, w12, w5
10012ea70:     	ucvtf	s0, w5
10012ea74:     	ldr	s1, [x6, #0xc]
10012ea78:     	fcmp	s1, s0
10012ea7c:     	b.ne	0x10012eadc <_render.TerminalRenderer.drawPane+0x6dc>
10012ea80:     	mul	w2, w2, w3
10012ea84:     	ucvtf	s0, w2
10012ea88:     	add	x2, x16, x8
10012ea8c:     	ldr	s1, [x2, #0x10]
10012ea90:     	fcmp	s1, s0
10012ea94:     	b.ne	0x10012eadc <_render.TerminalRenderer.drawPane+0x6dc>
10012ea98:     	ucvtf	s0, w4
10012ea9c:     	ldr	s1, [x2, #0x14]
10012eaa0:     	fcmp	s1, s0
10012eaa4:     	b.ne	0x10012eadc <_render.TerminalRenderer.drawPane+0x6dc>
10012eaa8:     	add	x2, x16, x8
10012eaac:     	ldur	q0, [x2, #0x18]
10012eab0:     	ldur	q1, [x2, #0x28]
10012eab4:     	ldp	q2, q3, [x1]
10012eab8:     	eor.16b	v0, v2, v0
10012eabc:     	eor.16b	v1, v3, v1
10012eac0:     	orr.16b	v0, v1, v0
10012eac4:     	umaxv.16b	b0, v0
10012eac8:     	fmov	w2, s0
10012eacc:     	add	x8, x8, #0x40
10012ead0:     	add	x17, x17, #0x20
10012ead4:     	add	x1, x0, #0x1
10012ead8:     	cbz	w2, 0x10012e8c0 <_render.TerminalRenderer.drawPane+0x4c0>
10012eadc:     	cmp	x0, x24
10012eae0:     	b.hs	0x10012eb48 <_render.TerminalRenderer.drawPane+0x748>
10012eae4:     	str	x28, [sp, #0x178]
10012eae8:     	str	x24, [sp, #0x148]
10012eaec:     	str	x7, [sp, #0x100]
10012eaf0:     	cbz	w24, 0x10012eb34 <_render.TerminalRenderer.drawPane+0x734>
10012eaf4:     	ldr	x8, [sp, #0xf0]
10012eaf8:     	add	x8, x8, #0x1e
10012eafc:     	mov	x9, x24
10012eb00:     	ldrb	w10, [x8]
10012eb04:     	cmp	w10, #0x1
10012eb08:     	b.ne	0x10012ec94 <_render.TerminalRenderer.drawPane+0x894>
10012eb0c:     	ldursb	x10, [x8, #-0x10]
10012eb10:     	tbnz	x10, #0x3f, 0x10012ec94 <_render.TerminalRenderer.drawPane+0x894>
10012eb14:     	ldr	x11, [sp, #0xf8]
10012eb18:     	ldrb	w10, [x11, x10]
10012eb1c:     	and	w10, w10, #0x3
10012eb20:     	cmp	w10, #0x2
10012eb24:     	b.eq	0x10012ec94 <_render.TerminalRenderer.drawPane+0x894>
10012eb28:     	add	x8, x8, #0x20
10012eb2c:     	subs	x9, x9, #0x1
10012eb30:     	b.ne	0x10012eb00 <_render.TerminalRenderer.drawPane+0x700>
10012eb34:     	str	wzr, [sp, #0xe0]
10012eb38:     	str	xzr, [x22, #0x30]
10012eb3c:     	strh	wzr, [x22, #0x60]
10012eb40:     	cbnz	w24, 0x10012f35c <_render.TerminalRenderer.drawPane+0xf5c>
10012eb44:     	b	0x10012ec74 <_render.TerminalRenderer.drawPane+0x874>
10012eb48:     	cbz	w24, 0x10012ec70 <_render.TerminalRenderer.drawPane+0x870>
10012eb4c:     	ldr	x8, [sp, #0x170]
10012eb50:     	ldr	x8, [x8, #0x18]
10012eb54:     	ldr	x9, [sp, #0x230]
10012eb58:     	add	x9, x28, x9
10012eb5c:     	madd	x9, x9, x11, x20
10012eb60:     	mov	w11, #0xa0              ; =160
10012eb64:     	madd	x20, x9, x11, x8
10012eb68:     	add	x8, x10, x9, lsl #6
10012eb6c:     	add	x21, x8, #0x39
10012eb70:     	b	0x10012ebc0 <_render.TerminalRenderer.drawPane+0x7c0>
10012eb74:     	add	x9, x8, #0x1
10012eb78:     	str	x9, [x22, #0x80]
10012eb7c:     	ldr	x9, [x22, #0x78]
10012eb80:     	mov	w10, #0x50              ; =80
10012eb84:     	madd	x8, x8, x10, x9
10012eb88:     	ldr	q0, [sp, #0x22f0]
10012eb8c:     	str	q0, [x8, #0x10]
10012eb90:     	ldr	q0, [sp, #0x2300]
10012eb94:     	str	q0, [x8, #0x20]
10012eb98:     	ldr	q0, [sp, #0x2310]
10012eb9c:     	str	q0, [x8, #0x30]
10012eba0:     	ldr	q0, [sp, #0x2320]
10012eba4:     	str	q0, [x8, #0x40]
10012eba8:     	ldr	q0, [sp, #0x22e0]
10012ebac:     	str	q0, [x8]
10012ebb0:     	add	x20, x20, #0xa0
10012ebb4:     	add	x21, x21, #0x40
10012ebb8:     	subs	x24, x24, #0x1
10012ebbc:     	b.eq	0x10012ec70 <_render.TerminalRenderer.drawPane+0x870>
10012ebc0:     	ldrb	w8, [x21]
10012ebc4:     	tbz	w8, #0x0, 0x10012ebb0 <_render.TerminalRenderer.drawPane+0x7b0>
10012ebc8:     	ldr	q0, [x20, #0x10]
10012ebcc:     	str	q0, [sp, #0x22f0]
10012ebd0:     	ldr	q0, [x20, #0x20]
10012ebd4:     	str	q0, [sp, #0x2300]
10012ebd8:     	ldr	q0, [x20, #0x30]
10012ebdc:     	str	q0, [sp, #0x2310]
10012ebe0:     	ldr	q0, [x20, #0x40]
10012ebe4:     	str	q0, [sp, #0x2320]
10012ebe8:     	ldr	q0, [x20]
10012ebec:     	str	q0, [sp, #0x22e0]
10012ebf0:     	ldrb	w8, [x22, #0x98]
10012ebf4:     	cbz	w8, 0x10012ec18 <_render.TerminalRenderer.drawPane+0x818>
10012ebf8:     	ldr	x9, [x22, #0x90]
10012ebfc:     	ldr	x8, [x22, #0x80]
10012ec00:     	cmp	x8, x9
10012ec04:     	b.lo	0x10012eb74 <_render.TerminalRenderer.drawPane+0x774>
10012ec08:     	ldr	x8, [x22, #0xa0]
10012ec0c:     	add	x8, x8, #0x1
10012ec10:     	str	x8, [x22, #0xa0]
10012ec14:     	b	0x10012ebb0 <_render.TerminalRenderer.drawPane+0x7b0>
10012ec18:     	ldr	x9, [sp, #0x278]
10012ec1c:     	add	x8, x9, #0x10, lsl #12  ; =0x10000
10012ec20:     	ldr	q0, [x8, #0x2940]
10012ec24:     	str	q0, [sp, #0xee0]
10012ec28:     	ldp	x8, x9, [x22, #0x80]
10012ec2c:     	cmp	x9, x8
10012ec30:     	b.hi	0x10012eb74 <_render.TerminalRenderer.drawPane+0x774>
10012ec34:     	add	x8, x8, #0x1
10012ec38:     	lsr	x9, x8, #1
10012ec3c:     	add	x9, x9, #0x1
10012ec40:     	adds	x8, x8, x9
10012ec44:     	csinv	x2, x8, xzr, lo
10012ec48:     	mov	w8, #0x2950             ; =10576
10012ec4c:     	movk	w8, #0x1, lsl #16
10012ec50:     	ldr	x9, [sp, #0x278]
10012ec54:     	add	x0, x9, x8
10012ec58:     	add	x1, sp, #0xee0
10012ec5c:     	bl	0x1001ae678 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
10012ec60:     	ands	w0, w0, #0xffff
10012ec64:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
10012ec68:     	ldr	x8, [x22, #0x80]
10012ec6c:     	b	0x10012eb74 <_render.TerminalRenderer.drawPane+0x774>
10012ec70:     	ldr	x21, [sp, #0x260]
10012ec74:     	add	x28, x28, #0x1
10012ec78:     	ldr	x8, [sp, #0x108]
10012ec7c:     	add	x8, x8, #0x20
10012ec80:     	str	x8, [sp, #0x108]
10012ec84:     	ldr	x8, [sp, #0x128]
10012ec88:     	cmp	x28, x8
10012ec8c:     	b.ne	0x10012e7ec <_render.TerminalRenderer.drawPane+0x3ec>
10012ec90:     	b	0x10013322c <_render.TerminalRenderer.drawPane+0x4e2c>
10012ec94:     	mov	x24, #0x0               ; =0
10012ec98:     	str	xzr, [x22, #0x30]
10012ec9c:     	strh	wzr, [x22, #0x60]
10012eca0:     	str	x20, [sp, #0x220]
10012eca4:     	b	0x10012ed14 <_render.TerminalRenderer.drawPane+0x914>
10012eca8:     	mov	w8, #0x0                ; =0
10012ecac:     	mov	w9, #0x0                ; =0
10012ecb0:     	ldp	x11, x10, [x22, #0x28]
10012ecb4:     	add	x12, x10, #0x1
10012ecb8:     	str	x12, [x22, #0x30]
10012ecbc:     	strb	w8, [sp, #0xce0]
10012ecc0:     	add	x12, sp, #0x3, lsl #12  ; =0x3000
10012ecc4:     	add	x12, x12, #0x8e0
10012ecc8:     	strb	w9, [x12, #0x20]
10012eccc:     	add	x12, sp, #0x3, lsl #12  ; =0x3000
10012ecd0:     	add	x12, x12, #0x700
10012ecd4:     	strb	wzr, [x12, #0xc0]
10012ecd8:     	madd	x10, x10, x26, x11
10012ecdc:     	strh	w27, [x10]
10012ece0:     	strb	w8, [x10, #0x2]
10012ece4:     	strb	w9, [x10, #0x3]
10012ece8:     	strb	wzr, [x10, #0x4]
10012ecec:     	ldp	q1, q0, [x25]
10012ecf0:     	stp	q1, q0, [x22, #0x40]
10012ecf4:     	ldrh	w9, [x22, #0x60]
10012ecf8:     	cmp	w8, #0x2
10012ecfc:     	cinc	w8, w9, eq
10012ed00:     	strh	w8, [x22, #0x60]
10012ed04:     	add	x24, x24, #0x1
10012ed08:     	ldr	x9, [sp, #0x148]
10012ed0c:     	cmp	x24, x9
10012ed10:     	b.eq	0x10012f228 <_render.TerminalRenderer.drawPane+0xe28>
10012ed14:     	ldr	x8, [sp, #0x298]
10012ed18:     	add	x25, x8, x24, lsl #5
10012ed1c:     	ldrb	w8, [x23, #0x40]
10012ed20:     	cbz	w8, 0x10012edf0 <_render.TerminalRenderer.drawPane+0x9f0>
10012ed24:     	ldrb	w8, [x23, #0x38]
10012ed28:     	cbz	w8, 0x10012edf0 <_render.TerminalRenderer.drawPane+0x9f0>
10012ed2c:     	ldr	w11, [x23, #0x28]
10012ed30:     	ldr	x8, [x23, #0x30]
10012ed34:     	ldrb	w10, [x23, #0x3d]
10012ed38:     	ldr	x9, [x23]
10012ed3c:     	ldr	w9, [x9, #0xfc]
10012ed40:     	ldr	w12, [sp, #0x190]
10012ed44:     	add	w9, w9, w12
10012ed48:     	tbz	w10, #0x0, 0x10012ed80 <_render.TerminalRenderer.drawPane+0x980>
10012ed4c:     	cmp	w8, w11
10012ed50:     	csel	w10, w8, w11, lo
10012ed54:     	csel	w8, w8, w11, hi
10012ed58:     	cmp	w9, w10
10012ed5c:     	ccmp	w9, w8, #0x2, hs
10012ed60:     	b.hi	0x10012edf0 <_render.TerminalRenderer.drawPane+0x9f0>
10012ed64:     	ldp	q1, q0, [x25]
10012ed68:     	stp	q1, q0, [sp, #0x380]
10012ed6c:     	ldrh	w8, [sp, #0x380]
10012ed70:     	eor	w8, w8, #0x10
10012ed74:     	strh	w8, [sp, #0x380]
10012ed78:     	add	x25, sp, #0x380
10012ed7c:     	b	0x10012edf0 <_render.TerminalRenderer.drawPane+0x9f0>
10012ed80:     	ldr	w10, [x23, #0x2c]
10012ed84:     	lsr	x12, x8, #32
10012ed88:     	cmp	w11, w8
10012ed8c:     	b.lo	0x10012eda4 <_render.TerminalRenderer.drawPane+0x9a4>
10012ed90:     	cmp	w11, w8
10012ed94:     	b.ne	0x10012edbc <_render.TerminalRenderer.drawPane+0x9bc>
10012ed98:     	and	w13, w10, #0xffff
10012ed9c:     	cmp	w13, w12, uxth
10012eda0:     	b.hs	0x10012edbc <_render.TerminalRenderer.drawPane+0x9bc>
10012eda4:     	mov	x13, x10
10012eda8:     	mov	x10, x12
10012edac:     	mov	x12, x11
10012edb0:     	cmp	w9, w12
10012edb4:     	b.hs	0x10012edd0 <_render.TerminalRenderer.drawPane+0x9d0>
10012edb8:     	b	0x10012edf0 <_render.TerminalRenderer.drawPane+0x9f0>
10012edbc:     	mov	x13, x12
10012edc0:     	mov	x12, x8
10012edc4:     	mov	x8, x11
10012edc8:     	cmp	w9, w12
10012edcc:     	b.lo	0x10012edf0 <_render.TerminalRenderer.drawPane+0x9f0>
10012edd0:     	cmp	w24, w13, uxth
10012edd4:     	ccmp	w9, w12, #0x0, lo
10012edd8:     	ccmp	w8, w9, #0x0, ne
10012eddc:     	b.lo	0x10012edf0 <_render.TerminalRenderer.drawPane+0x9f0>
10012ede0:     	and	w10, w10, #0xffff
10012ede4:     	cmp	w8, w9
10012ede8:     	ccmp	w24, w10, #0x0, eq
10012edec:     	b.ls	0x10012ed64 <_render.TerminalRenderer.drawPane+0x964>
10012edf0:     	ldr	w8, [sp, #0x280]
10012edf4:     	cbz	w8, 0x10012ee00 <_render.TerminalRenderer.drawPane+0xa00>
10012edf8:     	cmp	x24, x7
10012edfc:     	b.eq	0x10012eca8 <_render.TerminalRenderer.drawPane+0x8a8>
10012ee00:     	ldrb	w8, [x25, #0x1f]
10012ee04:     	cmp	w8, #0x1
10012ee08:     	b.ne	0x10012eca8 <_render.TerminalRenderer.drawPane+0x8a8>
10012ee0c:     	ldrh	w8, [x25]
10012ee10:     	tbnz	w8, #0x5, 0x10012eca8 <_render.TerminalRenderer.drawPane+0x8a8>
10012ee14:     	ldrb	w23, [x25, #0x1e]
10012ee18:     	add	x28, x25, #0xe
10012ee1c:     	cmp	w23, #0x3
10012ee20:     	b.ne	0x10012ee6c <_render.TerminalRenderer.drawPane+0xa6c>
10012ee24:     	ldrb	w8, [x28]
10012ee28:     	cmp	w8, #0xe2
10012ee2c:     	ldr	x23, [sp, #0x258]
10012ee30:     	b.ne	0x10012f0cc <_render.TerminalRenderer.drawPane+0xccc>
10012ee34:     	ldrb	w8, [x25, #0xf]
10012ee38:     	sub	w9, w8, #0xa4
10012ee3c:     	cmn	w9, #0x4
10012ee40:     	b.lo	0x10012ee50 <_render.TerminalRenderer.drawPane+0xa50>
10012ee44:     	ldrsb	w9, [x25, #0x10]
10012ee48:     	cmn	w9, #0x40
10012ee4c:     	b.lt	0x10012f0e0 <_render.TerminalRenderer.drawPane+0xce0>
10012ee50:     	and	w9, w8, #0xfe
10012ee54:     	cmp	w9, #0x94
10012ee58:     	b.ne	0x10012f0b8 <_render.TerminalRenderer.drawPane+0xcb8>
10012ee5c:     	ldrsb	w8, [x25, #0x10]
10012ee60:     	cmn	w8, #0x41
10012ee64:     	b.gt	0x10012f0cc <_render.TerminalRenderer.drawPane+0xccc>
10012ee68:     	b	0x10012f0e0 <_render.TerminalRenderer.drawPane+0xce0>
10012ee6c:     	cmp	w23, #0x1
10012ee70:     	b.ne	0x10012ee88 <_render.TerminalRenderer.drawPane+0xa88>
10012ee74:     	ldrsb	x8, [x28]
10012ee78:     	tbnz	x8, #0x3f, 0x10012f0ec <_render.TerminalRenderer.drawPane+0xcec>
10012ee7c:     	ldr	x9, [sp, #0xf8]
10012ee80:     	add	x8, x9, x8
10012ee84:     	b	0x10012efd8 <_render.TerminalRenderer.drawPane+0xbd8>
10012ee88:     	ldr	x8, [sp, #0x278]
10012ee8c:     	ldr	x26, [x8, #0xfe8]
10012ee90:     	cbz	x26, 0x10012f1e0 <_render.TerminalRenderer.drawPane+0xde0>
10012ee94:     	ldr	x8, [sp, #0x278]
10012ee98:     	ldr	x27, [x8, #0xff0]
10012ee9c:     	mov	x9, x23
10012eea0:     	mov	x8, x28
10012eea4:     	cmp	w23, #0x10
10012eea8:     	b.lo	0x10012eed0 <_render.TerminalRenderer.drawPane+0xad0>
10012eeac:     	ldr	q0, [x8]
10012eeb0:     	cmlt.16b	v0, v0, #0
10012eeb4:     	umaxv.16b	b0, v0
10012eeb8:     	fmov	w10, s0
10012eebc:     	tbnz	w10, #0x0, 0x10012f10c <_render.TerminalRenderer.drawPane+0xd0c>
10012eec0:     	add	x8, x8, #0x10
10012eec4:     	sub	x9, x9, #0x10
10012eec8:     	cmp	x9, #0xf
10012eecc:     	b.hi	0x10012eeac <_render.TerminalRenderer.drawPane+0xaac>
10012eed0:     	cbnz	x9, 0x10012f10c <_render.TerminalRenderer.drawPane+0xd0c>
10012eed4:     	mov	w8, #0x0                ; =0
10012eed8:     	mov	x22, #0x0               ; =0
10012eedc:     	and	w20, w8, #0x3
10012eee0:     	strb	w20, [sp, #0x4e0]
10012eee4:     	b	0x10012eef4 <_render.TerminalRenderer.drawPane+0xaf4>
10012eee8:     	mov	w8, #0x2                ; =2
10012eeec:     	cmp	w8, w20
10012eef0:     	b.hi	0x10012eedc <_render.TerminalRenderer.drawPane+0xadc>
10012eef4:     	cmp	x22, x23
10012eef8:     	b.hs	0x10012ef6c <_render.TerminalRenderer.drawPane+0xb6c>
10012eefc:     	add	x1, x28, x22
10012ef00:     	ldrsb	w9, [x1]
10012ef04:     	adrp	x8, 0x100596000 <___anon_29692+0x370>
10012ef08:     	add	x8, x8, #0xd2c
10012ef0c:     	tbz	w9, #0x1f, 0x10012ef58 <_render.TerminalRenderer.drawPane+0xb58>
10012ef10:     	and	w9, w9, #0xff
10012ef14:     	and	w10, w9, #0xe0
10012ef18:     	adrp	x8, 0x100596000 <___anon_29692+0x370>
10012ef1c:     	add	x8, x8, #0xd30
10012ef20:     	cmp	w10, #0xc0
10012ef24:     	b.eq	0x10012ef58 <_render.TerminalRenderer.drawPane+0xb58>
10012ef28:     	and	w8, w9, #0xf0
10012ef2c:     	and	w9, w9, #0xf8
10012ef30:     	cmp	w9, #0xf0
10012ef34:     	adrp	x9, 0x100596000 <___anon_29692+0x370>
10012ef38:     	add	x9, x9, #0xd3c
10012ef3c:     	adrp	x10, 0x100596000 <___anon_29692+0x370>
10012ef40:     	add	x10, x10, #0xd38
10012ef44:     	csel	x9, x10, x9, eq
10012ef48:     	cmp	w8, #0xe0
10012ef4c:     	adrp	x8, 0x100596000 <___anon_29692+0x370>
10012ef50:     	add	x8, x8, #0xd34
10012ef54:     	csel	x8, x8, x9, eq
10012ef58:     	ldrb	w8, [x8, #0x2]
10012ef5c:     	and	x2, x8, #0x7
10012ef60:     	add	x22, x22, x2
10012ef64:     	cbnz	x1, 0x10012ef78 <_render.TerminalRenderer.drawPane+0xb78>
10012ef68:     	b	0x10012efcc <_render.TerminalRenderer.drawPane+0xbcc>
10012ef6c:     	mov	x1, #0x0                ; =0
10012ef70:     	mov	x2, #0x0                ; =0
10012ef74:     	cbz	x1, 0x10012efcc <_render.TerminalRenderer.drawPane+0xbcc>
10012ef78:     	add	x0, sp, #0x2, lsl #12   ; =0x2000
10012ef7c:     	add	x0, x0, #0x2e0
10012ef80:     	bl	0x10019b4d4 <_unicode.utf8Decode>
10012ef84:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
10012ef88:     	add	x9, x9, #0x2e0
10012ef8c:     	ldrb	w8, [x9, #0x2]
10012ef90:     	ldrh	w21, [x9]
10012ef94:     	bfi	w21, w8, #16, #5
10012ef98:     	mov	x0, x26
10012ef9c:     	mov	x1, x21
10012efa0:     	bl	0x10009f6f8 <_hb_set_has>
10012efa4:     	cbnz	w0, 0x10012eee8 <_render.TerminalRenderer.drawPane+0xae8>
10012efa8:     	mov	x0, x27
10012efac:     	mov	x1, x21
10012efb0:     	bl	0x10009f6f8 <_hb_set_has>
10012efb4:     	ldr	x21, [sp, #0x260]
10012efb8:     	cbz	w0, 0x10012f1e0 <_render.TerminalRenderer.drawPane+0xde0>
10012efbc:     	mov	w8, #0x1                ; =1
10012efc0:     	cmp	w8, w20
10012efc4:     	b.ls	0x10012eef4 <_render.TerminalRenderer.drawPane+0xaf4>
10012efc8:     	b	0x10012eedc <_render.TerminalRenderer.drawPane+0xadc>
10012efcc:     	add	x8, sp, #0x4e0
10012efd0:     	ldr	x22, [sp, #0x270]
10012efd4:     	ldr	x21, [sp, #0x260]
10012efd8:     	ldrb	w8, [x8]
10012efdc:     	and	w8, w8, #0x3
10012efe0:     	ldr	x9, [x22, #0x30]
10012efe4:     	cmp	w8, #0x0
10012efe8:     	ccmp	x9, #0x0, #0x4, ne
10012efec:     	ldr	x23, [sp, #0x258]
10012eff0:     	mov	w26, #0x6               ; =6
10012eff4:     	mov	w27, #0xffff            ; =65535
10012eff8:     	ldr	x7, [sp, #0x100]
10012effc:     	ldr	x20, [sp, #0x220]
10012f000:     	b.eq	0x10012f0b0 <_render.TerminalRenderer.drawPane+0xcb0>
10012f004:     	ldr	x10, [x22, #0x28]
10012f008:     	madd	x9, x9, x26, x10
10012f00c:     	ldurb	w9, [x9, #-0x4]
10012f010:     	tst	w9, #0x3
10012f014:     	b.eq	0x10012f0b0 <_render.TerminalRenderer.drawPane+0xcb0>
10012f018:     	mov	w9, #0x0                ; =0
10012f01c:     	ldrh	w10, [x22, #0x40]
10012f020:     	ldur	w12, [x22, #0x42]
10012f024:     	ldrh	w11, [x25]
10012f028:     	ldur	w13, [x25, #0x2]
10012f02c:     	tst	w10, #0x10
10012f030:     	csel	w12, w12, wzr, eq
10012f034:     	tst	w11, #0x10
10012f038:     	csel	w13, w13, wzr, eq
10012f03c:     	eor	w14, w11, w10
10012f040:     	tst	w14, #0xfffff83f
10012f044:     	b.ne	0x10012f210 <_render.TerminalRenderer.drawPane+0xe10>
10012f048:     	cmp	w12, w13
10012f04c:     	b.ne	0x10012f210 <_render.TerminalRenderer.drawPane+0xe10>
10012f050:     	ldur	w12, [x22, #0x46]
10012f054:     	ldur	w13, [x25, #0x6]
10012f058:     	lsl	w10, w10, #27
10012f05c:     	and	w10, w12, w10, asr #31
10012f060:     	lsl	w11, w11, #27
10012f064:     	and	w11, w13, w11, asr #31
10012f068:     	cmp	w10, w11
10012f06c:     	b.ne	0x10012f210 <_render.TerminalRenderer.drawPane+0xe10>
10012f070:     	ldrb	w9, [x22, #0x5e]
10012f074:     	cmp	w9, #0x1
10012f078:     	b.ne	0x10012f208 <_render.TerminalRenderer.drawPane+0xe08>
10012f07c:     	ldrb	w9, [x25, #0x1e]
10012f080:     	cmp	w9, #0x1
10012f084:     	b.ne	0x10012f208 <_render.TerminalRenderer.drawPane+0xe08>
10012f088:     	ldrb	w9, [x22, #0x4e]
10012f08c:     	cmp	w9, #0x73
10012f090:     	b.eq	0x10012f218 <_render.TerminalRenderer.drawPane+0xe18>
10012f094:     	cmp	w9, #0x66
10012f098:     	b.ne	0x10012f208 <_render.TerminalRenderer.drawPane+0xe08>
10012f09c:     	ldrb	w9, [x28]
10012f0a0:     	cmp	w9, #0x69
10012f0a4:     	mov	w10, #0x6c              ; =108
10012f0a8:     	ccmp	w9, w10, #0x4, ne
10012f0ac:     	b	0x10012f220 <_render.TerminalRenderer.drawPane+0xe20>
10012f0b0:     	mov	w9, #0x0                ; =0
10012f0b4:     	b	0x10012f210 <_render.TerminalRenderer.drawPane+0xe10>
10012f0b8:     	cmp	w8, #0x96
10012f0bc:     	b.ne	0x10012f0cc <_render.TerminalRenderer.drawPane+0xccc>
10012f0c0:     	ldrsb	w8, [x25, #0x10]
10012f0c4:     	cmn	w8, #0x61
10012f0c8:     	b.le	0x10012f0e0 <_render.TerminalRenderer.drawPane+0xce0>
10012f0cc:     	ldr	x8, [sp, #0x278]
10012f0d0:     	ldr	x26, [x8, #0xfe8]
10012f0d4:     	cbz	x26, 0x10012f1e0 <_render.TerminalRenderer.drawPane+0xde0>
10012f0d8:     	mov	w23, #0x3               ; =3
10012f0dc:     	b	0x10012f0fc <_render.TerminalRenderer.drawPane+0xcfc>
10012f0e0:     	mov	w8, #0x0                ; =0
10012f0e4:     	mov	w9, #0x0                ; =0
10012f0e8:     	b	0x10012f210 <_render.TerminalRenderer.drawPane+0xe10>
10012f0ec:     	ldr	x8, [sp, #0x278]
10012f0f0:     	ldr	x26, [x8, #0xfe8]
10012f0f4:     	cbz	x26, 0x10012f1e0 <_render.TerminalRenderer.drawPane+0xde0>
10012f0f8:     	mov	w23, #0x1               ; =1
10012f0fc:     	ldr	x8, [sp, #0x278]
10012f100:     	ldr	x27, [x8, #0xff0]
10012f104:     	mov	x8, x28
10012f108:     	mov	x9, x23
10012f10c:     	mov	x10, #0x0               ; =0
10012f110:     	b	0x10012f124 <_render.TerminalRenderer.drawPane+0xd24>
10012f114:     	mov	w11, #0x1               ; =1
10012f118:     	add	x10, x11, x10
10012f11c:     	cmp	x10, x9
10012f120:     	b.hs	0x10012eed4 <_render.TerminalRenderer.drawPane+0xad4>
10012f124:     	add	x11, x8, x10
10012f128:     	ldrsb	w12, [x11]
10012f12c:     	tbz	w12, #0x1f, 0x10012f114 <_render.TerminalRenderer.drawPane+0xd14>
10012f130:     	and	x12, x12, #0xff
10012f134:     	adrp	x13, 0x10059b000 <___anon_64753+0xf50>
10012f138:     	add	x13, x13, #0x2bb
10012f13c:     	ldrb	w13, [x13, x12]
10012f140:     	cmp	w13, #0xf1
10012f144:     	and	x12, x13, #0x7
10012f148:     	add	x14, x10, x12
10012f14c:     	ccmp	x14, x9, #0x2, ne
10012f150:     	b.hi	0x10012f1e0 <_render.TerminalRenderer.drawPane+0xde0>
10012f154:     	lsr	w13, w13, #1
10012f158:     	and	w13, w13, #0x78
10012f15c:     	mov	x14, #0xa080            ; =41088
10012f160:     	movk	x14, #0x9080, lsl #16
10012f164:     	movk	x14, #0x80, lsl #32
10012f168:     	lsr	x14, x14, x13
10012f16c:     	and	w14, w14, #0xff0
10012f170:     	mov	x15, #0xbfbf            ; =49087
10012f174:     	movk	x15, #0xbf9f, lsl #16
10012f178:     	movk	x15, #0x8f, lsl #32
10012f17c:     	lsr	x13, x15, x13
10012f180:     	and	w13, w13, #0xff
10012f184:     	ldrb	w15, [x11, #0x1]
10012f188:     	cmp	w15, w14
10012f18c:     	ccmp	w15, w13, #0x2, hs
10012f190:     	b.hi	0x10012f1e0 <_render.TerminalRenderer.drawPane+0xde0>
10012f194:     	cmp	w12, #0x2
10012f198:     	b.eq	0x10012f1c4 <_render.TerminalRenderer.drawPane+0xdc4>
10012f19c:     	cmp	w12, #0x4
10012f1a0:     	b.ne	0x10012f1cc <_render.TerminalRenderer.drawPane+0xdcc>
10012f1a4:     	ldrsb	w12, [x11, #0x2]
10012f1a8:     	cmn	w12, #0x41
10012f1ac:     	b.gt	0x10012f1e0 <_render.TerminalRenderer.drawPane+0xde0>
10012f1b0:     	ldrsb	w11, [x11, #0x3]
10012f1b4:     	cmn	w11, #0x41
10012f1b8:     	b.gt	0x10012f1e0 <_render.TerminalRenderer.drawPane+0xde0>
10012f1bc:     	mov	w11, #0x4               ; =4
10012f1c0:     	b	0x10012f118 <_render.TerminalRenderer.drawPane+0xd18>
10012f1c4:     	mov	w11, w12
10012f1c8:     	b	0x10012f118 <_render.TerminalRenderer.drawPane+0xd18>
10012f1cc:     	ldrsb	w11, [x11, #0x2]
10012f1d0:     	cmn	w11, #0x41
10012f1d4:     	b.gt	0x10012f1e0 <_render.TerminalRenderer.drawPane+0xde0>
10012f1d8:     	mov	w11, #0x3               ; =3
10012f1dc:     	b	0x10012f118 <_render.TerminalRenderer.drawPane+0xd18>
10012f1e0:     	mov	w8, #0x0                ; =0
10012f1e4:     	mov	w9, #0x0                ; =0
10012f1e8:     	ldr	x23, [sp, #0x258]
10012f1ec:     	ldr	x22, [sp, #0x270]
10012f1f0:     	ldr	x28, [sp, #0x178]
10012f1f4:     	mov	w26, #0x6               ; =6
10012f1f8:     	mov	w27, #0xffff            ; =65535
10012f1fc:     	ldr	x7, [sp, #0x100]
10012f200:     	ldr	x20, [sp, #0x220]
10012f204:     	b	0x10012ecb0 <_render.TerminalRenderer.drawPane+0x8b0>
10012f208:     	mov	w9, #0x0                ; =0
10012f20c:     	eor	w9, w9, #0x1
10012f210:     	ldr	x28, [sp, #0x178]
10012f214:     	b	0x10012ecb0 <_render.TerminalRenderer.drawPane+0x8b0>
10012f218:     	ldrb	w9, [x28]
10012f21c:     	cmp	w9, #0x74
10012f220:     	cset	w9, eq
10012f224:     	b	0x10012f20c <_render.TerminalRenderer.drawPane+0xe0c>
10012f228:     	tst	w8, #0xffff
10012f22c:     	b.eq	0x10012f348 <_render.TerminalRenderer.drawPane+0xf48>
10012f230:     	ldr	x8, [sp, #0x278]
10012f234:     	ldrh	w8, [x8, #0xff8]
10012f238:     	sub	w9, w8, #0x81
10012f23c:     	ubfx	w9, w9, #7, #9
10012f240:     	cmp	w9, #0x1ff
10012f244:     	mov	w9, #0x80               ; =128
10012f248:     	csel	w8, w9, w8, lo
10012f24c:     	ldr	x9, [x22, #0x30]
10012f250:     	add	x25, sp, #0x4e0
10012f254:     	ldr	x24, [sp, #0x148]
10012f258:     	cbz	x9, 0x10012f338 <_render.TerminalRenderer.drawPane+0xf38>
10012f25c:     	ldr	x10, [x22, #0x28]
10012f260:     	add	x10, x10, #0x3
10012f264:     	mov	w11, #0xffff            ; =65535
10012f268:     	ldrb	w12, [x10]
10012f26c:     	ldurb	w13, [x10, #-0x1]
10012f270:     	and	w13, w13, #0x3
10012f274:     	and	w11, w11, #0xffff
10012f278:     	add	w14, w11, #0x1
10012f27c:     	cmp	w14, w27
10012f280:     	csinc	w11, w27, w11, hs
10012f284:     	cmp	w12, #0x0
10012f288:     	csinv	w11, w11, wzr, ne
10012f28c:     	cmp	w13, #0x2
10012f290:     	csel	w11, wzr, w11, eq
10012f294:     	sturh	w11, [x10, #-0x3]
10012f298:     	add	x10, x10, #0x6
10012f29c:     	subs	x9, x9, #0x1
10012f2a0:     	b.ne	0x10012f268 <_render.TerminalRenderer.drawPane+0xe68>
10012f2a4:     	ldr	x9, [x22, #0x30]
10012f2a8:     	cbz	x9, 0x10012f338 <_render.TerminalRenderer.drawPane+0xf38>
10012f2ac:     	cmp	x9, #0x8
10012f2b0:     	b.hs	0x100132154 <_render.TerminalRenderer.drawPane+0x3d54>
10012f2b4:     	mov	w13, #0xffff            ; =65535
10012f2b8:     	mov	x10, x9
10012f2bc:     	and	x9, x9, #0x7
10012f2c0:     	cbz	x9, 0x10012f338 <_render.TerminalRenderer.drawPane+0xf38>
10012f2c4:     	add	x10, x10, x10, lsl #1
10012f2c8:     	lsl	x10, x10, #1
10012f2cc:     	b	0x10012f304 <_render.TerminalRenderer.drawPane+0xf04>
10012f2d0:     	ldurh	w13, [x11, #-0x6]
10012f2d4:     	and	w14, w12, #0xffff
10012f2d8:     	cmp	w13, w14
10012f2dc:     	csel	w13, w13, w14, lo
10012f2e0:     	cmp	w13, w8, uxth
10012f2e4:     	cset	w13, lo
10012f2e8:     	sturb	w13, [x11, #-0x2]
10012f2ec:     	ldurb	w11, [x11, #-0x3]
10012f2f0:     	cmp	w11, #0x0
10012f2f4:     	csinv	w13, w12, wzr, ne
10012f2f8:     	sub	x10, x10, #0x6
10012f2fc:     	subs	x9, x9, #0x1
10012f300:     	b.eq	0x10012f338 <_render.TerminalRenderer.drawPane+0xf38>
10012f304:     	ldr	x11, [x22, #0x28]
10012f308:     	add	x11, x11, x10
10012f30c:     	ldurb	w12, [x11, #-0x4]
10012f310:     	and	w14, w12, #0x3
10012f314:     	and	w12, w13, #0xffff
10012f318:     	add	w13, w12, #0x1
10012f31c:     	cmp	w13, w27
10012f320:     	csinc	w12, w27, w12, hs
10012f324:     	cmp	w14, #0x2
10012f328:     	csel	w12, wzr, w12, eq
10012f32c:     	cbnz	w14, 0x10012f2d0 <_render.TerminalRenderer.drawPane+0xed0>
10012f330:     	mov	w13, #0x0               ; =0
10012f334:     	b	0x10012f2e8 <_render.TerminalRenderer.drawPane+0xee8>
10012f338:     	mov	w8, #0x1                ; =1
10012f33c:     	str	w8, [sp, #0xe0]
10012f340:     	cbnz	w24, 0x10012f35c <_render.TerminalRenderer.drawPane+0xf5c>
10012f344:     	b	0x10012ec74 <_render.TerminalRenderer.drawPane+0x874>
10012f348:     	mov	w8, #0x1                ; =1
10012f34c:     	str	w8, [sp, #0xe0]
10012f350:     	add	x25, sp, #0x4e0
10012f354:     	ldr	x24, [sp, #0x148]
10012f358:     	cbz	w24, 0x10012ec74 <_render.TerminalRenderer.drawPane+0x874>
10012f35c:     	str	xzr, [sp, #0x158]
10012f360:     	ldr	x11, [sp, #0x170]
10012f364:     	ldrh	w8, [x11, #0x48]
10012f368:     	ldr	x9, [x11]
10012f36c:     	ldr	x10, [x11, #0x18]
10012f370:     	ldr	x11, [x11, #0x30]
10012f374:     	sub	x13, x24, #0x1
10012f378:     	ldr	x12, [sp, #0x230]
10012f37c:     	add	x12, x28, x12
10012f380:     	madd	x8, x12, x8, x20
10012f384:     	mov	w12, #0x6e0             ; =1760
10012f388:     	madd	x11, x8, x12, x11
10012f38c:     	stp	x11, x13, [sp, #0xa8]
10012f390:     	mov	w11, #0xa0              ; =160
10012f394:     	madd	x10, x8, x11, x10
10012f398:     	add	x8, x9, x8, lsl #6
10012f39c:     	stp	x8, x10, [sp, #0x98]
10012f3a0:     	mov	w8, #0x437f0000         ; =1132396544
10012f3a4:     	dup.2s	v0, w8
10012f3a8:     	str	d0, [sp, #0x180]
10012f3ac:     	mov	w8, #0xaaab             ; =43691
10012f3b0:     	movk	w8, #0x2aaa, lsl #16
10012f3b4:     	dup.2s	v0, w8
10012f3b8:     	str	d0, [sp, #0x118]
10012f3bc:     	ldr	w8, [sp, #0xe0]
10012f3c0:     	tbz	w8, #0x0, 0x10012f478 <_render.TerminalRenderer.drawPane+0x1078>
10012f3c4:     	ldr	x10, [x22, #0x28]
10012f3c8:     	ldr	x11, [sp, #0x158]
10012f3cc:     	and	x12, x11, #0xffff
10012f3d0:     	umaddl	x8, w12, w26, x10
10012f3d4:     	ldrb	w8, [x8, #0x4]
10012f3d8:     	cmp	w8, #0x1
10012f3dc:     	b.ne	0x10012f490 <_render.TerminalRenderer.drawPane+0x1090>
10012f3e0:     	ldr	x9, [x22, #0x30]
10012f3e4:     	add	w8, w11, #0x1
10012f3e8:     	and	x8, x8, #0xffff
10012f3ec:     	cmp	x9, x8
10012f3f0:     	b.ls	0x10012f428 <_render.TerminalRenderer.drawPane+0x1028>
10012f3f4:     	umaddl	x10, w8, w26, x10
10012f3f8:     	add	x10, x10, #0x4
10012f3fc:     	ldrb	w11, [x10]
10012f400:     	cmp	w11, #0x1
10012f404:     	b.ne	0x10012f428 <_render.TerminalRenderer.drawPane+0x1028>
10012f408:     	ldurb	w11, [x10, #-0x1]
10012f40c:     	cmp	w11, #0x1
10012f410:     	b.ne	0x10012f428 <_render.TerminalRenderer.drawPane+0x1028>
10012f414:     	add	x8, x8, #0x1
10012f418:     	add	x10, x10, #0x6
10012f41c:     	cmp	x9, x8
10012f420:     	b.ne	0x10012f3fc <_render.TerminalRenderer.drawPane+0xffc>
10012f424:     	mov	x8, x9
10012f428:     	sub	x9, x8, x12
10012f42c:     	sub	x8, x9, #0x2
10012f430:     	cmp	x8, #0x7f
10012f434:     	cset	w8, lo
10012f438:     	strb	w8, [sp, #0x3ae]
10012f43c:     	b.hs	0x1001302cc <_render.TerminalRenderer.drawPane+0x1ecc>
10012f440:     	str	x12, [sp, #0x1c8]
10012f444:     	ldr	x8, [x23]
10012f448:     	str	x8, [sp, #0x168]
10012f44c:     	ldrh	w8, [x23, #0x18]
10012f450:     	str	w8, [sp, #0x160]
10012f454:     	ldrh	w8, [x23, #0x1a]
10012f458:     	str	w8, [sp, #0x230]
10012f45c:     	add	x26, sp, #0xce0
10012f460:     	cbz	x9, 0x1001311ec <_render.TerminalRenderer.drawPane+0x2dec>
10012f464:     	mov	x10, x9
10012f468:     	mov	x20, x9
10012f46c:     	ldr	x27, [sp, #0x158]
10012f470:     	ldr	x9, [sp, #0x168]
10012f474:     	b	0x10012f4c4 <_render.TerminalRenderer.drawPane+0x10c4>
10012f478:     	str	wzr, [sp, #0x220]
10012f47c:     	ldr	x8, [sp, #0x158]
10012f480:     	and	x12, x8, #0xffff
10012f484:     	mov	x9, x24
10012f488:     	str	x24, [sp, #0x298]
10012f48c:     	b	0x1001302e0 <_render.TerminalRenderer.drawPane+0x1ee0>
10012f490:     	strb	wzr, [sp, #0x3ae]
10012f494:     	tbz	wzr, #0x0, 0x1001302c8 <_render.TerminalRenderer.drawPane+0x1ec8>
10012f498:     	str	x12, [sp, #0x1c8]
10012f49c:     	ldr	x9, [x23]
10012f4a0:     	ldrh	w8, [x23, #0x18]
10012f4a4:     	str	w8, [sp, #0x160]
10012f4a8:     	ldrh	w8, [x23, #0x1a]
10012f4ac:     	str	w8, [sp, #0x230]
10012f4b0:     	mov	w8, #0x1                ; =1
10012f4b4:     	mov	w10, #0x1               ; =1
10012f4b8:     	mov	x20, x8
10012f4bc:     	add	x26, sp, #0xce0
10012f4c0:     	ldr	x27, [sp, #0x158]
10012f4c4:     	mov	x22, #0x0               ; =0
10012f4c8:     	mov	x23, #0x0               ; =0
10012f4cc:     	ldrh	w8, [x9, #0x50]
10012f4d0:     	str	x9, [sp, #0x168]
10012f4d4:     	ldr	x9, [x9, #0x30]
10012f4d8:     	mul	x8, x28, x8
10012f4dc:     	add	x24, x9, x8, lsl #5
10012f4e0:     	mov	x28, x10
10012f4e4:     	add	w8, w27, w22
10012f4e8:     	and	x8, x8, #0xffff
10012f4ec:     	add	x8, x24, x8, lsl #5
10012f4f0:     	ldrb	w21, [x8, #0x1e]
10012f4f4:     	add	x0, x25, x23
10012f4f8:     	add	x1, x8, #0xe
10012f4fc:     	mov	x2, x21
10012f500:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
10012f504:     	add	x23, x23, x21
10012f508:     	str	w23, [x26, x22, lsl #2]
10012f50c:     	add	x22, x22, #0x1
10012f510:     	cmp	x28, x22
10012f514:     	b.ne	0x10012f4e4 <_render.TerminalRenderer.drawPane+0x10e4>
10012f518:     	mov	w22, #0x0               ; =0
10012f51c:     	ldr	x21, [sp, #0x260]
10012f520:     	mov	x26, x20
10012f524:     	and	w8, w26, #0xffff
10012f528:     	ldrh	w3, [x21, #0x8]
10012f52c:     	str	x25, [sp, #0x38e0]
10012f530:     	str	x23, [sp, #0x38e8]
10012f534:     	ldr	x9, [sp, #0xb8]
10012f538:     	str	x9, [sp, #0x38f0]
10012f53c:     	str	w8, [sp, #0x38f8]
10012f540:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10012f544:     	add	x8, x8, #0x700
10012f548:     	strb	wzr, [x8, #0x1fc]
10012f54c:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
10012f550:     	add	x0, x0, #0x900
10012f554:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
10012f558:     	add	x2, x2, #0x8e0
10012f55c:     	ldr	x1, [sp, #0x278]
10012f560:     	bl	0x100120964 <_text.GlyphAtlas.shape>
10012f564:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10012f568:     	add	x8, x8, #0x8e0
10012f56c:     	ldrh	w0, [x8, #0x48]
10012f570:     	cbnz	w0, 0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
10012f574:     	ldrb	w23, [x8, #0x45]
10012f578:     	str	x28, [sp, #0x298]
10012f57c:     	str	x26, [sp, #0x110]
10012f580:     	tbnz	w23, #0x0, 0x10012f5d0 <_render.TerminalRenderer.drawPane+0x11d0>
10012f584:     	ldr	x1, [sp, #0x3900]
10012f588:     	ldr	x20, [sp, #0x3908]
10012f58c:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10012f590:     	add	x8, x8, #0x8e0
10012f594:     	ldrh	w24, [x8, #0x46]
10012f598:     	cmp	x20, #0x2
10012f59c:     	b.lo	0x10012f5c4 <_render.TerminalRenderer.drawPane+0x11c4>
10012f5a0:     	add	x8, x1, #0x1c
10012f5a4:     	sub	x9, x20, #0x1
10012f5a8:     	ldr	w10, [x8]
10012f5ac:     	ldur	w11, [x8, #-0x14]
10012f5b0:     	cmp	w10, w11
10012f5b4:     	b.lo	0x10012f5d0 <_render.TerminalRenderer.drawPane+0x11d0>
10012f5b8:     	add	x8, x8, #0x14
10012f5bc:     	subs	x9, x9, #0x1
10012f5c0:     	b.ne	0x10012f5a8 <_render.TerminalRenderer.drawPane+0x11a8>
10012f5c4:     	sub	x8, x20, #0x101
10012f5c8:     	cmn	x8, #0x101
10012f5cc:     	b.hi	0x100131200 <_render.TerminalRenderer.drawPane+0x2e00>
10012f5d0:     	tbnz	w22, #0x0, 0x100131248 <_render.TerminalRenderer.drawPane+0x2e48>
10012f5d4:     	mov	x20, #0x0               ; =0
10012f5d8:     	ldr	x8, [sp, #0x158]
10012f5dc:     	add	w8, w8, w20
10012f5e0:     	ldr	x17, [sp, #0x258]
10012f5e4:     	ldr	x12, [x17]
10012f5e8:     	ldrh	w9, [x12, #0x50]
10012f5ec:     	ldr	x0, [sp, #0x178]
10012f5f0:     	mul	x10, x0, x9
10012f5f4:     	and	x11, x8, #0xffff
10012f5f8:     	ldr	x13, [x12, #0x30]
10012f5fc:     	add	x10, x13, x10, lsl #5
10012f600:     	add	x10, x10, x11, lsl #5
10012f604:     	ldrb	w11, [x17, #0x40]
10012f608:     	cbz	w11, 0x10012f678 <_render.TerminalRenderer.drawPane+0x1278>
10012f60c:     	ldrb	w11, [x17, #0x38]
10012f610:     	cbz	w11, 0x10012f678 <_render.TerminalRenderer.drawPane+0x1278>
10012f614:     	ldr	w14, [x17, #0x28]
10012f618:     	ldr	x11, [x17, #0x30]
10012f61c:     	ldrb	w13, [x17, #0x3d]
10012f620:     	ldr	w12, [x12, #0xfc]
10012f624:     	ldr	w15, [sp, #0x190]
10012f628:     	add	w12, w12, w15
10012f62c:     	ldr	x22, [sp, #0x270]
10012f630:     	tbz	w13, #0x0, 0x10012f8e8 <_render.TerminalRenderer.drawPane+0x14e8>
10012f634:     	cmp	w11, w14
10012f638:     	csel	w13, w11, w14, lo
10012f63c:     	csel	w11, w11, w14, hi
10012f640:     	cmp	w12, w13
10012f644:     	ccmp	w12, w11, #0x2, hs
10012f648:     	b.hi	0x10012f67c <_render.TerminalRenderer.drawPane+0x127c>
10012f64c:     	ldp	q0, q1, [x10]
10012f650:     	str	q0, [sp, #0x3870]
10012f654:     	str	q1, [sp, #0x3880]
10012f658:     	add	x11, sp, #0x3, lsl #12  ; =0x3000
10012f65c:     	add	x11, x11, #0x700
10012f660:     	ldrh	w10, [x11, #0x170]
10012f664:     	eor	w10, w10, #0x10
10012f668:     	strh	w10, [x11, #0x170]
10012f66c:     	add	x10, sp, #0x3, lsl #12  ; =0x3000
10012f670:     	add	x10, x10, #0x870
10012f674:     	b	0x10012f67c <_render.TerminalRenderer.drawPane+0x127c>
10012f678:     	ldr	x22, [sp, #0x270]
10012f67c:     	ldrh	w11, [x17, #0x18]
10012f680:     	ldrh	w12, [x17, #0x1a]
10012f684:     	ldp	q3, q4, [x10]
10012f688:     	umov.b	w27, v4[15]
10012f68c:     	add	w10, w11, w8, uxth
10012f690:     	add	w11, w12, w0, uxth
10012f694:     	tst	w27, #0xfe
10012f698:     	csinc	w12, w27, wzr, ne
10012f69c:     	ldrh	w13, [x17, #0x1c]
10012f6a0:     	cmp	w13, w9
10012f6a4:     	csel	w9, w13, w9, lo
10012f6a8:     	sub	w8, w9, w8
10012f6ac:     	and	w8, w8, #0xffff
10012f6b0:     	cmp	w12, w8
10012f6b4:     	csel	w9, w12, w8, lo
10012f6b8:     	ldrh	w8, [x21, #0x4]
10012f6bc:     	ldrh	w12, [x21, #0x6]
10012f6c0:     	ldr	x14, [sp, #0x240]
10012f6c4:     	ldp	w14, w13, [x14]
10012f6c8:     	madd	w14, w8, w10, w14
10012f6cc:     	ucvtf	s15, w14
10012f6d0:     	madd	w13, w12, w11, w13
10012f6d4:     	ucvtf	s11, w13
10012f6d8:     	mul	w9, w9, w8
10012f6dc:     	ucvtf	s14, w9
10012f6e0:     	ucvtf	s12, w12
10012f6e4:     	ldr	x12, [sp, #0x170]
10012f6e8:     	ldrh	w9, [x12, #0x48]
10012f6ec:     	and	x11, x11, #0xffff
10012f6f0:     	umull	x9, w9, w11
10012f6f4:     	add	x9, x9, w10, uxth
10012f6f8:     	ldr	x10, [x12]
10012f6fc:     	add	x23, x10, x9, lsl #6
10012f700:     	ldr	x11, [x12, #0x18]
10012f704:     	ldr	x10, [x12, #0x30]
10012f708:     	ldrb	w12, [x23, #0x38]
10012f70c:     	cmp	w12, #0x1
10012f710:     	b.ne	0x10012f76c <_render.TerminalRenderer.drawPane+0x136c>
10012f714:     	ldr	s0, [x23, #0x8]
10012f718:     	fcmp	s0, s15
10012f71c:     	b.ne	0x10012f76c <_render.TerminalRenderer.drawPane+0x136c>
10012f720:     	ldr	s0, [x23, #0xc]
10012f724:     	fcmp	s0, s11
10012f728:     	b.ne	0x10012f76c <_render.TerminalRenderer.drawPane+0x136c>
10012f72c:     	ldr	s0, [x23, #0x10]
10012f730:     	fcmp	s0, s14
10012f734:     	b.ne	0x10012f76c <_render.TerminalRenderer.drawPane+0x136c>
10012f738:     	ldr	s0, [x23, #0x14]
10012f73c:     	fcmp	s0, s12
10012f740:     	b.ne	0x10012f76c <_render.TerminalRenderer.drawPane+0x136c>
10012f744:     	ldur	q0, [x23, #0x18]
10012f748:     	ldur	q1, [x23, #0x28]
10012f74c:     	eor.16b	v0, v0, v3
10012f750:     	eor.16b	v1, v1, v4
10012f754:     	orr.16b	v0, v1, v0
10012f758:     	umaxv.16b	b0, v0
10012f75c:     	fmov	w12, s0
10012f760:     	cbnz	w12, 0x10012f76c <_render.TerminalRenderer.drawPane+0x136c>
10012f764:     	ldr	x12, [x23]
10012f768:     	cbz	x12, 0x1001302b8 <_render.TerminalRenderer.drawPane+0x1eb8>
10012f76c:     	mov	w12, #0xa0              ; =160
10012f770:     	madd	x26, x9, x12, x11
10012f774:     	mov	w11, #0x6e0             ; =1760
10012f778:     	madd	x28, x9, x11, x10
10012f77c:     	str	q3, [sp, #0x38e0]
10012f780:     	str	q4, [sp, #0x38f0]
10012f784:     	str	xzr, [x22, #0xc0]
10012f788:     	mov.d	x9, v3[1]
10012f78c:     	fmov	x25, d3
10012f790:     	umov.b	w1, v4[14]
10012f794:     	umov.b	w21, v3[14]
10012f798:     	umov.b	w2, v3[2]
10012f79c:     	and	w17, w25, #0xffff
10012f7a0:     	mov	w15, #0x6b78            ; =27512
10012f7a4:     	movk	w15, #0x1, lsl #16
10012f7a8:     	add	x14, x15, #0x10
10012f7ac:     	extr	x3, x9, x25, #0x30
10012f7b0:     	tst	w25, #0x10
10012f7b4:     	csel	w13, w3, w2, eq
10012f7b8:     	mov	w9, #0x3                ; =3
10012f7bc:     	mov	w10, #0x7               ; =7
10012f7c0:     	csel	x10, x10, x9, eq
10012f7c4:     	mov	w9, #0x4                ; =4
10012f7c8:     	mov	w11, #0x8               ; =8
10012f7cc:     	csel	x11, x11, x9, eq
10012f7d0:     	mov	w9, #0x5                ; =5
10012f7d4:     	mov	w12, #0x9               ; =9
10012f7d8:     	csel	x12, x12, x9, eq
10012f7dc:     	csel	x14, x15, x14, eq
10012f7e0:     	tst	w25, #0x10
10012f7e4:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012f7e8:     	add	x9, x9, #0x890
10012f7ec:     	add	x15, sp, #0x3, lsl #12  ; =0x3000
10012f7f0:     	add	x15, x15, #0x8a0
10012f7f4:     	csel	x9, x15, x9, eq
10012f7f8:     	str	q3, [sp, #0x2d0]
10012f7fc:     	add	x15, sp, #0x2d0
10012f800:     	orr	x10, x15, x10
10012f804:     	ldrb	w10, [x10]
10012f808:     	ldr	x15, [sp, #0x278]
10012f80c:     	ldr	q0, [x15, x14]
10012f810:     	str	q0, [x9]
10012f814:     	and	w13, w13, #0xff
10012f818:     	cmp	w13, #0x2
10012f81c:     	stp	q4, q3, [sp, #0x220]
10012f820:     	b.eq	0x10012f874 <_render.TerminalRenderer.drawPane+0x1474>
10012f824:     	cmp	w13, #0x1
10012f828:     	b.ne	0x10012f8c0 <_render.TerminalRenderer.drawPane+0x14c0>
10012f82c:     	and	w9, w10, #0xff
10012f830:     	cmp	w9, #0x10
10012f834:     	b.hs	0x10012f924 <_render.TerminalRenderer.drawPane+0x1524>
10012f838:     	and	x9, x10, #0xff
10012f83c:     	add	x9, x9, w10, uxtb #1
10012f840:     	ldr	x10, [sp, #0x1c0]
10012f844:     	add	x9, x10, x9
10012f848:     	ldr	b0, [x9]
10012f84c:     	ucvtf	s0, s0
10012f850:     	mov	w10, #0x437f0000        ; =1132396544
10012f854:     	fmov	s1, w10
10012f858:     	fdiv	s5, s0, s1
10012f85c:     	ldr	b0, [x9, #0x1]
10012f860:     	ucvtf	s0, s0
10012f864:     	fdiv	s0, s0, s1
10012f868:     	stp	s5, s0, [x29, #-0xb0]
10012f86c:     	ldr	b0, [x9, #0x2]
10012f870:     	b	0x10012f8b0 <_render.TerminalRenderer.drawPane+0x14b0>
10012f874:     	add	x13, sp, #0x2c0
10012f878:     	orr	x9, x13, x12
10012f87c:     	str	q3, [sp, #0x2c0]
10012f880:     	orr	x11, x13, x11
10012f884:     	and	w10, w10, #0xff
10012f888:     	ucvtf	s0, w10
10012f88c:     	mov	w10, #0x437f0000        ; =1132396544
10012f890:     	fmov	s1, w10
10012f894:     	fdiv	s5, s0, s1
10012f898:     	stur	s5, [x29, #-0xb0]
10012f89c:     	ldr	b0, [x11]
10012f8a0:     	ucvtf	s0, s0
10012f8a4:     	fdiv	s0, s0, s1
10012f8a8:     	stur	s0, [x29, #-0xac]
10012f8ac:     	ldr	b0, [x9]
10012f8b0:     	ucvtf	s0, s0
10012f8b4:     	fdiv	s0, s0, s1
10012f8b8:     	stur	s0, [x29, #-0xa8]
10012f8bc:     	b	0x10012faa0 <_render.TerminalRenderer.drawPane+0x16a0>
10012f8c0:     	ldr	s5, [x9]
10012f8c4:     	ldp	s10, s9, [x9, #0x4]
10012f8c8:     	ldr	s8, [x9, #0xc]
10012f8cc:     	ucvtf	s13, w8
10012f8d0:     	ldrb	w8, [x22, #0xd8]
10012f8d4:     	cbnz	w8, 0x10012fac0 <_render.TerminalRenderer.drawPane+0x16c0>
10012f8d8:     	ldr	x8, [x22, #0xc8]
10012f8dc:     	cbz	x8, 0x10012f9c0 <_render.TerminalRenderer.drawPane+0x15c0>
10012f8e0:     	mov	x8, #0x0                ; =0
10012f8e4:     	b	0x10012fa54 <_render.TerminalRenderer.drawPane+0x1654>
10012f8e8:     	ldr	w13, [x17, #0x2c]
10012f8ec:     	lsr	x15, x11, #32
10012f8f0:     	cmp	w14, w11
10012f8f4:     	b.lo	0x10012f90c <_render.TerminalRenderer.drawPane+0x150c>
10012f8f8:     	cmp	w14, w11
10012f8fc:     	b.ne	0x10012fccc <_render.TerminalRenderer.drawPane+0x18cc>
10012f900:     	and	w16, w13, #0xffff
10012f904:     	cmp	w16, w15, uxth
10012f908:     	b.hs	0x10012fccc <_render.TerminalRenderer.drawPane+0x18cc>
10012f90c:     	mov	x16, x13
10012f910:     	mov	x13, x15
10012f914:     	mov	x15, x14
10012f918:     	cmp	w12, w15
10012f91c:     	b.hs	0x10012fce0 <_render.TerminalRenderer.drawPane+0x18e0>
10012f920:     	b	0x10012f67c <_render.TerminalRenderer.drawPane+0x127c>
10012f924:     	cmp	w9, #0xe7
10012f928:     	b.hi	0x10012fa6c <_render.TerminalRenderer.drawPane+0x166c>
10012f92c:     	sub	w9, w10, #0x10
10012f930:     	and	w10, w9, #0xff
10012f934:     	mov	w11, #0x39              ; =57
10012f938:     	mul	w11, w10, w11
10012f93c:     	lsr	w11, w11, #11
10012f940:     	mov	w12, #0x28              ; =40
10012f944:     	mov	w13, #0x37              ; =55
10012f948:     	madd	w11, w11, w12, w13
10012f94c:     	cmp	w10, #0x24
10012f950:     	csel	w11, wzr, w11, lo
10012f954:     	and	w11, w11, #0xff
10012f958:     	mov	w12, #0xab              ; =171
10012f95c:     	mul	w10, w10, w12
10012f960:     	lsr	w10, w10, #10
10012f964:     	ucvtf	s0, w11
10012f968:     	mov	w11, #0x437f0000        ; =1132396544
10012f96c:     	fmov	s1, w11
10012f970:     	fmov	s2, w10
10012f974:     	mov.s	v2[1], w9
10012f978:     	fdiv	s5, s0, s1
10012f97c:     	movi	d0, #0x0000ff000000ff
10012f980:     	and.8b	v0, v2, v0
10012f984:     	ldr	d1, [sp, #0x118]
10012f988:     	umull.2d	v1, v0, v1
10012f98c:     	shrn.2s	v1, v1, #0x20
10012f990:     	movi.2s	v2, #0x6
10012f994:     	mls.2s	v0, v1, v2
10012f998:     	movi.2s	v1, #0x37
10012f99c:     	movi.2s	v2, #0x28
10012f9a0:     	mla.2s	v1, v0, v2
10012f9a4:     	cmeq.2s	v0, v0, #0
10012f9a8:     	bic.8b	v0, v1, v0
10012f9ac:     	bic.2s	v0, #0x3, lsl #8
10012f9b0:     	ucvtf.2s	v0, v0
10012f9b4:     	ldr	d1, [sp, #0x180]
10012f9b8:     	fdiv.2s	v0, v0, v1
10012f9bc:     	b	0x10012fa90 <_render.TerminalRenderer.drawPane+0x1690>
10012f9c0:     	ldp	x0, x8, [x22, #0xa8]
10012f9c4:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012f9c8:     	add	x9, x9, #0x8e0
10012f9cc:     	strb	wzr, [x9, #0xb0]
10012f9d0:     	tbnz	wzr, #0x0, 0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
10012f9d4:     	str	q5, [sp, #0x1a0]
10012f9d8:     	str	x3, [sp, #0x1d0]
10012f9dc:     	str	w2, [sp, #0x1e0]
10012f9e0:     	str	x1, [sp, #0x1f0]
10012f9e4:     	str	w17, [sp, #0x210]
10012f9e8:     	mov	x19, x28
10012f9ec:     	mov	x28, x20
10012f9f0:     	mov	x20, x26
10012f9f4:     	ldr	x8, [x8]
10012f9f8:     	mov	w1, #0xa0               ; =160
10012f9fc:     	mov	w2, #0x2                ; =2
10012fa00:     	ldr	x3, [sp, #0x188]
10012fa04:     	blr	x8
10012fa08:     	cbz	x0, 0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
10012fa0c:     	mov	x26, x0
10012fa10:     	ldr	x22, [sp, #0x270]
10012fa14:     	ldp	x1, x8, [x22, #0xb8]
10012fa18:     	add	x8, x8, x8, lsl #2
10012fa1c:     	lsl	x2, x8, #4
10012fa20:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
10012fa24:     	ldr	x8, [x22, #0xc0]
10012fa28:     	str	x26, [x22, #0xb8]
10012fa2c:     	mov	w9, #0x2                ; =2
10012fa30:     	str	x9, [x22, #0xc8]
10012fa34:     	mov	x26, x20
10012fa38:     	mov	x20, x28
10012fa3c:     	mov	x28, x19
10012fa40:     	ldr	w17, [sp, #0x210]
10012fa44:     	ldr	x1, [sp, #0x1f0]
10012fa48:     	ldr	w2, [sp, #0x1e0]
10012fa4c:     	ldr	x3, [sp, #0x1d0]
10012fa50:     	ldr	q5, [sp, #0x1a0]
10012fa54:     	add	x9, x8, #0x1
10012fa58:     	str	x9, [x22, #0xc0]
10012fa5c:     	ldr	x9, [x22, #0xb8]
10012fa60:     	mov	w10, #0x50              ; =80
10012fa64:     	madd	x8, x8, x10, x9
10012fa68:     	b	0x10012fad4 <_render.TerminalRenderer.drawPane+0x16d4>
10012fa6c:     	mov	w9, #0xa                ; =10
10012fa70:     	mov	w11, #-0x8              ; =-8
10012fa74:     	madd	w9, w10, w9, w11
10012fa78:     	and	w9, w9, #0xfe
10012fa7c:     	ucvtf	s0, w9
10012fa80:     	mov	w9, #0x437f0000         ; =1132396544
10012fa84:     	fmov	s1, w9
10012fa88:     	fdiv	s5, s0, s1
10012fa8c:     	dup.2s	v0, v5[0]
10012fa90:     	stur	s5, [x29, #-0xb0]
10012fa94:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012fa98:     	add	x9, x9, #0x8e0
10012fa9c:     	stur	d0, [x9, #0xb4]
10012faa0:     	sub	x9, x29, #0xb0
10012faa4:     	mov	w10, #0x3f800000        ; =1065353216
10012faa8:     	str	w10, [x9, #0xc]
10012faac:     	ldp	s10, s9, [x9, #0x4]
10012fab0:     	ldr	s8, [x9, #0xc]
10012fab4:     	ucvtf	s13, w8
10012fab8:     	ldrb	w8, [x22, #0xd8]
10012fabc:     	cbz	w8, 0x10012f8d8 <_render.TerminalRenderer.drawPane+0x14d8>
10012fac0:     	ldr	x8, [x22, #0xd0]
10012fac4:     	cbz	x8, 0x10012fb00 <_render.TerminalRenderer.drawPane+0x1700>
10012fac8:     	mov	w8, #0x1                ; =1
10012facc:     	str	x8, [x22, #0xc0]
10012fad0:     	ldr	x8, [x22, #0xb8]
10012fad4:     	stp	s15, s11, [x8]
10012fad8:     	stp	s13, s12, [x8, #0x8]
10012fadc:     	movi.4s	v0, #0x3a, lsl #24
10012fae0:     	str	q0, [x8, #0x10]
10012fae4:     	stp	s5, s10, [x8, #0x20]
10012fae8:     	stp	s9, s8, [x8, #0x28]
10012faec:     	movi.2d	v0, #0000000000000000
10012faf0:     	stp	q0, q0, [x8, #0x30]
10012faf4:     	tst	w27, #0xff
10012faf8:     	b.ne	0x10012fb14 <_render.TerminalRenderer.drawPane+0x1714>
10012fafc:     	b	0x100130200 <_render.TerminalRenderer.drawPane+0x1e00>
10012fb00:     	ldr	x8, [x22, #0xe0]
10012fb04:     	add	x8, x8, #0x1
10012fb08:     	str	x8, [x22, #0xe0]
10012fb0c:     	tst	w27, #0xff
10012fb10:     	b.eq	0x100130200 <_render.TerminalRenderer.drawPane+0x1e00>
10012fb14:     	tbnz	w17, #0x5, 0x100130200 <_render.TerminalRenderer.drawPane+0x1e00>
10012fb18:     	tbnz	w17, #0x4, 0x10012fb40 <_render.TerminalRenderer.drawPane+0x1740>
10012fb1c:     	mov	w8, #0x6b78             ; =27512
10012fb20:     	movk	w8, #0x1, lsl #16
10012fb24:     	add	x11, x8, #0x10
10012fb28:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10012fb2c:     	add	x8, x8, #0x8c0
10012fb30:     	mov	w9, #0x3                ; =3
10012fb34:     	mov	w10, #0x4               ; =4
10012fb38:     	mov	w12, #0x5               ; =5
10012fb3c:     	b	0x10012fb60 <_render.TerminalRenderer.drawPane+0x1760>
10012fb40:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10012fb44:     	add	x8, x8, #0x8b0
10012fb48:     	mov	x2, x3
10012fb4c:     	mov	w9, #0x7                ; =7
10012fb50:     	mov	w10, #0x8               ; =8
10012fb54:     	mov	w12, #0x9               ; =9
10012fb58:     	mov	w11, #0x6b78            ; =27512
10012fb5c:     	movk	w11, #0x1, lsl #16
10012fb60:     	ldr	q3, [sp, #0x230]
10012fb64:     	str	q3, [sp, #0x2b0]
10012fb68:     	add	x13, sp, #0x2b0
10012fb6c:     	orr	x9, x13, x9
10012fb70:     	ldrb	w9, [x9]
10012fb74:     	ldr	x13, [sp, #0x278]
10012fb78:     	ldr	q0, [x13, x11]
10012fb7c:     	str	q0, [x8]
10012fb80:     	and	w11, w2, #0xff
10012fb84:     	cmp	w11, #0x2
10012fb88:     	b.eq	0x10012fbdc <_render.TerminalRenderer.drawPane+0x17dc>
10012fb8c:     	cmp	w11, #0x1
10012fb90:     	b.ne	0x10012fc28 <_render.TerminalRenderer.drawPane+0x1828>
10012fb94:     	and	w8, w9, #0xff
10012fb98:     	cmp	w8, #0x10
10012fb9c:     	b.hs	0x10012fc30 <_render.TerminalRenderer.drawPane+0x1830>
10012fba0:     	and	x8, x9, #0xff
10012fba4:     	add	x8, x8, w9, uxtb #1
10012fba8:     	ldr	x9, [sp, #0x1c0]
10012fbac:     	add	x8, x9, x8
10012fbb0:     	ldr	b0, [x8]
10012fbb4:     	ucvtf	s0, s0
10012fbb8:     	mov	w9, #0x437f0000         ; =1132396544
10012fbbc:     	fmov	s1, w9
10012fbc0:     	fdiv	s4, s0, s1
10012fbc4:     	ldr	b0, [x8, #0x1]
10012fbc8:     	ucvtf	s0, s0
10012fbcc:     	fdiv	s0, s0, s1
10012fbd0:     	stp	s4, s0, [x29, #-0xb0]
10012fbd4:     	ldr	b0, [x8, #0x2]
10012fbd8:     	b	0x10012fc18 <_render.TerminalRenderer.drawPane+0x1818>
10012fbdc:     	add	x11, sp, #0x2a0
10012fbe0:     	orr	x8, x11, x12
10012fbe4:     	str	q3, [sp, #0x2a0]
10012fbe8:     	orr	x10, x11, x10
10012fbec:     	and	w9, w9, #0xff
10012fbf0:     	ucvtf	s0, w9
10012fbf4:     	mov	w9, #0x437f0000         ; =1132396544
10012fbf8:     	fmov	s1, w9
10012fbfc:     	fdiv	s4, s0, s1
10012fc00:     	stur	s4, [x29, #-0xb0]
10012fc04:     	ldr	b0, [x10]
10012fc08:     	ucvtf	s0, s0
10012fc0c:     	fdiv	s0, s0, s1
10012fc10:     	stur	s0, [x29, #-0xac]
10012fc14:     	ldr	b0, [x8]
10012fc18:     	ucvtf	s0, s0
10012fc1c:     	fdiv	s0, s0, s1
10012fc20:     	stur	s0, [x29, #-0xa8]
10012fc24:     	b	0x10012fd40 <_render.TerminalRenderer.drawPane+0x1940>
10012fc28:     	ldr	s4, [x8]
10012fc2c:     	b	0x10012fd4c <_render.TerminalRenderer.drawPane+0x194c>
10012fc30:     	cmp	w8, #0xe7
10012fc34:     	b.hi	0x10012fd0c <_render.TerminalRenderer.drawPane+0x190c>
10012fc38:     	sub	w8, w9, #0x10
10012fc3c:     	and	w9, w8, #0xff
10012fc40:     	mov	w10, #0x39              ; =57
10012fc44:     	mul	w10, w9, w10
10012fc48:     	lsr	w10, w10, #11
10012fc4c:     	mov	w11, #0x28              ; =40
10012fc50:     	mov	w12, #0x37              ; =55
10012fc54:     	madd	w10, w10, w11, w12
10012fc58:     	cmp	w9, #0x24
10012fc5c:     	csel	w10, wzr, w10, lo
10012fc60:     	and	w10, w10, #0xff
10012fc64:     	mov	w11, #0xab              ; =171
10012fc68:     	mul	w9, w9, w11
10012fc6c:     	lsr	w9, w9, #10
10012fc70:     	ucvtf	s0, w10
10012fc74:     	mov	w10, #0x437f0000        ; =1132396544
10012fc78:     	fmov	s1, w10
10012fc7c:     	fmov	s2, w9
10012fc80:     	mov.s	v2[1], w8
10012fc84:     	fdiv	s4, s0, s1
10012fc88:     	movi	d0, #0x0000ff000000ff
10012fc8c:     	and.8b	v0, v2, v0
10012fc90:     	ldr	d1, [sp, #0x118]
10012fc94:     	umull.2d	v1, v0, v1
10012fc98:     	shrn.2s	v1, v1, #0x20
10012fc9c:     	movi.2s	v2, #0x6
10012fca0:     	mls.2s	v0, v1, v2
10012fca4:     	movi.2s	v1, #0x37
10012fca8:     	movi.2s	v2, #0x28
10012fcac:     	mla.2s	v1, v0, v2
10012fcb0:     	cmeq.2s	v0, v0, #0
10012fcb4:     	bic.8b	v0, v1, v0
10012fcb8:     	bic.2s	v0, #0x3, lsl #8
10012fcbc:     	ucvtf.2s	v0, v0
10012fcc0:     	ldr	d1, [sp, #0x180]
10012fcc4:     	fdiv.2s	v0, v0, v1
10012fcc8:     	b	0x10012fd30 <_render.TerminalRenderer.drawPane+0x1930>
10012fccc:     	mov	x16, x15
10012fcd0:     	mov	x15, x11
10012fcd4:     	mov	x11, x14
10012fcd8:     	cmp	w12, w15
10012fcdc:     	b.lo	0x10012f67c <_render.TerminalRenderer.drawPane+0x127c>
10012fce0:     	and	w14, w8, #0xffff
10012fce4:     	cmp	w14, w16, uxth
10012fce8:     	ccmp	w12, w15, #0x0, lo
10012fcec:     	ccmp	w11, w12, #0x0, ne
10012fcf0:     	b.lo	0x10012f67c <_render.TerminalRenderer.drawPane+0x127c>
10012fcf4:     	cmp	w11, w12
10012fcf8:     	b.ne	0x10012f64c <_render.TerminalRenderer.drawPane+0x124c>
10012fcfc:     	and	w11, w8, #0xffff
10012fd00:     	cmp	w11, w13, uxth
10012fd04:     	b.hi	0x10012f67c <_render.TerminalRenderer.drawPane+0x127c>
10012fd08:     	b	0x10012f64c <_render.TerminalRenderer.drawPane+0x124c>
10012fd0c:     	mov	w8, #0xa                ; =10
10012fd10:     	mov	w10, #-0x8              ; =-8
10012fd14:     	madd	w8, w9, w8, w10
10012fd18:     	and	w8, w8, #0xfe
10012fd1c:     	ucvtf	s0, w8
10012fd20:     	mov	w8, #0x437f0000         ; =1132396544
10012fd24:     	fmov	s1, w8
10012fd28:     	fdiv	s4, s0, s1
10012fd2c:     	dup.2s	v0, v4[0]
10012fd30:     	stur	s4, [x29, #-0xb0]
10012fd34:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10012fd38:     	add	x8, x8, #0x8e0
10012fd3c:     	stur	d0, [x8, #0xb4]
10012fd40:     	sub	x8, x29, #0xb0
10012fd44:     	mov	w9, #0x3f800000         ; =1065353216
10012fd48:     	str	w9, [x8, #0xc]
10012fd4c:     	ldp	s9, s10, [x8, #0x4]
10012fd50:     	ldr	s0, [x8, #0xc]
10012fd54:     	fmov	s1, #0.50000000
10012fd58:     	fmul	s1, s0, s1
10012fd5c:     	tst	w17, #0x4
10012fd60:     	fcsel	s13, s0, s1, eq
10012fd64:     	and	x9, x1, #0xff
10012fd68:     	and	w10, w1, #0xff
10012fd6c:     	ldr	x11, [sp, #0x260]
10012fd70:     	ldr	s0, [x11]
10012fd74:     	ldrh	w8, [x11, #0x8]
10012fd78:     	ldr	h2, [x11, #0x4]
10012fd7c:     	ldr	h1, [x11, #0x6]
10012fd80:     	and	w11, w25, #0x1
10012fd84:     	add	x12, sp, #0x3, lsl #12  ; =0x3000
10012fd88:     	add	x12, x12, #0x700
10012fd8c:     	strb	w11, [x12, #0x1d6]
10012fd90:     	ubfx	w11, w17, #1, #1
10012fd94:     	strb	w11, [x12, #0x1d5]
10012fd98:     	strb	wzr, [x12, #0x1d0]
10012fd9c:     	cmp	w10, #0x1
10012fda0:     	str	q4, [sp, #0x210]
10012fda4:     	b.ne	0x10012fe6c <_render.TerminalRenderer.drawPane+0x1a6c>
10012fda8:     	and	w10, w21, #0xff
10012fdac:     	cmp	w10, #0x20
10012fdb0:     	b.ne	0x10012fe6c <_render.TerminalRenderer.drawPane+0x1a6c>
10012fdb4:     	sub	x10, x9, #0x1
10012fdb8:     	ldr	x11, [sp, #0xe8]
10012fdbc:     	ldrb	w11, [x11, x10]
10012fdc0:     	adrp	x12, 0x100687000 <___anon_33667+0x17f7>
10012fdc4:     	add	x12, x12, #0x88c
10012fdc8:     	ldrb	w10, [x12, x10]
10012fdcc:     	cmp	w11, w10
10012fdd0:     	b.ne	0x10012fe6c <_render.TerminalRenderer.drawPane+0x1a6c>
10012fdd4:     	tst	w17, #0x700
10012fdd8:     	b.eq	0x10012ff20 <_render.TerminalRenderer.drawPane+0x1b20>
10012fddc:     	str	s12, [sp, #0x1f0]
10012fde0:     	str	s14, [sp, #0x1e0]
10012fde4:     	fmov	d8, d13
10012fde8:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10012fdec:     	add	x8, x8, #0x8e0
10012fdf0:     	ldur	w8, [x8, #0xa]
10012fdf4:     	str	s10, [sp, #0x1d0]
10012fdf8:     	fmov	d14, d9
10012fdfc:     	fmov	d3, d4
10012fe00:     	ands	w9, w8, #0xff
10012fe04:     	b.eq	0x10013005c <_render.TerminalRenderer.drawPane+0x1c5c>
10012fe08:     	cmp	w9, #0x1
10012fe0c:     	b.ne	0x10012ff28 <_render.TerminalRenderer.drawPane+0x1b28>
10012fe10:     	ubfx	w9, w8, #8, #8
10012fe14:     	cmp	w9, #0x10
10012fe18:     	b.hs	0x10012ff70 <_render.TerminalRenderer.drawPane+0x1b70>
10012fe1c:     	ubfx	x8, x8, #8, #4
10012fe20:     	add	x8, x8, x8, lsl #1
10012fe24:     	ldr	x9, [sp, #0x1c0]
10012fe28:     	add	x8, x9, x8
10012fe2c:     	ldr	b0, [x8]
10012fe30:     	ucvtf	s0, s0
10012fe34:     	mov	w9, #0x437f0000         ; =1132396544
10012fe38:     	fmov	s1, w9
10012fe3c:     	fdiv	s3, s0, s1
10012fe40:     	ldr	b0, [x8, #0x1]
10012fe44:     	ucvtf	s0, s0
10012fe48:     	fdiv	s2, s0, s1
10012fe4c:     	ldr	b0, [x8, #0x2]
10012fe50:     	ucvtf	s0, s0
10012fe54:     	fdiv	s0, s0, s1
10012fe58:     	stp	s0, s2, [x29, #-0xb8]
10012fe5c:     	sub	x8, x29, #0xbc
10012fe60:     	sub	x10, x29, #0xb8
10012fe64:     	sub	x9, x29, #0xb4
10012fe68:     	b	0x100130048 <_render.TerminalRenderer.drawPane+0x1c48>
10012fe6c:     	fneg	s3, s0
10012fe70:     	ucvtf	s2, s2
10012fe74:     	ucvtf	s1, s1
10012fe78:     	ldr	x10, [sp, #0xe8]
10012fe7c:     	str	x10, [sp, #0x3900]
10012fe80:     	str	x9, [sp, #0x3908]
10012fe84:     	fadd	s0, s0, s11
10012fe88:     	str	s15, [sp, #0x3910]
10012fe8c:     	str	s0, [sp, #0x3914]
10012fe90:     	str	s4, [sp, #0x3918]
10012fe94:     	str	s9, [sp, #0x391c]
10012fe98:     	str	s10, [sp, #0x3920]
10012fe9c:     	str	s13, [sp, #0x3924]
10012fea0:     	str	wzr, [sp, #0x3928]
10012fea4:     	str	s3, [sp, #0x392c]
10012fea8:     	str	s2, [sp, #0x3930]
10012feac:     	str	s1, [sp, #0x3934]
10012feb0:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012feb4:     	add	x9, x9, #0x8e0
10012feb8:     	mov	w10, #0x1               ; =1
10012febc:     	strb	w10, [x9, #0x58]
10012fec0:     	strh	w8, [x9, #0x5c]
10012fec4:     	add	x21, sp, #0x3, lsl #12  ; =0x3000
10012fec8:     	add	x21, x21, #0x700
10012fecc:     	ldrb	w8, [x21, #0x1d6]
10012fed0:     	strb	w8, [x9, #0x5e]
10012fed4:     	ldrb	w8, [x21, #0x1d5]
10012fed8:     	strb	w8, [x9, #0x5f]
10012fedc:     	ldrb	w8, [x21, #0x1d0]
10012fee0:     	strb	w8, [x9, #0x60]
10012fee4:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
10012fee8:     	add	x0, x0, #0x8d8
10012feec:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
10012fef0:     	add	x2, x2, #0x900
10012fef4:     	add	x3, x22, #0xa8
10012fef8:     	ldr	x1, [sp, #0x278]
10012fefc:     	bl	0x100127d20 <_text.GlyphAtlas.place>
10012ff00:     	ldrh	w0, [x21, #0x1dc]
10012ff04:     	cbnz	w0, 0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
10012ff08:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10012ff0c:     	add	x8, x8, #0x700
10012ff10:     	ldrh	w17, [x8, #0x1e0]
10012ff14:     	ldr	q4, [sp, #0x210]
10012ff18:     	tst	w17, #0x700
10012ff1c:     	b.ne	0x10012fddc <_render.TerminalRenderer.drawPane+0x19dc>
10012ff20:     	tbnz	w17, #0x6, 0x10013014c <_render.TerminalRenderer.drawPane+0x1d4c>
10012ff24:     	b	0x100130200 <_render.TerminalRenderer.drawPane+0x1e00>
10012ff28:     	ubfx	w9, w8, #8, #8
10012ff2c:     	dup.2s	v0, w8
10012ff30:     	adrp	x8, 0x1001fe000 <__ZL19_hb_ucd_dm2_u64_map+0xb10>
10012ff34:     	ldr	d1, [x8, #0xd68]
10012ff38:     	ushl.2s	v0, v0, v1
10012ff3c:     	ucvtf	s1, w9
10012ff40:     	mov	w8, #0x437f0000         ; =1132396544
10012ff44:     	fmov	s2, w8
10012ff48:     	fdiv	s3, s1, s2
10012ff4c:     	bic.2s	v0, #0xff, lsl #8
10012ff50:     	ucvtf.2s	v0, v0
10012ff54:     	ldr	d1, [sp, #0x180]
10012ff58:     	fdiv.2s	v0, v0, v1
10012ff5c:     	stur	d0, [x29, #-0xc8]
10012ff60:     	sub	x8, x29, #0xb4
10012ff64:     	sub	x9, x29, #0xc8
10012ff68:     	ldr	x10, [sp, #0x20]
10012ff6c:     	b	0x100130048 <_render.TerminalRenderer.drawPane+0x1c48>
10012ff70:     	ubfx	w9, w8, #8, #8
10012ff74:     	lsr	w8, w8, #8
10012ff78:     	cmp	w9, #0xe7
10012ff7c:     	b.hi	0x100130014 <_render.TerminalRenderer.drawPane+0x1c14>
10012ff80:     	sub	w8, w8, #0x10
10012ff84:     	and	w9, w8, #0xff
10012ff88:     	mov	w10, #0x39              ; =57
10012ff8c:     	mul	w10, w9, w10
10012ff90:     	lsr	w10, w10, #11
10012ff94:     	mov	w11, #0x28              ; =40
10012ff98:     	mov	w12, #0x37              ; =55
10012ff9c:     	madd	w10, w10, w11, w12
10012ffa0:     	cmp	w9, #0x24
10012ffa4:     	csel	w10, wzr, w10, lo
10012ffa8:     	and	w10, w10, #0xff
10012ffac:     	mov	w11, #0xab              ; =171
10012ffb0:     	mul	w9, w9, w11
10012ffb4:     	lsr	w9, w9, #10
10012ffb8:     	ucvtf	s0, w10
10012ffbc:     	mov	w10, #0x437f0000        ; =1132396544
10012ffc0:     	fmov	s1, w10
10012ffc4:     	fmov	s2, w9
10012ffc8:     	mov.s	v2[1], w8
10012ffcc:     	fdiv	s3, s0, s1
10012ffd0:     	movi	d0, #0x0000ff000000ff
10012ffd4:     	and.8b	v0, v2, v0
10012ffd8:     	ldr	d1, [sp, #0x118]
10012ffdc:     	umull.2d	v1, v0, v1
10012ffe0:     	shrn.2s	v1, v1, #0x20
10012ffe4:     	movi.2s	v2, #0x6
10012ffe8:     	mls.2s	v0, v1, v2
10012ffec:     	movi.2s	v1, #0x37
10012fff0:     	movi.2s	v2, #0x28
10012fff4:     	mla.2s	v1, v0, v2
10012fff8:     	cmeq.2s	v0, v0, #0
10012fffc:     	bic.8b	v0, v1, v0
100130000:     	bic.2s	v0, #0x3, lsl #8
100130004:     	ucvtf.2s	v0, v0
100130008:     	ldr	d1, [sp, #0x180]
10013000c:     	fdiv.2s	v0, v0, v1
100130010:     	b	0x100130038 <_render.TerminalRenderer.drawPane+0x1c38>
100130014:     	mov	w9, #0xa                ; =10
100130018:     	mov	w10, #-0x8              ; =-8
10013001c:     	madd	w8, w8, w9, w10
100130020:     	and	w8, w8, #0xfe
100130024:     	ucvtf	s0, w8
100130028:     	mov	w8, #0x437f0000         ; =1132396544
10013002c:     	fmov	s1, w8
100130030:     	fdiv	s3, s0, s1
100130034:     	dup.2s	v0, v3[0]
100130038:     	stur	d0, [x29, #-0xb0]
10013003c:     	sub	x8, x29, #0xb4
100130040:     	sub	x9, x29, #0xb0
100130044:     	ldr	x10, [sp, #0x8]
100130048:     	mov	w11, #0x3f800000        ; =1065353216
10013004c:     	str	w11, [x8]
100130050:     	ldr	s14, [x9]
100130054:     	fmov	s8, #1.00000000
100130058:     	ldr	s10, [x10]
10013005c:     	fmov	d12, d13
100130060:     	fmov	d13, d9
100130064:     	ldr	s0, [sp, #0x1f0]
100130068:     	fadd	s0, s0, s11
10013006c:     	fmov	s1, #-2.00000000
100130070:     	fadd	s9, s0, s1
100130074:     	ldrb	w8, [x22, #0xd8]
100130078:     	cbz	w8, 0x10013009c <_render.TerminalRenderer.drawPane+0x1c9c>
10013007c:     	ldr	x9, [x22, #0xd0]
100130080:     	ldr	x8, [x22, #0xc0]
100130084:     	cmp	x8, x9
100130088:     	b.lo	0x1001300e8 <_render.TerminalRenderer.drawPane+0x1ce8>
10013008c:     	ldr	x8, [x22, #0xe0]
100130090:     	add	x8, x8, #0x1
100130094:     	str	x8, [x22, #0xe0]
100130098:     	b	0x100130128 <_render.TerminalRenderer.drawPane+0x1d28>
10013009c:     	ldur	q0, [x22, #0xa8]
1001300a0:     	stur	q0, [x29, #-0xb0]
1001300a4:     	ldp	x8, x9, [x22, #0xc0]
1001300a8:     	cmp	x9, x8
1001300ac:     	b.hi	0x1001300e8 <_render.TerminalRenderer.drawPane+0x1ce8>
1001300b0:     	str	q3, [sp, #0x1a0]
1001300b4:     	add	x8, x8, #0x1
1001300b8:     	lsr	x9, x8, #1
1001300bc:     	add	x9, x9, #0x1
1001300c0:     	adds	x8, x8, x9
1001300c4:     	csinv	x2, x8, xzr, lo
1001300c8:     	add	x0, x22, #0xb8
1001300cc:     	sub	x1, x29, #0xb0
1001300d0:     	bl	0x1001ae678 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
1001300d4:     	ands	w0, w0, #0xffff
1001300d8:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
1001300dc:     	ldr	x8, [x22, #0xc0]
1001300e0:     	ldr	q4, [sp, #0x210]
1001300e4:     	ldr	q3, [sp, #0x1a0]
1001300e8:     	add	x9, x8, #0x1
1001300ec:     	str	x9, [x22, #0xc0]
1001300f0:     	ldr	x9, [x22, #0xb8]
1001300f4:     	mov	w10, #0x50              ; =80
1001300f8:     	madd	x8, x8, x10, x9
1001300fc:     	stp	s15, s9, [x8]
100130100:     	ldr	s0, [sp, #0x1e0]
100130104:     	str	s0, [x8, #0x8]
100130108:     	ldr	q0, [sp, #0x130]
10013010c:     	stur	q0, [x8, #0xc]
100130110:     	mov	w9, #0x3a000000         ; =973078528
100130114:     	str	w9, [x8, #0x1c]
100130118:     	stp	s3, s14, [x8, #0x20]
10013011c:     	stp	s10, s8, [x8, #0x28]
100130120:     	movi.2d	v0, #0000000000000000
100130124:     	stp	q0, q0, [x8, #0x30]
100130128:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10013012c:     	add	x8, x8, #0x8e0
100130130:     	ldrh	w17, [x8]
100130134:     	ldr	s14, [sp, #0x1e0]
100130138:     	ldr	s10, [sp, #0x1d0]
10013013c:     	fmov	d9, d13
100130140:     	fmov	d13, d12
100130144:     	ldr	s12, [sp, #0x1f0]
100130148:     	tbz	w17, #0x6, 0x100130200 <_render.TerminalRenderer.drawPane+0x1e00>
10013014c:     	fmov	s0, #0.50000000
100130150:     	fmul	s0, s12, s0
100130154:     	fadd	s8, s0, s11
100130158:     	ldrb	w8, [x22, #0xd8]
10013015c:     	cbz	w8, 0x100130180 <_render.TerminalRenderer.drawPane+0x1d80>
100130160:     	ldr	x9, [x22, #0xd0]
100130164:     	ldr	x8, [x22, #0xc0]
100130168:     	cmp	x8, x9
10013016c:     	b.lo	0x1001301c4 <_render.TerminalRenderer.drawPane+0x1dc4>
100130170:     	ldr	x8, [x22, #0xe0]
100130174:     	add	x8, x8, #0x1
100130178:     	str	x8, [x22, #0xe0]
10013017c:     	b	0x100130200 <_render.TerminalRenderer.drawPane+0x1e00>
100130180:     	ldur	q0, [x22, #0xa8]
100130184:     	stur	q0, [x29, #-0xb0]
100130188:     	ldp	x8, x9, [x22, #0xc0]
10013018c:     	cmp	x9, x8
100130190:     	b.hi	0x1001301c4 <_render.TerminalRenderer.drawPane+0x1dc4>
100130194:     	add	x8, x8, #0x1
100130198:     	lsr	x9, x8, #1
10013019c:     	add	x9, x9, #0x1
1001301a0:     	adds	x8, x8, x9
1001301a4:     	csinv	x2, x8, xzr, lo
1001301a8:     	add	x0, x22, #0xb8
1001301ac:     	sub	x1, x29, #0xb0
1001301b0:     	bl	0x1001ae678 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
1001301b4:     	ands	w0, w0, #0xffff
1001301b8:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
1001301bc:     	ldr	x8, [x22, #0xc0]
1001301c0:     	ldr	q4, [sp, #0x210]
1001301c4:     	add	x9, x8, #0x1
1001301c8:     	str	x9, [x22, #0xc0]
1001301cc:     	ldr	x9, [x22, #0xb8]
1001301d0:     	mov	w10, #0x50              ; =80
1001301d4:     	madd	x8, x8, x10, x9
1001301d8:     	stp	s15, s8, [x8]
1001301dc:     	str	s14, [x8, #0x8]
1001301e0:     	ldr	q0, [sp, #0x130]
1001301e4:     	stur	q0, [x8, #0xc]
1001301e8:     	mov	w9, #0x3a000000         ; =973078528
1001301ec:     	str	w9, [x8, #0x1c]
1001301f0:     	stp	s4, s9, [x8, #0x20]
1001301f4:     	stp	s10, s13, [x8, #0x28]
1001301f8:     	movi.2d	v0, #0000000000000000
1001301fc:     	stp	q0, q0, [x8, #0x30]
100130200:     	ldp	x21, x19, [x22, #0xb8]
100130204:     	cmp	x19, #0x2
100130208:     	mov	w8, #0x2                ; =2
10013020c:     	csel	x24, x19, x8, lo
100130210:     	add	x8, x24, x24, lsl #2
100130214:     	lsl	x22, x8, #4
100130218:     	mov	x0, x26
10013021c:     	mov	x1, x21
100130220:     	mov	x2, x22
100130224:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100130228:     	sub	x8, x19, x24
10013022c:     	add	x8, x8, x8, lsl #2
100130230:     	lsl	x2, x8, #4
100130234:     	add	x1, x21, x22
100130238:     	mov	x0, x28
10013023c:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100130240:     	strb	w19, [x23, #0x3c]
100130244:     	str	xzr, [x23]
100130248:     	stp	s15, s11, [x23, #0x8]
10013024c:     	stp	s14, s12, [x23, #0x10]
100130250:     	ldp	q0, q1, [sp, #0x220]
100130254:     	stur	q1, [x23, #0x18]
100130258:     	stur	q0, [x23, #0x28]
10013025c:     	mov	w8, #0x1                ; =1
100130260:     	strb	w8, [x23, #0x38]
100130264:     	ldr	x21, [sp, #0x260]
100130268:     	ldr	s0, [x21, #0x1ac]
10013026c:     	ldr	s1, [x26, #0x20]
100130270:     	fcmp	s1, s0
100130274:     	b.ne	0x1001302a0 <_render.TerminalRenderer.drawPane+0x1ea0>
100130278:     	ldr	s0, [x21, #0x1b0]
10013027c:     	ldr	s1, [x26, #0x24]
100130280:     	fcmp	s1, s0
100130284:     	ldr	x28, [sp, #0x298]
100130288:     	b.ne	0x1001302a4 <_render.TerminalRenderer.drawPane+0x1ea4>
10013028c:     	ldr	s0, [x21, #0x1b4]
100130290:     	ldr	s1, [x26, #0x28]
100130294:     	fcmp	s1, s0
100130298:     	cset	w8, ne
10013029c:     	b	0x1001302a4 <_render.TerminalRenderer.drawPane+0x1ea4>
1001302a0:     	ldr	x28, [sp, #0x298]
1001302a4:     	strb	w8, [x23, #0x39]
1001302a8:     	ldr	x9, [sp, #0x270]
1001302ac:     	ldr	x8, [x9, #0x10]
1001302b0:     	add	x8, x8, #0x1
1001302b4:     	str	x8, [x9, #0x10]
1001302b8:     	add	x20, x20, #0x1
1001302bc:     	cmp	x28, x20
1001302c0:     	b.ne	0x10012f5d8 <_render.TerminalRenderer.drawPane+0x11d8>
1001302c4:     	b	0x100131248 <_render.TerminalRenderer.drawPane+0x2e48>
1001302c8:     	mov	w9, #0x1                ; =1
1001302cc:     	str	wzr, [sp, #0x220]
1001302d0:     	and	x8, x9, #0xffff
1001302d4:     	str	x8, [sp, #0x298]
1001302d8:     	tst	w9, #0xffff
1001302dc:     	b.eq	0x10013127c <_render.TerminalRenderer.drawPane+0x2e7c>
1001302e0:     	str	x9, [sp, #0x110]
1001302e4:     	mov	x25, #0x0               ; =0
1001302e8:     	ldp	x9, x8, [sp, #0xa8]
1001302ec:     	sub	x8, x8, x12
1001302f0:     	str	x8, [sp, #0x210]
1001302f4:     	sub	x8, x7, x12
1001302f8:     	str	x8, [sp, #0x1f0]
1001302fc:     	mov	w8, #0x6e0              ; =1760
100130300:     	umaddl	x26, w12, w8, x9
100130304:     	ldr	x8, [sp, #0xf0]
100130308:     	add	x24, x8, x12, lsl #5
10013030c:     	mov	w8, #0xa0               ; =160
100130310:     	ldr	x9, [sp, #0xa0]
100130314:     	umaddl	x27, w12, w8, x9
100130318:     	ldr	x8, [sp, #0x98]
10013031c:     	str	x12, [sp, #0x1c8]
100130320:     	add	x20, x8, x12, lsl #6
100130324:     	b	0x100130354 <_render.TerminalRenderer.drawPane+0x1f54>
100130328:     	ldr	x8, [x22, #0xa0]
10013032c:     	add	x8, x8, #0x1
100130330:     	str	x8, [x22, #0xa0]
100130334:     	add	x25, x25, #0x1
100130338:     	add	x24, x24, #0x20
10013033c:     	add	x26, x26, #0x6e0
100130340:     	add	x27, x27, #0xa0
100130344:     	add	x20, x20, #0x40
100130348:     	ldr	x8, [sp, #0x298]
10013034c:     	cmp	x8, x25
100130350:     	b.eq	0x1001311d4 <_render.TerminalRenderer.drawPane+0x2dd4>
100130354:     	ldr	w8, [sp, #0x220]
100130358:     	tbnz	w8, #0x0, 0x100130f6c <_render.TerminalRenderer.drawPane+0x2b6c>
10013035c:     	ldr	x8, [sp, #0x1c8]
100130360:     	add	x8, x8, x25
100130364:     	ldrb	w10, [x23, #0x40]
100130368:     	ldr	x9, [x23]
10013036c:     	mov	x13, x24
100130370:     	cbz	w10, 0x10013045c <_render.TerminalRenderer.drawPane+0x205c>
100130374:     	ldrb	w10, [x23, #0x38]
100130378:     	mov	x13, x24
10013037c:     	cbz	w10, 0x10013045c <_render.TerminalRenderer.drawPane+0x205c>
100130380:     	ldr	w13, [x23, #0x28]
100130384:     	ldr	x10, [x23, #0x30]
100130388:     	ldrb	w12, [x23, #0x3d]
10013038c:     	ldr	w11, [x9, #0xfc]
100130390:     	ldr	w14, [sp, #0x190]
100130394:     	add	w11, w11, w14
100130398:     	tbz	w12, #0x0, 0x1001303d4 <_render.TerminalRenderer.drawPane+0x1fd4>
10013039c:     	cmp	w10, w13
1001303a0:     	csel	w12, w10, w13, lo
1001303a4:     	csel	w10, w10, w13, hi
1001303a8:     	cmp	w11, w12
1001303ac:     	ccmp	w11, w10, #0x2, hs
1001303b0:     	mov	x13, x24
1001303b4:     	b.hi	0x10013045c <_render.TerminalRenderer.drawPane+0x205c>
1001303b8:     	ldp	q0, q1, [x24]
1001303bc:     	stp	q0, q1, [sp, #0x3b0]
1001303c0:     	ldrh	w10, [sp, #0x3b0]
1001303c4:     	eor	w10, w10, #0x10
1001303c8:     	strh	w10, [sp, #0x3b0]
1001303cc:     	add	x13, sp, #0x3b0
1001303d0:     	b	0x10013045c <_render.TerminalRenderer.drawPane+0x205c>
1001303d4:     	ldr	w12, [x23, #0x2c]
1001303d8:     	lsr	x15, x10, #32
1001303dc:     	cmp	w13, w10
1001303e0:     	b.lo	0x1001303f8 <_render.TerminalRenderer.drawPane+0x1ff8>
1001303e4:     	cmp	w13, w10
1001303e8:     	b.ne	0x100130414 <_render.TerminalRenderer.drawPane+0x2014>
1001303ec:     	and	w14, w12, #0xffff
1001303f0:     	cmp	w14, w15, uxth
1001303f4:     	b.hs	0x100130414 <_render.TerminalRenderer.drawPane+0x2014>
1001303f8:     	mov	x14, x12
1001303fc:     	mov	x12, x15
100130400:     	mov	x15, x13
100130404:     	mov	x13, x24
100130408:     	cmp	w11, w15
10013040c:     	b.hs	0x10013042c <_render.TerminalRenderer.drawPane+0x202c>
100130410:     	b	0x10013045c <_render.TerminalRenderer.drawPane+0x205c>
100130414:     	mov	x14, x15
100130418:     	mov	x15, x10
10013041c:     	mov	x10, x13
100130420:     	mov	x13, x24
100130424:     	cmp	w11, w15
100130428:     	b.lo	0x10013045c <_render.TerminalRenderer.drawPane+0x205c>
10013042c:     	and	w13, w8, #0xffff
100130430:     	cmp	w13, w14, uxth
100130434:     	ccmp	w11, w15, #0x0, lo
100130438:     	ccmp	w10, w11, #0x0, ne
10013043c:     	mov	x13, x24
100130440:     	b.lo	0x10013045c <_render.TerminalRenderer.drawPane+0x205c>
100130444:     	cmp	w10, w11
100130448:     	b.ne	0x1001303b8 <_render.TerminalRenderer.drawPane+0x1fb8>
10013044c:     	and	w10, w8, #0xffff
100130450:     	cmp	w10, w12, uxth
100130454:     	mov	x13, x24
100130458:     	b.ls	0x1001303b8 <_render.TerminalRenderer.drawPane+0x1fb8>
10013045c:     	ldp	q3, q4, [x13]
100130460:     	umov.b	w10, v4[15]
100130464:     	ldrh	w11, [x23, #0x18]
100130468:     	ldrh	w12, [x23, #0x1a]
10013046c:     	add	w11, w11, w8, uxth
100130470:     	add	w12, w12, w28, uxth
100130474:     	tst	w10, #0xfe
100130478:     	csinc	w10, w10, wzr, ne
10013047c:     	ldrh	w13, [x23, #0x1c]
100130480:     	ldrh	w9, [x9, #0x50]
100130484:     	cmp	w13, w9
100130488:     	csel	w9, w13, w9, lo
10013048c:     	sub	w8, w9, w8
100130490:     	and	w8, w8, #0xffff
100130494:     	cmp	w10, w8
100130498:     	csel	w9, w10, w8, lo
10013049c:     	ldrh	w8, [x21, #0x4]
1001304a0:     	ldrh	w10, [x21, #0x6]
1001304a4:     	ldr	x14, [sp, #0x240]
1001304a8:     	ldp	w14, w13, [x14]
1001304ac:     	madd	w11, w8, w11, w14
1001304b0:     	ucvtf	s15, w11
1001304b4:     	madd	w11, w10, w12, w13
1001304b8:     	ucvtf	s11, w11
1001304bc:     	mul	w9, w9, w8
1001304c0:     	ucvtf	s0, w9
1001304c4:     	str	s0, [sp, #0x230]
1001304c8:     	ucvtf	s9, w10
1001304cc:     	ldrb	w9, [x20, #0x38]
1001304d0:     	cmp	w9, #0x1
1001304d4:     	b.ne	0x100130534 <_render.TerminalRenderer.drawPane+0x2134>
1001304d8:     	ldr	s0, [x20, #0x8]
1001304dc:     	fcmp	s0, s15
1001304e0:     	b.ne	0x100130534 <_render.TerminalRenderer.drawPane+0x2134>
1001304e4:     	ldr	s0, [x20, #0xc]
1001304e8:     	fcmp	s0, s11
1001304ec:     	b.ne	0x100130534 <_render.TerminalRenderer.drawPane+0x2134>
1001304f0:     	ldr	s0, [x20, #0x10]
1001304f4:     	ldr	s1, [sp, #0x230]
1001304f8:     	fcmp	s0, s1
1001304fc:     	b.ne	0x100130534 <_render.TerminalRenderer.drawPane+0x2134>
100130500:     	ldr	s0, [x20, #0x14]
100130504:     	fcmp	s0, s9
100130508:     	b.ne	0x100130534 <_render.TerminalRenderer.drawPane+0x2134>
10013050c:     	ldur	q0, [x20, #0x18]
100130510:     	ldur	q1, [x20, #0x28]
100130514:     	eor.16b	v0, v0, v3
100130518:     	eor.16b	v1, v1, v4
10013051c:     	orr.16b	v0, v1, v0
100130520:     	umaxv.16b	b0, v0
100130524:     	fmov	w9, s0
100130528:     	cbnz	w9, 0x100130534 <_render.TerminalRenderer.drawPane+0x2134>
10013052c:     	ldr	x9, [x20]
100130530:     	cbz	x9, 0x100130f6c <_render.TerminalRenderer.drawPane+0x2b6c>
100130534:     	stp	q3, q4, [sp, #0x3d0]
100130538:     	fmov	x9, d3
10013053c:     	str	xzr, [x22, #0xc0]
100130540:     	tbnz	w9, #0x4, 0x1001305dc <_render.TerminalRenderer.drawPane+0x21dc>
100130544:     	ldr	x9, [sp, #0x208]
100130548:     	ldr	q0, [x9]
10013054c:     	str	q0, [sp, #0x400]
100130550:     	mov	b0, v3[8]
100130554:     	mov.b	v0[4], v3[9]
100130558:     	mov	b1, v3[6]
10013055c:     	mov.b	v1[4], v3[7]
100130560:     	add	x9, sp, #0x400
100130564:     	fmov	w10, s1
100130568:     	and	w10, w10, #0xff
10013056c:     	cmp	w10, #0x2
100130570:     	stp	q4, q3, [sp, #0x1d0]
100130574:     	b.eq	0x100130618 <_render.TerminalRenderer.drawPane+0x2218>
100130578:     	cmp	w10, #0x1
10013057c:     	b.ne	0x10013064c <_render.TerminalRenderer.drawPane+0x224c>
100130580:     	mov.s	w9, v1[1]
100130584:     	and	w10, w9, #0xff
100130588:     	cmp	w10, #0x10
10013058c:     	b.hs	0x10013067c <_render.TerminalRenderer.drawPane+0x227c>
100130590:     	and	x10, x9, #0xff
100130594:     	add	x9, x10, w9, uxtb #1
100130598:     	ldr	x10, [sp, #0x1c0]
10013059c:     	add	x9, x10, x9
1001305a0:     	ldr	b0, [x9]
1001305a4:     	ucvtf	s0, s0
1001305a8:     	mov	w10, #0x437f0000        ; =1132396544
1001305ac:     	fmov	s1, w10
1001305b0:     	fdiv	s5, s0, s1
1001305b4:     	ldr	b0, [x9, #0x1]
1001305b8:     	ucvtf	s0, s0
1001305bc:     	fdiv	s0, s0, s1
1001305c0:     	str	s5, [sp, #0x22e0]
1001305c4:     	str	s0, [sp, #0x22e4]
1001305c8:     	ldr	b0, [x9, #0x2]
1001305cc:     	ucvtf	s0, s0
1001305d0:     	fdiv	s0, s0, s1
1001305d4:     	str	s0, [sp, #0x22e8]
1001305d8:     	b	0x1001307ec <_render.TerminalRenderer.drawPane+0x23ec>
1001305dc:     	mov	w9, #0x6b88             ; =27528
1001305e0:     	movk	w9, #0x1, lsl #16
1001305e4:     	ldr	x10, [sp, #0x278]
1001305e8:     	ldr	q0, [x10, x9]
1001305ec:     	str	q0, [sp, #0x3f0]
1001305f0:     	mov	b0, v3[4]
1001305f4:     	mov.b	v0[4], v3[5]
1001305f8:     	mov	b1, v3[2]
1001305fc:     	mov.b	v1[4], v3[3]
100130600:     	add	x9, sp, #0x3f0
100130604:     	fmov	w10, s1
100130608:     	and	w10, w10, #0xff
10013060c:     	cmp	w10, #0x2
100130610:     	stp	q4, q3, [sp, #0x1d0]
100130614:     	b.ne	0x100130578 <_render.TerminalRenderer.drawPane+0x2178>
100130618:     	mov.s	w9, v1[1]
10013061c:     	and	w9, w9, #0xff
100130620:     	ucvtf	s1, w9
100130624:     	mov	w9, #0x437f0000         ; =1132396544
100130628:     	fmov	s2, w9
10013062c:     	fdiv	s5, s1, s2
100130630:     	str	s5, [sp, #0x22e0]
100130634:     	movi	d1, #0x0000ff000000ff
100130638:     	and.8b	v0, v0, v1
10013063c:     	ucvtf.2s	v0, v0
100130640:     	ldr	d1, [sp, #0x180]
100130644:     	fdiv.2s	v0, v0, v1
100130648:     	b	0x1001307e0 <_render.TerminalRenderer.drawPane+0x23e0>
10013064c:     	ldr	s5, [x9]
100130650:     	ldp	s13, s10, [x9, #0x4]
100130654:     	ldr	s8, [x9, #0xc]
100130658:     	ucvtf	s12, w8
10013065c:     	ldrb	w8, [x22, #0xd8]
100130660:     	cbnz	w8, 0x100130810 <_render.TerminalRenderer.drawPane+0x2410>
100130664:     	ldr	x8, [x22, #0xc8]
100130668:     	cbz	x8, 0x100130718 <_render.TerminalRenderer.drawPane+0x2318>
10013066c:     	mov	x8, #0x0                ; =0
100130670:     	mov	x21, x22
100130674:     	ldur	x22, [x22, #0xb8]
100130678:     	b	0x100130774 <_render.TerminalRenderer.drawPane+0x2374>
10013067c:     	cmp	w10, #0xe7
100130680:     	b.hi	0x1001307b8 <_render.TerminalRenderer.drawPane+0x23b8>
100130684:     	sub	w9, w9, #0x10
100130688:     	and	w10, w9, #0xff
10013068c:     	mov	w11, #0x39              ; =57
100130690:     	mul	w11, w10, w11
100130694:     	lsr	w11, w11, #11
100130698:     	mov	w12, #0x28              ; =40
10013069c:     	mov	w13, #0x37              ; =55
1001306a0:     	madd	w11, w11, w12, w13
1001306a4:     	cmp	w10, #0x24
1001306a8:     	csel	w11, wzr, w11, lo
1001306ac:     	and	w11, w11, #0xff
1001306b0:     	mov	w12, #0xab              ; =171
1001306b4:     	mul	w10, w10, w12
1001306b8:     	lsr	w10, w10, #10
1001306bc:     	ucvtf	s0, w11
1001306c0:     	mov	w11, #0x437f0000        ; =1132396544
1001306c4:     	fmov	s1, w11
1001306c8:     	fmov	s2, w10
1001306cc:     	mov.s	v2[1], w9
1001306d0:     	fdiv	s5, s0, s1
1001306d4:     	movi	d0, #0x0000ff000000ff
1001306d8:     	and.8b	v0, v2, v0
1001306dc:     	ldr	d1, [sp, #0x118]
1001306e0:     	umull.2d	v1, v0, v1
1001306e4:     	shrn.2s	v1, v1, #0x20
1001306e8:     	movi.2s	v2, #0x6
1001306ec:     	mls.2s	v0, v1, v2
1001306f0:     	movi.2s	v1, #0x37
1001306f4:     	movi.2s	v2, #0x28
1001306f8:     	mla.2s	v1, v0, v2
1001306fc:     	cmeq.2s	v0, v0, #0
100130700:     	bic.8b	v0, v1, v0
100130704:     	bic.2s	v0, #0x3, lsl #8
100130708:     	ucvtf.2s	v0, v0
10013070c:     	ldr	d1, [sp, #0x180]
100130710:     	fdiv.2s	v0, v0, v1
100130714:     	b	0x1001307dc <_render.TerminalRenderer.drawPane+0x23dc>
100130718:     	ldp	x0, x8, [x22, #0xa8]
10013071c:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
100130720:     	add	x9, x9, #0x2e0
100130724:     	strb	wzr, [x9]
100130728:     	tbnz	wzr, #0x0, 0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
10013072c:     	str	q5, [sp, #0x1a0]
100130730:     	ldr	x8, [x8]
100130734:     	mov	w1, #0xa0               ; =160
100130738:     	mov	w2, #0x2                ; =2
10013073c:     	ldr	x3, [sp, #0x188]
100130740:     	blr	x8
100130744:     	cbz	x0, 0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
100130748:     	mov	x22, x0
10013074c:     	ldr	x21, [sp, #0x270]
100130750:     	ldp	x1, x8, [x21, #0xb8]
100130754:     	add	x8, x8, x8, lsl #2
100130758:     	lsl	x2, x8, #4
10013075c:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100130760:     	ldr	x8, [x21, #0xc0]
100130764:     	str	x22, [x21, #0xb8]
100130768:     	mov	w9, #0x2                ; =2
10013076c:     	str	x9, [x21, #0xc8]
100130770:     	ldr	q5, [sp, #0x1a0]
100130774:     	add	x9, x8, #0x1
100130778:     	str	x9, [x21, #0xc0]
10013077c:     	mov	w9, #0x50               ; =80
100130780:     	madd	x8, x8, x9, x22
100130784:     	stp	s15, s11, [x8]
100130788:     	stp	s12, s9, [x8, #0x8]
10013078c:     	movi.4s	v0, #0x3a, lsl #24
100130790:     	str	q0, [x8, #0x10]
100130794:     	stp	s5, s13, [x8, #0x20]
100130798:     	stp	s10, s8, [x8, #0x28]
10013079c:     	movi.2d	v0, #0000000000000000
1001307a0:     	stp	q0, q0, [x8, #0x30]
1001307a4:     	mov	x22, x21
1001307a8:     	ldr	x21, [sp, #0x260]
1001307ac:     	ldrb	w8, [sp, #0x3ef]
1001307b0:     	cbnz	w8, 0x100130864 <_render.TerminalRenderer.drawPane+0x2464>
1001307b4:     	b	0x100130eb0 <_render.TerminalRenderer.drawPane+0x2ab0>
1001307b8:     	mov	w10, #0xa               ; =10
1001307bc:     	mov	w11, #-0x8              ; =-8
1001307c0:     	madd	w9, w9, w10, w11
1001307c4:     	and	w9, w9, #0xfe
1001307c8:     	ucvtf	s0, w9
1001307cc:     	mov	w9, #0x437f0000         ; =1132396544
1001307d0:     	fmov	s1, w9
1001307d4:     	fdiv	s5, s0, s1
1001307d8:     	dup.2s	v0, v5[0]
1001307dc:     	str	s5, [sp, #0x22e0]
1001307e0:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
1001307e4:     	add	x9, x9, #0x2e0
1001307e8:     	stur	d0, [x9, #0x4]
1001307ec:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
1001307f0:     	add	x9, x9, #0x2e0
1001307f4:     	mov	w10, #0x3f800000        ; =1065353216
1001307f8:     	str	w10, [x9, #0xc]
1001307fc:     	ldp	s13, s10, [x9, #0x4]
100130800:     	ldr	s8, [x9, #0xc]
100130804:     	ucvtf	s12, w8
100130808:     	ldrb	w8, [x22, #0xd8]
10013080c:     	cbz	w8, 0x100130664 <_render.TerminalRenderer.drawPane+0x2264>
100130810:     	ldr	x8, [x22, #0xd0]
100130814:     	cbz	x8, 0x100130850 <_render.TerminalRenderer.drawPane+0x2450>
100130818:     	mov	w8, #0x1                ; =1
10013081c:     	str	x8, [x22, #0xc0]
100130820:     	ldr	x8, [x22, #0xb8]
100130824:     	stp	s15, s11, [x8]
100130828:     	stp	s12, s9, [x8, #0x8]
10013082c:     	movi.4s	v0, #0x3a, lsl #24
100130830:     	str	q0, [x8, #0x10]
100130834:     	stp	s5, s13, [x8, #0x20]
100130838:     	stp	s10, s8, [x8, #0x28]
10013083c:     	movi.2d	v0, #0000000000000000
100130840:     	stp	q0, q0, [x8, #0x30]
100130844:     	ldrb	w8, [sp, #0x3ef]
100130848:     	cbnz	w8, 0x100130864 <_render.TerminalRenderer.drawPane+0x2464>
10013084c:     	b	0x100130eb0 <_render.TerminalRenderer.drawPane+0x2ab0>
100130850:     	ldr	x8, [x22, #0xe0]
100130854:     	add	x8, x8, #0x1
100130858:     	str	x8, [x22, #0xe0]
10013085c:     	ldrb	w8, [sp, #0x3ef]
100130860:     	cbz	w8, 0x100130eb0 <_render.TerminalRenderer.drawPane+0x2ab0>
100130864:     	ldrh	w8, [sp, #0x3d0]
100130868:     	tbnz	w8, #0x5, 0x100130eb0 <_render.TerminalRenderer.drawPane+0x2ab0>
10013086c:     	tbnz	w8, #0x4, 0x1001308f4 <_render.TerminalRenderer.drawPane+0x24f4>
100130870:     	ldrb	w11, [sp, #0x3d2]
100130874:     	ldrb	w10, [sp, #0x3d3]
100130878:     	ldrb	w12, [sp, #0x3d4]
10013087c:     	ldrb	w13, [sp, #0x3d5]
100130880:     	mov	w9, #0x6b88             ; =27528
100130884:     	movk	w9, #0x1, lsl #16
100130888:     	ldr	x14, [sp, #0x278]
10013088c:     	ldr	q0, [x14, x9]
100130890:     	str	q0, [sp, #0x420]
100130894:     	add	x9, sp, #0x420
100130898:     	cmp	w11, #0x2
10013089c:     	b.eq	0x10013091c <_render.TerminalRenderer.drawPane+0x251c>
1001308a0:     	cmp	w11, #0x1
1001308a4:     	b.ne	0x10013094c <_render.TerminalRenderer.drawPane+0x254c>
1001308a8:     	subs	w9, w10, #0x10
1001308ac:     	b.hs	0x100130954 <_render.TerminalRenderer.drawPane+0x2554>
1001308b0:     	mov	w9, w10
1001308b4:     	add	x9, x9, w10, uxtw #1
1001308b8:     	ldr	x10, [sp, #0x1c0]
1001308bc:     	add	x9, x10, x9
1001308c0:     	ldr	b0, [x9]
1001308c4:     	ucvtf	s0, s0
1001308c8:     	mov	w10, #0x437f0000        ; =1132396544
1001308cc:     	fmov	s1, w10
1001308d0:     	fdiv	s4, s0, s1
1001308d4:     	ldr	b0, [x9, #0x1]
1001308d8:     	ucvtf	s0, s0
1001308dc:     	fdiv	s0, s0, s1
1001308e0:     	str	s4, [sp, #0x22e0]
1001308e4:     	str	s0, [sp, #0x22e4]
1001308e8:     	ldr	b0, [x9, #0x2]
1001308ec:     	ucvtf	s0, s0
1001308f0:     	b	0x100130940 <_render.TerminalRenderer.drawPane+0x2540>
1001308f4:     	ldrb	w11, [sp, #0x3d6]
1001308f8:     	ldrb	w10, [sp, #0x3d7]
1001308fc:     	ldrb	w12, [sp, #0x3d8]
100130900:     	ldrb	w13, [sp, #0x3d9]
100130904:     	ldr	x9, [sp, #0x208]
100130908:     	ldr	q0, [x9]
10013090c:     	str	q0, [sp, #0x410]
100130910:     	add	x9, sp, #0x410
100130914:     	cmp	w11, #0x2
100130918:     	b.ne	0x1001308a0 <_render.TerminalRenderer.drawPane+0x24a0>
10013091c:     	ucvtf	s0, w10
100130920:     	mov	w9, #0x437f0000         ; =1132396544
100130924:     	fmov	s1, w9
100130928:     	fdiv	s4, s0, s1
10013092c:     	ucvtf	s0, w12
100130930:     	fdiv	s0, s0, s1
100130934:     	str	s4, [sp, #0x22e0]
100130938:     	str	s0, [sp, #0x22e4]
10013093c:     	ucvtf	s0, w13
100130940:     	fdiv	s0, s0, s1
100130944:     	str	s0, [sp, #0x22e8]
100130948:     	b	0x100130a20 <_render.TerminalRenderer.drawPane+0x2620>
10013094c:     	ldr	s4, [x9]
100130950:     	b	0x100130a30 <_render.TerminalRenderer.drawPane+0x2630>
100130954:     	cmp	w10, #0xe7
100130958:     	b.hi	0x1001309ec <_render.TerminalRenderer.drawPane+0x25ec>
10013095c:     	and	w10, w9, #0xff
100130960:     	mov	w11, #0x39              ; =57
100130964:     	mul	w11, w10, w11
100130968:     	lsr	w11, w11, #11
10013096c:     	mov	w12, #0x28              ; =40
100130970:     	mov	w13, #0x37              ; =55
100130974:     	madd	w11, w11, w12, w13
100130978:     	cmp	w9, #0x24
10013097c:     	csel	w11, wzr, w11, lo
100130980:     	and	w11, w11, #0xff
100130984:     	mov	w12, #0xab              ; =171
100130988:     	mul	w10, w10, w12
10013098c:     	lsr	w10, w10, #10
100130990:     	ucvtf	s0, w11
100130994:     	mov	w11, #0x437f0000        ; =1132396544
100130998:     	fmov	s1, w11
10013099c:     	fmov	s2, w10
1001309a0:     	mov.s	v2[1], w9
1001309a4:     	fdiv	s4, s0, s1
1001309a8:     	movi	d0, #0x0000ff000000ff
1001309ac:     	and.8b	v0, v2, v0
1001309b0:     	ldr	d1, [sp, #0x118]
1001309b4:     	umull.2d	v1, v0, v1
1001309b8:     	shrn.2s	v1, v1, #0x20
1001309bc:     	movi.2s	v2, #0x6
1001309c0:     	mls.2s	v0, v1, v2
1001309c4:     	movi.2s	v1, #0x37
1001309c8:     	movi.2s	v2, #0x28
1001309cc:     	mla.2s	v1, v0, v2
1001309d0:     	cmeq.2s	v0, v0, #0
1001309d4:     	bic.8b	v0, v1, v0
1001309d8:     	bic.2s	v0, #0x3, lsl #8
1001309dc:     	ucvtf.2s	v0, v0
1001309e0:     	ldr	d1, [sp, #0x180]
1001309e4:     	fdiv.2s	v0, v0, v1
1001309e8:     	b	0x100130a10 <_render.TerminalRenderer.drawPane+0x2610>
1001309ec:     	mov	w9, #0xa                ; =10
1001309f0:     	mov	w11, #-0x8              ; =-8
1001309f4:     	madd	w9, w10, w9, w11
1001309f8:     	and	w9, w9, #0xfe
1001309fc:     	ucvtf	s0, w9
100130a00:     	mov	w9, #0x437f0000         ; =1132396544
100130a04:     	fmov	s1, w9
100130a08:     	fdiv	s4, s0, s1
100130a0c:     	dup.2s	v0, v4[0]
100130a10:     	str	s4, [sp, #0x22e0]
100130a14:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
100130a18:     	add	x9, x9, #0x2e0
100130a1c:     	stur	d0, [x9, #0x4]
100130a20:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
100130a24:     	add	x9, x9, #0x2e0
100130a28:     	mov	w10, #0x3f800000        ; =1065353216
100130a2c:     	str	w10, [x9, #0xc]
100130a30:     	ldp	s14, s10, [x9, #0x4]
100130a34:     	ldr	s0, [x9, #0xc]
100130a38:     	fmov	s1, #0.50000000
100130a3c:     	fmul	s1, s0, s1
100130a40:     	tst	w8, #0x4
100130a44:     	fcsel	s13, s0, s1, eq
100130a48:     	ldrb	w10, [sp, #0x3ee]
100130a4c:     	ldr	s0, [x21]
100130a50:     	ldrh	w9, [x21, #0x8]
100130a54:     	ldr	h2, [x21, #0x4]
100130a58:     	ldr	h1, [x21, #0x6]
100130a5c:     	and	w11, w8, #0x1
100130a60:     	strb	w11, [sp, #0x43e]
100130a64:     	ubfx	w11, w8, #1, #1
100130a68:     	strb	w11, [sp, #0x43d]
100130a6c:     	strb	wzr, [sp, #0x438]
100130a70:     	subs	x11, x10, #0x1
100130a74:     	str	q4, [sp, #0x1a0]
100130a78:     	b.ne	0x100130b3c <_render.TerminalRenderer.drawPane+0x273c>
100130a7c:     	ldrb	w12, [sp, #0x3de]
100130a80:     	cmp	w12, #0x20
100130a84:     	b.ne	0x100130b3c <_render.TerminalRenderer.drawPane+0x273c>
100130a88:     	ldr	x12, [sp, #0x150]
100130a8c:     	ldrb	w12, [x12, x11]
100130a90:     	adrp	x13, 0x100687000 <___anon_33667+0x17f7>
100130a94:     	add	x13, x13, #0x88c
100130a98:     	ldrb	w11, [x13, x11]
100130a9c:     	cmp	w12, w11
100130aa0:     	b.ne	0x100130b3c <_render.TerminalRenderer.drawPane+0x273c>
100130aa4:     	tst	w8, #0x700
100130aa8:     	b.eq	0x100130bd0 <_render.TerminalRenderer.drawPane+0x27d0>
100130aac:     	str	s13, [sp, #0x160]
100130ab0:     	add	x8, sp, #0x30c
100130ab4:     	ldur	w8, [x8, #0xce]
100130ab8:     	str	s10, [sp, #0x168]
100130abc:     	fmov	d8, d10
100130ac0:     	fmov	d10, d14
100130ac4:     	fmov	d3, d4
100130ac8:     	ands	w9, w8, #0xff
100130acc:     	b.eq	0x100130d10 <_render.TerminalRenderer.drawPane+0x2910>
100130ad0:     	cmp	w9, #0x1
100130ad4:     	b.ne	0x100130bd8 <_render.TerminalRenderer.drawPane+0x27d8>
100130ad8:     	ubfx	w9, w8, #8, #8
100130adc:     	cmp	w9, #0x10
100130ae0:     	b.hs	0x100130c20 <_render.TerminalRenderer.drawPane+0x2820>
100130ae4:     	ubfx	x8, x8, #8, #4
100130ae8:     	add	x8, x8, x8, lsl #1
100130aec:     	ldr	x9, [sp, #0x1c0]
100130af0:     	add	x8, x9, x8
100130af4:     	ldr	b0, [x8]
100130af8:     	ucvtf	s0, s0
100130afc:     	mov	w9, #0x437f0000         ; =1132396544
100130b00:     	fmov	s1, w9
100130b04:     	fdiv	s3, s0, s1
100130b08:     	ldr	b0, [x8, #0x1]
100130b0c:     	ucvtf	s0, s0
100130b10:     	fdiv	s0, s0, s1
100130b14:     	str	s0, [sp, #0x4e0]
100130b18:     	ldr	b0, [x8, #0x2]
100130b1c:     	ucvtf	s0, s0
100130b20:     	fdiv	s0, s0, s1
100130b24:     	str	s0, [sp, #0xce0]
100130b28:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100130b2c:     	add	x8, x8, #0x900
100130b30:     	add	x10, sp, #0xce0
100130b34:     	add	x9, sp, #0x4e0
100130b38:     	b	0x100130cfc <_render.TerminalRenderer.drawPane+0x28fc>
100130b3c:     	fneg	s3, s0
100130b40:     	ucvtf	s2, s2
100130b44:     	ucvtf	s1, s1
100130b48:     	ldr	x8, [sp, #0x150]
100130b4c:     	str	x8, [sp, #0x440]
100130b50:     	str	x10, [sp, #0x448]
100130b54:     	fadd	s0, s0, s11
100130b58:     	str	s15, [sp, #0x450]
100130b5c:     	str	s0, [sp, #0x454]
100130b60:     	str	s4, [sp, #0x458]
100130b64:     	str	s14, [sp, #0x45c]
100130b68:     	str	s10, [sp, #0x460]
100130b6c:     	str	s13, [sp, #0x464]
100130b70:     	str	wzr, [sp, #0x468]
100130b74:     	str	s3, [sp, #0x46c]
100130b78:     	str	s2, [sp, #0x470]
100130b7c:     	str	s1, [sp, #0x474]
100130b80:     	mov	w8, #0x1                ; =1
100130b84:     	strb	w8, [sp, #0x478]
100130b88:     	strh	w9, [sp, #0x47c]
100130b8c:     	ldrb	w8, [sp, #0x43e]
100130b90:     	strb	w8, [sp, #0x47e]
100130b94:     	ldrb	w8, [sp, #0x43d]
100130b98:     	strb	w8, [sp, #0x47f]
100130b9c:     	ldrb	w8, [sp, #0x438]
100130ba0:     	strb	w8, [sp, #0x480]
100130ba4:     	add	x0, sp, #0x488
100130ba8:     	add	x2, sp, #0x440
100130bac:     	add	x3, x22, #0xa8
100130bb0:     	ldr	x1, [sp, #0x278]
100130bb4:     	bl	0x100127d20 <_text.GlyphAtlas.place>
100130bb8:     	ldrh	w0, [sp, #0x48c]
100130bbc:     	cbnz	w0, 0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100130bc0:     	ldrh	w8, [sp, #0x3d0]
100130bc4:     	ldr	q4, [sp, #0x1a0]
100130bc8:     	tst	w8, #0x700
100130bcc:     	b.ne	0x100130aac <_render.TerminalRenderer.drawPane+0x26ac>
100130bd0:     	tbnz	w8, #0x6, 0x100130df4 <_render.TerminalRenderer.drawPane+0x29f4>
100130bd4:     	b	0x100130eb0 <_render.TerminalRenderer.drawPane+0x2ab0>
100130bd8:     	ubfx	w9, w8, #8, #8
100130bdc:     	dup.2s	v0, w8
100130be0:     	adrp	x8, 0x1001fe000 <__ZL19_hb_ucd_dm2_u64_map+0xb10>
100130be4:     	ldr	d1, [x8, #0xd68]
100130be8:     	ushl.2s	v0, v0, v1
100130bec:     	ucvtf	s1, w9
100130bf0:     	mov	w8, #0x437f0000         ; =1132396544
100130bf4:     	fmov	s2, w8
100130bf8:     	fdiv	s3, s1, s2
100130bfc:     	bic.2s	v0, #0xff, lsl #8
100130c00:     	ucvtf.2s	v0, v0
100130c04:     	ldr	d1, [sp, #0x180]
100130c08:     	fdiv.2s	v0, v0, v1
100130c0c:     	str	d0, [sp, #0xee0]
100130c10:     	add	x8, sp, #0x4e0
100130c14:     	add	x9, sp, #0xee0
100130c18:     	ldr	x10, [sp, #0xd8]
100130c1c:     	b	0x100130cfc <_render.TerminalRenderer.drawPane+0x28fc>
100130c20:     	ubfx	w9, w8, #8, #8
100130c24:     	lsr	w8, w8, #8
100130c28:     	cmp	w9, #0xe7
100130c2c:     	b.hi	0x100130cc4 <_render.TerminalRenderer.drawPane+0x28c4>
100130c30:     	sub	w8, w8, #0x10
100130c34:     	and	w9, w8, #0xff
100130c38:     	mov	w10, #0x39              ; =57
100130c3c:     	mul	w10, w9, w10
100130c40:     	lsr	w10, w10, #11
100130c44:     	mov	w11, #0x28              ; =40
100130c48:     	mov	w12, #0x37              ; =55
100130c4c:     	madd	w10, w10, w11, w12
100130c50:     	cmp	w9, #0x24
100130c54:     	csel	w10, wzr, w10, lo
100130c58:     	and	w10, w10, #0xff
100130c5c:     	mov	w11, #0xab              ; =171
100130c60:     	mul	w9, w9, w11
100130c64:     	lsr	w9, w9, #10
100130c68:     	ucvtf	s0, w10
100130c6c:     	mov	w10, #0x437f0000        ; =1132396544
100130c70:     	fmov	s1, w10
100130c74:     	fmov	s2, w9
100130c78:     	mov.s	v2[1], w8
100130c7c:     	fdiv	s3, s0, s1
100130c80:     	movi	d0, #0x0000ff000000ff
100130c84:     	and.8b	v0, v2, v0
100130c88:     	ldr	d1, [sp, #0x118]
100130c8c:     	umull.2d	v1, v0, v1
100130c90:     	shrn.2s	v1, v1, #0x20
100130c94:     	movi.2s	v2, #0x6
100130c98:     	mls.2s	v0, v1, v2
100130c9c:     	movi.2s	v1, #0x37
100130ca0:     	movi.2s	v2, #0x28
100130ca4:     	mla.2s	v1, v0, v2
100130ca8:     	cmeq.2s	v0, v0, #0
100130cac:     	bic.8b	v0, v1, v0
100130cb0:     	bic.2s	v0, #0x3, lsl #8
100130cb4:     	ucvtf.2s	v0, v0
100130cb8:     	ldr	d1, [sp, #0x180]
100130cbc:     	fdiv.2s	v0, v0, v1
100130cc0:     	b	0x100130ce8 <_render.TerminalRenderer.drawPane+0x28e8>
100130cc4:     	mov	w9, #0xa                ; =10
100130cc8:     	mov	w10, #-0x8              ; =-8
100130ccc:     	madd	w8, w8, w9, w10
100130cd0:     	and	w8, w8, #0xfe
100130cd4:     	ucvtf	s0, w8
100130cd8:     	mov	w8, #0x437f0000         ; =1132396544
100130cdc:     	fmov	s1, w8
100130ce0:     	fdiv	s3, s0, s1
100130ce4:     	dup.2s	v0, v3[0]
100130ce8:     	str	d0, [sp, #0x22e0]
100130cec:     	add	x8, sp, #0x4e0
100130cf0:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
100130cf4:     	add	x9, x9, #0x2e0
100130cf8:     	ldr	x10, [sp, #0x80]
100130cfc:     	mov	w11, #0x3f800000        ; =1065353216
100130d00:     	str	w11, [x8]
100130d04:     	ldr	s10, [x9]
100130d08:     	fmov	s13, #1.00000000
100130d0c:     	ldr	s8, [x10]
100130d10:     	fadd	s0, s9, s11
100130d14:     	fmov	s1, #-2.00000000
100130d18:     	fadd	s12, s0, s1
100130d1c:     	ldrb	w8, [x22, #0xd8]
100130d20:     	cbz	w8, 0x100130d54 <_render.TerminalRenderer.drawPane+0x2954>
100130d24:     	ldr	x9, [x22, #0xd0]
100130d28:     	ldr	x8, [x22, #0xc0]
100130d2c:     	cmp	x8, x9
100130d30:     	b.lo	0x100130da4 <_render.TerminalRenderer.drawPane+0x29a4>
100130d34:     	ldr	x8, [x22, #0xe0]
100130d38:     	add	x8, x8, #0x1
100130d3c:     	str	x8, [x22, #0xe0]
100130d40:     	ldrh	w8, [sp, #0x3d0]
100130d44:     	ldr	s10, [sp, #0x168]
100130d48:     	ldr	s13, [sp, #0x160]
100130d4c:     	tbnz	w8, #0x6, 0x100130df4 <_render.TerminalRenderer.drawPane+0x29f4>
100130d50:     	b	0x100130eb0 <_render.TerminalRenderer.drawPane+0x2ab0>
100130d54:     	ldur	q0, [x22, #0xa8]
100130d58:     	str	q0, [sp, #0x22e0]
100130d5c:     	ldp	x8, x9, [x22, #0xc0]
100130d60:     	cmp	x9, x8
100130d64:     	b.hi	0x100130da4 <_render.TerminalRenderer.drawPane+0x29a4>
100130d68:     	str	q3, [sp, #0xc0]
100130d6c:     	add	x8, x8, #0x1
100130d70:     	lsr	x9, x8, #1
100130d74:     	add	x9, x9, #0x1
100130d78:     	adds	x8, x8, x9
100130d7c:     	csinv	x2, x8, xzr, lo
100130d80:     	add	x0, x22, #0xb8
100130d84:     	add	x1, sp, #0x2, lsl #12   ; =0x2000
100130d88:     	add	x1, x1, #0x2e0
100130d8c:     	bl	0x1001ae678 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
100130d90:     	ands	w0, w0, #0xffff
100130d94:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100130d98:     	ldr	x8, [x22, #0xc0]
100130d9c:     	ldr	q4, [sp, #0x1a0]
100130da0:     	ldr	q3, [sp, #0xc0]
100130da4:     	add	x9, x8, #0x1
100130da8:     	str	x9, [x22, #0xc0]
100130dac:     	ldr	x9, [x22, #0xb8]
100130db0:     	mov	w10, #0x50              ; =80
100130db4:     	madd	x8, x8, x10, x9
100130db8:     	stp	s15, s12, [x8]
100130dbc:     	ldr	s0, [sp, #0x230]
100130dc0:     	str	s0, [x8, #0x8]
100130dc4:     	ldr	q0, [sp, #0x130]
100130dc8:     	stur	q0, [x8, #0xc]
100130dcc:     	mov	w9, #0x3a000000         ; =973078528
100130dd0:     	str	w9, [x8, #0x1c]
100130dd4:     	stp	s3, s10, [x8, #0x20]
100130dd8:     	stp	s8, s13, [x8, #0x28]
100130ddc:     	movi.2d	v0, #0000000000000000
100130de0:     	stp	q0, q0, [x8, #0x30]
100130de4:     	ldrh	w8, [sp, #0x3d0]
100130de8:     	ldr	s10, [sp, #0x168]
100130dec:     	ldr	s13, [sp, #0x160]
100130df0:     	tbz	w8, #0x6, 0x100130eb0 <_render.TerminalRenderer.drawPane+0x2ab0>
100130df4:     	fmov	s0, #0.50000000
100130df8:     	fmul	s0, s9, s0
100130dfc:     	fadd	s8, s0, s11
100130e00:     	ldrb	w8, [x22, #0xd8]
100130e04:     	cbz	w8, 0x100130e28 <_render.TerminalRenderer.drawPane+0x2a28>
100130e08:     	ldr	x9, [x22, #0xd0]
100130e0c:     	ldr	x8, [x22, #0xc0]
100130e10:     	cmp	x8, x9
100130e14:     	b.lo	0x100130e70 <_render.TerminalRenderer.drawPane+0x2a70>
100130e18:     	ldr	x8, [x22, #0xe0]
100130e1c:     	add	x8, x8, #0x1
100130e20:     	str	x8, [x22, #0xe0]
100130e24:     	b	0x100130eb0 <_render.TerminalRenderer.drawPane+0x2ab0>
100130e28:     	ldur	q0, [x22, #0xa8]
100130e2c:     	str	q0, [sp, #0x22e0]
100130e30:     	ldp	x8, x9, [x22, #0xc0]
100130e34:     	cmp	x9, x8
100130e38:     	b.hi	0x100130e70 <_render.TerminalRenderer.drawPane+0x2a70>
100130e3c:     	add	x8, x8, #0x1
100130e40:     	lsr	x9, x8, #1
100130e44:     	add	x9, x9, #0x1
100130e48:     	adds	x8, x8, x9
100130e4c:     	csinv	x2, x8, xzr, lo
100130e50:     	add	x0, x22, #0xb8
100130e54:     	add	x1, sp, #0x2, lsl #12   ; =0x2000
100130e58:     	add	x1, x1, #0x2e0
100130e5c:     	bl	0x1001ae678 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
100130e60:     	ands	w0, w0, #0xffff
100130e64:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100130e68:     	ldr	x8, [x22, #0xc0]
100130e6c:     	ldr	q4, [sp, #0x1a0]
100130e70:     	add	x9, x8, #0x1
100130e74:     	str	x9, [x22, #0xc0]
100130e78:     	ldr	x9, [x22, #0xb8]
100130e7c:     	mov	w10, #0x50              ; =80
100130e80:     	madd	x8, x8, x10, x9
100130e84:     	stp	s15, s8, [x8]
100130e88:     	ldr	s0, [sp, #0x230]
100130e8c:     	str	s0, [x8, #0x8]
100130e90:     	ldr	q0, [sp, #0x130]
100130e94:     	stur	q0, [x8, #0xc]
100130e98:     	mov	w9, #0x3a000000         ; =973078528
100130e9c:     	str	w9, [x8, #0x1c]
100130ea0:     	stp	s4, s14, [x8, #0x20]
100130ea4:     	stp	s10, s13, [x8, #0x28]
100130ea8:     	movi.2d	v0, #0000000000000000
100130eac:     	stp	q0, q0, [x8, #0x30]
100130eb0:     	ldp	x21, x19, [x22, #0xb8]
100130eb4:     	cmp	x19, #0x2
100130eb8:     	mov	w8, #0x2                ; =2
100130ebc:     	csel	x23, x19, x8, lo
100130ec0:     	add	x8, x23, x23, lsl #2
100130ec4:     	lsl	x22, x8, #4
100130ec8:     	mov	x0, x27
100130ecc:     	mov	x1, x21
100130ed0:     	mov	x2, x22
100130ed4:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100130ed8:     	sub	x8, x19, x23
100130edc:     	add	x8, x8, x8, lsl #2
100130ee0:     	lsl	x2, x8, #4
100130ee4:     	add	x1, x21, x22
100130ee8:     	ldr	x21, [sp, #0x260]
100130eec:     	mov	x0, x26
100130ef0:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100130ef4:     	strb	w19, [x20, #0x3c]
100130ef8:     	str	xzr, [x20]
100130efc:     	stp	s15, s11, [x20, #0x8]
100130f00:     	ldr	s0, [sp, #0x230]
100130f04:     	stp	s0, s9, [x20, #0x10]
100130f08:     	ldp	q0, q1, [sp, #0x1d0]
100130f0c:     	stur	q1, [x20, #0x18]
100130f10:     	stur	q0, [x20, #0x28]
100130f14:     	mov	w8, #0x1                ; =1
100130f18:     	strb	w8, [x20, #0x38]
100130f1c:     	ldr	s0, [x21, #0x1ac]
100130f20:     	ldr	s1, [x27, #0x20]
100130f24:     	fcmp	s1, s0
100130f28:     	b.ne	0x100130f54 <_render.TerminalRenderer.drawPane+0x2b54>
100130f2c:     	ldr	s0, [x21, #0x1b0]
100130f30:     	ldr	s1, [x27, #0x24]
100130f34:     	fcmp	s1, s0
100130f38:     	ldr	x23, [sp, #0x258]
100130f3c:     	b.ne	0x100130f58 <_render.TerminalRenderer.drawPane+0x2b58>
100130f40:     	ldr	s0, [x21, #0x1b4]
100130f44:     	ldr	s1, [x27, #0x28]
100130f48:     	fcmp	s1, s0
100130f4c:     	cset	w8, ne
100130f50:     	b	0x100130f58 <_render.TerminalRenderer.drawPane+0x2b58>
100130f54:     	ldr	x23, [sp, #0x258]
100130f58:     	strb	w8, [x20, #0x39]
100130f5c:     	ldr	x22, [sp, #0x270]
100130f60:     	ldr	x8, [x22, #0x10]
100130f64:     	add	x8, x8, #0x1
100130f68:     	str	x8, [x22, #0x10]
100130f6c:     	ldr	w8, [sp, #0x280]
100130f70:     	cmp	w8, #0x0
100130f74:     	ldr	x8, [sp, #0x1f0]
100130f78:     	ccmp	x8, x25, #0x0, ne
100130f7c:     	cset	w8, eq
100130f80:     	strb	w8, [x20, #0x3a]
100130f84:     	ldr	x8, [sp, #0x210]
100130f88:     	cmp	x8, x25
100130f8c:     	cset	w8, eq
100130f90:     	strb	w8, [x20, #0x3b]
100130f94:     	ldrb	w8, [x20, #0x39]
100130f98:     	tbz	w8, #0x0, 0x100130334 <_render.TerminalRenderer.drawPane+0x1f34>
100130f9c:     	ldp	q0, q1, [x27, #0x20]
100130fa0:     	str	q0, [sp, #0x4b0]
100130fa4:     	str	q1, [sp, #0x4c0]
100130fa8:     	ldr	q0, [x27, #0x40]
100130fac:     	str	q0, [sp, #0x4d0]
100130fb0:     	ldp	q1, q0, [x27]
100130fb4:     	str	q0, [sp, #0x4a0]
100130fb8:     	str	q1, [sp, #0x490]
100130fbc:     	ldrb	w8, [x22, #0x98]
100130fc0:     	cbz	w8, 0x10013100c <_render.TerminalRenderer.drawPane+0x2c0c>
100130fc4:     	ldr	x9, [x22, #0x90]
100130fc8:     	ldr	x8, [x22, #0x80]
100130fcc:     	cmp	x8, x9
100130fd0:     	b.hs	0x100130328 <_render.TerminalRenderer.drawPane+0x1f28>
100130fd4:     	add	x9, x8, #0x1
100130fd8:     	str	x9, [x22, #0x80]
100130fdc:     	ldr	x9, [x22, #0x78]
100130fe0:     	mov	w10, #0x50              ; =80
100130fe4:     	madd	x8, x8, x10, x9
100130fe8:     	ldr	q0, [sp, #0x4b0]
100130fec:     	ldr	q1, [sp, #0x4c0]
100130ff0:     	stp	q0, q1, [x8, #0x20]
100130ff4:     	ldr	q0, [sp, #0x4d0]
100130ff8:     	str	q0, [x8, #0x40]
100130ffc:     	ldr	q0, [sp, #0x4a0]
100131000:     	ldr	q1, [sp, #0x490]
100131004:     	stp	q1, q0, [x8]
100131008:     	b	0x100130334 <_render.TerminalRenderer.drawPane+0x1f34>
10013100c:     	ldp	x8, x21, [x22, #0x80]
100131010:     	ldr	x23, [x22, #0x78]
100131014:     	cmp	x21, x8
100131018:     	b.ls	0x100131024 <_render.TerminalRenderer.drawPane+0x2c24>
10013101c:     	ldr	x21, [sp, #0x260]
100131020:     	b	0x100131184 <_render.TerminalRenderer.drawPane+0x2d84>
100131024:     	ldp	x0, x10, [x22, #0x68]
100131028:     	add	x8, x8, #0x1
10013102c:     	lsr	x9, x8, #1
100131030:     	add	x9, x9, #0x1
100131034:     	adds	x8, x8, x9
100131038:     	csinv	x22, x8, xzr, lo
10013103c:     	add	x11, x22, x22, lsl #2
100131040:     	cbz	x21, 0x100131064 <_render.TerminalRenderer.drawPane+0x2c64>
100131044:     	mov	w8, #0x50               ; =80
100131048:     	umulh	x8, x22, x8
10013104c:     	cmp	xzr, x8
100131050:     	cset	w8, ne
100131054:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
100131058:     	add	x9, x9, #0x2e0
10013105c:     	strb	w8, [x9]
100131060:     	b.eq	0x100131078 <_render.TerminalRenderer.drawPane+0x2c78>
100131064:     	mov	x28, #0x0               ; =0
100131068:     	mov	x8, #0x0                ; =0
10013106c:     	cbz	x28, 0x1001310d0 <_render.TerminalRenderer.drawPane+0x2cd0>
100131070:     	mov	x22, x8
100131074:     	b	0x100131164 <_render.TerminalRenderer.drawPane+0x2d64>
100131078:     	str	x11, [sp, #0x1e0]
10013107c:     	lsl	x4, x11, #4
100131080:     	add	x8, x21, x21, lsl #2
100131084:     	lsl	x2, x8, #4
100131088:     	str	x10, [sp, #0x230]
10013108c:     	ldr	x8, [x10, #0x10]
100131090:     	str	x0, [sp, #0x1d0]
100131094:     	mov	x1, x23
100131098:     	mov	w3, #0x2                ; =2
10013109c:     	mov	x19, x4
1001310a0:     	ldr	x5, [sp, #0x188]
1001310a4:     	blr	x8
1001310a8:     	mov	x28, x0
1001310ac:     	cbz	x0, 0x1001311bc <_render.TerminalRenderer.drawPane+0x2dbc>
1001310b0:     	lsr	x8, x19, #4
1001310b4:     	mov	x9, #-0x3333333333333334 ; =-3689348814741910324
1001310b8:     	movk	x9, #0xcccd
1001310bc:     	mul	x8, x8, x9
1001310c0:     	ldr	x0, [sp, #0x1d0]
1001310c4:     	ldr	x10, [sp, #0x230]
1001310c8:     	ldr	x11, [sp, #0x1e0]
1001310cc:     	cbnz	x28, 0x100131070 <_render.TerminalRenderer.drawPane+0x2c70>
1001310d0:     	mov	w8, #0x50               ; =80
1001310d4:     	umulh	x8, x22, x8
1001310d8:     	cmp	xzr, x8
1001310dc:     	cset	w8, ne
1001310e0:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
1001310e4:     	add	x9, x9, #0x2e0
1001310e8:     	strb	w8, [x9]
1001310ec:     	b.ne	0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
1001310f0:     	lsl	x1, x11, #4
1001310f4:     	str	x10, [sp, #0x230]
1001310f8:     	cbz	x1, 0x10013111c <_render.TerminalRenderer.drawPane+0x2d1c>
1001310fc:     	ldr	x8, [x10]
100131100:     	mov	x19, x0
100131104:     	mov	w2, #0x2                ; =2
100131108:     	ldr	x3, [sp, #0x188]
10013110c:     	blr	x8
100131110:     	mov	x28, x0
100131114:     	cbnz	x0, 0x100131124 <_render.TerminalRenderer.drawPane+0x2d24>
100131118:     	b	0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
10013111c:     	mov	x19, x0
100131120:     	mov	x28, #-0x4              ; =-4
100131124:     	ldr	x9, [sp, #0x270]
100131128:     	ldp	x1, x8, [x9, #0x78]
10013112c:     	add	x8, x8, x8, lsl #2
100131130:     	lsl	x2, x8, #4
100131134:     	mov	x0, x28
100131138:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
10013113c:     	cbz	x21, 0x100131164 <_render.TerminalRenderer.drawPane+0x2d64>
100131140:     	add	x8, x21, x21, lsl #2
100131144:     	lsl	x2, x8, #4
100131148:     	ldr	x8, [sp, #0x230]
10013114c:     	ldr	x8, [x8, #0x18]
100131150:     	mov	x0, x19
100131154:     	mov	x1, x23
100131158:     	mov	w3, #0x2                ; =2
10013115c:     	ldr	x4, [sp, #0x188]
100131160:     	blr	x8
100131164:     	ldr	x8, [sp, #0x270]
100131168:     	str	x28, [x8, #0x78]
10013116c:     	str	x22, [x8, #0x88]
100131170:     	mov	x22, x8
100131174:     	mov	x23, x28
100131178:     	ldr	x8, [x8, #0x80]
10013117c:     	ldr	x21, [sp, #0x260]
100131180:     	ldr	x28, [sp, #0x178]
100131184:     	add	x9, x8, #0x1
100131188:     	str	x9, [x22, #0x80]
10013118c:     	mov	w9, #0x50               ; =80
100131190:     	madd	x8, x8, x9, x23
100131194:     	ldr	q0, [sp, #0x490]
100131198:     	str	q0, [x8]
10013119c:     	ldr	q0, [sp, #0x4a0]
1001311a0:     	ldr	q1, [sp, #0x4b0]
1001311a4:     	ldr	q2, [sp, #0x4c0]
1001311a8:     	ldr	q3, [sp, #0x4d0]
1001311ac:     	stp	q2, q3, [x8, #0x30]
1001311b0:     	stp	q0, q1, [x8, #0x10]
1001311b4:     	ldr	x23, [sp, #0x258]
1001311b8:     	b	0x100130334 <_render.TerminalRenderer.drawPane+0x1f34>
1001311bc:     	mov	x8, #0x0                ; =0
1001311c0:     	ldr	x0, [sp, #0x1d0]
1001311c4:     	ldr	x10, [sp, #0x230]
1001311c8:     	ldr	x11, [sp, #0x1e0]
1001311cc:     	cbnz	x28, 0x100131070 <_render.TerminalRenderer.drawPane+0x2c70>
1001311d0:     	b	0x1001310d0 <_render.TerminalRenderer.drawPane+0x2cd0>
1001311d4:     	add	x25, sp, #0x4e0
1001311d8:     	mov	w27, #0xffff            ; =65535
1001311dc:     	ldr	x24, [sp, #0x148]
1001311e0:     	ldr	x7, [sp, #0x100]
1001311e4:     	ldr	x9, [sp, #0x110]
1001311e8:     	b	0x100131280 <_render.TerminalRenderer.drawPane+0x2e80>
1001311ec:     	mov	x28, #0x0               ; =0
1001311f0:     	mov	w26, #0x0               ; =0
1001311f4:     	mov	x23, #0x0               ; =0
1001311f8:     	mov	w22, #0x1               ; =1
1001311fc:     	b	0x10012f524 <_render.TerminalRenderer.drawPane+0x1124>
100131200:     	ldr	x21, [sp, #0x3910]
100131204:     	ldr	x19, [sp, #0x3918]
100131208:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10013120c:     	add	x8, x8, #0x8e0
100131210:     	ldrb	w25, [x8, #0x44]
100131214:     	ldr	w26, [sp, #0x3920]
100131218:     	add	x8, x20, x20, lsl #2
10013121c:     	lsl	x2, x8, #2
100131220:     	add	x0, sp, #0xee0
100131224:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100131228:     	add	x8, x19, x19, lsl #2
10013122c:     	lsl	x2, x8, #2
100131230:     	add	x0, sp, #0x2, lsl #12   ; =0x2000
100131234:     	add	x0, x0, #0x2e0
100131238:     	mov	x1, x21
10013123c:     	ldr	x21, [sp, #0x260]
100131240:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100131244:     	tbz	w22, #0x0, 0x10013129c <_render.TerminalRenderer.drawPane+0x2e9c>
100131248:     	mov	w8, #0x1                ; =1
10013124c:     	str	w8, [sp, #0x220]
100131250:     	ldr	x23, [sp, #0x258]
100131254:     	ldr	x22, [sp, #0x270]
100131258:     	add	x25, sp, #0x4e0
10013125c:     	ldr	x28, [sp, #0x178]
100131260:     	mov	w27, #0xffff            ; =65535
100131264:     	ldr	x24, [sp, #0x148]
100131268:     	ldr	x7, [sp, #0x100]
10013126c:     	ldr	x12, [sp, #0x1c8]
100131270:     	ldr	x9, [sp, #0x110]
100131274:     	tst	w9, #0xffff
100131278:     	b.ne	0x1001302e0 <_render.TerminalRenderer.drawPane+0x1ee0>
10013127c:     	mov	w9, #0x0                ; =0
100131280:     	ldr	x8, [sp, #0x158]
100131284:     	add	w8, w9, w8
100131288:     	str	x8, [sp, #0x158]
10013128c:     	cmp	w24, w8, uxth
100131290:     	mov	w26, #0x6               ; =6
100131294:     	b.hi	0x10012f3a0 <_render.TerminalRenderer.drawPane+0xfa0>
100131298:     	b	0x10012ec74 <_render.TerminalRenderer.drawPane+0x874>
10013129c:     	mov	x12, #0x0               ; =0
1001312a0:     	orr	x8, x26, x25, lsl #32
1001312a4:     	lsl	x9, x23, #40
1001312a8:     	orr	x9, x9, x24, lsl #48
1001312ac:     	orr	x8, x9, x8
1001312b0:     	str	x8, [sp, #0x10]
1001312b4:     	ubfx	x11, x8, #32, #4
1001312b8:     	mov	x8, #0x642f             ; =25647
1001312bc:     	movk	x8, #0x78bd, lsl #16
1001312c0:     	movk	x8, #0x1d64, lsl #32
1001312c4:     	movk	x8, #0xa076, lsl #48
1001312c8:     	eor	x8, x11, x8
1001312cc:     	mov	x10, #0x28db            ; =10459
1001312d0:     	movk	x10, #0xa0b4, lsl #16
1001312d4:     	movk	x10, #0x7ed1, lsl #32
1001312d8:     	movk	x10, #0xe703, lsl #48
1001312dc:     	mul	x9, x8, x10
1001312e0:     	umulh	x8, x8, x10
1001312e4:     	eor	x8, x8, x9
1001312e8:     	str	x11, [sp]
1001312ec:     	eor	x8, x11, x8
1001312f0:     	str	x8, [sp, #0x18]
1001312f4:     	ldr	x8, [sp, #0x178]
1001312f8:     	ldr	w9, [sp, #0x230]
1001312fc:     	add	w8, w9, w8
100131300:     	and	x8, x8, #0xffff
100131304:     	str	x8, [sp, #0xc0]
100131308:     	add	x8, sp, #0xee0
10013130c:     	str	x8, [sp, #0x230]
100131310:     	add	x8, sp, #0x2, lsl #12   ; =0x2000
100131314:     	add	x8, x8, #0x2e0
100131318:     	str	x8, [sp, #0x210]
10013131c:     	mov	x25, x20
100131320:     	mov	x27, #0x0               ; =0
100131324:     	cbz	x20, 0x100131360 <_render.TerminalRenderer.drawPane+0x2f60>
100131328:     	add	x8, sp, #0xce0
10013132c:     	ldr	w8, [x8, x12, lsl #2]
100131330:     	ldr	x9, [sp, #0x230]
100131334:     	add	x9, x9, #0x8
100131338:     	ldr	x20, [sp, #0x258]
10013133c:     	ldr	x11, [sp, #0x168]
100131340:     	ldr	w10, [x9], #0x14
100131344:     	cmp	w10, w8
100131348:     	b.hs	0x100131368 <_render.TerminalRenderer.drawPane+0x2f68>
10013134c:     	add	x27, x27, #0x1
100131350:     	cmp	x25, x27
100131354:     	b.ne	0x100131340 <_render.TerminalRenderer.drawPane+0x2f40>
100131358:     	mov	x27, x25
10013135c:     	b	0x100131368 <_render.TerminalRenderer.drawPane+0x2f68>
100131360:     	ldr	x20, [sp, #0x258]
100131364:     	ldr	x11, [sp, #0x168]
100131368:     	ldr	x8, [sp, #0x158]
10013136c:     	str	x12, [sp, #0x1e0]
100131370:     	add	w26, w8, w12
100131374:     	ldrh	w8, [x11, #0x50]
100131378:     	ldr	x9, [sp, #0x178]
10013137c:     	mul	x8, x9, x8
100131380:     	and	x9, x26, #0xffff
100131384:     	ldr	x10, [x11, #0x30]
100131388:     	add	x8, x10, x8, lsl #5
10013138c:     	add	x21, x8, x9, lsl #5
100131390:     	ldrb	w8, [x20, #0x40]
100131394:     	ldr	x22, [sp, #0x270]
100131398:     	cbz	w8, 0x100131480 <_render.TerminalRenderer.drawPane+0x3080>
10013139c:     	ldrb	w8, [x20, #0x38]
1001313a0:     	cbz	w8, 0x100131480 <_render.TerminalRenderer.drawPane+0x3080>
1001313a4:     	ldr	w11, [x20, #0x28]
1001313a8:     	ldr	x8, [x20, #0x30]
1001313ac:     	ldrb	w10, [x20, #0x3d]
1001313b0:     	ldr	x9, [x20]
1001313b4:     	ldr	w9, [x9, #0xfc]
1001313b8:     	ldr	w12, [sp, #0x190]
1001313bc:     	add	w9, w9, w12
1001313c0:     	tbz	w10, #0x0, 0x100131408 <_render.TerminalRenderer.drawPane+0x3008>
1001313c4:     	cmp	w8, w11
1001313c8:     	csel	w10, w8, w11, lo
1001313cc:     	csel	w8, w8, w11, hi
1001313d0:     	cmp	w9, w10
1001313d4:     	ccmp	w9, w8, #0x2, hs
1001313d8:     	b.hi	0x100131480 <_render.TerminalRenderer.drawPane+0x3080>
1001313dc:     	ldp	q1, q0, [x21]
1001313e0:     	str	q1, [sp, #0x36e0]
1001313e4:     	str	q0, [sp, #0x36f0]
1001313e8:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
1001313ec:     	add	x9, x9, #0x2e0
1001313f0:     	ldrh	w8, [x9, #0x1400]
1001313f4:     	eor	w8, w8, #0x10
1001313f8:     	strh	w8, [x9, #0x1400]
1001313fc:     	add	x21, sp, #0x3, lsl #12  ; =0x3000
100131400:     	add	x21, x21, #0x6e0
100131404:     	b	0x100131480 <_render.TerminalRenderer.drawPane+0x3080>
100131408:     	ldr	w10, [x20, #0x2c]
10013140c:     	lsr	x12, x8, #32
100131410:     	cmp	w11, w8
100131414:     	b.lo	0x10013142c <_render.TerminalRenderer.drawPane+0x302c>
100131418:     	cmp	w11, w8
10013141c:     	b.ne	0x100131444 <_render.TerminalRenderer.drawPane+0x3044>
100131420:     	and	w13, w10, #0xffff
100131424:     	cmp	w13, w12, uxth
100131428:     	b.hs	0x100131444 <_render.TerminalRenderer.drawPane+0x3044>
10013142c:     	mov	x13, x10
100131430:     	mov	x10, x12
100131434:     	mov	x12, x11
100131438:     	cmp	w9, w12
10013143c:     	b.hs	0x100131458 <_render.TerminalRenderer.drawPane+0x3058>
100131440:     	b	0x100131480 <_render.TerminalRenderer.drawPane+0x3080>
100131444:     	mov	x13, x12
100131448:     	mov	x12, x8
10013144c:     	mov	x8, x11
100131450:     	cmp	w9, w12
100131454:     	b.lo	0x100131480 <_render.TerminalRenderer.drawPane+0x3080>
100131458:     	and	w11, w26, #0xffff
10013145c:     	cmp	w11, w13, uxth
100131460:     	ccmp	w9, w12, #0x0, lo
100131464:     	b.eq	0x100131480 <_render.TerminalRenderer.drawPane+0x3080>
100131468:     	cmp	w8, w9
10013146c:     	b.lo	0x100131480 <_render.TerminalRenderer.drawPane+0x3080>
100131470:     	b.ne	0x1001313dc <_render.TerminalRenderer.drawPane+0x2fdc>
100131474:     	and	w8, w26, #0xffff
100131478:     	cmp	w8, w10, uxth
10013147c:     	b.ls	0x1001313dc <_render.TerminalRenderer.drawPane+0x2fdc>
100131480:     	add	x8, x21, #0xe
100131484:     	ldrb	w9, [x21, #0x1e]
100131488:     	ldr	x10, [sp, #0x260]
10013148c:     	ldrh	w3, [x10, #0x8]
100131490:     	str	x8, [sp, #0x38e0]
100131494:     	str	x9, [sp, #0x38e8]
100131498:     	ldr	x8, [sp, #0xb8]
10013149c:     	str	x8, [sp, #0x38f0]
1001314a0:     	mov	w8, #0x1                ; =1
1001314a4:     	str	w8, [sp, #0x38f8]
1001314a8:     	add	x23, sp, #0x3, lsl #12  ; =0x3000
1001314ac:     	add	x23, x23, #0x8e0
1001314b0:     	strb	wzr, [x23, #0x1c]
1001314b4:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
1001314b8:     	add	x0, x0, #0x900
1001314bc:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
1001314c0:     	add	x2, x2, #0x8e0
1001314c4:     	ldr	x1, [sp, #0x278]
1001314c8:     	bl	0x100120964 <_text.GlyphAtlas.shape>
1001314cc:     	ldrh	w0, [x23, #0x48]
1001314d0:     	cbnz	w0, 0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
1001314d4:     	ldrb	w8, [x23, #0x45]
1001314d8:     	tbnz	w8, #0x0, 0x100131530 <_render.TerminalRenderer.drawPane+0x3130>
1001314dc:     	ldr	x8, [sp, #0x3900]
1001314e0:     	ldr	x9, [sp, #0x3908]
1001314e4:     	cmp	x9, #0x2
1001314e8:     	b.lo	0x100131510 <_render.TerminalRenderer.drawPane+0x3110>
1001314ec:     	add	x10, x8, #0x1c
1001314f0:     	sub	x11, x9, #0x1
1001314f4:     	ldr	w12, [x10]
1001314f8:     	ldur	w13, [x10, #-0x14]
1001314fc:     	cmp	w12, w13
100131500:     	b.lo	0x100131530 <_render.TerminalRenderer.drawPane+0x3130>
100131504:     	add	x10, x10, #0x14
100131508:     	subs	x11, x11, #0x1
10013150c:     	b.ne	0x1001314f4 <_render.TerminalRenderer.drawPane+0x30f4>
100131510:     	add	x10, sp, #0x3, lsl #12  ; =0x3000
100131514:     	add	x10, x10, #0x8e0
100131518:     	ldrb	w10, [x10, #0x44]
10013151c:     	and	w10, w10, #0xf
100131520:     	ldr	x11, [sp]
100131524:     	cmp	w11, w10
100131528:     	ccmp	x27, x9, #0x0, eq
10013152c:     	b.eq	0x100131ac0 <_render.TerminalRenderer.drawPane+0x36c0>
100131530:     	mov	w24, #0x1               ; =1
100131534:     	str	x25, [sp, #0x1d0]
100131538:     	ldp	q3, q0, [x21]
10013153c:     	str	q0, [sp, #0x220]
100131540:     	umov.b	w8, v0[15]
100131544:     	ldrh	w11, [x20, #0x18]
100131548:     	ldrh	w14, [x20, #0x1a]
10013154c:     	tst	w8, #0xfe
100131550:     	csinc	w8, w8, wzr, ne
100131554:     	ldr	x9, [x20]
100131558:     	ldrh	w10, [x20, #0x1c]
10013155c:     	ldrh	w9, [x9, #0x50]
100131560:     	cmp	w10, w9
100131564:     	csel	w9, w10, w9, lo
100131568:     	sub	w9, w9, w26
10013156c:     	and	w9, w9, #0xffff
100131570:     	cmp	w8, w9
100131574:     	csel	w10, w8, w9, lo
100131578:     	ldr	x8, [sp, #0x260]
10013157c:     	ldrh	w13, [x8, #0x4]
100131580:     	ldrh	w15, [x8, #0x6]
100131584:     	ldr	x8, [sp, #0x240]
100131588:     	ldp	w17, w16, [x8]
10013158c:     	str	q3, [sp, #0x1f0]
100131590:     	tbz	w24, #0x0, 0x10013186c <_render.TerminalRenderer.drawPane+0x346c>
100131594:     	stp	w17, w16, [sp, #0x48]
100131598:     	stp	w15, w10, [sp, #0x50]
10013159c:     	stp	w14, w11, [sp, #0x58]
1001315a0:     	str	w13, [sp, #0x60]
1001315a4:     	str	x26, [sp, #0x1a0]
1001315a8:     	str	xzr, [sp, #0x3908]
1001315ac:     	str	xzr, [sp, #0x3900]
1001315b0:     	ldr	x8, [sp, #0x18]
1001315b4:     	str	x8, [sp, #0x3910]
1001315b8:     	str	x8, [sp, #0x3918]
1001315bc:     	str	x8, [sp, #0x3920]
1001315c0:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
1001315c4:     	add	x8, x8, #0x900
1001315c8:     	movi.2d	v0, #0000000000000000
1001315cc:     	stur	q0, [x8, #0x28]
1001315d0:     	stur	q0, [x8, #0x38]
1001315d4:     	stur	q0, [x8, #0x48]
1001315d8:     	stur	q0, [x8, #0x58]
1001315dc:     	cbz	x27, 0x100131838 <_render.TerminalRenderer.drawPane+0x3438>
1001315e0:     	mov	x26, #0x0               ; =0
1001315e4:     	ldr	x25, [sp, #0x230]
1001315e8:     	ldr	x23, [sp, #0x210]
1001315ec:     	mov	x20, x27
1001315f0:     	b	0x1001316dc <_render.TerminalRenderer.drawPane+0x32dc>
1001315f4:     	mov	w8, #0x30               ; =48
1001315f8:     	sub	x21, x8, x22
1001315fc:     	ldr	x28, [sp, #0x1b0]
100131600:     	add	x0, x28, x22
100131604:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
100131608:     	add	x1, x1, #0x870
10013160c:     	mov	x2, x21
100131610:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100131614:     	ldr	x8, [sp, #0x3938]
100131618:     	ldr	x9, [sp, #0x3920]
10013161c:     	mov	x10, #0x28db            ; =10459
100131620:     	movk	x10, #0xa0b4, lsl #16
100131624:     	movk	x10, #0x7ed1, lsl #32
100131628:     	movk	x10, #0xe703, lsl #48
10013162c:     	eor	x8, x8, x10
100131630:     	ldr	x10, [sp, #0x3940]
100131634:     	ldr	x11, [sp, #0x3948]
100131638:     	ldr	x12, [sp, #0x3910]
10013163c:     	ldr	x13, [sp, #0x3918]
100131640:     	eor	x10, x12, x10
100131644:     	mul	x12, x10, x8
100131648:     	umulh	x8, x10, x8
10013164c:     	eor	x8, x8, x12
100131650:     	mov	x10, #0xc6e3            ; =50915
100131654:     	movk	x10, #0x9c88, lsl #16
100131658:     	movk	x10, #0x6af0, lsl #32
10013165c:     	movk	x10, #0x8ebc, lsl #48
100131660:     	eor	x10, x11, x10
100131664:     	ldr	x11, [sp, #0x3950]
100131668:     	ldr	x12, [sp, #0x3958]
10013166c:     	eor	x11, x13, x11
100131670:     	mul	x13, x11, x10
100131674:     	umulh	x10, x11, x10
100131678:     	eor	x10, x10, x13
10013167c:     	str	x8, [sp, #0x3910]
100131680:     	str	x10, [sp, #0x3918]
100131684:     	ldr	x8, [sp, #0x3960]
100131688:     	mov	x10, #0x4cc3            ; =19651
10013168c:     	movk	x10, #0x7537, lsl #16
100131690:     	movk	x10, #0x65cc, lsl #32
100131694:     	movk	x10, #0x5899, lsl #48
100131698:     	eor	x10, x12, x10
10013169c:     	eor	x8, x9, x8
1001316a0:     	mul	x9, x8, x10
1001316a4:     	umulh	x8, x8, x10
1001316a8:     	eor	x8, x8, x9
1001316ac:     	str	x8, [sp, #0x3920]
1001316b0:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
1001316b4:     	add	x8, x8, #0x870
1001316b8:     	add	x1, x8, x21
1001316bc:     	mov	x0, x28
1001316c0:     	mov	x2, x26
1001316c4:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
1001316c8:     	ldr	x28, [sp, #0x298]
1001316cc:     	str	x26, [sp, #0x3930]
1001316d0:     	add	x25, x25, #0x14
1001316d4:     	subs	x20, x20, #0x1
1001316d8:     	b.eq	0x100131838 <_render.TerminalRenderer.drawPane+0x3438>
1001316dc:     	ldr	q0, [x25]
1001316e0:     	str	q0, [sp, #0x38e0]
1001316e4:     	ldr	w8, [x25, #0x10]
1001316e8:     	ldr	q0, [x23], #0x14
1001316ec:     	str	w8, [sp, #0x38f0]
1001316f0:     	str	q0, [sp, #0x3870]
1001316f4:     	ldr	x8, [sp, #0x3928]
1001316f8:     	add	x8, x8, #0x4
1001316fc:     	str	x8, [sp, #0x3928]
100131700:     	subs	x22, x26, #0x2c
100131704:     	b.ls	0x1001317f4 <_render.TerminalRenderer.drawPane+0x33f4>
100131708:     	mov	w8, #0x30               ; =48
10013170c:     	sub	x21, x8, x26
100131710:     	ldr	x28, [sp, #0x1b0]
100131714:     	add	x0, x28, x26
100131718:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
10013171c:     	add	x1, x1, #0x8e0
100131720:     	mov	x2, x21
100131724:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100131728:     	ldr	x8, [sp, #0x3938]
10013172c:     	ldr	x9, [sp, #0x3920]
100131730:     	mov	x10, #0x28db            ; =10459
100131734:     	movk	x10, #0xa0b4, lsl #16
100131738:     	movk	x10, #0x7ed1, lsl #32
10013173c:     	movk	x10, #0xe703, lsl #48
100131740:     	eor	x8, x8, x10
100131744:     	ldr	x10, [sp, #0x3940]
100131748:     	ldr	x11, [sp, #0x3948]
10013174c:     	ldr	x12, [sp, #0x3910]
100131750:     	ldr	x13, [sp, #0x3918]
100131754:     	eor	x10, x12, x10
100131758:     	mul	x12, x10, x8
10013175c:     	umulh	x8, x10, x8
100131760:     	eor	x8, x8, x12
100131764:     	mov	x10, #0xc6e3            ; =50915
100131768:     	movk	x10, #0x9c88, lsl #16
10013176c:     	movk	x10, #0x6af0, lsl #32
100131770:     	movk	x10, #0x8ebc, lsl #48
100131774:     	eor	x10, x11, x10
100131778:     	ldr	x11, [sp, #0x3950]
10013177c:     	ldr	x12, [sp, #0x3958]
100131780:     	eor	x11, x13, x11
100131784:     	mul	x13, x11, x10
100131788:     	umulh	x10, x11, x10
10013178c:     	eor	x10, x10, x13
100131790:     	str	x8, [sp, #0x3910]
100131794:     	str	x10, [sp, #0x3918]
100131798:     	ldr	x8, [sp, #0x3960]
10013179c:     	mov	x10, #0x4cc3            ; =19651
1001317a0:     	movk	x10, #0x7537, lsl #16
1001317a4:     	movk	x10, #0x65cc, lsl #32
1001317a8:     	movk	x10, #0x5899, lsl #48
1001317ac:     	eor	x10, x12, x10
1001317b0:     	eor	x8, x9, x8
1001317b4:     	mul	x9, x8, x10
1001317b8:     	umulh	x8, x8, x10
1001317bc:     	eor	x8, x8, x9
1001317c0:     	str	x8, [sp, #0x3920]
1001317c4:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
1001317c8:     	add	x8, x8, #0x8e0
1001317cc:     	add	x1, x8, x21
1001317d0:     	mov	x0, x28
1001317d4:     	mov	x2, x22
1001317d8:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
1001317dc:     	ldr	x8, [sp, #0x3928]
1001317e0:     	add	x8, x8, #0x10
1001317e4:     	str	x8, [sp, #0x3928]
1001317e8:     	subs	x26, x22, #0x20
1001317ec:     	b.hi	0x1001315f4 <_render.TerminalRenderer.drawPane+0x31f4>
1001317f0:     	b	0x100131814 <_render.TerminalRenderer.drawPane+0x3414>
1001317f4:     	ldr	w9, [sp, #0x38e0]
1001317f8:     	ldr	x10, [sp, #0x1b0]
1001317fc:     	str	w9, [x10, x26]
100131800:     	add	x22, x26, #0x4
100131804:     	add	x8, x8, #0x10
100131808:     	str	x8, [sp, #0x3928]
10013180c:     	subs	x26, x22, #0x20
100131810:     	b.hi	0x1001315f4 <_render.TerminalRenderer.drawPane+0x31f4>
100131814:     	ldr	q0, [sp, #0x3870]
100131818:     	ldr	x8, [sp, #0x1b0]
10013181c:     	str	q0, [x8, x22]
100131820:     	add	x26, x22, #0x10
100131824:     	ldr	x28, [sp, #0x298]
100131828:     	str	x26, [sp, #0x3930]
10013182c:     	add	x25, x25, #0x14
100131830:     	subs	x20, x20, #0x1
100131834:     	b.ne	0x1001316dc <_render.TerminalRenderer.drawPane+0x32dc>
100131838:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
10013183c:     	add	x0, x0, #0x900
100131840:     	bl	0x10019a2f8 <_hash.wyhash.Wyhash.final>
100131844:     	ldr	q3, [sp, #0x1f0]
100131848:     	cmp	x0, #0x1
10013184c:     	csinc	x12, x0, xzr, hi
100131850:     	ldr	x22, [sp, #0x270]
100131854:     	ldr	x26, [sp, #0x1a0]
100131858:     	ldp	w11, w13, [sp, #0x5c]
10013185c:     	ldp	w10, w14, [sp, #0x54]
100131860:     	ldp	w16, w15, [sp, #0x4c]
100131864:     	ldr	w17, [sp, #0x48]
100131868:     	b	0x100131870 <_render.TerminalRenderer.drawPane+0x3470>
10013186c:     	mov	x12, #0x0               ; =0
100131870:     	add	w8, w11, w26, uxth
100131874:     	ldr	x9, [sp, #0x178]
100131878:     	add	w9, w14, w9, uxth
10013187c:     	madd	w8, w13, w8, w17
100131880:     	ucvtf	s9, w8
100131884:     	madd	w8, w15, w9, w16
100131888:     	ucvtf	s11, w8
10013188c:     	mul	w8, w10, w13
100131890:     	ucvtf	s12, w8
100131894:     	ucvtf	s15, w15
100131898:     	ldr	w8, [sp, #0x160]
10013189c:     	add	w8, w26, w8
1001318a0:     	ldr	x10, [sp, #0x170]
1001318a4:     	ldrh	w9, [x10, #0x48]
1001318a8:     	ldr	x11, [sp, #0xc0]
1001318ac:     	umull	x9, w9, w11
1001318b0:     	add	x21, x9, w8, uxth
1001318b4:     	ldr	x8, [x10]
1001318b8:     	add	x25, x8, x21, lsl #6
1001318bc:     	ldr	x26, [x10, #0x18]
1001318c0:     	ldr	x20, [x10, #0x30]
1001318c4:     	ldrb	w8, [x25, #0x38]
1001318c8:     	cmp	w8, #0x1
1001318cc:     	b.ne	0x100131930 <_render.TerminalRenderer.drawPane+0x3530>
1001318d0:     	ldr	s0, [x25, #0x8]
1001318d4:     	fcmp	s0, s9
1001318d8:     	b.ne	0x100131930 <_render.TerminalRenderer.drawPane+0x3530>
1001318dc:     	ldr	s0, [x25, #0xc]
1001318e0:     	fcmp	s0, s11
1001318e4:     	b.ne	0x100131930 <_render.TerminalRenderer.drawPane+0x3530>
1001318e8:     	ldr	s0, [x25, #0x10]
1001318ec:     	fcmp	s0, s12
1001318f0:     	b.ne	0x100131930 <_render.TerminalRenderer.drawPane+0x3530>
1001318f4:     	ldr	s0, [x25, #0x14]
1001318f8:     	fcmp	s0, s15
1001318fc:     	b.ne	0x100131930 <_render.TerminalRenderer.drawPane+0x3530>
100131900:     	ldur	q0, [x25, #0x18]
100131904:     	ldur	q1, [x25, #0x28]
100131908:     	eor.16b	v0, v0, v3
10013190c:     	ldr	q2, [sp, #0x220]
100131910:     	eor.16b	v1, v1, v2
100131914:     	orr.16b	v0, v1, v0
100131918:     	umaxv.16b	b0, v0
10013191c:     	fmov	w8, s0
100131920:     	cbnz	w8, 0x100131930 <_render.TerminalRenderer.drawPane+0x3530>
100131924:     	ldr	x8, [x25]
100131928:     	cmp	x8, x12
10013192c:     	b.eq	0x10013210c <_render.TerminalRenderer.drawPane+0x3d0c>
100131930:     	str	x12, [sp, #0x1a0]
100131934:     	adrp	x23, 0x100537000 <___anon_12840+0x13d14>
100131938:     	add	x23, x23, #0x530
10013193c:     	tbz	w24, #0x0, 0x100131978 <_render.TerminalRenderer.drawPane+0x3578>
100131940:     	ldr	x8, [sp, #0x230]
100131944:     	str	x8, [sp, #0x3700]
100131948:     	str	x27, [sp, #0x3708]
10013194c:     	ldr	x8, [sp, #0x210]
100131950:     	str	x8, [sp, #0x3710]
100131954:     	str	x27, [sp, #0x3718]
100131958:     	ldr	x8, [sp, #0x10]
10013195c:     	str	x8, [sp, #0x3720]
100131960:     	add	x23, sp, #0x3, lsl #12  ; =0x3000
100131964:     	add	x23, x23, #0x700
100131968:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10013196c:     	add	x8, x8, #0x700
100131970:     	mov	w9, #0x1                ; =1
100131974:     	strb	w9, [x8, #0x28]
100131978:     	str	q3, [sp, #0x3730]
10013197c:     	ldr	q0, [sp, #0x220]
100131980:     	str	q0, [sp, #0x3740]
100131984:     	fmov	x8, d3
100131988:     	str	xzr, [x22, #0xc0]
10013198c:     	tbnz	w8, #0x4, 0x100131a28 <_render.TerminalRenderer.drawPane+0x3628>
100131990:     	ldr	x8, [sp, #0x208]
100131994:     	ldr	q0, [x8]
100131998:     	str	q0, [sp, #0x3760]
10013199c:     	mov	b0, v3[8]
1001319a0:     	mov.b	v0[4], v3[9]
1001319a4:     	mov	b1, v3[6]
1001319a8:     	mov.b	v1[4], v3[7]
1001319ac:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
1001319b0:     	add	x8, x8, #0x760
1001319b4:     	fmov	w9, s1
1001319b8:     	and	w9, w9, #0xff
1001319bc:     	cmp	w9, #0x2
1001319c0:     	b.eq	0x100131a64 <_render.TerminalRenderer.drawPane+0x3664>
1001319c4:     	cmp	w9, #0x1
1001319c8:     	b.ne	0x100131a98 <_render.TerminalRenderer.drawPane+0x3698>
1001319cc:     	mov.s	w8, v1[1]
1001319d0:     	and	w9, w8, #0xff
1001319d4:     	cmp	w9, #0x10
1001319d8:     	b.hs	0x100131b24 <_render.TerminalRenderer.drawPane+0x3724>
1001319dc:     	and	x9, x8, #0xff
1001319e0:     	add	x8, x9, w8, uxtb #1
1001319e4:     	ldr	x9, [sp, #0x1c0]
1001319e8:     	add	x8, x9, x8
1001319ec:     	ldr	b0, [x8]
1001319f0:     	ucvtf	s0, s0
1001319f4:     	mov	w9, #0x437f0000         ; =1132396544
1001319f8:     	fmov	s1, w9
1001319fc:     	fdiv	s3, s0, s1
100131a00:     	ldr	b0, [x8, #0x1]
100131a04:     	ucvtf	s0, s0
100131a08:     	fdiv	s0, s0, s1
100131a0c:     	str	s3, [sp, #0x3900]
100131a10:     	str	s0, [sp, #0x3904]
100131a14:     	ldr	b0, [x8, #0x2]
100131a18:     	ucvtf	s0, s0
100131a1c:     	fdiv	s0, s0, s1
100131a20:     	str	s0, [sp, #0x3908]
100131a24:     	b	0x100131c6c <_render.TerminalRenderer.drawPane+0x386c>
100131a28:     	mov	w8, #0x6b88             ; =27528
100131a2c:     	movk	w8, #0x1, lsl #16
100131a30:     	ldr	x9, [sp, #0x278]
100131a34:     	ldr	q0, [x9, x8]
100131a38:     	str	q0, [sp, #0x3750]
100131a3c:     	mov	b0, v3[4]
100131a40:     	mov.b	v0[4], v3[5]
100131a44:     	mov	b1, v3[2]
100131a48:     	mov.b	v1[4], v3[3]
100131a4c:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131a50:     	add	x8, x8, #0x750
100131a54:     	fmov	w9, s1
100131a58:     	and	w9, w9, #0xff
100131a5c:     	cmp	w9, #0x2
100131a60:     	b.ne	0x1001319c4 <_render.TerminalRenderer.drawPane+0x35c4>
100131a64:     	mov.s	w8, v1[1]
100131a68:     	and	w8, w8, #0xff
100131a6c:     	ucvtf	s1, w8
100131a70:     	mov	w8, #0x437f0000         ; =1132396544
100131a74:     	fmov	s2, w8
100131a78:     	fdiv	s3, s1, s2
100131a7c:     	str	s3, [sp, #0x3900]
100131a80:     	movi	d1, #0x0000ff000000ff
100131a84:     	and.8b	v0, v0, v1
100131a88:     	ucvtf.2s	v0, v0
100131a8c:     	ldr	d1, [sp, #0x180]
100131a90:     	fdiv.2s	v0, v0, v1
100131a94:     	b	0x100131c60 <_render.TerminalRenderer.drawPane+0x3860>
100131a98:     	ldr	s3, [x8]
100131a9c:     	ldp	s13, s10, [x8, #0x4]
100131aa0:     	ldr	s8, [x8, #0xc]
100131aa4:     	ucvtf	s14, w13
100131aa8:     	ldrb	w8, [x22, #0xd8]
100131aac:     	cbnz	w8, 0x100131c90 <_render.TerminalRenderer.drawPane+0x3890>
100131ab0:     	ldr	x8, [x22, #0xc8]
100131ab4:     	cbz	x8, 0x100131bc0 <_render.TerminalRenderer.drawPane+0x37c0>
100131ab8:     	mov	x8, #0x0                ; =0
100131abc:     	b	0x100131c20 <_render.TerminalRenderer.drawPane+0x3820>
100131ac0:     	cbz	x27, 0x10013214c <_render.TerminalRenderer.drawPane+0x3d4c>
100131ac4:     	ldr	x10, [sp, #0x3910]
100131ac8:     	ldr	x9, [sp, #0x210]
100131acc:     	add	x9, x9, #0x8
100131ad0:     	add	x10, x10, #0x8
100131ad4:     	ldr	x11, [sp, #0x230]
100131ad8:     	mov	x12, x27
100131adc:     	ldr	w13, [x11], #0x14
100131ae0:     	ldr	w14, [x8], #0x14
100131ae4:     	cmp	w13, w14
100131ae8:     	b.ne	0x100131530 <_render.TerminalRenderer.drawPane+0x3130>
100131aec:     	ldp	w14, w13, [x10, #-0x8]
100131af0:     	ldp	w16, w15, [x9, #-0x8]
100131af4:     	cmp	w16, w14
100131af8:     	ccmp	w15, w13, #0x0, eq
100131afc:     	b.ne	0x100131530 <_render.TerminalRenderer.drawPane+0x3130>
100131b00:     	ldp	w13, w14, [x9], #0x14
100131b04:     	ldp	w15, w16, [x10], #0x14
100131b08:     	cmp	w13, w15
100131b0c:     	ccmp	w14, w16, #0x0, eq
100131b10:     	b.ne	0x100131530 <_render.TerminalRenderer.drawPane+0x3130>
100131b14:     	mov	w24, #0x0               ; =0
100131b18:     	subs	x12, x12, #0x1
100131b1c:     	b.ne	0x100131adc <_render.TerminalRenderer.drawPane+0x36dc>
100131b20:     	b	0x100131534 <_render.TerminalRenderer.drawPane+0x3134>
100131b24:     	cmp	w9, #0xe7
100131b28:     	b.hi	0x100131c38 <_render.TerminalRenderer.drawPane+0x3838>
100131b2c:     	sub	w8, w8, #0x10
100131b30:     	and	w9, w8, #0xff
100131b34:     	mov	w10, #0x39              ; =57
100131b38:     	mul	w10, w9, w10
100131b3c:     	lsr	w10, w10, #11
100131b40:     	mov	w11, #0x28              ; =40
100131b44:     	mov	w12, #0x37              ; =55
100131b48:     	madd	w10, w10, w11, w12
100131b4c:     	cmp	w9, #0x24
100131b50:     	csel	w10, wzr, w10, lo
100131b54:     	and	w10, w10, #0xff
100131b58:     	mov	w11, #0xab              ; =171
100131b5c:     	mul	w9, w9, w11
100131b60:     	lsr	w9, w9, #10
100131b64:     	ucvtf	s0, w10
100131b68:     	mov	w10, #0x437f0000        ; =1132396544
100131b6c:     	fmov	s1, w10
100131b70:     	fmov	s2, w9
100131b74:     	mov.s	v2[1], w8
100131b78:     	fdiv	s3, s0, s1
100131b7c:     	movi	d0, #0x0000ff000000ff
100131b80:     	and.8b	v0, v2, v0
100131b84:     	ldr	d1, [sp, #0x118]
100131b88:     	umull.2d	v1, v0, v1
100131b8c:     	shrn.2s	v1, v1, #0x20
100131b90:     	movi.2s	v2, #0x6
100131b94:     	mls.2s	v0, v1, v2
100131b98:     	movi.2s	v1, #0x37
100131b9c:     	movi.2s	v2, #0x28
100131ba0:     	mla.2s	v1, v0, v2
100131ba4:     	cmeq.2s	v0, v0, #0
100131ba8:     	bic.8b	v0, v1, v0
100131bac:     	bic.2s	v0, #0x3, lsl #8
100131bb0:     	ucvtf.2s	v0, v0
100131bb4:     	ldr	d1, [sp, #0x180]
100131bb8:     	fdiv.2s	v0, v0, v1
100131bbc:     	b	0x100131c5c <_render.TerminalRenderer.drawPane+0x385c>
100131bc0:     	ldp	x0, x8, [x22, #0xa8]
100131bc4:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
100131bc8:     	add	x9, x9, #0x8e0
100131bcc:     	strb	wzr, [x9, #0x20]
100131bd0:     	tbnz	wzr, #0x0, 0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
100131bd4:     	str	q3, [sp, #0x60]
100131bd8:     	ldr	x8, [x8]
100131bdc:     	mov	w1, #0xa0               ; =160
100131be0:     	mov	w2, #0x2                ; =2
100131be4:     	ldr	x3, [sp, #0x188]
100131be8:     	blr	x8
100131bec:     	cbz	x0, 0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
100131bf0:     	mov	x22, x0
100131bf4:     	ldr	x19, [sp, #0x270]
100131bf8:     	ldp	x1, x8, [x19, #0xb8]
100131bfc:     	add	x8, x8, x8, lsl #2
100131c00:     	lsl	x2, x8, #4
100131c04:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100131c08:     	ldr	x8, [x19, #0xc0]
100131c0c:     	str	x22, [x19, #0xb8]
100131c10:     	mov	x22, x19
100131c14:     	mov	w9, #0x2                ; =2
100131c18:     	str	x9, [x19, #0xc8]
100131c1c:     	ldr	q3, [sp, #0x60]
100131c20:     	add	x9, x8, #0x1
100131c24:     	str	x9, [x22, #0xc0]
100131c28:     	ldr	x9, [x22, #0xb8]
100131c2c:     	mov	w10, #0x50              ; =80
100131c30:     	madd	x8, x8, x10, x9
100131c34:     	b	0x100131ca4 <_render.TerminalRenderer.drawPane+0x38a4>
100131c38:     	mov	w9, #0xa                ; =10
100131c3c:     	mov	w10, #-0x8              ; =-8
100131c40:     	madd	w8, w8, w9, w10
100131c44:     	and	w8, w8, #0xfe
100131c48:     	ucvtf	s0, w8
100131c4c:     	mov	w8, #0x437f0000         ; =1132396544
100131c50:     	fmov	s1, w8
100131c54:     	fdiv	s3, s0, s1
100131c58:     	dup.2s	v0, v3[0]
100131c5c:     	str	s3, [sp, #0x3900]
100131c60:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131c64:     	add	x8, x8, #0x8e0
100131c68:     	stur	d0, [x8, #0x24]
100131c6c:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131c70:     	add	x8, x8, #0x900
100131c74:     	mov	w9, #0x3f800000         ; =1065353216
100131c78:     	str	w9, [x8, #0xc]
100131c7c:     	ldp	s13, s10, [x8, #0x4]
100131c80:     	ldr	s8, [x8, #0xc]
100131c84:     	ucvtf	s14, w13
100131c88:     	ldrb	w8, [x22, #0xd8]
100131c8c:     	cbz	w8, 0x100131ab0 <_render.TerminalRenderer.drawPane+0x36b0>
100131c90:     	ldr	x8, [x22, #0xd0]
100131c94:     	cbz	x8, 0x100131cd8 <_render.TerminalRenderer.drawPane+0x38d8>
100131c98:     	mov	w8, #0x1                ; =1
100131c9c:     	str	x8, [x22, #0xc0]
100131ca0:     	ldr	x8, [x22, #0xb8]
100131ca4:     	stp	s9, s11, [x8]
100131ca8:     	stp	s14, s15, [x8, #0x8]
100131cac:     	movi.4s	v0, #0x3a, lsl #24
100131cb0:     	str	q0, [x8, #0x10]
100131cb4:     	stp	s3, s13, [x8, #0x20]
100131cb8:     	stp	s10, s8, [x8, #0x28]
100131cbc:     	movi.2d	v0, #0000000000000000
100131cc0:     	stp	q0, q0, [x8, #0x30]
100131cc4:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131cc8:     	add	x8, x8, #0x700
100131ccc:     	ldrb	w8, [x8, #0x4f]
100131cd0:     	cbnz	w8, 0x100131cf4 <_render.TerminalRenderer.drawPane+0x38f4>
100131cd4:     	b	0x100132044 <_render.TerminalRenderer.drawPane+0x3c44>
100131cd8:     	ldr	x8, [x22, #0xe0]
100131cdc:     	add	x8, x8, #0x1
100131ce0:     	str	x8, [x22, #0xe0]
100131ce4:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131ce8:     	add	x8, x8, #0x700
100131cec:     	ldrb	w8, [x8, #0x4f]
100131cf0:     	cbz	w8, 0x100132044 <_render.TerminalRenderer.drawPane+0x3c44>
100131cf4:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131cf8:     	add	x8, x8, #0x700
100131cfc:     	ldrh	w8, [x8, #0x30]
100131d00:     	tbnz	w8, #0x5, 0x100132044 <_render.TerminalRenderer.drawPane+0x3c44>
100131d04:     	str	x26, [sp, #0x60]
100131d08:     	mov	x26, x20
100131d0c:     	add	x24, sp, #0x3, lsl #12  ; =0x3000
100131d10:     	add	x24, x24, #0x700
100131d14:     	tbnz	w8, #0x4, 0x100131d48 <_render.TerminalRenderer.drawPane+0x3948>
100131d18:     	ldur	w8, [x24, #0x32]
100131d1c:     	str	w8, [sp, #0x377c]
100131d20:     	ldr	x19, [sp, #0x278]
100131d24:     	mov	w8, #0x6b88             ; =27528
100131d28:     	movk	w8, #0x1, lsl #16
100131d2c:     	ldr	q0, [x19, x8]
100131d30:     	str	q0, [sp, #0x3790]
100131d34:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
100131d38:     	add	x2, x2, #0x790
100131d3c:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
100131d40:     	add	x1, x1, #0x77c
100131d44:     	b	0x100131d70 <_render.TerminalRenderer.drawPane+0x3970>
100131d48:     	ldur	w8, [x24, #0x36]
100131d4c:     	str	w8, [sp, #0x3778]
100131d50:     	ldr	x8, [sp, #0x208]
100131d54:     	ldr	q0, [x8]
100131d58:     	str	q0, [sp, #0x3780]
100131d5c:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
100131d60:     	add	x2, x2, #0x780
100131d64:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
100131d68:     	add	x1, x1, #0x778
100131d6c:     	ldr	x19, [sp, #0x278]
100131d70:     	ldr	x20, [sp, #0x270]
100131d74:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
100131d78:     	add	x0, x0, #0x900
100131d7c:     	ldr	x3, [sp, #0x1c0]
100131d80:     	bl	0x10019b340 <_render.cell_colors.withPalette>
100131d84:     	ldr	x8, [sp, #0x3900]
100131d88:     	str	x8, [sp, #0x37a8]
100131d8c:     	ldr	w8, [sp, #0x3908]
100131d90:     	str	w8, [sp, #0x37b0]
100131d94:     	ldr	s0, [sp, #0x390c]
100131d98:     	ldrh	w10, [x24, #0x30]
100131d9c:     	fmov	s1, #0.50000000
100131da0:     	fmul	s1, s0, s1
100131da4:     	tst	w10, #0x4
100131da8:     	fcsel	s8, s0, s1, eq
100131dac:     	ldrb	w9, [x24, #0x4e]
100131db0:     	ldr	x11, [sp, #0x260]
100131db4:     	ldr	s0, [x11]
100131db8:     	fadd	s3, s0, s11
100131dbc:     	ldrh	w8, [x11, #0x8]
100131dc0:     	fneg	s0, s0
100131dc4:     	ldr	h1, [x11, #0x4]
100131dc8:     	ucvtf	s1, s1
100131dcc:     	ldr	h2, [x11, #0x6]
100131dd0:     	ucvtf	s2, s2
100131dd4:     	and	w11, w10, #0x1
100131dd8:     	strb	w11, [x24, #0xbe]
100131ddc:     	ubfx	w10, w10, #1, #1
100131de0:     	strb	w10, [x24, #0xbd]
100131de4:     	strb	wzr, [x24, #0xb8]
100131de8:     	ldrb	w10, [x23, #0x28]
100131dec:     	cbz	w10, 0x100131e98 <_render.TerminalRenderer.drawPane+0x3a98>
100131df0:     	ldp	q4, q5, [x23]
100131df4:     	add	x11, sp, #0x3, lsl #12  ; =0x3000
100131df8:     	add	x11, x11, #0x900
100131dfc:     	stur	q4, [x11, #0x48]
100131e00:     	stur	q5, [x11, #0x58]
100131e04:     	ldr	x10, [x23, #0x20]
100131e08:     	stur	x10, [x11, #0x68]
100131e0c:     	ldr	x10, [sp, #0x37a8]
100131e10:     	stur	x10, [x11, #0x18]
100131e14:     	ldr	w10, [sp, #0x37b0]
100131e18:     	stur	w10, [x11, #0x20]
100131e1c:     	ldrb	w10, [x24, #0xbe]
100131e20:     	ldrb	w11, [x24, #0xbd]
100131e24:     	ldrb	w12, [x24, #0xb8]
100131e28:     	ldr	x13, [sp, #0x28]
100131e2c:     	str	x13, [sp, #0x3900]
100131e30:     	str	x9, [sp, #0x3908]
100131e34:     	str	s9, [sp, #0x3910]
100131e38:     	str	s3, [sp, #0x3914]
100131e3c:     	str	s8, [sp, #0x3924]
100131e40:     	str	wzr, [sp, #0x3928]
100131e44:     	str	s0, [sp, #0x392c]
100131e48:     	str	s1, [sp, #0x3930]
100131e4c:     	str	s2, [sp, #0x3934]
100131e50:     	add	x22, sp, #0x3, lsl #12  ; =0x3000
100131e54:     	add	x22, x22, #0x8e0
100131e58:     	mov	w9, #0x1                ; =1
100131e5c:     	strb	w9, [x22, #0x58]
100131e60:     	strh	w8, [x22, #0x5c]
100131e64:     	strb	w10, [x22, #0x5e]
100131e68:     	strb	w11, [x22, #0x5f]
100131e6c:     	strb	w12, [x22, #0x60]
100131e70:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
100131e74:     	add	x0, x0, #0x8e0
100131e78:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
100131e7c:     	add	x2, x2, #0x900
100131e80:     	add	x3, x20, #0xa8
100131e84:     	mov	x1, x19
100131e88:     	bl	0x100126bb0 <_text.GlyphAtlas.paint>
100131e8c:     	ldrh	w0, [x22, #0x4]
100131e90:     	cbz	w0, 0x100131f54 <_render.TerminalRenderer.drawPane+0x3b54>
100131e94:     	b	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100131e98:     	cmp	w9, #0x1
100131e9c:     	b.ne	0x100131ecc <_render.TerminalRenderer.drawPane+0x3acc>
100131ea0:     	ldrb	w10, [x24, #0x3e]
100131ea4:     	cmp	w10, #0x20
100131ea8:     	b.ne	0x100131ecc <_render.TerminalRenderer.drawPane+0x3acc>
100131eac:     	sub	x10, x9, #0x1
100131eb0:     	ldr	x11, [sp, #0x28]
100131eb4:     	ldrb	w11, [x11, x10]
100131eb8:     	adrp	x12, 0x100687000 <___anon_33667+0x17f7>
100131ebc:     	add	x12, x12, #0x88c
100131ec0:     	ldrb	w10, [x12, x10]
100131ec4:     	cmp	w11, w10
100131ec8:     	b.eq	0x100131f54 <_render.TerminalRenderer.drawPane+0x3b54>
100131ecc:     	ldr	x10, [sp, #0x28]
100131ed0:     	str	x10, [sp, #0x37c0]
100131ed4:     	str	x9, [sp, #0x37c8]
100131ed8:     	str	s9, [sp, #0x37d0]
100131edc:     	str	s3, [sp, #0x37d4]
100131ee0:     	ldr	x9, [sp, #0x37a8]
100131ee4:     	add	x10, sp, #0x3, lsl #12  ; =0x3000
100131ee8:     	add	x10, x10, #0x7c0
100131eec:     	stur	x9, [x10, #0x18]
100131ef0:     	ldr	w9, [sp, #0x37b0]
100131ef4:     	stur	w9, [x10, #0x20]
100131ef8:     	str	s8, [sp, #0x37e4]
100131efc:     	str	wzr, [sp, #0x37e8]
100131f00:     	str	s0, [sp, #0x37ec]
100131f04:     	str	s1, [sp, #0x37f0]
100131f08:     	str	s2, [sp, #0x37f4]
100131f0c:     	mov	w9, #0x1                ; =1
100131f10:     	strb	w9, [x24, #0xf8]
100131f14:     	strh	w8, [x24, #0xfc]
100131f18:     	ldrb	w8, [x24, #0xbe]
100131f1c:     	strb	w8, [x24, #0xfe]
100131f20:     	ldrb	w8, [x24, #0xbd]
100131f24:     	strb	w8, [x24, #0xff]
100131f28:     	ldrb	w8, [x24, #0xb8]
100131f2c:     	strb	w8, [x24, #0x100]
100131f30:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
100131f34:     	add	x0, x0, #0x814
100131f38:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
100131f3c:     	add	x2, x2, #0x7c0
100131f40:     	add	x3, x20, #0xa8
100131f44:     	mov	x1, x19
100131f48:     	bl	0x100127d20 <_text.GlyphAtlas.place>
100131f4c:     	ldrh	w0, [x24, #0x118]
100131f50:     	cbnz	w0, 0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100131f54:     	ldrh	w8, [x24, #0x30]
100131f58:     	tst	w8, #0x700
100131f5c:     	b.eq	0x100131fe0 <_render.TerminalRenderer.drawPane+0x3be0>
100131f60:     	fadd	s0, s15, s11
100131f64:     	fmov	s1, #-2.00000000
100131f68:     	fadd	s0, s0, s1
100131f6c:     	str	s9, [sp, #0x381c]
100131f70:     	str	s0, [sp, #0x3820]
100131f74:     	str	s12, [sp, #0x3824]
100131f78:     	mov	w8, #0x3f800000         ; =1065353216
100131f7c:     	str	w8, [sp, #0x3828]
100131f80:     	ldur	w8, [x24, #0x3a]
100131f84:     	str	w8, [sp, #0x382c]
100131f88:     	ldr	x8, [sp, #0x37a8]
100131f8c:     	str	x8, [sp, #0x3830]
100131f90:     	ldr	w8, [sp, #0x37b0]
100131f94:     	str	w8, [sp, #0x3838]
100131f98:     	str	s8, [sp, #0x383c]
100131f9c:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
100131fa0:     	add	x0, x0, #0x840
100131fa4:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
100131fa8:     	add	x1, x1, #0x82c
100131fac:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
100131fb0:     	add	x2, x2, #0x830
100131fb4:     	ldr	x3, [sp, #0x1c0]
100131fb8:     	bl	0x10019b340 <_render.cell_colors.withPalette>
100131fbc:     	add	x0, x20, #0xa8
100131fc0:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
100131fc4:     	add	x1, x1, #0x81c
100131fc8:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
100131fcc:     	add	x2, x2, #0x840
100131fd0:     	bl	0x10012156c <_QuadList.pushRect>
100131fd4:     	ands	w0, w0, #0xffff
100131fd8:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100131fdc:     	ldrh	w8, [x24, #0x30]
100131fe0:     	mov	x20, x26
100131fe4:     	ldr	x26, [sp, #0x60]
100131fe8:     	tbz	w8, #0x6, 0x100132044 <_render.TerminalRenderer.drawPane+0x3c44>
100131fec:     	fmov	s0, #0.50000000
100131ff0:     	fmul	s0, s15, s0
100131ff4:     	fadd	s0, s0, s11
100131ff8:     	str	s9, [sp, #0x3850]
100131ffc:     	str	s0, [sp, #0x3854]
100132000:     	str	s12, [sp, #0x3858]
100132004:     	mov	w8, #0x3f800000         ; =1065353216
100132008:     	str	w8, [sp, #0x385c]
10013200c:     	ldr	x8, [sp, #0x37a8]
100132010:     	str	x8, [sp, #0x3860]
100132014:     	ldr	w8, [sp, #0x37b0]
100132018:     	str	w8, [sp, #0x3868]
10013201c:     	str	s8, [sp, #0x386c]
100132020:     	ldr	x8, [sp, #0x270]
100132024:     	add	x0, x8, #0xa8
100132028:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
10013202c:     	add	x1, x1, #0x850
100132030:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
100132034:     	add	x2, x2, #0x860
100132038:     	bl	0x10012156c <_QuadList.pushRect>
10013203c:     	ands	w0, w0, #0xffff
100132040:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100132044:     	mov	w8, #0xa0               ; =160
100132048:     	madd	x22, x21, x8, x26
10013204c:     	mov	w8, #0x6e0              ; =1760
100132050:     	madd	x21, x21, x8, x20
100132054:     	ldr	x8, [sp, #0x270]
100132058:     	ldp	x23, x19, [x8, #0xb8]
10013205c:     	cmp	x19, #0x2
100132060:     	mov	w8, #0x2                ; =2
100132064:     	csel	x20, x19, x8, lo
100132068:     	add	x8, x20, x20, lsl #2
10013206c:     	lsl	x26, x8, #4
100132070:     	mov	x0, x22
100132074:     	mov	x1, x23
100132078:     	mov	x2, x26
10013207c:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100132080:     	sub	x8, x19, x20
100132084:     	add	x8, x8, x8, lsl #2
100132088:     	lsl	x2, x8, #4
10013208c:     	add	x1, x23, x26
100132090:     	mov	x0, x21
100132094:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100132098:     	strb	w19, [x25, #0x3c]
10013209c:     	ldr	x8, [sp, #0x1a0]
1001320a0:     	str	x8, [x25]
1001320a4:     	stp	s9, s11, [x25, #0x8]
1001320a8:     	stp	s12, s15, [x25, #0x10]
1001320ac:     	ldr	q0, [sp, #0x1f0]
1001320b0:     	stur	q0, [x25, #0x18]
1001320b4:     	ldr	q0, [sp, #0x220]
1001320b8:     	stur	q0, [x25, #0x28]
1001320bc:     	mov	w8, #0x1                ; =1
1001320c0:     	strb	w8, [x25, #0x38]
1001320c4:     	ldr	x9, [sp, #0x260]
1001320c8:     	ldr	s0, [x9, #0x1ac]
1001320cc:     	ldr	s1, [x22, #0x20]
1001320d0:     	fcmp	s1, s0
1001320d4:     	b.ne	0x1001320f8 <_render.TerminalRenderer.drawPane+0x3cf8>
1001320d8:     	ldr	s0, [x9, #0x1b0]
1001320dc:     	ldr	s1, [x22, #0x24]
1001320e0:     	fcmp	s1, s0
1001320e4:     	b.ne	0x1001320f8 <_render.TerminalRenderer.drawPane+0x3cf8>
1001320e8:     	ldr	s0, [x9, #0x1b4]
1001320ec:     	ldr	s1, [x22, #0x28]
1001320f0:     	fcmp	s1, s0
1001320f4:     	cset	w8, ne
1001320f8:     	strb	w8, [x25, #0x39]
1001320fc:     	ldr	x9, [sp, #0x270]
100132100:     	ldr	x8, [x9, #0x10]
100132104:     	add	x8, x8, #0x1
100132108:     	str	x8, [x9, #0x10]
10013210c:     	add	x8, x27, x27, lsl #2
100132110:     	lsl	x8, x8, #2
100132114:     	ldr	x9, [sp, #0x230]
100132118:     	add	x9, x9, x8
10013211c:     	str	x9, [sp, #0x230]
100132120:     	ldr	x20, [sp, #0x1d0]
100132124:     	sub	x20, x20, x27
100132128:     	ldr	x9, [sp, #0x210]
10013212c:     	add	x9, x9, x8
100132130:     	str	x9, [sp, #0x210]
100132134:     	ldr	x12, [sp, #0x1e0]
100132138:     	add	x12, x12, #0x1
10013213c:     	cmp	x12, x28
100132140:     	ldr	x21, [sp, #0x260]
100132144:     	b.ne	0x10013131c <_render.TerminalRenderer.drawPane+0x2f1c>
100132148:     	b	0x100131248 <_render.TerminalRenderer.drawPane+0x2e48>
10013214c:     	mov	w24, #0x0               ; =0
100132150:     	b	0x100131534 <_render.TerminalRenderer.drawPane+0x3134>
100132154:     	and	x11, x9, #0xfffffffffffffff8
100132158:     	mov	x10, #-0x18             ; =-24
10013215c:     	madd	x12, x9, x26, x10
100132160:     	mov	w13, #0xffff            ; =65535
100132164:     	mov	x10, x9
100132168:     	b	0x1001321a4 <_render.TerminalRenderer.drawPane+0x3da4>
10013216c:     	ldurh	w15, [x13, #-0x18]
100132170:     	and	w16, w14, #0xffff
100132174:     	cmp	w15, w16
100132178:     	csel	w15, w15, w16, lo
10013217c:     	cmp	w15, w8, uxth
100132180:     	cset	w15, lo
100132184:     	ldurb	w16, [x13, #-0x15]
100132188:     	cmp	w16, #0x0
10013218c:     	sturb	w15, [x13, #-0x14]
100132190:     	csinv	w13, w14, wzr, ne
100132194:     	sub	x12, x12, #0x30
100132198:     	sub	x10, x10, #0x8
10013219c:     	sub	x11, x11, #0x8
1001321a0:     	cbz	x11, 0x10012f2bc <_render.TerminalRenderer.drawPane+0xebc>
1001321a4:     	ldr	x14, [x22, #0x28]
1001321a8:     	add	x14, x14, x12
1001321ac:     	ldrb	w15, [x14, #0x14]
1001321b0:     	and	w16, w15, #0x3
1001321b4:     	and	w13, w13, #0xffff
1001321b8:     	add	w15, w13, #0x1
1001321bc:     	cmp	w15, w27
1001321c0:     	csinc	w13, w27, w13, hs
1001321c4:     	cmp	w16, #0x2
1001321c8:     	csel	w15, wzr, w13, eq
1001321cc:     	cbz	w16, 0x1001321ec <_render.TerminalRenderer.drawPane+0x3dec>
1001321d0:     	ldrh	w13, [x14, #0x12]
1001321d4:     	and	w16, w15, #0xffff
1001321d8:     	cmp	w13, w16
1001321dc:     	csel	w13, w13, w16, lo
1001321e0:     	cmp	w13, w8, uxth
1001321e4:     	cset	w13, lo
1001321e8:     	b	0x1001321f0 <_render.TerminalRenderer.drawPane+0x3df0>
1001321ec:     	mov	w13, #0x0               ; =0
1001321f0:     	strb	w13, [x14, #0x16]
1001321f4:     	ldrb	w14, [x14, #0x15]
1001321f8:     	ldr	x13, [x22, #0x28]
1001321fc:     	add	x13, x13, x12
100132200:     	ldrb	w16, [x13, #0xe]
100132204:     	and	w16, w16, #0x3
100132208:     	and	w15, w15, #0xffff
10013220c:     	add	w17, w15, #0x1
100132210:     	cmp	w17, w27
100132214:     	csinc	w15, w27, w15, hs
100132218:     	cmp	w14, #0x0
10013221c:     	csinv	w14, w15, wzr, ne
100132220:     	cmp	w16, #0x2
100132224:     	csel	w14, wzr, w14, eq
100132228:     	cbz	w16, 0x100132248 <_render.TerminalRenderer.drawPane+0x3e48>
10013222c:     	ldrh	w15, [x13, #0xc]
100132230:     	and	w16, w14, #0xffff
100132234:     	cmp	w15, w16
100132238:     	csel	w15, w15, w16, lo
10013223c:     	cmp	w15, w8, uxth
100132240:     	cset	w15, lo
100132244:     	b	0x10013224c <_render.TerminalRenderer.drawPane+0x3e4c>
100132248:     	mov	w15, #0x0               ; =0
10013224c:     	strb	w15, [x13, #0x10]
100132250:     	ldrb	w15, [x13, #0xf]
100132254:     	ldr	x13, [x22, #0x28]
100132258:     	add	x13, x13, x12
10013225c:     	ldrb	w16, [x13, #0x8]
100132260:     	and	w16, w16, #0x3
100132264:     	and	w14, w14, #0xffff
100132268:     	add	w17, w14, #0x1
10013226c:     	cmp	w17, w27
100132270:     	csinc	w14, w27, w14, hs
100132274:     	cmp	w15, #0x0
100132278:     	csinv	w14, w14, wzr, ne
10013227c:     	cmp	w16, #0x2
100132280:     	csel	w14, wzr, w14, eq
100132284:     	cbz	w16, 0x1001322a4 <_render.TerminalRenderer.drawPane+0x3ea4>
100132288:     	ldrh	w15, [x13, #0x6]
10013228c:     	and	w16, w14, #0xffff
100132290:     	cmp	w15, w16
100132294:     	csel	w15, w15, w16, lo
100132298:     	cmp	w15, w8, uxth
10013229c:     	cset	w15, lo
1001322a0:     	b	0x1001322a8 <_render.TerminalRenderer.drawPane+0x3ea8>
1001322a4:     	mov	w15, #0x0               ; =0
1001322a8:     	strb	w15, [x13, #0xa]
1001322ac:     	ldrb	w16, [x13, #0x9]
1001322b0:     	ldr	x15, [x22, #0x28]
1001322b4:     	add	x13, x15, x12
1001322b8:     	ldrb	w17, [x13, #0x2]
1001322bc:     	and	w17, w17, #0x3
1001322c0:     	and	w14, w14, #0xffff
1001322c4:     	add	w0, w14, #0x1
1001322c8:     	cmp	w0, w27
1001322cc:     	csinc	w14, w27, w14, hs
1001322d0:     	cmp	w16, #0x0
1001322d4:     	csinv	w14, w14, wzr, ne
1001322d8:     	cmp	w17, #0x2
1001322dc:     	csel	w14, wzr, w14, eq
1001322e0:     	cbz	w17, 0x100132300 <_render.TerminalRenderer.drawPane+0x3f00>
1001322e4:     	ldrh	w15, [x15, x12]
1001322e8:     	and	w16, w14, #0xffff
1001322ec:     	cmp	w15, w16
1001322f0:     	csel	w15, w15, w16, lo
1001322f4:     	cmp	w15, w8, uxth
1001322f8:     	cset	w15, lo
1001322fc:     	b	0x100132304 <_render.TerminalRenderer.drawPane+0x3f04>
100132300:     	mov	w15, #0x0               ; =0
100132304:     	strb	w15, [x13, #0x4]
100132308:     	ldrb	w15, [x13, #0x3]
10013230c:     	ldr	x13, [x22, #0x28]
100132310:     	add	x13, x13, x12
100132314:     	ldurb	w16, [x13, #-0x4]
100132318:     	and	w16, w16, #0x3
10013231c:     	and	w14, w14, #0xffff
100132320:     	add	w17, w14, #0x1
100132324:     	cmp	w17, w27
100132328:     	csinc	w14, w27, w14, hs
10013232c:     	cmp	w15, #0x0
100132330:     	csinv	w14, w14, wzr, ne
100132334:     	cmp	w16, #0x2
100132338:     	csel	w14, wzr, w14, eq
10013233c:     	cbz	w16, 0x10013235c <_render.TerminalRenderer.drawPane+0x3f5c>
100132340:     	ldurh	w15, [x13, #-0x6]
100132344:     	and	w16, w14, #0xffff
100132348:     	cmp	w15, w16
10013234c:     	csel	w15, w15, w16, lo
100132350:     	cmp	w15, w8, uxth
100132354:     	cset	w15, lo
100132358:     	b	0x100132360 <_render.TerminalRenderer.drawPane+0x3f60>
10013235c:     	mov	w15, #0x0               ; =0
100132360:     	sturb	w15, [x13, #-0x2]
100132364:     	ldurb	w15, [x13, #-0x3]
100132368:     	ldr	x13, [x22, #0x28]
10013236c:     	add	x13, x13, x12
100132370:     	ldurb	w16, [x13, #-0xa]
100132374:     	and	w16, w16, #0x3
100132378:     	and	w14, w14, #0xffff
10013237c:     	add	w17, w14, #0x1
100132380:     	cmp	w17, w27
100132384:     	csinc	w14, w27, w14, hs
100132388:     	cmp	w15, #0x0
10013238c:     	csinv	w14, w14, wzr, ne
100132390:     	cmp	w16, #0x2
100132394:     	csel	w14, wzr, w14, eq
100132398:     	cbz	w16, 0x1001323b8 <_render.TerminalRenderer.drawPane+0x3fb8>
10013239c:     	ldurh	w15, [x13, #-0xc]
1001323a0:     	and	w16, w14, #0xffff
1001323a4:     	cmp	w15, w16
1001323a8:     	csel	w15, w15, w16, lo
1001323ac:     	cmp	w15, w8, uxth
1001323b0:     	cset	w15, lo
1001323b4:     	b	0x1001323bc <_render.TerminalRenderer.drawPane+0x3fbc>
1001323b8:     	mov	w15, #0x0               ; =0
1001323bc:     	sturb	w15, [x13, #-0x8]
1001323c0:     	ldurb	w15, [x13, #-0x9]
1001323c4:     	ldr	x13, [x22, #0x28]
1001323c8:     	add	x13, x13, x12
1001323cc:     	ldurb	w16, [x13, #-0x10]
1001323d0:     	and	w16, w16, #0x3
1001323d4:     	and	w14, w14, #0xffff
1001323d8:     	add	w17, w14, #0x1
1001323dc:     	cmp	w17, w27
1001323e0:     	csinc	w14, w27, w14, hs
1001323e4:     	cmp	w15, #0x0
1001323e8:     	csinv	w14, w14, wzr, ne
1001323ec:     	cmp	w16, #0x2
1001323f0:     	csel	w14, wzr, w14, eq
1001323f4:     	cbz	w16, 0x100132414 <_render.TerminalRenderer.drawPane+0x4014>
1001323f8:     	ldurh	w15, [x13, #-0x12]
1001323fc:     	and	w16, w14, #0xffff
100132400:     	cmp	w15, w16
100132404:     	csel	w15, w15, w16, lo
100132408:     	cmp	w15, w8, uxth
10013240c:     	cset	w15, lo
100132410:     	b	0x100132418 <_render.TerminalRenderer.drawPane+0x4018>
100132414:     	mov	w15, #0x0               ; =0
100132418:     	sturb	w15, [x13, #-0xe]
10013241c:     	ldurb	w15, [x13, #-0xf]
100132420:     	ldr	x13, [x22, #0x28]
100132424:     	add	x13, x13, x12
100132428:     	ldurb	w16, [x13, #-0x16]
10013242c:     	and	w16, w16, #0x3
100132430:     	and	w14, w14, #0xffff
100132434:     	add	w17, w14, #0x1
100132438:     	cmp	w17, w27
10013243c:     	csinc	w14, w27, w14, hs
100132440:     	cmp	w15, #0x0
100132444:     	csinv	w14, w14, wzr, ne
100132448:     	cmp	w16, #0x2
10013244c:     	csel	w14, wzr, w14, eq
100132450:     	cbnz	w16, 0x10013216c <_render.TerminalRenderer.drawPane+0x3d6c>
100132454:     	mov	w15, #0x0               ; =0
100132458:     	b	0x100132184 <_render.TerminalRenderer.drawPane+0x3d84>
10013245c:     	str	xzr, [sp, #0x1a0]
100132460:     	str	xzr, [sp, #0x230]
100132464:     	add	x10, sp, #0x490
100132468:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10013246c:     	add	x9, x9, #0x870
100132470:     	orr	x10, x10, #0x4
100132474:     	orr	x9, x9, #0x4
100132478:     	stp	x10, x9, [sp, #0x178]
10013247c:     	add	x9, x25, #0xe
100132480:     	str	x9, [sp, #0x1d0]
100132484:     	fmov	s15, #0.50000000
100132488:     	ldr	q0, [x8, #0xaf0]
10013248c:     	str	q0, [sp, #0x1b0]
100132490:     	b	0x1001324b8 <_render.TerminalRenderer.drawPane+0x40b8>
100132494:     	ldr	x9, [sp, #0x230]
100132498:     	add	x9, x9, #0x1
10013249c:     	ldr	x8, [sp, #0x1a0]
1001324a0:     	add	x8, x8, #0x20
1001324a4:     	str	x8, [sp, #0x1a0]
1001324a8:     	ldr	x8, [sp, #0x128]
1001324ac:     	str	x9, [sp, #0x230]
1001324b0:     	cmp	x9, x8
1001324b4:     	b.eq	0x10013322c <_render.TerminalRenderer.drawPane+0x4e2c>
1001324b8:     	ldr	x10, [x23]
1001324bc:     	ldrh	w9, [x23, #0x1c]
1001324c0:     	ldrh	w8, [x10, #0x50]
1001324c4:     	cmp	w9, w8
1001324c8:     	csel	w9, w9, w8, lo
1001324cc:     	ldr	x22, [sp, #0x270]
1001324d0:     	cbz	w9, 0x100132494 <_render.TerminalRenderer.drawPane+0x4094>
1001324d4:     	mov	x28, #0x0               ; =0
1001324d8:     	mov	x27, #0x0               ; =0
1001324dc:     	ldrh	w11, [x23, #0x18]
1001324e0:     	ldrh	w12, [x23, #0x1a]
1001324e4:     	ldr	x10, [x10, #0x30]
1001324e8:     	ldr	x16, [sp, #0x170]
1001324ec:     	ldrh	w13, [x16, #0x48]
1001324f0:     	ldr	x14, [x16]
1001324f4:     	ldr	x15, [x16, #0x18]
1001324f8:     	ldr	x17, [sp, #0x230]
1001324fc:     	add	x12, x17, x12
100132500:     	madd	x11, x12, x13, x11
100132504:     	ldr	x12, [x16, #0x30]
100132508:     	and	w13, w17, #0xffff
10013250c:     	str	w13, [sp, #0x1c8]
100132510:     	lsl	x9, x9, #6
100132514:     	str	x9, [sp, #0x220]
100132518:     	add	x9, x14, x11, lsl #6
10013251c:     	str	x9, [sp, #0x298]
100132520:     	mov	w9, #0x6e0              ; =1760
100132524:     	madd	x25, x11, x9, x12
100132528:     	mov	w9, #0xa0               ; =160
10013252c:     	madd	x26, x11, x9, x15
100132530:     	ldr	x9, [sp, #0x1a0]
100132534:     	madd	x20, x9, x8, x10
100132538:     	b	0x100132598 <_render.TerminalRenderer.drawPane+0x4198>
10013253c:     	add	x9, x8, #0x1
100132540:     	str	x9, [x22, #0x80]
100132544:     	ldr	x9, [x22, #0x78]
100132548:     	mov	w10, #0x50              ; =80
10013254c:     	madd	x8, x8, x10, x9
100132550:     	ldr	q0, [sp, #0x22f0]
100132554:     	str	q0, [x8, #0x10]
100132558:     	ldr	q0, [sp, #0x2300]
10013255c:     	str	q0, [x8, #0x20]
100132560:     	ldr	q0, [sp, #0x2310]
100132564:     	str	q0, [x8, #0x30]
100132568:     	ldr	q0, [sp, #0x2320]
10013256c:     	str	q0, [x8, #0x40]
100132570:     	ldr	q0, [sp, #0x22e0]
100132574:     	str	q0, [x8]
100132578:     	add	x27, x27, #0x1
10013257c:     	add	x28, x28, #0x40
100132580:     	add	x25, x25, #0x6e0
100132584:     	add	x26, x26, #0xa0
100132588:     	add	x20, x20, #0x20
10013258c:     	ldr	x8, [sp, #0x220]
100132590:     	cmp	x8, x28
100132594:     	b.eq	0x100132494 <_render.TerminalRenderer.drawPane+0x4094>
100132598:     	ldrb	w10, [x23, #0x40]
10013259c:     	ldr	x8, [x23]
1001325a0:     	mov	x9, x20
1001325a4:     	cbz	w10, 0x1001326a4 <_render.TerminalRenderer.drawPane+0x42a4>
1001325a8:     	ldrb	w10, [x23, #0x38]
1001325ac:     	mov	x9, x20
1001325b0:     	cbz	w10, 0x1001326a4 <_render.TerminalRenderer.drawPane+0x42a4>
1001325b4:     	ldr	w10, [x23, #0x28]
1001325b8:     	ldr	x9, [x23, #0x30]
1001325bc:     	ldrb	w12, [x23, #0x3d]
1001325c0:     	ldr	w11, [x8, #0xfc]
1001325c4:     	ldr	w13, [sp, #0x1c8]
1001325c8:     	add	w11, w11, w13
1001325cc:     	tbz	w12, #0x0, 0x10013261c <_render.TerminalRenderer.drawPane+0x421c>
1001325d0:     	cmp	w9, w10
1001325d4:     	csel	w12, w9, w10, lo
1001325d8:     	csel	w9, w9, w10, hi
1001325dc:     	cmp	w11, w12
1001325e0:     	ccmp	w11, w9, #0x2, hs
1001325e4:     	mov	x9, x20
1001325e8:     	b.hi	0x1001326a4 <_render.TerminalRenderer.drawPane+0x42a4>
1001325ec:     	ldr	q0, [x20]
1001325f0:     	str	q0, [sp, #0x3900]
1001325f4:     	ldr	q0, [x20, #0x10]
1001325f8:     	str	q0, [sp, #0x3910]
1001325fc:     	add	x10, sp, #0x3, lsl #12  ; =0x3000
100132600:     	add	x10, x10, #0x8e0
100132604:     	ldrh	w9, [x10, #0x20]
100132608:     	eor	w9, w9, #0x10
10013260c:     	strh	w9, [x10, #0x20]
100132610:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
100132614:     	add	x9, x9, #0x900
100132618:     	b	0x1001326a4 <_render.TerminalRenderer.drawPane+0x42a4>
10013261c:     	ldr	w12, [x23, #0x2c]
100132620:     	lsr	x13, x9, #32
100132624:     	cmp	w10, w9
100132628:     	b.lo	0x100132640 <_render.TerminalRenderer.drawPane+0x4240>
10013262c:     	cmp	w10, w9
100132630:     	b.ne	0x100132664 <_render.TerminalRenderer.drawPane+0x4264>
100132634:     	and	w14, w12, #0xffff
100132638:     	cmp	w14, w13, uxth
10013263c:     	b.hs	0x100132664 <_render.TerminalRenderer.drawPane+0x4264>
100132640:     	mov	x0, x13
100132644:     	mov	x13, x12
100132648:     	mov	x12, x0
10013264c:     	mov	x14, x10
100132650:     	mov	x10, x9
100132654:     	mov	x9, x20
100132658:     	cmp	w11, w14
10013265c:     	b.hs	0x100132674 <_render.TerminalRenderer.drawPane+0x4274>
100132660:     	b	0x1001326a4 <_render.TerminalRenderer.drawPane+0x42a4>
100132664:     	mov	x14, x9
100132668:     	mov	x9, x20
10013266c:     	cmp	w11, w14
100132670:     	b.lo	0x1001326a4 <_render.TerminalRenderer.drawPane+0x42a4>
100132674:     	and	w9, w27, #0xffff
100132678:     	cmp	w9, w13, uxth
10013267c:     	ccmp	w11, w14, #0x0, lo
100132680:     	ccmp	w10, w11, #0x0, ne
100132684:     	mov	x9, x20
100132688:     	b.lo	0x1001326a4 <_render.TerminalRenderer.drawPane+0x42a4>
10013268c:     	cmp	w10, w11
100132690:     	b.ne	0x1001325ec <_render.TerminalRenderer.drawPane+0x41ec>
100132694:     	and	w9, w27, #0xffff
100132698:     	cmp	w9, w12, uxth
10013269c:     	mov	x9, x20
1001326a0:     	b.ls	0x1001325ec <_render.TerminalRenderer.drawPane+0x41ec>
1001326a4:     	ldrb	w10, [x9, #0x1f]
1001326a8:     	ldrh	w11, [x23, #0x18]
1001326ac:     	ldrh	w12, [x23, #0x1a]
1001326b0:     	add	w11, w11, w27, uxth
1001326b4:     	ldr	x13, [sp, #0x230]
1001326b8:     	add	w12, w12, w13
1001326bc:     	cmp	w10, #0x1
1001326c0:     	csinc	w10, w10, wzr, hi
1001326c4:     	ldrh	w13, [x23, #0x1c]
1001326c8:     	ldrh	w8, [x8, #0x50]
1001326cc:     	cmp	w13, w8
1001326d0:     	csel	w8, w13, w8, lo
1001326d4:     	sub	w8, w8, w27
1001326d8:     	and	w8, w8, #0xffff
1001326dc:     	cmp	w10, w8
1001326e0:     	csel	w10, w10, w8, lo
1001326e4:     	ldrh	w8, [x21, #0x4]
1001326e8:     	ldrh	w13, [x21, #0x6]
1001326ec:     	ldr	x15, [sp, #0x240]
1001326f0:     	ldp	w15, w14, [x15]
1001326f4:     	madd	w11, w8, w11, w15
1001326f8:     	ucvtf	s13, w11
1001326fc:     	madd	w11, w13, w12, w14
100132700:     	ucvtf	s14, w11
100132704:     	mul	w10, w10, w8
100132708:     	ucvtf	s0, w10
10013270c:     	str	s0, [sp, #0x280]
100132710:     	ucvtf	s10, w13
100132714:     	ldr	x10, [sp, #0x298]
100132718:     	add	x23, x10, x28
10013271c:     	ldrb	w10, [x23, #0x38]
100132720:     	cmp	w10, #0x1
100132724:     	b.ne	0x100132790 <_render.TerminalRenderer.drawPane+0x4390>
100132728:     	ldr	s0, [x23, #0x8]
10013272c:     	fcmp	s0, s13
100132730:     	b.ne	0x100132790 <_render.TerminalRenderer.drawPane+0x4390>
100132734:     	ldr	x10, [sp, #0x298]
100132738:     	add	x10, x10, x28
10013273c:     	ldr	s0, [x10, #0xc]
100132740:     	fcmp	s0, s14
100132744:     	b.ne	0x100132790 <_render.TerminalRenderer.drawPane+0x4390>
100132748:     	ldr	s0, [x10, #0x10]
10013274c:     	ldr	s1, [sp, #0x280]
100132750:     	fcmp	s0, s1
100132754:     	b.ne	0x100132790 <_render.TerminalRenderer.drawPane+0x4390>
100132758:     	ldr	x10, [sp, #0x298]
10013275c:     	add	x10, x10, x28
100132760:     	ldr	s0, [x10, #0x14]
100132764:     	fcmp	s0, s10
100132768:     	b.ne	0x100132790 <_render.TerminalRenderer.drawPane+0x4390>
10013276c:     	ldur	q0, [x10, #0x18]
100132770:     	ldur	q1, [x10, #0x28]
100132774:     	ldp	q2, q3, [x9]
100132778:     	eor.16b	v0, v2, v0
10013277c:     	eor.16b	v1, v3, v1
100132780:     	orr.16b	v0, v1, v0
100132784:     	umaxv.16b	b0, v0
100132788:     	fmov	w10, s0
10013278c:     	cbz	w10, 0x10013316c <_render.TerminalRenderer.drawPane+0x4d6c>
100132790:     	ldp	q0, q1, [x9]
100132794:     	str	q1, [sp, #0xcf0]
100132798:     	str	q0, [sp, #0xce0]
10013279c:     	ldp	q1, q0, [x9]
1001327a0:     	str	q1, [sp, #0x4e0]
1001327a4:     	str	q0, [sp, #0x4f0]
1001327a8:     	str	xzr, [x22, #0xc0]
1001327ac:     	ldrb	w9, [sp, #0x4e0]
1001327b0:     	tbnz	w9, #0x4, 0x100132834 <_render.TerminalRenderer.drawPane+0x4434>
1001327b4:     	ldrb	w11, [sp, #0x4e6]
1001327b8:     	ldrb	w10, [sp, #0x4e7]
1001327bc:     	ldrb	w12, [sp, #0x4e8]
1001327c0:     	ldrb	w13, [sp, #0x4e9]
1001327c4:     	ldr	x9, [sp, #0x208]
1001327c8:     	ldr	q0, [x9]
1001327cc:     	str	q0, [sp, #0x3700]
1001327d0:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
1001327d4:     	add	x9, x9, #0x700
1001327d8:     	cmp	w11, #0x2
1001327dc:     	b.eq	0x100132868 <_render.TerminalRenderer.drawPane+0x4468>
1001327e0:     	cmp	w11, #0x1
1001327e4:     	b.ne	0x100132898 <_render.TerminalRenderer.drawPane+0x4498>
1001327e8:     	subs	w9, w10, #0x10
1001327ec:     	b.hs	0x1001328c8 <_render.TerminalRenderer.drawPane+0x44c8>
1001327f0:     	mov	w9, w10
1001327f4:     	add	x9, x9, w10, uxtw #1
1001327f8:     	ldr	x10, [sp, #0x1c0]
1001327fc:     	add	x9, x10, x9
100132800:     	ldr	b0, [x9]
100132804:     	ucvtf	s0, s0
100132808:     	mov	w10, #0x437f0000        ; =1132396544
10013280c:     	fmov	s1, w10
100132810:     	fdiv	s3, s0, s1
100132814:     	ldr	b0, [x9, #0x1]
100132818:     	ucvtf	s0, s0
10013281c:     	fdiv	s0, s0, s1
100132820:     	str	s3, [sp, #0x490]
100132824:     	str	s0, [sp, #0x494]
100132828:     	ldr	b0, [x9, #0x2]
10013282c:     	ucvtf	s0, s0
100132830:     	b	0x10013288c <_render.TerminalRenderer.drawPane+0x448c>
100132834:     	ldrb	w11, [sp, #0x4e2]
100132838:     	ldrb	w10, [sp, #0x4e3]
10013283c:     	ldrb	w12, [sp, #0x4e4]
100132840:     	ldrb	w13, [sp, #0x4e5]
100132844:     	mov	w9, #0x6b88             ; =27528
100132848:     	movk	w9, #0x1, lsl #16
10013284c:     	ldr	x14, [sp, #0x278]
100132850:     	ldr	q0, [x14, x9]
100132854:     	str	q0, [sp, #0x38e0]
100132858:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10013285c:     	add	x9, x9, #0x8e0
100132860:     	cmp	w11, #0x2
100132864:     	b.ne	0x1001327e0 <_render.TerminalRenderer.drawPane+0x43e0>
100132868:     	ucvtf	s0, w10
10013286c:     	mov	w9, #0x437f0000         ; =1132396544
100132870:     	fmov	s1, w9
100132874:     	fdiv	s3, s0, s1
100132878:     	ucvtf	s0, w12
10013287c:     	fdiv	s0, s0, s1
100132880:     	str	s3, [sp, #0x490]
100132884:     	str	s0, [sp, #0x494]
100132888:     	ucvtf	s0, w13
10013288c:     	fdiv	s0, s0, s1
100132890:     	str	s0, [sp, #0x498]
100132894:     	b	0x1001329d4 <_render.TerminalRenderer.drawPane+0x45d4>
100132898:     	ldr	s3, [x9]
10013289c:     	ldp	s11, s9, [x9, #0x4]
1001328a0:     	ldr	s8, [x9, #0xc]
1001328a4:     	ucvtf	s12, w8
1001328a8:     	ldrb	w8, [x22, #0xd8]
1001328ac:     	cbnz	w8, 0x1001329f4 <_render.TerminalRenderer.drawPane+0x45f4>
1001328b0:     	ldur	q0, [x22, #0xa8]
1001328b4:     	str	q0, [sp, #0x490]
1001328b8:     	ldr	x8, [x22, #0xc8]
1001328bc:     	cbz	x8, 0x100132968 <_render.TerminalRenderer.drawPane+0x4568>
1001328c0:     	mov	x8, #0x0                ; =0
1001328c4:     	b	0x10013298c <_render.TerminalRenderer.drawPane+0x458c>
1001328c8:     	cmp	w10, #0xe8
1001328cc:     	b.hs	0x1001329a4 <_render.TerminalRenderer.drawPane+0x45a4>
1001328d0:     	and	w10, w9, #0xff
1001328d4:     	mov	w11, #0x39              ; =57
1001328d8:     	mul	w11, w10, w11
1001328dc:     	lsr	w11, w11, #11
1001328e0:     	mov	w12, #0x28              ; =40
1001328e4:     	mov	w13, #0x37              ; =55
1001328e8:     	madd	w11, w11, w12, w13
1001328ec:     	cmp	w9, #0x24
1001328f0:     	csel	w11, wzr, w11, lo
1001328f4:     	and	w11, w11, #0xff
1001328f8:     	mov	w12, #0xab              ; =171
1001328fc:     	mul	w10, w10, w12
100132900:     	lsr	w10, w10, #10
100132904:     	ucvtf	s0, w11
100132908:     	mov	w11, #0x437f0000        ; =1132396544
10013290c:     	fmov	s1, w11
100132910:     	fdiv	s3, s0, s1
100132914:     	fmov	s0, w10
100132918:     	mov.s	v0[1], w9
10013291c:     	movi	d1, #0x0000ff000000ff
100132920:     	and.8b	v0, v0, v1
100132924:     	mov	w9, #0xaaab             ; =43691
100132928:     	movk	w9, #0x2aaa, lsl #16
10013292c:     	dup.2s	v1, w9
100132930:     	umull.2d	v1, v0, v1
100132934:     	shrn.2s	v1, v1, #0x20
100132938:     	movi.2s	v2, #0x6
10013293c:     	mls.2s	v0, v1, v2
100132940:     	movi.2s	v1, #0x37
100132944:     	movi.2s	v2, #0x28
100132948:     	mla.2s	v1, v0, v2
10013294c:     	cmeq.2s	v0, v0, #0
100132950:     	bic.8b	v0, v1, v0
100132954:     	bic.2s	v0, #0x3, lsl #8
100132958:     	ucvtf.2s	v0, v0
10013295c:     	dup.2s	v1, w11
100132960:     	fdiv.2s	v0, v0, v1
100132964:     	b	0x1001329c8 <_render.TerminalRenderer.drawPane+0x45c8>
100132968:     	str	q3, [sp, #0x210]
10013296c:     	add	x0, x22, #0xb8
100132970:     	add	x1, sp, #0x490
100132974:     	mov	w2, #0x2                ; =2
100132978:     	bl	0x1001ae678 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
10013297c:     	ands	w0, w0, #0xffff
100132980:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100132984:     	ldr	x8, [x22, #0xc0]
100132988:     	ldr	q3, [sp, #0x210]
10013298c:     	add	x9, x8, #0x1
100132990:     	str	x9, [x22, #0xc0]
100132994:     	ldr	x9, [x22, #0xb8]
100132998:     	mov	w10, #0x50              ; =80
10013299c:     	madd	x8, x8, x10, x9
1001329a0:     	b	0x100132a08 <_render.TerminalRenderer.drawPane+0x4608>
1001329a4:     	mov	w9, #0xa                ; =10
1001329a8:     	mov	w11, #-0x8              ; =-8
1001329ac:     	madd	w9, w10, w9, w11
1001329b0:     	and	w9, w9, #0xfe
1001329b4:     	ucvtf	s0, w9
1001329b8:     	mov	w9, #0x437f0000         ; =1132396544
1001329bc:     	fmov	s1, w9
1001329c0:     	fdiv	s3, s0, s1
1001329c4:     	dup.2s	v0, v3[0]
1001329c8:     	str	s3, [sp, #0x490]
1001329cc:     	add	x9, sp, #0x490
1001329d0:     	stur	d0, [x9, #0x4]
1001329d4:     	add	x9, sp, #0x490
1001329d8:     	mov	w10, #0x3f800000        ; =1065353216
1001329dc:     	str	w10, [x9, #0xc]
1001329e0:     	ldp	s11, s9, [x9, #0x4]
1001329e4:     	ldr	s8, [x9, #0xc]
1001329e8:     	ucvtf	s12, w8
1001329ec:     	ldrb	w8, [x22, #0xd8]
1001329f0:     	cbz	w8, 0x1001328b0 <_render.TerminalRenderer.drawPane+0x44b0>
1001329f4:     	ldr	x8, [x22, #0xd0]
1001329f8:     	cbz	x8, 0x100132a34 <_render.TerminalRenderer.drawPane+0x4634>
1001329fc:     	mov	w8, #0x1                ; =1
100132a00:     	str	x8, [x22, #0xc0]
100132a04:     	ldr	x8, [x22, #0xb8]
100132a08:     	stp	s13, s14, [x8]
100132a0c:     	stp	s12, s10, [x8, #0x8]
100132a10:     	movi.4s	v0, #0x3a, lsl #24
100132a14:     	str	q0, [x8, #0x10]
100132a18:     	stp	s3, s11, [x8, #0x20]
100132a1c:     	stp	s9, s8, [x8, #0x28]
100132a20:     	movi.2d	v0, #0000000000000000
100132a24:     	stp	q0, q0, [x8, #0x30]
100132a28:     	ldrb	w8, [sp, #0x4ff]
100132a2c:     	cbnz	w8, 0x100132a48 <_render.TerminalRenderer.drawPane+0x4648>
100132a30:     	b	0x1001330b0 <_render.TerminalRenderer.drawPane+0x4cb0>
100132a34:     	ldr	x8, [x22, #0xe0]
100132a38:     	add	x8, x8, #0x1
100132a3c:     	str	x8, [x22, #0xe0]
100132a40:     	ldrb	w8, [sp, #0x4ff]
100132a44:     	cbz	w8, 0x1001330b0 <_render.TerminalRenderer.drawPane+0x4cb0>
100132a48:     	ldrh	w8, [sp, #0x4e0]
100132a4c:     	tbnz	w8, #0x5, 0x1001330b0 <_render.TerminalRenderer.drawPane+0x4cb0>
100132a50:     	tbnz	w8, #0x4, 0x100132adc <_render.TerminalRenderer.drawPane+0x46dc>
100132a54:     	ldrb	w11, [sp, #0x4e2]
100132a58:     	ldrb	w10, [sp, #0x4e3]
100132a5c:     	ldrb	w12, [sp, #0x4e4]
100132a60:     	ldrb	w13, [sp, #0x4e5]
100132a64:     	mov	w9, #0x6b88             ; =27528
100132a68:     	movk	w9, #0x1, lsl #16
100132a6c:     	ldr	x14, [sp, #0x278]
100132a70:     	ldr	q0, [x14, x9]
100132a74:     	str	q0, [sp, #0x37c0]
100132a78:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
100132a7c:     	add	x9, x9, #0x7c0
100132a80:     	cmp	w11, #0x2
100132a84:     	b.eq	0x100132b04 <_render.TerminalRenderer.drawPane+0x4704>
100132a88:     	cmp	w11, #0x1
100132a8c:     	b.ne	0x100132b34 <_render.TerminalRenderer.drawPane+0x4734>
100132a90:     	subs	w9, w10, #0x10
100132a94:     	b.hs	0x100132b3c <_render.TerminalRenderer.drawPane+0x473c>
100132a98:     	mov	w9, w10
100132a9c:     	add	x9, x9, w10, uxtw #1
100132aa0:     	ldr	x10, [sp, #0x1c0]
100132aa4:     	add	x9, x10, x9
100132aa8:     	ldr	b0, [x9]
100132aac:     	ucvtf	s0, s0
100132ab0:     	mov	w10, #0x437f0000        ; =1132396544
100132ab4:     	fmov	s1, w10
100132ab8:     	fdiv	s4, s0, s1
100132abc:     	ldr	b0, [x9, #0x1]
100132ac0:     	ucvtf	s0, s0
100132ac4:     	fdiv	s0, s0, s1
100132ac8:     	str	s4, [sp, #0x490]
100132acc:     	str	s0, [sp, #0x494]
100132ad0:     	ldr	b0, [x9, #0x2]
100132ad4:     	ucvtf	s0, s0
100132ad8:     	b	0x100132b28 <_render.TerminalRenderer.drawPane+0x4728>
100132adc:     	ldrb	w11, [sp, #0x4e6]
100132ae0:     	ldrb	w10, [sp, #0x4e7]
100132ae4:     	ldrb	w12, [sp, #0x4e8]
100132ae8:     	ldrb	w13, [sp, #0x4e9]
100132aec:     	ldr	x9, [sp, #0x208]
100132af0:     	ldr	q0, [x9]
100132af4:     	str	q0, [sp, #0x440]
100132af8:     	add	x9, sp, #0x440
100132afc:     	cmp	w11, #0x2
100132b00:     	b.ne	0x100132a88 <_render.TerminalRenderer.drawPane+0x4688>
100132b04:     	ucvtf	s0, w10
100132b08:     	mov	w9, #0x437f0000         ; =1132396544
100132b0c:     	fmov	s1, w9
100132b10:     	fdiv	s4, s0, s1
100132b14:     	ucvtf	s0, w12
100132b18:     	fdiv	s0, s0, s1
100132b1c:     	str	s4, [sp, #0x490]
100132b20:     	str	s0, [sp, #0x494]
100132b24:     	ucvtf	s0, w13
100132b28:     	fdiv	s0, s0, s1
100132b2c:     	str	s0, [sp, #0x498]
100132b30:     	b	0x100132c0c <_render.TerminalRenderer.drawPane+0x480c>
100132b34:     	ldr	s4, [x9]
100132b38:     	b	0x100132c18 <_render.TerminalRenderer.drawPane+0x4818>
100132b3c:     	cmp	w10, #0xe8
100132b40:     	b.hs	0x100132bdc <_render.TerminalRenderer.drawPane+0x47dc>
100132b44:     	and	w10, w9, #0xff
100132b48:     	mov	w11, #0x39              ; =57
100132b4c:     	mul	w11, w10, w11
100132b50:     	lsr	w11, w11, #11
100132b54:     	mov	w12, #0x28              ; =40
100132b58:     	mov	w13, #0x37              ; =55
100132b5c:     	madd	w11, w11, w12, w13
100132b60:     	cmp	w9, #0x24
100132b64:     	csel	w11, wzr, w11, lo
100132b68:     	and	w11, w11, #0xff
100132b6c:     	mov	w12, #0xab              ; =171
100132b70:     	mul	w10, w10, w12
100132b74:     	lsr	w10, w10, #10
100132b78:     	ucvtf	s0, w11
100132b7c:     	mov	w11, #0x437f0000        ; =1132396544
100132b80:     	fmov	s1, w11
100132b84:     	fdiv	s4, s0, s1
100132b88:     	fmov	s0, w10
100132b8c:     	mov.s	v0[1], w9
100132b90:     	movi	d1, #0x0000ff000000ff
100132b94:     	and.8b	v0, v0, v1
100132b98:     	mov	w9, #0xaaab             ; =43691
100132b9c:     	movk	w9, #0x2aaa, lsl #16
100132ba0:     	dup.2s	v1, w9
100132ba4:     	umull.2d	v1, v0, v1
100132ba8:     	shrn.2s	v1, v1, #0x20
100132bac:     	movi.2s	v2, #0x6
100132bb0:     	mls.2s	v0, v1, v2
100132bb4:     	movi.2s	v1, #0x37
100132bb8:     	movi.2s	v2, #0x28
100132bbc:     	mla.2s	v1, v0, v2
100132bc0:     	cmeq.2s	v0, v0, #0
100132bc4:     	bic.8b	v0, v1, v0
100132bc8:     	bic.2s	v0, #0x3, lsl #8
100132bcc:     	ucvtf.2s	v0, v0
100132bd0:     	dup.2s	v1, w11
100132bd4:     	fdiv.2s	v0, v0, v1
100132bd8:     	b	0x100132c00 <_render.TerminalRenderer.drawPane+0x4800>
100132bdc:     	mov	w9, #0xa                ; =10
100132be0:     	mov	w11, #-0x8              ; =-8
100132be4:     	madd	w9, w10, w9, w11
100132be8:     	and	w9, w9, #0xfe
100132bec:     	ucvtf	s0, w9
100132bf0:     	mov	w9, #0x437f0000         ; =1132396544
100132bf4:     	fmov	s1, w9
100132bf8:     	fdiv	s4, s0, s1
100132bfc:     	dup.2s	v0, v4[0]
100132c00:     	str	s4, [sp, #0x490]
100132c04:     	add	x9, sp, #0x490
100132c08:     	stur	d0, [x9, #0x4]
100132c0c:     	add	x9, sp, #0x490
100132c10:     	mov	w10, #0x3f800000        ; =1065353216
100132c14:     	str	w10, [x9, #0xc]
100132c18:     	ldp	s12, s11, [x9, #0x4]
100132c1c:     	ldr	s0, [x9, #0xc]
100132c20:     	fmul	s1, s0, s15
100132c24:     	tst	w8, #0x4
100132c28:     	fcsel	s8, s0, s1, eq
100132c2c:     	ldrb	w10, [sp, #0x4fe]
100132c30:     	ldr	s0, [x21]
100132c34:     	ldrh	w9, [x21, #0x8]
100132c38:     	ldr	h2, [x21, #0x4]
100132c3c:     	ldr	h1, [x21, #0x6]
100132c40:     	and	w11, w8, #0x1
100132c44:     	strb	w11, [sp, #0x380]
100132c48:     	ubfx	w11, w8, #1, #1
100132c4c:     	add	x13, sp, #0x3, lsl #12  ; =0x3000
100132c50:     	add	x13, x13, #0x8e0
100132c54:     	strb	w11, [x13, #0xb0]
100132c58:     	add	x21, sp, #0x3, lsl #12  ; =0x3000
100132c5c:     	add	x21, x21, #0x700
100132c60:     	strb	wzr, [x21, #0x1c0]
100132c64:     	subs	x11, x10, #0x1
100132c68:     	str	q4, [sp, #0x210]
100132c6c:     	b.ne	0x100132d18 <_render.TerminalRenderer.drawPane+0x4918>
100132c70:     	ldrb	w12, [sp, #0x4ee]
100132c74:     	cmp	w12, #0x20
100132c78:     	b.ne	0x100132d18 <_render.TerminalRenderer.drawPane+0x4918>
100132c7c:     	ldr	x12, [sp, #0x1d0]
100132c80:     	ldrb	w12, [x12, x11]
100132c84:     	adrp	x14, 0x100687000 <___anon_33667+0x17f7>
100132c88:     	add	x14, x14, #0x88c
100132c8c:     	ldrb	w11, [x14, x11]
100132c90:     	cmp	w12, w11
100132c94:     	b.ne	0x100132d18 <_render.TerminalRenderer.drawPane+0x4918>
100132c98:     	tst	w8, #0x700
100132c9c:     	b.eq	0x100132db0 <_render.TerminalRenderer.drawPane+0x49b0>
100132ca0:     	fmov	d9, d8
100132ca4:     	add	x8, sp, #0x490
100132ca8:     	ldur	w8, [x8, #0x5a]
100132cac:     	str	s11, [sp, #0x1f0]
100132cb0:     	str	s12, [sp, #0x1e0]
100132cb4:     	fmov	d3, d4
100132cb8:     	ands	w9, w8, #0xff
100132cbc:     	b.eq	0x100132f14 <_render.TerminalRenderer.drawPane+0x4b14>
100132cc0:     	cmp	w9, #0x2
100132cc4:     	b.ne	0x100132db8 <_render.TerminalRenderer.drawPane+0x49b8>
100132cc8:     	ubfx	w9, w8, #8, #8
100132ccc:     	dup.2s	v0, w8
100132cd0:     	adrp	x8, 0x1001fe000 <__ZL19_hb_ucd_dm2_u64_map+0xb10>
100132cd4:     	ldr	d1, [x8, #0xd68]
100132cd8:     	ucvtf	s2, w9
100132cdc:     	ushl.2s	v0, v0, v1
100132ce0:     	mov	w8, #0x437f0000         ; =1132396544
100132ce4:     	fmov	s1, w8
100132ce8:     	fdiv	s3, s2, s1
100132cec:     	bic.2s	v0, #0xff, lsl #8
100132cf0:     	dup.2s	v1, w8
100132cf4:     	ucvtf.2s	v0, v0
100132cf8:     	fdiv.2s	v0, v0, v1
100132cfc:     	str	d0, [sp, #0x3870]
100132d00:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100132d04:     	add	x8, x8, #0x6e0
100132d08:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
100132d0c:     	add	x9, x9, #0x870
100132d10:     	ldr	x10, [sp, #0x180]
100132d14:     	b	0x100132f00 <_render.TerminalRenderer.drawPane+0x4b00>
100132d18:     	fneg	s3, s0
100132d1c:     	ucvtf	s2, s2
100132d20:     	ucvtf	s1, s1
100132d24:     	ldr	x8, [sp, #0x1d0]
100132d28:     	str	x8, [sp, #0xee0]
100132d2c:     	str	x10, [sp, #0xee8]
100132d30:     	fadd	s0, s0, s14
100132d34:     	str	s13, [sp, #0xef0]
100132d38:     	str	s0, [sp, #0xef4]
100132d3c:     	str	s4, [sp, #0xef8]
100132d40:     	str	s12, [sp, #0xefc]
100132d44:     	str	s11, [sp, #0xf00]
100132d48:     	str	s8, [sp, #0xf04]
100132d4c:     	str	wzr, [sp, #0xf08]
100132d50:     	str	s3, [sp, #0xf0c]
100132d54:     	str	s2, [sp, #0xf10]
100132d58:     	str	s1, [sp, #0xf14]
100132d5c:     	mov	w8, #0x1                ; =1
100132d60:     	strb	w8, [sp, #0xf18]
100132d64:     	strh	w9, [sp, #0xf1c]
100132d68:     	ldrb	w8, [sp, #0x380]
100132d6c:     	strb	w8, [sp, #0xf1e]
100132d70:     	ldrb	w8, [x13, #0xb0]
100132d74:     	strb	w8, [sp, #0xf1f]
100132d78:     	ldrb	w8, [x21, #0x1c0]
100132d7c:     	strb	w8, [sp, #0xf20]
100132d80:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
100132d84:     	add	x0, x0, #0x730
100132d88:     	add	x2, sp, #0xee0
100132d8c:     	add	x3, x22, #0xa8
100132d90:     	ldr	x1, [sp, #0x278]
100132d94:     	bl	0x100127d20 <_text.GlyphAtlas.place>
100132d98:     	ldrh	w0, [x21, #0x34]
100132d9c:     	cbnz	w0, 0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100132da0:     	ldrh	w8, [sp, #0x4e0]
100132da4:     	ldr	q4, [sp, #0x210]
100132da8:     	tst	w8, #0x700
100132dac:     	b.ne	0x100132ca0 <_render.TerminalRenderer.drawPane+0x48a0>
100132db0:     	tbnz	w8, #0x6, 0x100132ffc <_render.TerminalRenderer.drawPane+0x4bfc>
100132db4:     	b	0x1001330b0 <_render.TerminalRenderer.drawPane+0x4cb0>
100132db8:     	ubfx	w9, w8, #8, #8
100132dbc:     	cmp	w9, #0x10
100132dc0:     	b.hs	0x100132e1c <_render.TerminalRenderer.drawPane+0x4a1c>
100132dc4:     	ubfx	x8, x8, #8, #4
100132dc8:     	add	x8, x8, x8, lsl #1
100132dcc:     	ldr	x9, [sp, #0x1c0]
100132dd0:     	add	x8, x9, x8
100132dd4:     	ldr	b0, [x8]
100132dd8:     	ucvtf	s0, s0
100132ddc:     	mov	w9, #0x437f0000         ; =1132396544
100132de0:     	fmov	s1, w9
100132de4:     	fdiv	s3, s0, s1
100132de8:     	ldr	b0, [x8, #0x1]
100132dec:     	ucvtf	s0, s0
100132df0:     	fdiv	s0, s0, s1
100132df4:     	str	s0, [sp, #0x36e0]
100132df8:     	ldr	b0, [x8, #0x2]
100132dfc:     	ucvtf	s0, s0
100132e00:     	fdiv	s0, s0, s1
100132e04:     	str	s0, [sp, #0x3d0]
100132e08:     	add	x8, sp, #0x3b0
100132e0c:     	add	x10, sp, #0x3d0
100132e10:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
100132e14:     	add	x9, x9, #0x6e0
100132e18:     	b	0x100132f00 <_render.TerminalRenderer.drawPane+0x4b00>
100132e1c:     	ubfx	w9, w8, #8, #8
100132e20:     	lsr	w8, w8, #8
100132e24:     	cmp	w9, #0xe8
100132e28:     	b.hs	0x100132ec8 <_render.TerminalRenderer.drawPane+0x4ac8>
100132e2c:     	sub	w8, w8, #0x10
100132e30:     	and	w9, w8, #0xff
100132e34:     	mov	w10, #0x39              ; =57
100132e38:     	mul	w10, w9, w10
100132e3c:     	lsr	w10, w10, #11
100132e40:     	mov	w11, #0x28              ; =40
100132e44:     	mov	w12, #0x37              ; =55
100132e48:     	madd	w10, w10, w11, w12
100132e4c:     	cmp	w9, #0x24
100132e50:     	csel	w10, wzr, w10, lo
100132e54:     	and	w10, w10, #0xff
100132e58:     	mov	w11, #0xab              ; =171
100132e5c:     	mul	w9, w9, w11
100132e60:     	lsr	w9, w9, #10
100132e64:     	ucvtf	s0, w10
100132e68:     	mov	w10, #0x437f0000        ; =1132396544
100132e6c:     	fmov	s1, w10
100132e70:     	fdiv	s3, s0, s1
100132e74:     	fmov	s0, w9
100132e78:     	mov.s	v0[1], w8
100132e7c:     	movi	d1, #0x0000ff000000ff
100132e80:     	and.8b	v0, v0, v1
100132e84:     	mov	w8, #0xaaab             ; =43691
100132e88:     	movk	w8, #0x2aaa, lsl #16
100132e8c:     	dup.2s	v1, w8
100132e90:     	umull.2d	v1, v0, v1
100132e94:     	shrn.2s	v1, v1, #0x20
100132e98:     	movi.2s	v2, #0x6
100132e9c:     	mls.2s	v0, v1, v2
100132ea0:     	movi.2s	v1, #0x37
100132ea4:     	movi.2s	v2, #0x28
100132ea8:     	mla.2s	v1, v0, v2
100132eac:     	cmeq.2s	v0, v0, #0
100132eb0:     	bic.8b	v0, v1, v0
100132eb4:     	bic.2s	v0, #0x3, lsl #8
100132eb8:     	ucvtf.2s	v0, v0
100132ebc:     	dup.2s	v1, w10
100132ec0:     	fdiv.2s	v0, v0, v1
100132ec4:     	b	0x100132eec <_render.TerminalRenderer.drawPane+0x4aec>
100132ec8:     	mov	w9, #0xa                ; =10
100132ecc:     	mov	w10, #-0x8              ; =-8
100132ed0:     	madd	w8, w8, w9, w10
100132ed4:     	and	w8, w8, #0xfe
100132ed8:     	ucvtf	s0, w8
100132edc:     	mov	w8, #0x437f0000         ; =1132396544
100132ee0:     	fmov	s1, w8
100132ee4:     	fdiv	s3, s0, s1
100132ee8:     	dup.2s	v0, v3[0]
100132eec:     	str	d0, [sp, #0x490]
100132ef0:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100132ef4:     	add	x8, x8, #0x6e0
100132ef8:     	add	x9, sp, #0x490
100132efc:     	ldr	x10, [sp, #0x178]
100132f00:     	mov	w11, #0x3f800000        ; =1065353216
100132f04:     	str	w11, [x8]
100132f08:     	ldr	s12, [x9]
100132f0c:     	fmov	s9, #1.00000000
100132f10:     	ldr	s11, [x10]
100132f14:     	fadd	s0, s10, s14
100132f18:     	fmov	s1, #-2.00000000
100132f1c:     	fadd	s15, s0, s1
100132f20:     	ldrb	w8, [x22, #0xd8]
100132f24:     	cbz	w8, 0x100132f5c <_render.TerminalRenderer.drawPane+0x4b5c>
100132f28:     	ldr	x9, [x22, #0xd0]
100132f2c:     	ldr	x8, [x22, #0xc0]
100132f30:     	cmp	x8, x9
100132f34:     	b.lo	0x100132fa8 <_render.TerminalRenderer.drawPane+0x4ba8>
100132f38:     	ldr	x8, [x22, #0xe0]
100132f3c:     	add	x8, x8, #0x1
100132f40:     	str	x8, [x22, #0xe0]
100132f44:     	fmov	s15, #0.50000000
100132f48:     	ldr	s11, [sp, #0x1f0]
100132f4c:     	ldr	s12, [sp, #0x1e0]
100132f50:     	ldrh	w8, [sp, #0x4e0]
100132f54:     	tbnz	w8, #0x6, 0x100132ffc <_render.TerminalRenderer.drawPane+0x4bfc>
100132f58:     	b	0x1001330b0 <_render.TerminalRenderer.drawPane+0x4cb0>
100132f5c:     	ldur	q0, [x22, #0xa8]
100132f60:     	str	q0, [sp, #0x490]
100132f64:     	ldp	x8, x9, [x22, #0xc0]
100132f68:     	cmp	x9, x8
100132f6c:     	b.hi	0x100132fa8 <_render.TerminalRenderer.drawPane+0x4ba8>
100132f70:     	str	q3, [sp, #0x190]
100132f74:     	add	x8, x8, #0x1
100132f78:     	lsr	x9, x8, #1
100132f7c:     	add	x9, x9, #0x1
100132f80:     	adds	x8, x8, x9
100132f84:     	csinv	x2, x8, xzr, lo
100132f88:     	add	x0, x22, #0xb8
100132f8c:     	add	x1, sp, #0x490
100132f90:     	bl	0x1001ae678 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
100132f94:     	ands	w0, w0, #0xffff
100132f98:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100132f9c:     	ldr	x8, [x22, #0xc0]
100132fa0:     	ldr	q4, [sp, #0x210]
100132fa4:     	ldr	q3, [sp, #0x190]
100132fa8:     	add	x9, x8, #0x1
100132fac:     	str	x9, [x22, #0xc0]
100132fb0:     	ldr	x9, [x22, #0xb8]
100132fb4:     	mov	w10, #0x50              ; =80
100132fb8:     	madd	x8, x8, x10, x9
100132fbc:     	stp	s13, s15, [x8]
100132fc0:     	ldr	s0, [sp, #0x280]
100132fc4:     	str	s0, [x8, #0x8]
100132fc8:     	ldr	q0, [sp, #0x1b0]
100132fcc:     	stur	q0, [x8, #0xc]
100132fd0:     	mov	w9, #0x3a000000         ; =973078528
100132fd4:     	str	w9, [x8, #0x1c]
100132fd8:     	stp	s3, s12, [x8, #0x20]
100132fdc:     	stp	s11, s9, [x8, #0x28]
100132fe0:     	movi.2d	v0, #0000000000000000
100132fe4:     	stp	q0, q0, [x8, #0x30]
100132fe8:     	fmov	s15, #0.50000000
100132fec:     	ldr	s11, [sp, #0x1f0]
100132ff0:     	ldr	s12, [sp, #0x1e0]
100132ff4:     	ldrh	w8, [sp, #0x4e0]
100132ff8:     	tbz	w8, #0x6, 0x1001330b0 <_render.TerminalRenderer.drawPane+0x4cb0>
100132ffc:     	fmul	s0, s10, s15
100133000:     	fadd	s9, s0, s14
100133004:     	ldrb	w8, [x22, #0xd8]
100133008:     	cbz	w8, 0x10013302c <_render.TerminalRenderer.drawPane+0x4c2c>
10013300c:     	ldr	x9, [x22, #0xd0]
100133010:     	ldr	x8, [x22, #0xc0]
100133014:     	cmp	x8, x9
100133018:     	b.lo	0x100133070 <_render.TerminalRenderer.drawPane+0x4c70>
10013301c:     	ldr	x8, [x22, #0xe0]
100133020:     	add	x8, x8, #0x1
100133024:     	str	x8, [x22, #0xe0]
100133028:     	b	0x1001330b0 <_render.TerminalRenderer.drawPane+0x4cb0>
10013302c:     	ldur	q0, [x22, #0xa8]
100133030:     	str	q0, [sp, #0x490]
100133034:     	ldp	x8, x9, [x22, #0xc0]
100133038:     	cmp	x9, x8
10013303c:     	b.hi	0x100133070 <_render.TerminalRenderer.drawPane+0x4c70>
100133040:     	add	x8, x8, #0x1
100133044:     	lsr	x9, x8, #1
100133048:     	add	x9, x9, #0x1
10013304c:     	adds	x8, x8, x9
100133050:     	csinv	x2, x8, xzr, lo
100133054:     	add	x0, x22, #0xb8
100133058:     	add	x1, sp, #0x490
10013305c:     	bl	0x1001ae678 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
100133060:     	ands	w0, w0, #0xffff
100133064:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100133068:     	ldr	x8, [x22, #0xc0]
10013306c:     	ldr	q4, [sp, #0x210]
100133070:     	add	x9, x8, #0x1
100133074:     	str	x9, [x22, #0xc0]
100133078:     	ldr	x9, [x22, #0xb8]
10013307c:     	mov	w10, #0x50              ; =80
100133080:     	madd	x8, x8, x10, x9
100133084:     	stp	s13, s9, [x8]
100133088:     	ldr	s0, [sp, #0x280]
10013308c:     	str	s0, [x8, #0x8]
100133090:     	ldr	q0, [sp, #0x1b0]
100133094:     	stur	q0, [x8, #0xc]
100133098:     	mov	w9, #0x3a000000         ; =973078528
10013309c:     	str	w9, [x8, #0x1c]
1001330a0:     	stp	s4, s12, [x8, #0x20]
1001330a4:     	stp	s11, s8, [x8, #0x28]
1001330a8:     	movi.2d	v0, #0000000000000000
1001330ac:     	stp	q0, q0, [x8, #0x30]
1001330b0:     	ldp	x21, x24, [x22, #0xb8]
1001330b4:     	cmp	x24, #0x2
1001330b8:     	mov	w8, #0x2                ; =2
1001330bc:     	csel	x19, x24, x8, lo
1001330c0:     	add	x8, x19, x19, lsl #2
1001330c4:     	lsl	x22, x8, #4
1001330c8:     	mov	x0, x26
1001330cc:     	mov	x1, x21
1001330d0:     	mov	x2, x22
1001330d4:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
1001330d8:     	sub	x8, x24, x19
1001330dc:     	add	x8, x8, x8, lsl #2
1001330e0:     	lsl	x2, x8, #4
1001330e4:     	add	x1, x21, x22
1001330e8:     	ldr	x21, [sp, #0x260]
1001330ec:     	mov	x0, x25
1001330f0:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
1001330f4:     	ldr	x8, [sp, #0x298]
1001330f8:     	add	x8, x8, x28
1001330fc:     	strb	w24, [x8, #0x3c]
100133100:     	str	xzr, [x8]
100133104:     	stp	s13, s14, [x8, #0x8]
100133108:     	ldr	s0, [sp, #0x280]
10013310c:     	stp	s0, s10, [x8, #0x10]
100133110:     	ldr	q0, [sp, #0xce0]
100133114:     	ldr	q1, [sp, #0xcf0]
100133118:     	stur	q0, [x8, #0x18]
10013311c:     	stur	q1, [x8, #0x28]
100133120:     	mov	w9, #0x1                ; =1
100133124:     	strb	w9, [x23, #0x38]
100133128:     	ldr	s0, [x21, #0x1ac]
10013312c:     	ldr	s1, [x26, #0x20]
100133130:     	fcmp	s1, s0
100133134:     	b.ne	0x100133158 <_render.TerminalRenderer.drawPane+0x4d58>
100133138:     	ldr	s0, [x21, #0x1b0]
10013313c:     	ldr	s1, [x26, #0x24]
100133140:     	fcmp	s1, s0
100133144:     	b.ne	0x100133158 <_render.TerminalRenderer.drawPane+0x4d58>
100133148:     	ldr	s0, [x21, #0x1b4]
10013314c:     	ldr	s1, [x26, #0x28]
100133150:     	fcmp	s1, s0
100133154:     	cset	w9, ne
100133158:     	strb	w9, [x8, #0x39]
10013315c:     	ldr	x22, [sp, #0x270]
100133160:     	ldr	x8, [x22, #0x10]
100133164:     	add	x8, x8, #0x1
100133168:     	str	x8, [x22, #0x10]
10013316c:     	ldr	x8, [sp, #0x298]
100133170:     	add	x8, x8, x28
100133174:     	ldrb	w8, [x8, #0x39]
100133178:     	cmp	w8, #0x1
10013317c:     	ldr	x23, [sp, #0x258]
100133180:     	b.ne	0x100132578 <_render.TerminalRenderer.drawPane+0x4178>
100133184:     	ldr	q0, [x26, #0x10]
100133188:     	str	q0, [sp, #0x22f0]
10013318c:     	ldr	q0, [x26, #0x20]
100133190:     	str	q0, [sp, #0x2300]
100133194:     	ldr	q0, [x26, #0x30]
100133198:     	str	q0, [sp, #0x2310]
10013319c:     	ldr	q0, [x26, #0x40]
1001331a0:     	str	q0, [sp, #0x2320]
1001331a4:     	ldr	q0, [x26]
1001331a8:     	str	q0, [sp, #0x22e0]
1001331ac:     	ldrb	w8, [x22, #0x98]
1001331b0:     	cbz	w8, 0x1001331d4 <_render.TerminalRenderer.drawPane+0x4dd4>
1001331b4:     	ldr	x9, [x22, #0x90]
1001331b8:     	ldr	x8, [x22, #0x80]
1001331bc:     	cmp	x8, x9
1001331c0:     	b.lo	0x10013253c <_render.TerminalRenderer.drawPane+0x413c>
1001331c4:     	ldr	x8, [x22, #0xa0]
1001331c8:     	add	x8, x8, #0x1
1001331cc:     	str	x8, [x22, #0xa0]
1001331d0:     	b	0x100132578 <_render.TerminalRenderer.drawPane+0x4178>
1001331d4:     	ldr	x9, [sp, #0x278]
1001331d8:     	add	x8, x9, #0x10, lsl #12  ; =0x10000
1001331dc:     	ldr	q0, [x8, #0x2940]
1001331e0:     	str	q0, [sp, #0x490]
1001331e4:     	ldp	x8, x9, [x22, #0x80]
1001331e8:     	cmp	x9, x8
1001331ec:     	b.hi	0x10013253c <_render.TerminalRenderer.drawPane+0x413c>
1001331f0:     	add	x8, x8, #0x1
1001331f4:     	lsr	x9, x8, #1
1001331f8:     	add	x9, x9, #0x1
1001331fc:     	adds	x8, x8, x9
100133200:     	csinv	x2, x8, xzr, lo
100133204:     	mov	w8, #0x2950             ; =10576
100133208:     	movk	w8, #0x1, lsl #16
10013320c:     	ldr	x9, [sp, #0x278]
100133210:     	add	x0, x9, x8
100133214:     	add	x1, sp, #0x490
100133218:     	bl	0x1001ae678 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
10013321c:     	ands	w0, w0, #0xffff
100133220:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100133224:     	ldr	x8, [x22, #0x80]
100133228:     	b	0x10013253c <_render.TerminalRenderer.drawPane+0x413c>
10013322c:     	ldr	x0, [sp, #0x278]
100133230:     	mov	x1, x23
100133234:     	ldp	x3, x2, [sp, #0x88]
100133238:     	mov	w4, #0x1                ; =1
10013323c:     	bl	0x10012e0b8 <_render.TerminalRenderer.pushImages>
100133240:     	ands	w0, w0, #0xffff
100133244:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100133248:     	ldrb	w8, [x21, #0x249]
10013324c:     	cmp	w8, #0x1
100133250:     	ldr	x21, [sp, #0x270]
100133254:     	ldr	x2, [sp, #0x120]
100133258:     	ldr	x20, [sp, #0x78]
10013325c:     	b.ne	0x1001333b0 <_render.TerminalRenderer.drawPane+0x4fb0>
100133260:     	ldr	x9, [x23]
100133264:     	ldr	w10, [x23, #0x28]
100133268:     	ldrb	w11, [x23, #0x3c]
10013326c:     	ldrb	w12, [x23, #0x40]
100133270:     	ldrb	w14, [x23, #0x44]
100133274:     	cbz	w12, 0x10013327c <_render.TerminalRenderer.drawPane+0x4e7c>
100133278:     	tbz	w11, #0x0, 0x10013328c <_render.TerminalRenderer.drawPane+0x4e8c>
10013327c:     	ldrh	w13, [x9, #0x100]
100133280:     	ldrh	w8, [x9, #0x102]
100133284:     	add	x15, x9, #0x104
100133288:     	b	0x1001332c8 <_render.TerminalRenderer.drawPane+0x4ec8>
10013328c:     	ldr	w8, [x9, #0xfc]
100133290:     	subs	w8, w10, w8
100133294:     	b.lo	0x1001332b8 <_render.TerminalRenderer.drawPane+0x4eb8>
100133298:     	ldrh	w13, [x9, #0x52]
10013329c:     	cmp	w8, w13
1001332a0:     	b.hs	0x1001332b8 <_render.TerminalRenderer.drawPane+0x4eb8>
1001332a4:     	ldrh	w13, [x23, #0x2c]
1001332a8:     	mov	w15, #0x1               ; =1
1001332ac:     	strb	w15, [sp, #0x4e0]
1001332b0:     	add	x15, sp, #0x4e0
1001332b4:     	b	0x1001332c8 <_render.TerminalRenderer.drawPane+0x4ec8>
1001332b8:     	mov	w13, #0x0               ; =0
1001332bc:     	mov	w8, #0x0                ; =0
1001332c0:     	adrp	x15, 0x100537000 <___anon_12840+0x13d14>
1001332c4:     	add	x15, x15, #0x524
1001332c8:     	tbnz	w14, #0x0, 0x1001333b0 <_render.TerminalRenderer.drawPane+0x4fb0>
1001332cc:     	ldrb	w14, [x23, #0x22]
1001332d0:     	tbz	w14, #0x0, 0x1001333b0 <_render.TerminalRenderer.drawPane+0x4fb0>
1001332d4:     	ldrb	w14, [x15]
1001332d8:     	tbz	w14, #0x0, 0x1001333b0 <_render.TerminalRenderer.drawPane+0x4fb0>
1001332dc:     	ldrh	w14, [x23, #0x1c]
1001332e0:     	ldrh	w15, [x9, #0x50]
1001332e4:     	cmp	w14, w15
1001332e8:     	csel	w14, w14, w15, lo
1001332ec:     	cmp	w13, w14
1001332f0:     	b.hs	0x1001333b0 <_render.TerminalRenderer.drawPane+0x4fb0>
1001332f4:     	ldrh	w17, [x23, #0x1e]
1001332f8:     	ldrh	w16, [x9, #0x52]
1001332fc:     	cmp	w17, w16
100133300:     	csel	w17, w17, w16, lo
100133304:     	cmp	w17, w8, uxth
100133308:     	b.ls	0x1001333b0 <_render.TerminalRenderer.drawPane+0x4fb0>
10013330c:     	cbz	w13, 0x100133338 <_render.TerminalRenderer.drawPane+0x4f38>
100133310:     	and	x17, x8, #0xffff
100133314:     	umull	x17, w15, w17
100133318:     	mov	w0, w13
10013331c:     	ldr	x1, [x9, #0x30]
100133320:     	add	x17, x1, x17, lsl #5
100133324:     	add	x17, x17, x0, lsl #5
100133328:     	ldrb	w17, [x17, #0x1f]
10013332c:     	cmp	w17, #0x0
100133330:     	cset	w17, eq
100133334:     	sub	w13, w13, w17
100133338:     	cbz	w12, 0x100133340 <_render.TerminalRenderer.drawPane+0x4f40>
10013333c:     	tbz	w11, #0x0, 0x100134458 <_render.TerminalRenderer.drawPane+0x6058>
100133340:     	ldrb	w12, [x9, #0x105]
100133344:     	and	x10, x8, #0xffff
100133348:     	umull	x10, w15, w10
10013334c:     	and	x11, x13, #0xffff
100133350:     	ldr	x9, [x9, #0x30]
100133354:     	add	x9, x9, x10, lsl #5
100133358:     	add	x9, x9, x11, lsl #5
10013335c:     	ldrb	w9, [x9, #0x1f]
100133360:     	ldrh	w11, [x23, #0x18]
100133364:     	ldrh	w10, [x23, #0x1a]
100133368:     	cmp	w9, #0x1
10013336c:     	csinc	w9, w9, wzr, hi
100133370:     	sub	w14, w14, w13
100133374:     	and	w14, w14, #0xffff
100133378:     	cmp	w9, w14
10013337c:     	csel	w9, w9, w14, lo
100133380:     	ldr	x14, [sp, #0x260]
100133384:     	ldrb	w14, [x14, #0x24a]
100133388:     	tbz	w14, #0x0, 0x100134280 <_render.TerminalRenderer.drawPane+0x5e80>
10013338c:     	and	w12, w12, #0x7
100133390:     	cmp	w12, #0x1
100133394:     	b.le	0x10013446c <_render.TerminalRenderer.drawPane+0x606c>
100133398:     	cmp	w12, #0x2
10013339c:     	b.eq	0x100134488 <_render.TerminalRenderer.drawPane+0x6088>
1001333a0:     	cmp	w12, #0x3
1001333a4:     	b.ne	0x100134280 <_render.TerminalRenderer.drawPane+0x5e80>
1001333a8:     	mov	w15, #0x2               ; =2
1001333ac:     	b	0x100134284 <_render.TerminalRenderer.drawPane+0x5e84>
1001333b0:     	str	wzr, [sp, #0x1c0]
1001333b4:     	movi	d5, #0000000000000000
1001333b8:     	movi	d16, #0000000000000000
1001333bc:     	movi	d6, #0000000000000000
1001333c0:     	str	xzr, [sp, #0x2f8]
1001333c4:     	str	xzr, [sp, #0x2f0]
1001333c8:     	mov	w8, #0x1                ; =1
1001333cc:     	str	w8, [sp, #0x298]
1001333d0:     	strb	wzr, [sp, #0x2ec]
1001333d4:     	movi	d7, #0000000000000000
1001333d8:     	movi	d0, #0000000000000000
1001333dc:     	str	s0, [sp, #0x150]
1001333e0:     	strh	wzr, [sp, #0x2e8]
1001333e4:     	str	s0, [sp, #0x148]
1001333e8:     	str	s0, [sp, #0x130]
1001333ec:     	strb	wzr, [sp, #0x2ea]
1001333f0:     	str	s0, [sp, #0x1a0]
1001333f4:     	str	s0, [sp, #0x190]
1001333f8:     	ldr	x8, [sp, #0x128]
1001333fc:     	str	s5, [sp, #0x1f0]
100133400:     	str	s6, [sp, #0x1e0]
100133404:     	str	s7, [sp, #0x1d0]
100133408:     	str	s16, [sp, #0x1c8]
10013340c:     	cbz	w8, 0x10013418c <_render.TerminalRenderer.drawPane+0x5d8c>
100133410:     	cbz	w2, 0x10013418c <_render.TerminalRenderer.drawPane+0x5d8c>
100133414:     	mov	x13, #0x0               ; =0
100133418:     	ldr	x12, [sp, #0x40]
10013341c:     	lsr	w14, w12, #16
100133420:     	ldr	x11, [sp, #0x260]
100133424:     	ldrh	w8, [x11, #0x4]
100133428:     	ldr	w9, [x11, #0x17c]
10013342c:     	and	w10, w12, #0xffff
100133430:     	madd	w9, w10, w8, w9
100133434:     	ldrh	w10, [x11, #0x6]
100133438:     	ldr	w11, [x11, #0x180]
10013343c:     	ucvtf	s17, w9
100133440:     	madd	w9, w14, w10, w11
100133444:     	ucvtf	s14, w9
100133448:     	mul	w9, w10, w20
10013344c:     	ucvtf	s0, w9
100133450:     	ldr	x9, [sp, #0x38]
100133454:     	mul	w8, w9, w8
100133458:     	ucvtf	s1, w8
10013345c:     	and	x8, x12, #0xffff
100133460:     	stp	x8, x14, [sp, #0x158]
100133464:     	fadd	s15, s1, s17
100133468:     	mov	w14, w14
10013346c:     	fadd	s12, s0, s14
100133470:     	mov	w15, #0xa0              ; =160
100133474:     	mov	w16, #0x50              ; =80
100133478:     	str	s17, [sp, #0x1b0]
10013347c:     	b	0x10013349c <_render.TerminalRenderer.drawPane+0x509c>
100133480:     	ldr	x13, [sp, #0x178]
100133484:     	add	x13, x13, #0x1
100133488:     	ldr	x14, [sp, #0x168]
10013348c:     	add	x14, x14, #0x1
100133490:     	ldr	x8, [sp, #0x128]
100133494:     	cmp	x13, x8
100133498:     	b.eq	0x10013418c <_render.TerminalRenderer.drawPane+0x5d8c>
10013349c:     	mov	x25, #0x0               ; =0
1001334a0:     	str	x13, [sp, #0x178]
1001334a4:     	ldp	x12, x8, [sp, #0x158]
1001334a8:     	add	w8, w13, w8
1001334ac:     	ldr	x11, [sp, #0x170]
1001334b0:     	ldrh	w9, [x11, #0x48]
1001334b4:     	umaddl	x8, w9, w8, x12
1001334b8:     	ldr	x10, [x11]
1001334bc:     	add	x13, x10, x8, lsl #6
1001334c0:     	ldr	x10, [x11, #0x18]
1001334c4:     	madd	x17, x8, x15, x10
1001334c8:     	ldr	x8, [x11, #0x30]
1001334cc:     	str	x14, [sp, #0x168]
1001334d0:     	madd	x9, x14, x9, x12
1001334d4:     	mov	w10, #0x6e0             ; =1760
1001334d8:     	madd	x26, x9, x10, x8
1001334dc:     	str	x13, [sp, #0x210]
1001334e0:     	str	x17, [sp, #0x208]
1001334e4:     	b	0x1001334f8 <_render.TerminalRenderer.drawPane+0x50f8>
1001334e8:     	add	x25, x25, #0x1
1001334ec:     	add	x26, x26, #0x6e0
1001334f0:     	cmp	x25, x2
1001334f4:     	b.eq	0x100133480 <_render.TerminalRenderer.drawPane+0x5080>
1001334f8:     	add	x24, x13, x25, lsl #6
1001334fc:     	ldrb	w8, [x24, #0x3c]
100133500:     	cmp	w8, #0x2
100133504:     	b.lo	0x1001334e8 <_render.TerminalRenderer.drawPane+0x50e8>
100133508:     	ldr	w8, [sp, #0x298]
10013350c:     	tbnz	w8, #0x0, 0x100133614 <_render.TerminalRenderer.drawPane+0x5214>
100133510:     	ldr	w8, [sp, #0x1c0]
100133514:     	tst	w8, #0x3
100133518:     	b.ne	0x100133614 <_render.TerminalRenderer.drawPane+0x5214>
10013351c:     	ldp	s0, s1, [x24, #0x8]
100133520:     	ldr	s2, [sp, #0x190]
100133524:     	fcmp	s0, s2
100133528:     	ldr	s0, [sp, #0x1a0]
10013352c:     	fccmp	s1, s0, #0x0, eq
100133530:     	b.ne	0x100133614 <_render.TerminalRenderer.drawPane+0x5214>
100133534:     	madd	x8, x25, x15, x17
100133538:     	ldp	d0, d21, [x8, #0x50]
10013353c:     	ldr	q18, [x8, #0x60]
100133540:     	fmov	d20, d0
100133544:     	mov	s19, v0[1]
100133548:     	fadd	s1, s0, s21
10013354c:     	mov	s8, v21[1]
100133550:     	fadd	s2, s19, s8
100133554:     	fcmp	s0, s17
100133558:     	fccmp	s19, s14, #0x8, ge
10013355c:     	fccmp	s1, s15, #0x2, ge
100133560:     	fccmp	s2, s12, #0x2, ls
100133564:     	b.ls	0x1001335cc <_render.TerminalRenderer.drawPane+0x51cc>
100133568:     	fminnm	s1, s1, s15
10013356c:     	fminnm	s2, s2, s12
100133570:     	fmaxnm	s20, s20, s17
100133574:     	fmaxnm	s19, s19, s14
100133578:     	fmaxnm	s1, s20, s1
10013357c:     	fmaxnm	s2, s19, s2
100133580:     	fcmp	s21, #0.0
100133584:     	b.le	0x1001335c4 <_render.TerminalRenderer.drawPane+0x51c4>
100133588:     	fcmp	s8, #0.0
10013358c:     	b.le	0x1001335c4 <_render.TerminalRenderer.drawPane+0x51c4>
100133590:     	mov.d	v0[1], v0[0]
100133594:     	ext.16b	v3, v18, v18, #0x8
100133598:     	fsub.2s	v3, v3, v18
10013359c:     	mov.16b	v4, v20
1001335a0:     	mov.s	v4[1], v19[0]
1001335a4:     	mov.s	v4[2], v1[0]
1001335a8:     	mov.s	v4[3], v2[0]
1001335ac:     	fsub.4s	v0, v4, v0
1001335b0:     	fdiv.2s	v3, v3, v21
1001335b4:     	mov.d	v3[1], v3[0]
1001335b8:     	fmul.4s	v0, v0, v3
1001335bc:     	dup.2d	v3, v18[0]
1001335c0:     	fadd.4s	v18, v3, v0
1001335c4:     	fsub	s21, s1, s20
1001335c8:     	fsub	s8, s2, s19
1001335cc:     	ldur	q0, [x8, #0x80]
1001335d0:     	str	q0, [sp, #0x22e0]
1001335d4:     	ldur	q0, [x8, #0x90]
1001335d8:     	str	q0, [sp, #0x22f0]
1001335dc:     	fcmp	s21, #0.0
1001335e0:     	b.le	0x100133e30 <_render.TerminalRenderer.drawPane+0x5a30>
1001335e4:     	fcmp	s8, #0.0
1001335e8:     	b.le	0x100133e30 <_render.TerminalRenderer.drawPane+0x5a30>
1001335ec:     	ldrb	w8, [x21, #0x98]
1001335f0:     	cbz	w8, 0x100133758 <_render.TerminalRenderer.drawPane+0x5358>
1001335f4:     	ldr	x9, [x21, #0x90]
1001335f8:     	ldr	x8, [x21, #0x80]
1001335fc:     	cmp	x8, x9
100133600:     	b.lo	0x100133dfc <_render.TerminalRenderer.drawPane+0x59fc>
100133604:     	ldr	x8, [x21, #0xa0]
100133608:     	add	x8, x8, #0x1
10013360c:     	str	x8, [x21, #0xa0]
100133610:     	b	0x100133e30 <_render.TerminalRenderer.drawPane+0x5a30>
100133614:     	madd	x8, x25, x15, x17
100133618:     	ldp	d0, d21, [x8, #0x50]
10013361c:     	ldr	q18, [x8, #0x60]
100133620:     	fmov	d20, d0
100133624:     	mov	s19, v0[1]
100133628:     	fadd	s1, s0, s21
10013362c:     	mov	s8, v21[1]
100133630:     	fadd	s2, s19, s8
100133634:     	fcmp	s0, s17
100133638:     	fccmp	s19, s14, #0x8, ge
10013363c:     	fccmp	s1, s15, #0x2, ge
100133640:     	fccmp	s2, s12, #0x2, ls
100133644:     	b.ls	0x1001336ac <_render.TerminalRenderer.drawPane+0x52ac>
100133648:     	fminnm	s1, s1, s15
10013364c:     	fminnm	s2, s2, s12
100133650:     	fmaxnm	s20, s20, s17
100133654:     	fmaxnm	s19, s19, s14
100133658:     	fmaxnm	s1, s20, s1
10013365c:     	fmaxnm	s2, s19, s2
100133660:     	fcmp	s21, #0.0
100133664:     	b.le	0x1001336a4 <_render.TerminalRenderer.drawPane+0x52a4>
100133668:     	fcmp	s8, #0.0
10013366c:     	b.le	0x1001336a4 <_render.TerminalRenderer.drawPane+0x52a4>
100133670:     	mov.d	v0[1], v0[0]
100133674:     	ext.16b	v3, v18, v18, #0x8
100133678:     	fsub.2s	v3, v3, v18
10013367c:     	mov.16b	v4, v20
100133680:     	mov.s	v4[1], v19[0]
100133684:     	mov.s	v4[2], v1[0]
100133688:     	mov.s	v4[3], v2[0]
10013368c:     	fsub.4s	v0, v4, v0
100133690:     	fdiv.2s	v3, v3, v21
100133694:     	mov.d	v3[1], v3[0]
100133698:     	fmul.4s	v0, v0, v3
10013369c:     	dup.2d	v3, v18[0]
1001336a0:     	fadd.4s	v18, v3, v0
1001336a4:     	fsub	s21, s1, s20
1001336a8:     	fsub	s8, s2, s19
1001336ac:     	ldp	q1, q0, [x8, #0x70]
1001336b0:     	str	q0, [sp, #0x22e0]
1001336b4:     	ldur	q0, [x8, #0x90]
1001336b8:     	str	q0, [sp, #0x22f0]
1001336bc:     	fcmp	s21, #0.0
1001336c0:     	b.le	0x100133960 <_render.TerminalRenderer.drawPane+0x5560>
1001336c4:     	fcmp	s8, #0.0
1001336c8:     	b.le	0x100133960 <_render.TerminalRenderer.drawPane+0x5560>
1001336cc:     	ldrb	w8, [x21, #0x98]
1001336d0:     	cbz	w8, 0x1001336f4 <_render.TerminalRenderer.drawPane+0x52f4>
1001336d4:     	ldr	x9, [x21, #0x90]
1001336d8:     	ldr	x8, [x21, #0x80]
1001336dc:     	cmp	x8, x9
1001336e0:     	b.lo	0x100133934 <_render.TerminalRenderer.drawPane+0x5534>
1001336e4:     	ldr	x8, [x21, #0xa0]
1001336e8:     	add	x8, x8, #0x1
1001336ec:     	str	x8, [x21, #0xa0]
1001336f0:     	b	0x100133960 <_render.TerminalRenderer.drawPane+0x5560>
1001336f4:     	ldp	x8, x27, [x21, #0x80]
1001336f8:     	cmp	x27, x8
1001336fc:     	b.hi	0x100133934 <_render.TerminalRenderer.drawPane+0x5534>
100133700:     	add	x8, x8, #0x1
100133704:     	lsr	x9, x8, #1
100133708:     	add	x9, x9, #0x1
10013370c:     	adds	x8, x8, x9
100133710:     	csinv	x20, x8, xzr, lo
100133714:     	cmp	x27, x20
100133718:     	b.hs	0x100133930 <_render.TerminalRenderer.drawPane+0x5530>
10013371c:     	ldp	x22, x28, [x21, #0x68]
100133720:     	ldr	x9, [sp, #0x278]
100133724:     	add	x8, x9, #0x10, lsl #12  ; =0x10000
100133728:     	ldr	x19, [x8, #0x2950]
10013372c:     	cbz	x27, 0x100133744 <_render.TerminalRenderer.drawPane+0x5344>
100133730:     	umulh	x8, x20, x16
100133734:     	cmp	xzr, x8
100133738:     	cset	w8, ne
10013373c:     	strb	w8, [sp, #0xee0]
100133740:     	b.eq	0x1001337c4 <_render.TerminalRenderer.drawPane+0x53c4>
100133744:     	mov	x23, #0x0               ; =0
100133748:     	mov	x8, #0x0                ; =0
10013374c:     	cbz	x23, 0x100133858 <_render.TerminalRenderer.drawPane+0x5458>
100133750:     	mov	x20, x8
100133754:     	b	0x100133920 <_render.TerminalRenderer.drawPane+0x5520>
100133758:     	ldp	x8, x27, [x21, #0x80]
10013375c:     	cmp	x27, x8
100133760:     	b.hi	0x100133dfc <_render.TerminalRenderer.drawPane+0x59fc>
100133764:     	add	x8, x8, #0x1
100133768:     	lsr	x9, x8, #1
10013376c:     	add	x9, x9, #0x1
100133770:     	adds	x8, x8, x9
100133774:     	csinv	x20, x8, xzr, lo
100133778:     	cmp	x27, x20
10013377c:     	b.hs	0x100133df8 <_render.TerminalRenderer.drawPane+0x59f8>
100133780:     	ldp	x19, x28, [x21, #0x68]
100133784:     	ldr	x9, [sp, #0x278]
100133788:     	add	x8, x9, #0x10, lsl #12  ; =0x10000
10013378c:     	ldr	x10, [x8, #0x2950]
100133790:     	add	x22, x20, x20, lsl #2
100133794:     	cbz	x27, 0x1001337ac <_render.TerminalRenderer.drawPane+0x53ac>
100133798:     	umulh	x8, x20, x16
10013379c:     	cmp	xzr, x8
1001337a0:     	cset	w8, ne
1001337a4:     	strb	w8, [sp, #0xee0]
1001337a8:     	b.eq	0x100133ca4 <_render.TerminalRenderer.drawPane+0x58a4>
1001337ac:     	mov	x23, #0x0               ; =0
1001337b0:     	mov	x8, #0x0                ; =0
1001337b4:     	cbz	x23, 0x100133d34 <_render.TerminalRenderer.drawPane+0x5934>
1001337b8:     	mov	x20, x8
1001337bc:     	ldr	x21, [sp, #0x270]
1001337c0:     	b	0x100133dec <_render.TerminalRenderer.drawPane+0x59ec>
1001337c4:     	add	x8, x20, x20, lsl #2
1001337c8:     	lsl	x21, x8, #4
1001337cc:     	add	x8, x27, x27, lsl #2
1001337d0:     	lsl	x2, x8, #4
1001337d4:     	ldr	x8, [x28, #0x10]
1001337d8:     	mov	x0, x22
1001337dc:     	mov	x1, x19
1001337e0:     	mov	w3, #0x2                ; =2
1001337e4:     	mov	x4, x21
1001337e8:     	ldr	x5, [sp, #0x188]
1001337ec:     	str	q18, [sp, #0x280]
1001337f0:     	str	q19, [sp, #0x260]
1001337f4:     	stp	q21, q20, [sp, #0x230]
1001337f8:     	str	q1, [sp, #0x220]
1001337fc:     	blr	x8
100133800:     	ldp	q1, q21, [sp, #0x220]
100133804:     	ldr	q20, [sp, #0x240]
100133808:     	ldr	q19, [sp, #0x260]
10013380c:     	ldr	q18, [sp, #0x280]
100133810:     	ldr	x17, [sp, #0x208]
100133814:     	ldr	x13, [sp, #0x210]
100133818:     	mov	w16, #0x50              ; =80
10013381c:     	mov	w15, #0xa0              ; =160
100133820:     	ldr	s17, [sp, #0x1b0]
100133824:     	ldr	s16, [sp, #0x1c8]
100133828:     	ldr	s7, [sp, #0x1d0]
10013382c:     	ldr	s6, [sp, #0x1e0]
100133830:     	ldr	s5, [sp, #0x1f0]
100133834:     	ldr	x2, [sp, #0x120]
100133838:     	lsr	x8, x21, #4
10013383c:     	mov	x9, #-0x3333333333333334 ; =-3689348814741910324
100133840:     	movk	x9, #0xcccd
100133844:     	mul	x8, x8, x9
100133848:     	cmp	x0, #0x0
10013384c:     	csel	x23, xzr, x0, eq
100133850:     	csel	x8, xzr, x8, eq
100133854:     	cbnz	x23, 0x100133750 <_render.TerminalRenderer.drawPane+0x5350>
100133858:     	umulh	x8, x20, x16
10013385c:     	cmp	xzr, x8
100133860:     	cset	w8, ne
100133864:     	strb	w8, [sp, #0xee0]
100133868:     	b.ne	0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
10013386c:     	stp	q1, q21, [sp, #0x220]
100133870:     	str	q20, [sp, #0x240]
100133874:     	str	q19, [sp, #0x260]
100133878:     	str	q18, [sp, #0x280]
10013387c:     	add	x8, x20, x20, lsl #2
100133880:     	lsl	x1, x8, #4
100133884:     	cbz	x1, 0x1001338a8 <_render.TerminalRenderer.drawPane+0x54a8>
100133888:     	ldr	x8, [x28]
10013388c:     	mov	x0, x22
100133890:     	mov	w2, #0x2                ; =2
100133894:     	ldr	x3, [sp, #0x188]
100133898:     	blr	x8
10013389c:     	mov	x23, x0
1001338a0:     	cbnz	x0, 0x1001338ac <_render.TerminalRenderer.drawPane+0x54ac>
1001338a4:     	b	0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
1001338a8:     	mov	x23, #-0x4              ; =-4
1001338ac:     	ldr	x9, [sp, #0x270]
1001338b0:     	ldp	x1, x8, [x9, #0x78]
1001338b4:     	add	x8, x8, x8, lsl #2
1001338b8:     	lsl	x2, x8, #4
1001338bc:     	mov	x0, x23
1001338c0:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
1001338c4:     	cbz	x27, 0x1001338e8 <_render.TerminalRenderer.drawPane+0x54e8>
1001338c8:     	add	x8, x27, x27, lsl #2
1001338cc:     	lsl	x2, x8, #4
1001338d0:     	ldr	x8, [x28, #0x18]
1001338d4:     	mov	x0, x22
1001338d8:     	mov	x1, x19
1001338dc:     	mov	w3, #0x2                ; =2
1001338e0:     	ldr	x4, [sp, #0x188]
1001338e4:     	blr	x8
1001338e8:     	ldr	x2, [sp, #0x120]
1001338ec:     	ldr	s5, [sp, #0x1f0]
1001338f0:     	ldr	s6, [sp, #0x1e0]
1001338f4:     	ldr	s7, [sp, #0x1d0]
1001338f8:     	ldr	s16, [sp, #0x1c8]
1001338fc:     	ldr	s17, [sp, #0x1b0]
100133900:     	mov	w15, #0xa0              ; =160
100133904:     	mov	w16, #0x50              ; =80
100133908:     	ldr	x13, [sp, #0x210]
10013390c:     	ldr	x17, [sp, #0x208]
100133910:     	ldr	q18, [sp, #0x280]
100133914:     	ldr	q19, [sp, #0x260]
100133918:     	ldp	q21, q20, [sp, #0x230]
10013391c:     	ldr	q1, [sp, #0x220]
100133920:     	ldr	x21, [sp, #0x270]
100133924:     	str	x23, [x21, #0x78]
100133928:     	str	x20, [x21, #0x88]
10013392c:     	ldr	x23, [sp, #0x258]
100133930:     	ldr	x8, [x21, #0x80]
100133934:     	add	x9, x8, #0x1
100133938:     	str	x9, [x21, #0x80]
10013393c:     	ldr	x9, [x21, #0x78]
100133940:     	madd	x8, x8, x16, x9
100133944:     	stp	s20, s19, [x8]
100133948:     	stp	s21, s8, [x8, #0x8]
10013394c:     	stp	q18, q1, [x8, #0x10]
100133950:     	ldr	q0, [sp, #0x22e0]
100133954:     	str	q0, [x8, #0x30]
100133958:     	ldr	q0, [sp, #0x22f0]
10013395c:     	str	q0, [x8, #0x40]
100133960:     	ldrb	w8, [x24, #0x3c]
100133964:     	cmp	w8, #0x3
100133968:     	b.lo	0x1001334e8 <_render.TerminalRenderer.drawPane+0x50e8>
10013396c:     	mov	x28, #0x0               ; =0
100133970:     	sub	w8, w8, #0x2
100133974:     	and	x8, x8, #0xff
100133978:     	add	x8, x8, x8, lsl #2
10013397c:     	lsl	x20, x8, #4
100133980:     	b	0x1001339e8 <_render.TerminalRenderer.drawPane+0x55e8>
100133984:     	mov	x23, #0x0               ; =0
100133988:     	mov	x8, #0x0                ; =0
10013398c:     	cbz	x23, 0x100133bbc <_render.TerminalRenderer.drawPane+0x57bc>
100133990:     	mov	x27, x8
100133994:     	ldr	x21, [sp, #0x270]
100133998:     	str	x23, [x21, #0x78]
10013399c:     	str	x27, [x21, #0x88]
1001339a0:     	ldr	x23, [sp, #0x258]
1001339a4:     	ldr	x8, [x21, #0x80]
1001339a8:     	add	x9, x8, #0x1
1001339ac:     	str	x9, [x21, #0x80]
1001339b0:     	ldr	x9, [x21, #0x78]
1001339b4:     	madd	x8, x8, x16, x9
1001339b8:     	stp	s20, s19, [x8]
1001339bc:     	stp	s21, s8, [x8, #0x8]
1001339c0:     	str	q18, [x8, #0x10]
1001339c4:     	stp	s13, s11, [x8, #0x20]
1001339c8:     	stp	s10, s9, [x8, #0x28]
1001339cc:     	ldr	q0, [sp, #0x22e0]
1001339d0:     	str	q0, [x8, #0x30]
1001339d4:     	ldr	q0, [sp, #0x22f0]
1001339d8:     	str	q0, [x8, #0x40]
1001339dc:     	add	x28, x28, #0x50
1001339e0:     	cmp	x20, x28
1001339e4:     	b.eq	0x1001334e8 <_render.TerminalRenderer.drawPane+0x50e8>
1001339e8:     	add	x8, x26, x28
1001339ec:     	ldp	d0, d21, [x8]
1001339f0:     	ldr	q18, [x8, #0x10]
1001339f4:     	fmov	d20, d0
1001339f8:     	mov	s19, v0[1]
1001339fc:     	fadd	s1, s0, s21
100133a00:     	mov	s8, v21[1]
100133a04:     	fadd	s2, s19, s8
100133a08:     	fcmp	s0, s17
100133a0c:     	fccmp	s19, s14, #0x8, ge
100133a10:     	fccmp	s1, s15, #0x2, ge
100133a14:     	fccmp	s2, s12, #0x2, ls
100133a18:     	b.ls	0x100133a80 <_render.TerminalRenderer.drawPane+0x5680>
100133a1c:     	fminnm	s1, s1, s15
100133a20:     	fminnm	s2, s2, s12
100133a24:     	fmaxnm	s20, s20, s17
100133a28:     	fmaxnm	s19, s19, s14
100133a2c:     	fmaxnm	s1, s20, s1
100133a30:     	fmaxnm	s2, s19, s2
100133a34:     	fcmp	s21, #0.0
100133a38:     	b.le	0x100133a78 <_render.TerminalRenderer.drawPane+0x5678>
100133a3c:     	fcmp	s8, #0.0
100133a40:     	b.le	0x100133a78 <_render.TerminalRenderer.drawPane+0x5678>
100133a44:     	mov.d	v0[1], v0[0]
100133a48:     	ext.16b	v3, v18, v18, #0x8
100133a4c:     	fsub.2s	v3, v3, v18
100133a50:     	mov.16b	v4, v20
100133a54:     	mov.s	v4[1], v19[0]
100133a58:     	mov.s	v4[2], v1[0]
100133a5c:     	mov.s	v4[3], v2[0]
100133a60:     	fsub.4s	v0, v4, v0
100133a64:     	fdiv.2s	v3, v3, v21
100133a68:     	mov.d	v3[1], v3[0]
100133a6c:     	fmul.4s	v0, v0, v3
100133a70:     	dup.2d	v3, v18[0]
100133a74:     	fadd.4s	v18, v3, v0
100133a78:     	fsub	s21, s1, s20
100133a7c:     	fsub	s8, s2, s19
100133a80:     	ldp	s13, s11, [x8, #0x20]
100133a84:     	ldp	s10, s9, [x8, #0x28]
100133a88:     	ldur	q0, [x8, #0x30]
100133a8c:     	str	q0, [sp, #0x22e0]
100133a90:     	ldur	q0, [x8, #0x40]
100133a94:     	str	q0, [sp, #0x22f0]
100133a98:     	fcmp	s21, #0.0
100133a9c:     	b.le	0x1001339dc <_render.TerminalRenderer.drawPane+0x55dc>
100133aa0:     	fcmp	s8, #0.0
100133aa4:     	b.le	0x1001339dc <_render.TerminalRenderer.drawPane+0x55dc>
100133aa8:     	ldrb	w8, [x21, #0x98]
100133aac:     	cbz	w8, 0x100133ad0 <_render.TerminalRenderer.drawPane+0x56d0>
100133ab0:     	ldr	x9, [x21, #0x90]
100133ab4:     	ldr	x8, [x21, #0x80]
100133ab8:     	cmp	x8, x9
100133abc:     	b.lo	0x1001339a8 <_render.TerminalRenderer.drawPane+0x55a8>
100133ac0:     	ldr	x8, [x21, #0xa0]
100133ac4:     	add	x8, x8, #0x1
100133ac8:     	str	x8, [x21, #0xa0]
100133acc:     	b	0x1001339dc <_render.TerminalRenderer.drawPane+0x55dc>
100133ad0:     	ldp	x8, x24, [x21, #0x80]
100133ad4:     	cmp	x24, x8
100133ad8:     	b.hi	0x1001339a8 <_render.TerminalRenderer.drawPane+0x55a8>
100133adc:     	add	x8, x8, #0x1
100133ae0:     	lsr	x9, x8, #1
100133ae4:     	add	x9, x9, #0x1
100133ae8:     	adds	x8, x8, x9
100133aec:     	csinv	x27, x8, xzr, lo
100133af0:     	cmp	x24, x27
100133af4:     	b.hs	0x1001339a4 <_render.TerminalRenderer.drawPane+0x55a4>
100133af8:     	ldp	x19, x10, [x21, #0x68]
100133afc:     	ldr	x9, [sp, #0x278]
100133b00:     	add	x8, x9, #0x10, lsl #12  ; =0x10000
100133b04:     	ldr	x1, [x8, #0x2950]
100133b08:     	add	x22, x27, x27, lsl #2
100133b0c:     	cbz	x24, 0x100133984 <_render.TerminalRenderer.drawPane+0x5584>
100133b10:     	umulh	x8, x27, x16
100133b14:     	cmp	xzr, x8
100133b18:     	cset	w8, ne
100133b1c:     	strb	w8, [sp, #0xee0]
100133b20:     	b.ne	0x100133984 <_render.TerminalRenderer.drawPane+0x5584>
100133b24:     	stp	q21, q20, [sp, #0x230]
100133b28:     	str	q19, [sp, #0x260]
100133b2c:     	str	q18, [sp, #0x280]
100133b30:     	lsl	x21, x22, #4
100133b34:     	add	x8, x24, x24, lsl #2
100133b38:     	lsl	x2, x8, #4
100133b3c:     	str	x10, [sp, #0x180]
100133b40:     	ldr	x8, [x10, #0x10]
100133b44:     	mov	x0, x19
100133b48:     	str	x1, [sp, #0x220]
100133b4c:     	mov	w3, #0x2                ; =2
100133b50:     	mov	x4, x21
100133b54:     	ldr	x5, [sp, #0x188]
100133b58:     	blr	x8
100133b5c:     	mov	x23, x0
100133b60:     	cbz	x0, 0x100133b78 <_render.TerminalRenderer.drawPane+0x5778>
100133b64:     	lsr	x8, x21, #4
100133b68:     	mov	x9, #-0x3333333333333334 ; =-3689348814741910324
100133b6c:     	movk	x9, #0xcccd
100133b70:     	mul	x8, x8, x9
100133b74:     	b	0x100133b7c <_render.TerminalRenderer.drawPane+0x577c>
100133b78:     	mov	x8, #0x0                ; =0
100133b7c:     	ldr	x2, [sp, #0x120]
100133b80:     	ldr	s5, [sp, #0x1f0]
100133b84:     	ldr	s6, [sp, #0x1e0]
100133b88:     	ldr	s7, [sp, #0x1d0]
100133b8c:     	ldr	s16, [sp, #0x1c8]
100133b90:     	ldr	s17, [sp, #0x1b0]
100133b94:     	mov	w15, #0xa0              ; =160
100133b98:     	mov	w16, #0x50              ; =80
100133b9c:     	ldr	x13, [sp, #0x210]
100133ba0:     	ldr	x17, [sp, #0x208]
100133ba4:     	ldr	q18, [sp, #0x280]
100133ba8:     	ldr	q19, [sp, #0x260]
100133bac:     	ldp	q21, q20, [sp, #0x230]
100133bb0:     	ldr	x10, [sp, #0x180]
100133bb4:     	ldr	x1, [sp, #0x220]
100133bb8:     	cbnz	x23, 0x100133990 <_render.TerminalRenderer.drawPane+0x5590>
100133bbc:     	umulh	x8, x27, x16
100133bc0:     	cmp	xzr, x8
100133bc4:     	cset	w8, ne
100133bc8:     	strb	w8, [sp, #0xee0]
100133bcc:     	b.ne	0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
100133bd0:     	str	x1, [sp, #0x220]
100133bd4:     	stp	q21, q20, [sp, #0x230]
100133bd8:     	str	q19, [sp, #0x260]
100133bdc:     	str	q18, [sp, #0x280]
100133be0:     	lsl	x1, x22, #4
100133be4:     	cbz	x1, 0x100133c7c <_render.TerminalRenderer.drawPane+0x587c>
100133be8:     	mov	x22, x10
100133bec:     	ldr	x8, [x10]
100133bf0:     	mov	x0, x19
100133bf4:     	mov	w2, #0x2                ; =2
100133bf8:     	ldr	x3, [sp, #0x188]
100133bfc:     	blr	x8
100133c00:     	mov	x23, x0
100133c04:     	ldr	x21, [sp, #0x270]
100133c08:     	cbz	x0, 0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
100133c0c:     	ldp	x1, x8, [x21, #0x78]
100133c10:     	add	x8, x8, x8, lsl #2
100133c14:     	lsl	x2, x8, #4
100133c18:     	mov	x0, x23
100133c1c:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100133c20:     	cbz	x24, 0x100133c44 <_render.TerminalRenderer.drawPane+0x5844>
100133c24:     	add	x8, x24, x24, lsl #2
100133c28:     	lsl	x2, x8, #4
100133c2c:     	ldr	x8, [x22, #0x18]
100133c30:     	mov	x0, x19
100133c34:     	ldr	x1, [sp, #0x220]
100133c38:     	mov	w3, #0x2                ; =2
100133c3c:     	ldr	x4, [sp, #0x188]
100133c40:     	blr	x8
100133c44:     	ldr	x2, [sp, #0x120]
100133c48:     	ldr	s5, [sp, #0x1f0]
100133c4c:     	ldr	s6, [sp, #0x1e0]
100133c50:     	ldr	s7, [sp, #0x1d0]
100133c54:     	ldr	s16, [sp, #0x1c8]
100133c58:     	ldr	s17, [sp, #0x1b0]
100133c5c:     	mov	w15, #0xa0              ; =160
100133c60:     	mov	w16, #0x50              ; =80
100133c64:     	ldr	x13, [sp, #0x210]
100133c68:     	ldr	x17, [sp, #0x208]
100133c6c:     	ldr	q18, [sp, #0x280]
100133c70:     	ldr	q19, [sp, #0x260]
100133c74:     	ldp	q21, q20, [sp, #0x230]
100133c78:     	b	0x100133998 <_render.TerminalRenderer.drawPane+0x5598>
100133c7c:     	mov	x22, x10
100133c80:     	mov	x23, #-0x4              ; =-4
100133c84:     	ldr	x21, [sp, #0x270]
100133c88:     	ldp	x1, x8, [x21, #0x78]
100133c8c:     	add	x8, x8, x8, lsl #2
100133c90:     	lsl	x2, x8, #4
100133c94:     	mov	x0, x23
100133c98:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100133c9c:     	cbnz	x24, 0x100133c24 <_render.TerminalRenderer.drawPane+0x5824>
100133ca0:     	b	0x100133c44 <_render.TerminalRenderer.drawPane+0x5844>
100133ca4:     	lsl	x21, x22, #4
100133ca8:     	add	x8, x27, x27, lsl #2
100133cac:     	lsl	x2, x8, #4
100133cb0:     	ldr	x8, [x28, #0x10]
100133cb4:     	mov	x0, x19
100133cb8:     	mov	x23, x10
100133cbc:     	mov	x1, x10
100133cc0:     	mov	w3, #0x2                ; =2
100133cc4:     	mov	x4, x21
100133cc8:     	ldr	x5, [sp, #0x188]
100133ccc:     	str	q18, [sp, #0x280]
100133cd0:     	str	q19, [sp, #0x260]
100133cd4:     	stp	q21, q20, [sp, #0x230]
100133cd8:     	blr	x8
100133cdc:     	mov	x10, x23
100133ce0:     	ldp	q21, q20, [sp, #0x230]
100133ce4:     	ldr	q19, [sp, #0x260]
100133ce8:     	ldr	q18, [sp, #0x280]
100133cec:     	ldr	x17, [sp, #0x208]
100133cf0:     	ldr	x13, [sp, #0x210]
100133cf4:     	mov	w16, #0x50              ; =80
100133cf8:     	mov	w15, #0xa0              ; =160
100133cfc:     	ldr	s17, [sp, #0x1b0]
100133d00:     	ldr	s16, [sp, #0x1c8]
100133d04:     	ldr	s7, [sp, #0x1d0]
100133d08:     	ldr	s6, [sp, #0x1e0]
100133d0c:     	ldr	s5, [sp, #0x1f0]
100133d10:     	ldr	x2, [sp, #0x120]
100133d14:     	lsr	x8, x21, #4
100133d18:     	mov	x9, #-0x3333333333333334 ; =-3689348814741910324
100133d1c:     	movk	x9, #0xcccd
100133d20:     	mul	x8, x8, x9
100133d24:     	cmp	x0, #0x0
100133d28:     	csel	x23, xzr, x0, eq
100133d2c:     	csel	x8, xzr, x8, eq
100133d30:     	cbnz	x23, 0x1001337b8 <_render.TerminalRenderer.drawPane+0x53b8>
100133d34:     	umulh	x8, x20, x16
100133d38:     	cmp	xzr, x8
100133d3c:     	cset	w8, ne
100133d40:     	strb	w8, [sp, #0xee0]
100133d44:     	b.ne	0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
100133d48:     	str	x10, [sp, #0x220]
100133d4c:     	stp	q21, q20, [sp, #0x230]
100133d50:     	str	q19, [sp, #0x260]
100133d54:     	str	q18, [sp, #0x280]
100133d58:     	lsl	x1, x22, #4
100133d5c:     	cbz	x1, 0x100134160 <_render.TerminalRenderer.drawPane+0x5d60>
100133d60:     	ldr	x8, [x28]
100133d64:     	mov	x0, x19
100133d68:     	mov	w2, #0x2                ; =2
100133d6c:     	ldr	x3, [sp, #0x188]
100133d70:     	blr	x8
100133d74:     	mov	x23, x0
100133d78:     	ldr	x21, [sp, #0x270]
100133d7c:     	cbz	x0, 0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
100133d80:     	ldp	x1, x8, [x21, #0x78]
100133d84:     	add	x8, x8, x8, lsl #2
100133d88:     	lsl	x2, x8, #4
100133d8c:     	mov	x0, x23
100133d90:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100133d94:     	cbz	x27, 0x100133db8 <_render.TerminalRenderer.drawPane+0x59b8>
100133d98:     	add	x8, x27, x27, lsl #2
100133d9c:     	lsl	x2, x8, #4
100133da0:     	ldr	x8, [x28, #0x18]
100133da4:     	mov	x0, x19
100133da8:     	ldr	x1, [sp, #0x220]
100133dac:     	mov	w3, #0x2                ; =2
100133db0:     	ldr	x4, [sp, #0x188]
100133db4:     	blr	x8
100133db8:     	ldr	x2, [sp, #0x120]
100133dbc:     	ldr	s5, [sp, #0x1f0]
100133dc0:     	ldr	s6, [sp, #0x1e0]
100133dc4:     	ldr	s7, [sp, #0x1d0]
100133dc8:     	ldr	s16, [sp, #0x1c8]
100133dcc:     	ldr	s17, [sp, #0x1b0]
100133dd0:     	mov	w15, #0xa0              ; =160
100133dd4:     	mov	w16, #0x50              ; =80
100133dd8:     	ldr	x13, [sp, #0x210]
100133ddc:     	ldr	x17, [sp, #0x208]
100133de0:     	ldr	q18, [sp, #0x280]
100133de4:     	ldr	q19, [sp, #0x260]
100133de8:     	ldp	q21, q20, [sp, #0x230]
100133dec:     	str	x23, [x21, #0x78]
100133df0:     	str	x20, [x21, #0x88]
100133df4:     	ldr	x23, [sp, #0x258]
100133df8:     	ldr	x8, [x21, #0x80]
100133dfc:     	add	x9, x8, #0x1
100133e00:     	str	x9, [x21, #0x80]
100133e04:     	ldr	x9, [x21, #0x78]
100133e08:     	madd	x8, x8, x16, x9
100133e0c:     	stp	s20, s19, [x8]
100133e10:     	stp	s21, s8, [x8, #0x8]
100133e14:     	str	q18, [x8, #0x10]
100133e18:     	stp	s7, s6, [x8, #0x20]
100133e1c:     	stp	s16, s5, [x8, #0x28]
100133e20:     	ldr	q0, [sp, #0x22e0]
100133e24:     	str	q0, [x8, #0x30]
100133e28:     	ldr	q0, [sp, #0x22f0]
100133e2c:     	str	q0, [x8, #0x40]
100133e30:     	ldrb	w8, [x24, #0x3c]
100133e34:     	subs	w9, w8, #0x2
100133e38:     	csel	w28, wzr, w9, lo
100133e3c:     	cmp	w8, #0x3
100133e40:     	b.lo	0x1001334e8 <_render.TerminalRenderer.drawPane+0x50e8>
100133e44:     	mov	x20, x26
100133e48:     	b	0x100133eb0 <_render.TerminalRenderer.drawPane+0x5ab0>
100133e4c:     	mov	x23, #0x0               ; =0
100133e50:     	mov	x8, #0x0                ; =0
100133e54:     	cbz	x23, 0x100134078 <_render.TerminalRenderer.drawPane+0x5c78>
100133e58:     	mov	x24, x8
100133e5c:     	ldr	x21, [sp, #0x270]
100133e60:     	str	x23, [x21, #0x78]
100133e64:     	str	x24, [x21, #0x88]
100133e68:     	ldr	x23, [sp, #0x258]
100133e6c:     	ldr	x8, [x21, #0x80]
100133e70:     	add	x9, x8, #0x1
100133e74:     	str	x9, [x21, #0x80]
100133e78:     	ldr	x9, [x21, #0x78]
100133e7c:     	madd	x8, x8, x16, x9
100133e80:     	stp	s20, s19, [x8]
100133e84:     	stp	s21, s8, [x8, #0x8]
100133e88:     	str	q18, [x8, #0x10]
100133e8c:     	stp	s7, s6, [x8, #0x20]
100133e90:     	stp	s16, s5, [x8, #0x28]
100133e94:     	ldr	q0, [sp, #0x22e0]
100133e98:     	str	q0, [x8, #0x30]
100133e9c:     	ldr	q0, [sp, #0x22f0]
100133ea0:     	str	q0, [x8, #0x40]
100133ea4:     	add	x20, x20, #0x50
100133ea8:     	subs	x28, x28, #0x1
100133eac:     	b.eq	0x1001334e8 <_render.TerminalRenderer.drawPane+0x50e8>
100133eb0:     	ldp	d0, d21, [x20]
100133eb4:     	ldr	q18, [x20, #0x10]
100133eb8:     	fmov	d20, d0
100133ebc:     	mov	s19, v0[1]
100133ec0:     	fadd	s1, s0, s21
100133ec4:     	mov	s8, v21[1]
100133ec8:     	fadd	s2, s19, s8
100133ecc:     	fcmp	s0, s17
100133ed0:     	fccmp	s19, s14, #0x8, ge
100133ed4:     	fccmp	s1, s15, #0x2, ge
100133ed8:     	fccmp	s2, s12, #0x2, ls
100133edc:     	b.ls	0x100133f44 <_render.TerminalRenderer.drawPane+0x5b44>
100133ee0:     	fminnm	s1, s1, s15
100133ee4:     	fminnm	s2, s2, s12
100133ee8:     	fmaxnm	s20, s20, s17
100133eec:     	fmaxnm	s19, s19, s14
100133ef0:     	fmaxnm	s1, s20, s1
100133ef4:     	fmaxnm	s2, s19, s2
100133ef8:     	fcmp	s21, #0.0
100133efc:     	b.le	0x100133f3c <_render.TerminalRenderer.drawPane+0x5b3c>
100133f00:     	fcmp	s8, #0.0
100133f04:     	b.le	0x100133f3c <_render.TerminalRenderer.drawPane+0x5b3c>
100133f08:     	mov.d	v0[1], v0[0]
100133f0c:     	ext.16b	v3, v18, v18, #0x8
100133f10:     	fsub.2s	v3, v3, v18
100133f14:     	mov.16b	v4, v20
100133f18:     	mov.s	v4[1], v19[0]
100133f1c:     	mov.s	v4[2], v1[0]
100133f20:     	mov.s	v4[3], v2[0]
100133f24:     	fsub.4s	v0, v4, v0
100133f28:     	fdiv.2s	v3, v3, v21
100133f2c:     	mov.d	v3[1], v3[0]
100133f30:     	fmul.4s	v0, v0, v3
100133f34:     	dup.2d	v3, v18[0]
100133f38:     	fadd.4s	v18, v3, v0
100133f3c:     	fsub	s21, s1, s20
100133f40:     	fsub	s8, s2, s19
100133f44:     	ldur	q0, [x20, #0x30]
100133f48:     	str	q0, [sp, #0x22e0]
100133f4c:     	ldur	q0, [x20, #0x40]
100133f50:     	str	q0, [sp, #0x22f0]
100133f54:     	fcmp	s21, #0.0
100133f58:     	b.le	0x100133ea4 <_render.TerminalRenderer.drawPane+0x5aa4>
100133f5c:     	fcmp	s8, #0.0
100133f60:     	b.le	0x100133ea4 <_render.TerminalRenderer.drawPane+0x5aa4>
100133f64:     	ldrb	w8, [x21, #0x98]
100133f68:     	cbz	w8, 0x100133f8c <_render.TerminalRenderer.drawPane+0x5b8c>
100133f6c:     	ldr	x9, [x21, #0x90]
100133f70:     	ldr	x8, [x21, #0x80]
100133f74:     	cmp	x8, x9
100133f78:     	b.lo	0x100133e70 <_render.TerminalRenderer.drawPane+0x5a70>
100133f7c:     	ldr	x8, [x21, #0xa0]
100133f80:     	add	x8, x8, #0x1
100133f84:     	str	x8, [x21, #0xa0]
100133f88:     	b	0x100133ea4 <_render.TerminalRenderer.drawPane+0x5aa4>
100133f8c:     	ldp	x8, x27, [x21, #0x80]
100133f90:     	cmp	x27, x8
100133f94:     	b.hi	0x100133e70 <_render.TerminalRenderer.drawPane+0x5a70>
100133f98:     	add	x8, x8, #0x1
100133f9c:     	lsr	x9, x8, #1
100133fa0:     	add	x9, x9, #0x1
100133fa4:     	adds	x8, x8, x9
100133fa8:     	csinv	x24, x8, xzr, lo
100133fac:     	cmp	x27, x24
100133fb0:     	b.hs	0x100133e6c <_render.TerminalRenderer.drawPane+0x5a6c>
100133fb4:     	ldp	x19, x10, [x21, #0x68]
100133fb8:     	ldr	x9, [sp, #0x278]
100133fbc:     	add	x8, x9, #0x10, lsl #12  ; =0x10000
100133fc0:     	ldr	x1, [x8, #0x2950]
100133fc4:     	add	x22, x24, x24, lsl #2
100133fc8:     	cbz	x27, 0x100133e4c <_render.TerminalRenderer.drawPane+0x5a4c>
100133fcc:     	umulh	x8, x24, x16
100133fd0:     	cmp	xzr, x8
100133fd4:     	cset	w8, ne
100133fd8:     	strb	w8, [sp, #0xee0]
100133fdc:     	b.ne	0x100133e4c <_render.TerminalRenderer.drawPane+0x5a4c>
100133fe0:     	stp	q21, q20, [sp, #0x230]
100133fe4:     	str	q19, [sp, #0x260]
100133fe8:     	str	q18, [sp, #0x280]
100133fec:     	lsl	x21, x22, #4
100133ff0:     	add	x8, x27, x27, lsl #2
100133ff4:     	lsl	x2, x8, #4
100133ff8:     	str	x10, [sp, #0x180]
100133ffc:     	ldr	x8, [x10, #0x10]
100134000:     	mov	x0, x19
100134004:     	str	x1, [sp, #0x220]
100134008:     	mov	w3, #0x2                ; =2
10013400c:     	mov	x4, x21
100134010:     	ldr	x5, [sp, #0x188]
100134014:     	blr	x8
100134018:     	mov	x23, x0
10013401c:     	cbz	x0, 0x100134034 <_render.TerminalRenderer.drawPane+0x5c34>
100134020:     	lsr	x8, x21, #4
100134024:     	mov	x9, #-0x3333333333333334 ; =-3689348814741910324
100134028:     	movk	x9, #0xcccd
10013402c:     	mul	x8, x8, x9
100134030:     	b	0x100134038 <_render.TerminalRenderer.drawPane+0x5c38>
100134034:     	mov	x8, #0x0                ; =0
100134038:     	ldr	x2, [sp, #0x120]
10013403c:     	ldr	s5, [sp, #0x1f0]
100134040:     	ldr	s6, [sp, #0x1e0]
100134044:     	ldr	s7, [sp, #0x1d0]
100134048:     	ldr	s16, [sp, #0x1c8]
10013404c:     	ldr	s17, [sp, #0x1b0]
100134050:     	mov	w15, #0xa0              ; =160
100134054:     	mov	w16, #0x50              ; =80
100134058:     	ldr	x13, [sp, #0x210]
10013405c:     	ldr	x17, [sp, #0x208]
100134060:     	ldr	q18, [sp, #0x280]
100134064:     	ldr	q19, [sp, #0x260]
100134068:     	ldp	q21, q20, [sp, #0x230]
10013406c:     	ldr	x10, [sp, #0x180]
100134070:     	ldr	x1, [sp, #0x220]
100134074:     	cbnz	x23, 0x100133e58 <_render.TerminalRenderer.drawPane+0x5a58>
100134078:     	umulh	x8, x24, x16
10013407c:     	cmp	xzr, x8
100134080:     	cset	w8, ne
100134084:     	strb	w8, [sp, #0xee0]
100134088:     	b.ne	0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
10013408c:     	str	x1, [sp, #0x220]
100134090:     	stp	q21, q20, [sp, #0x230]
100134094:     	str	q19, [sp, #0x260]
100134098:     	str	q18, [sp, #0x280]
10013409c:     	lsl	x1, x22, #4
1001340a0:     	cbz	x1, 0x100134138 <_render.TerminalRenderer.drawPane+0x5d38>
1001340a4:     	mov	x22, x10
1001340a8:     	ldr	x8, [x10]
1001340ac:     	mov	x0, x19
1001340b0:     	mov	w2, #0x2                ; =2
1001340b4:     	ldr	x3, [sp, #0x188]
1001340b8:     	blr	x8
1001340bc:     	mov	x23, x0
1001340c0:     	ldr	x21, [sp, #0x270]
1001340c4:     	cbz	x0, 0x100134184 <_render.TerminalRenderer.drawPane+0x5d84>
1001340c8:     	ldp	x1, x8, [x21, #0x78]
1001340cc:     	add	x8, x8, x8, lsl #2
1001340d0:     	lsl	x2, x8, #4
1001340d4:     	mov	x0, x23
1001340d8:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
1001340dc:     	cbz	x27, 0x100134100 <_render.TerminalRenderer.drawPane+0x5d00>
1001340e0:     	add	x8, x27, x27, lsl #2
1001340e4:     	lsl	x2, x8, #4
1001340e8:     	ldr	x8, [x22, #0x18]
1001340ec:     	mov	x0, x19
1001340f0:     	ldr	x1, [sp, #0x220]
1001340f4:     	mov	w3, #0x2                ; =2
1001340f8:     	ldr	x4, [sp, #0x188]
1001340fc:     	blr	x8
100134100:     	ldr	x2, [sp, #0x120]
100134104:     	ldr	s5, [sp, #0x1f0]
100134108:     	ldr	s6, [sp, #0x1e0]
10013410c:     	ldr	s7, [sp, #0x1d0]
100134110:     	ldr	s16, [sp, #0x1c8]
100134114:     	ldr	s17, [sp, #0x1b0]
100134118:     	mov	w15, #0xa0              ; =160
10013411c:     	mov	w16, #0x50              ; =80
100134120:     	ldr	x13, [sp, #0x210]
100134124:     	ldr	x17, [sp, #0x208]
100134128:     	ldr	q18, [sp, #0x280]
10013412c:     	ldr	q19, [sp, #0x260]
100134130:     	ldp	q21, q20, [sp, #0x230]
100134134:     	b	0x100133e60 <_render.TerminalRenderer.drawPane+0x5a60>
100134138:     	mov	x22, x10
10013413c:     	mov	x23, #-0x4              ; =-4
100134140:     	ldr	x21, [sp, #0x270]
100134144:     	ldp	x1, x8, [x21, #0x78]
100134148:     	add	x8, x8, x8, lsl #2
10013414c:     	lsl	x2, x8, #4
100134150:     	mov	x0, x23
100134154:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
100134158:     	cbnz	x27, 0x1001340e0 <_render.TerminalRenderer.drawPane+0x5ce0>
10013415c:     	b	0x100134100 <_render.TerminalRenderer.drawPane+0x5d00>
100134160:     	mov	x23, #-0x4              ; =-4
100134164:     	ldr	x21, [sp, #0x270]
100134168:     	ldp	x1, x8, [x21, #0x78]
10013416c:     	add	x8, x8, x8, lsl #2
100134170:     	lsl	x2, x8, #4
100134174:     	mov	x0, x23
100134178:     	bl	0x1001cc354 <dyld_stub_binder+0x1001cc354>
10013417c:     	cbnz	x27, 0x100133d98 <_render.TerminalRenderer.drawPane+0x5998>
100134180:     	b	0x100133db8 <_render.TerminalRenderer.drawPane+0x59b8>
100134184:     	mov	w0, #0x1a               ; =26
100134188:     	b	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
10013418c:     	ldr	x0, [sp, #0x278]
100134190:     	mov	x1, x23
100134194:     	ldp	x3, x2, [sp, #0x88]
100134198:     	mov	w4, #0x2                ; =2
10013419c:     	bl	0x10012e0b8 <_render.TerminalRenderer.pushImages>
1001341a0:     	ands	w0, w0, #0xffff
1001341a4:     	ldr	w8, [sp, #0x298]
1001341a8:     	csinc	w8, w8, wzr, eq
1001341ac:     	tbnz	w8, #0x0, 0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
1001341b0:     	ldr	w8, [sp, #0x1c0]
1001341b4:     	tst	w8, #0x3
1001341b8:     	b.eq	0x100134248 <_render.TerminalRenderer.drawPane+0x5e48>
1001341bc:     	ldr	s0, [sp, #0x190]
1001341c0:     	str	s0, [sp, #0x344]
1001341c4:     	ldr	s0, [sp, #0x1a0]
1001341c8:     	str	s0, [sp, #0x348]
1001341cc:     	ldr	s0, [sp, #0x130]
1001341d0:     	str	s0, [sp, #0x34c]
1001341d4:     	ldr	s0, [sp, #0x148]
1001341d8:     	str	s0, [sp, #0x350]
1001341dc:     	ldr	q0, [sp, #0x2f0]
1001341e0:     	add	x9, sp, #0x30c
1001341e4:     	stur	q0, [x9, #0x48]
1001341e8:     	ldr	s0, [sp, #0x1d0]
1001341ec:     	str	s0, [sp, #0x364]
1001341f0:     	ldr	s0, [sp, #0x1e0]
1001341f4:     	str	s0, [sp, #0x368]
1001341f8:     	ldr	s0, [sp, #0x1c8]
1001341fc:     	str	s0, [sp, #0x36c]
100134200:     	ldr	s0, [sp, #0x1f0]
100134204:     	str	s0, [sp, #0x370]
100134208:     	ldr	s0, [sp, #0x150]
10013420c:     	str	s0, [sp, #0x374]
100134210:     	strb	w8, [sp, #0x378]
100134214:     	ldrh	w8, [sp, #0x2e8]
100134218:     	sturh	w8, [x9, #0x6d]
10013421c:     	ldrb	w8, [sp, #0x2ea]
100134220:     	strb	w8, [sp, #0x37b]
100134224:     	add	x0, sp, #0x344
100134228:     	mov	w8, #0x2940             ; =10560
10013422c:     	movk	w8, #0x1, lsl #16
100134230:     	ldr	x9, [sp, #0x278]
100134234:     	add	x1, x9, x8
100134238:     	bl	0x10012e29c <_render.CursorPaint.paint>
10013423c:     	ands	w8, w0, #0xffff
100134240:     	csel	w0, wzr, w8, eq
100134244:     	b	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
100134248:     	mov	w0, #0x0                ; =0
10013424c:     	add	sp, sp, #0x3, lsl #12   ; =0x3000
100134250:     	add	sp, sp, #0x9b0
100134254:     	ldp	x29, x30, [sp, #0x90]
100134258:     	ldp	x20, x19, [sp, #0x80]
10013425c:     	ldp	x22, x21, [sp, #0x70]
100134260:     	ldp	x24, x23, [sp, #0x60]
100134264:     	ldp	x26, x25, [sp, #0x50]
100134268:     	ldp	x28, x27, [sp, #0x40]
10013426c:     	ldp	d9, d8, [sp, #0x30]
100134270:     	ldp	d11, d10, [sp, #0x20]
100134274:     	ldp	d13, d12, [sp, #0x10]
100134278:     	ldp	d15, d14, [sp], #0xa0
10013427c:     	ret
100134280:     	mov	w15, #0x3               ; =3
100134284:     	add	w11, w11, w13, uxth
100134288:     	ldr	x16, [sp, #0x260]
10013428c:     	ldrh	w12, [x16, #0x4]
100134290:     	add	w10, w10, w8, uxth
100134294:     	ldrh	w8, [x16, #0x6]
100134298:     	ldr	w13, [x16, #0x180]
10013429c:     	ldr	w14, [x16, #0x17c]
1001342a0:     	and	w15, w15, #0x3
1001342a4:     	strb	w15, [sp, #0x2ec]
1001342a8:     	ldrb	w15, [x16, #0x1d5]
1001342ac:     	cbz	w15, 0x1001342f8 <_render.TerminalRenderer.drawPane+0x5ef8>
1001342b0:     	ldr	b0, [x16, #0x1d2]
1001342b4:     	ucvtf	s0, s0
1001342b8:     	mov	w15, #0x437f0000        ; =1132396544
1001342bc:     	fmov	s1, w15
1001342c0:     	fdiv	s0, s0, s1
1001342c4:     	ldr	b2, [x16, #0x1d3]
1001342c8:     	ucvtf	s2, s2
1001342cc:     	fdiv	s2, s2, s1
1001342d0:     	ldr	b3, [x16, #0x1d4]
1001342d4:     	ucvtf	s3, s3
1001342d8:     	str	s0, [sp, #0xee0]
1001342dc:     	str	s2, [sp, #0xee4]
1001342e0:     	fdiv	s0, s3, s1
1001342e4:     	str	s0, [sp, #0xee8]
1001342e8:     	mov	w15, #0x3f800000        ; =1065353216
1001342ec:     	str	w15, [sp, #0xeec]
1001342f0:     	add	x15, sp, #0xee0
1001342f4:     	b	0x100134314 <_render.TerminalRenderer.drawPane+0x5f14>
1001342f8:     	mov	w15, #0x6b88            ; =27528
1001342fc:     	movk	w15, #0x1, lsl #16
100134300:     	ldr	x17, [sp, #0x278]
100134304:     	ldr	q0, [x17, x15]
100134308:     	str	q0, [sp, #0x22e0]
10013430c:     	add	x15, sp, #0x2, lsl #12  ; =0x2000
100134310:     	add	x15, x15, #0x2e0
100134314:     	madd	w11, w12, w11, w14
100134318:     	madd	w10, w8, w10, w13
10013431c:     	mul	w9, w9, w12
100134320:     	ldr	q0, [x15]
100134324:     	str	q0, [sp, #0x2f0]
100134328:     	ldrb	w12, [x16, #0x1d9]
10013432c:     	cbz	w12, 0x100134364 <_render.TerminalRenderer.drawPane+0x5f64>
100134330:     	ldr	b0, [x16, #0x1d6]
100134334:     	ucvtf	s0, s0
100134338:     	mov	w12, #0x437f0000        ; =1132396544
10013433c:     	fmov	s1, w12
100134340:     	fdiv	s7, s0, s1
100134344:     	ldr	b0, [x16, #0x1d7]
100134348:     	ucvtf	s0, s0
10013434c:     	fdiv	s6, s0, s1
100134350:     	ldr	b0, [x16, #0x1d8]
100134354:     	ucvtf	s0, s0
100134358:     	fmov	s5, #1.00000000
10013435c:     	fdiv	s16, s0, s1
100134360:     	b	0x100134374 <_render.TerminalRenderer.drawPane+0x5f74>
100134364:     	ldr	s7, [x16, #0x1ac]
100134368:     	ldr	s6, [x16, #0x1b0]
10013436c:     	ldr	s16, [x16, #0x1b4]
100134370:     	ldr	s5, [x16, #0x1b8]
100134374:     	ucvtf	s2, w11
100134378:     	ucvtf	s15, w10
10013437c:     	ucvtf	s14, w9
100134380:     	ucvtf	s13, w8
100134384:     	ldr	s0, [x16, #0x178]
100134388:     	fadd	s0, s0, s0
10013438c:     	frinta	s0, s0
100134390:     	fmov	s1, #1.00000000
100134394:     	fmaxnm	s12, s0, s1
100134398:     	ldrb	w22, [sp, #0x2ec]
10013439c:     	tst	w22, #0x3
1001343a0:     	str	w22, [sp, #0x1c0]
1001343a4:     	str	s12, [sp, #0x150]
1001343a8:     	str	s13, [sp, #0x148]
1001343ac:     	str	s14, [sp, #0x130]
1001343b0:     	str	s15, [sp, #0x1a0]
1001343b4:     	str	s2, [sp, #0x190]
1001343b8:     	b.eq	0x1001343c4 <_render.TerminalRenderer.drawPane+0x5fc4>
1001343bc:     	str	wzr, [sp, #0x298]
1001343c0:     	b	0x1001333f8 <_render.TerminalRenderer.drawPane+0x4ff8>
1001343c4:     	str	s2, [sp, #0x30c]
1001343c8:     	str	s15, [sp, #0x310]
1001343cc:     	str	s14, [sp, #0x314]
1001343d0:     	str	s13, [sp, #0x318]
1001343d4:     	ldr	q0, [sp, #0x2f0]
1001343d8:     	add	x8, sp, #0x21d
1001343dc:     	stur	q0, [x8, #0xff]
1001343e0:     	fmov	d10, d7
1001343e4:     	str	s7, [sp, #0x32c]
1001343e8:     	fmov	d9, d6
1001343ec:     	str	s6, [sp, #0x330]
1001343f0:     	fmov	d11, d16
1001343f4:     	str	s16, [sp, #0x334]
1001343f8:     	fmov	d8, d5
1001343fc:     	str	s5, [sp, #0x338]
100134400:     	str	s12, [sp, #0x33c]
100134404:     	strb	w22, [sp, #0x340]
100134408:     	ldrh	w8, [sp, #0x2e8]
10013440c:     	add	x9, sp, #0x30c
100134410:     	sturh	w8, [x9, #0x35]
100134414:     	ldrb	w8, [sp, #0x2ea]
100134418:     	strb	w8, [sp, #0x343]
10013441c:     	add	x0, sp, #0x30c
100134420:     	mov	w8, #0x2940             ; =10560
100134424:     	movk	w8, #0x1, lsl #16
100134428:     	ldr	x9, [sp, #0x278]
10013442c:     	add	x1, x9, x8
100134430:     	bl	0x10012e29c <_render.CursorPaint.paint>
100134434:     	ands	w0, w0, #0xffff
100134438:     	b.ne	0x10013424c <_render.TerminalRenderer.drawPane+0x5e4c>
10013443c:     	str	wzr, [sp, #0x298]
100134440:     	ldr	x2, [sp, #0x120]
100134444:     	fmov	d5, d8
100134448:     	fmov	d6, d9
10013444c:     	fmov	d7, d10
100134450:     	fmov	d16, d11
100134454:     	b	0x1001333f8 <_render.TerminalRenderer.drawPane+0x4ff8>
100134458:     	ldr	w11, [x9, #0xfc]
10013445c:     	subs	w10, w10, w11
100134460:     	b.hs	0x10013447c <_render.TerminalRenderer.drawPane+0x607c>
100134464:     	mov	w12, #0x0               ; =0
100134468:     	b	0x100133344 <_render.TerminalRenderer.drawPane+0x4f44>
10013446c:     	cbnz	w12, 0x100134490 <_render.TerminalRenderer.drawPane+0x6090>
100134470:     	ldr	x12, [sp, #0x260]
100134474:     	ldrb	w15, [x12, #0x13c]
100134478:     	b	0x100134284 <_render.TerminalRenderer.drawPane+0x5e84>
10013447c:     	cmp	w10, w16
100134480:     	cset	w12, lo
100134484:     	b	0x100133344 <_render.TerminalRenderer.drawPane+0x4f44>
100134488:     	mov	w15, #0x1               ; =1
10013448c:     	b	0x100134284 <_render.TerminalRenderer.drawPane+0x5e84>
100134490:     	mov	w15, #0x0               ; =0
100134494:     	b	0x100134284 <_render.TerminalRenderer.drawPane+0x5e84>

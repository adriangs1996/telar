
/tmp/telar-access-clusters-2.QhXJGE/G/bin/telar-dod-probe:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010012e4bc <_render.TerminalRenderer.drawPane>:
10012e4bc:     	stp	d15, d14, [sp, #-0xa0]!
10012e4c0:     	stp	d13, d12, [sp, #0x10]
10012e4c4:     	stp	d11, d10, [sp, #0x20]
10012e4c8:     	stp	d9, d8, [sp, #0x30]
10012e4cc:     	stp	x28, x27, [sp, #0x40]
10012e4d0:     	stp	x26, x25, [sp, #0x50]
10012e4d4:     	stp	x24, x23, [sp, #0x60]
10012e4d8:     	stp	x22, x21, [sp, #0x70]
10012e4dc:     	stp	x20, x19, [sp, #0x80]
10012e4e0:     	stp	x29, x30, [sp, #0x90]
10012e4e4:     	add	x29, sp, #0x90
10012e4e8:     	sub	sp, sp, #0x3, lsl #12   ; =0x3000
10012e4ec:     	sub	sp, sp, #0x9d0
10012e4f0:     	str	x30, [sp, #0x198]
10012e4f4:     	str	x0, [sp, #0x290]
10012e4f8:     	add	x8, x0, #0x12, lsl #12  ; =0x12000
10012e4fc:     	add	x4, x8, #0x8f0
10012e500:     	ldr	x8, [x1]
10012e504:     	ldr	x26, [x1, #0x18]
10012e508:     	ubfx	x5, x26, #32, #16
10012e50c:     	ldrh	w9, [x8, #0x50]
10012e510:     	cmp	w5, w9
10012e514:     	csel	w23, w5, w9, lo
10012e518:     	ldr	x12, [x8, #0x10]
10012e51c:     	ldp	x10, x13, [x4]
10012e520:     	sub	x14, x10, #0x50
10012e524:     	cmp	x13, #0x2
10012e528:     	b.lo	0x10012e654 <_render.TerminalRenderer.drawPane+0x198>
10012e52c:     	mov	x11, #0x0               ; =0
10012e530:     	mov	w15, #0x50              ; =80
10012e534:     	mov	w16, #0x2               ; =2
10012e538:     	mov	w17, #-0x40000000       ; =-1073741824
10012e53c:     	mov	x0, x13
10012e540:     	lsr	x2, x0, #1
10012e544:     	sub	x0, x0, x2
10012e548:     	add	x3, x2, x11
10012e54c:     	mul	x2, x3, x15
10012e550:     	ldr	x2, [x14, x2]
10012e554:     	cmp	x12, x2
10012e558:     	cset	w2, lo
10012e55c:     	csel	w2, w16, w2, eq
10012e560:     	add	w2, w17, w2, lsl #30
10012e564:     	asr	w2, w2, #30
10012e568:     	cmp	w2, #0x0
10012e56c:     	csel	x11, x3, x11, lt
10012e570:     	cmp	x0, #0x1
10012e574:     	b.hi	0x10012e540 <_render.TerminalRenderer.drawPane+0x84>
10012e578:     	cmp	x11, x13
10012e57c:     	b.hs	0x10012e5a8 <_render.TerminalRenderer.drawPane+0xec>
10012e580:     	mov	w15, #0x50              ; =80
10012e584:     	mul	x15, x11, x15
10012e588:     	ldr	x15, [x10, x15]
10012e58c:     	cmp	x12, x15
10012e590:     	cset	w15, lo
10012e594:     	mov	w16, #0x2               ; =2
10012e598:     	csel	w15, w16, w15, eq
10012e59c:     	sub	w15, w15, #0x1
10012e5a0:     	ubfx	x15, x15, #1, #1
10012e5a4:     	add	x11, x15, x11
10012e5a8:     	cmp	x13, #0x2
10012e5ac:     	b.lo	0x10012e664 <_render.TerminalRenderer.drawPane+0x1a8>
10012e5b0:     	mov	x15, #0x0               ; =0
10012e5b4:     	mov	w16, #0x50              ; =80
10012e5b8:     	mov	w17, #0x2               ; =2
10012e5bc:     	mov	x0, x13
10012e5c0:     	lsr	x2, x0, #1
10012e5c4:     	sub	x0, x0, x2
10012e5c8:     	add	x3, x2, x15
10012e5cc:     	mul	x2, x3, x16
10012e5d0:     	ldr	x2, [x14, x2]
10012e5d4:     	cmp	x12, x2
10012e5d8:     	cset	w2, lo
10012e5dc:     	csel	w2, w17, w2, eq
10012e5e0:     	cmp	w2, #0x1
10012e5e4:     	csel	x15, x15, x3, eq
10012e5e8:     	cmp	x0, #0x1
10012e5ec:     	b.hi	0x10012e5c0 <_render.TerminalRenderer.drawPane+0x104>
10012e5f0:     	cmp	x15, x13
10012e5f4:     	b.hs	0x10012e61c <_render.TerminalRenderer.drawPane+0x160>
10012e5f8:     	mov	w13, #0x50              ; =80
10012e5fc:     	mul	x13, x15, x13
10012e600:     	ldr	x13, [x10, x13]
10012e604:     	cmp	x12, x13
10012e608:     	cset	w12, lo
10012e60c:     	mov	w13, #0x2               ; =2
10012e610:     	csel	w12, w13, w12, eq
10012e614:     	cmp	w12, #0x1
10012e618:     	cinc	x15, x15, ne
10012e61c:     	lsr	x27, x26, #48
10012e620:     	ldrh	w19, [x8, #0x52]
10012e624:     	mov	w12, #0x50              ; =80
10012e628:     	madd	x24, x11, x12, x10
10012e62c:     	sub	x25, x15, x11
10012e630:     	ldrb	w10, [x1, #0x40]
10012e634:     	ldrb	w12, [x1, #0x44]
10012e638:     	cbz	w10, 0x10012e644 <_render.TerminalRenderer.drawPane+0x188>
10012e63c:     	ldrb	w10, [x1, #0x3c]
10012e640:     	tbz	w10, #0x0, 0x10012e674 <_render.TerminalRenderer.drawPane+0x1b8>
10012e644:     	ldrh	w11, [x8, #0x100]
10012e648:     	ldrh	w10, [x8, #0x102]
10012e64c:     	add	x13, x8, #0x104
10012e650:     	b	0x10012e6bc <_render.TerminalRenderer.drawPane+0x200>
10012e654:     	mov	x11, #0x0               ; =0
10012e658:     	cmp	x11, x13
10012e65c:     	b.lo	0x10012e580 <_render.TerminalRenderer.drawPane+0xc4>
10012e660:     	b	0x10012e5a8 <_render.TerminalRenderer.drawPane+0xec>
10012e664:     	mov	x15, #0x0               ; =0
10012e668:     	cmp	x15, x13
10012e66c:     	b.lo	0x10012e5f8 <_render.TerminalRenderer.drawPane+0x13c>
10012e670:     	b	0x10012e61c <_render.TerminalRenderer.drawPane+0x160>
10012e674:     	ldr	w10, [x1, #0x28]
10012e678:     	ldr	w11, [x8, #0xfc]
10012e67c:     	subs	w10, w10, w11
10012e680:     	b.lo	0x10012e6ac <_render.TerminalRenderer.drawPane+0x1f0>
10012e684:     	cmp	w10, w19
10012e688:     	b.hs	0x10012e6ac <_render.TerminalRenderer.drawPane+0x1f0>
10012e68c:     	ldrh	w11, [x1, #0x2c]
10012e690:     	mov	w13, #0x1               ; =1
10012e694:     	add	x14, sp, #0x2, lsl #12  ; =0x2000
10012e698:     	add	x14, x14, #0x300
10012e69c:     	strb	w13, [x14]
10012e6a0:     	add	x13, sp, #0x2, lsl #12  ; =0x2000
10012e6a4:     	add	x13, x13, #0x300
10012e6a8:     	b	0x10012e6bc <_render.TerminalRenderer.drawPane+0x200>
10012e6ac:     	mov	w11, #0x0               ; =0
10012e6b0:     	mov	w10, #0x0               ; =0
10012e6b4:     	adrp	x13, 0x100537000 <___anon_12856+0x136a4>
10012e6b8:     	add	x13, x13, #0xb94
10012e6bc:     	mov	w15, #0x0               ; =0
10012e6c0:     	mov	w14, #0x1               ; =1
10012e6c4:     	str	w14, [sp, #0xdc]
10012e6c8:     	str	x1, [sp, #0x278]
10012e6cc:     	str	x4, [sp, #0x298]
10012e6d0:     	str	x5, [sp, #0x38]
10012e6d4:     	tbnz	w12, #0x0, 0x10012e738 <_render.TerminalRenderer.drawPane+0x27c>
10012e6d8:     	ldrb	w12, [x1, #0x22]
10012e6dc:     	tbz	w12, #0x0, 0x10012e738 <_render.TerminalRenderer.drawPane+0x27c>
10012e6e0:     	ldrb	w12, [x13]
10012e6e4:     	tbz	w12, #0x0, 0x10012e738 <_render.TerminalRenderer.drawPane+0x27c>
10012e6e8:     	mov	x20, x15
10012e6ec:     	cmp	w11, w23
10012e6f0:     	b.hs	0x10012e760 <_render.TerminalRenderer.drawPane+0x2a4>
10012e6f4:     	cmp	w27, w19
10012e6f8:     	csel	w12, w27, w19, lo
10012e6fc:     	cmp	w12, w10, uxth
10012e700:     	b.ls	0x10012e740 <_render.TerminalRenderer.drawPane+0x284>
10012e704:     	cbz	w11, 0x10012e754 <_render.TerminalRenderer.drawPane+0x298>
10012e708:     	str	wzr, [sp, #0xdc]
10012e70c:     	and	x12, x10, #0xffff
10012e710:     	umull	x9, w12, w9
10012e714:     	mov	w12, w11
10012e718:     	ldr	x8, [x8, #0x30]
10012e71c:     	add	x8, x8, x9, lsl #5
10012e720:     	add	x8, x8, x12, lsl #5
10012e724:     	ldrb	w8, [x8, #0x1f]
10012e728:     	cmp	w8, #0x0
10012e72c:     	cset	w8, eq
10012e730:     	sub	w15, w11, w8
10012e734:     	b	0x10012e75c <_render.TerminalRenderer.drawPane+0x2a0>
10012e738:     	mov	x20, x15
10012e73c:     	b	0x10012e760 <_render.TerminalRenderer.drawPane+0x2a4>
10012e740:     	mov	w15, #0x0               ; =0
10012e744:     	mov	w20, #0x0               ; =0
10012e748:     	mov	w8, #0x1                ; =1
10012e74c:     	str	w8, [sp, #0xdc]
10012e750:     	b	0x10012e760 <_render.TerminalRenderer.drawPane+0x2a4>
10012e754:     	mov	w15, #0x0               ; =0
10012e758:     	str	wzr, [sp, #0xdc]
10012e75c:     	mov	x20, x10
10012e760:     	str	w15, [sp, #0x5c]
10012e764:     	ldr	x0, [sp, #0x290]
10012e768:     	ldr	x22, [x0, #0xfe8]
10012e76c:     	ldr	x1, [sp, #0x278]
10012e770:     	mov	x2, x24
10012e774:     	mov	x3, x25
10012e778:     	mov	w4, #0x0                ; =0
10012e77c:     	bl	0x10012e174 <_render.TerminalRenderer.pushImages>
10012e780:     	ands	w0, w0, #0xffff
10012e784:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
10012e788:     	stp	x27, x26, [sp, #0x60]
10012e78c:     	stp	x25, x24, [sp, #0x78]
10012e790:     	ldr	x9, [sp, #0x290]
10012e794:     	add	x8, x9, #0x16, lsl #12  ; =0x16000
10012e798:     	add	x8, x8, #0x9e4
10012e79c:     	str	x8, [sp, #0x280]
10012e7a0:     	add	x8, x9, #0x11, lsl #12  ; =0x11000
10012e7a4:     	add	x8, x8, #0x620
10012e7a8:     	str	x8, [sp, #0x188]
10012e7ac:     	ldr	x8, [sp, #0x198]
10012e7b0:     	xpaci	x8
10012e7b4:     	str	x8, [sp, #0x198]
10012e7b8:     	cmp	w27, w19
10012e7bc:     	csel	w8, w27, w19, lo
10012e7c0:     	ldr	x30, [sp, #0x298]
10012e7c4:     	stp	x8, x23, [sp, #0x138]
10012e7c8:     	cbz	w8, 0x100133590 <_render.TerminalRenderer.drawPane+0x50d4>
10012e7cc:     	ldr	x8, [sp, #0x280]
10012e7d0:     	add	x9, x8, #0x17c
10012e7d4:     	str	x9, [sp, #0x260]
10012e7d8:     	add	x8, x8, #0x1ac
10012e7dc:     	str	x8, [sp, #0x228]
10012e7e0:     	ldr	x8, [sp, #0x290]
10012e7e4:     	add	x8, x8, #0x16, lsl #12  ; =0x16000
10012e7e8:     	add	x8, x8, #0xbbe
10012e7ec:     	str	x8, [sp, #0x1c0]
10012e7f0:     	add	x25, sp, #0x500
10012e7f4:     	adrp	x8, 0x1001ff000 <__ZL18_hb_ucd_dm1_p2_map+0x16e>
10012e7f8:     	cbz	x22, 0x10013276c <_render.TerminalRenderer.drawPane+0x42b0>
10012e7fc:     	str	xzr, [sp, #0x1c8]
10012e800:     	add	x9, sp, #0xf00
10012e804:     	sub	x10, x29, #0xb0
10012e808:     	sub	x11, x29, #0xc8
10012e80c:     	add	x12, sp, #0x2, lsl #12  ; =0x2000
10012e810:     	add	x12, x12, #0x300
10012e814:     	orr	x12, x12, #0x4
10012e818:     	str	x12, [sp, #0x70]
10012e81c:     	orr	x9, x9, #0x4
10012e820:     	str	x9, [sp, #0xd0]
10012e824:     	orr	x9, x10, #0x4
10012e828:     	str	x9, [sp, #0x8]
10012e82c:     	orr	x10, x11, #0x4
10012e830:     	ldr	x9, [sp, #0x290]
10012e834:     	add	x9, x9, #0xffa
10012e838:     	stp	x9, xzr, [sp, #0xf0]
10012e83c:     	adrp	x9, 0x100537000 <___anon_12856+0x136a4>
10012e840:     	ldr	x9, [x9, #0xb98]
10012e844:     	str	x9, [sp, #0xb8]
10012e848:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012e84c:     	add	x9, x9, #0x920
10012e850:     	add	x9, x9, #0x38
10012e854:     	str	x9, [sp, #0x1a8]
10012e858:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012e85c:     	add	x9, x9, #0x750
10012e860:     	orr	x9, x9, #0xe
10012e864:     	stp	x10, x9, [sp, #0x20]
10012e868:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012e86c:     	add	x9, x9, #0x900
10012e870:     	orr	x9, x9, #0xe
10012e874:     	str	x9, [sp, #0xe0]
10012e878:     	add	x9, sp, #0x3f0
10012e87c:     	orr	x9, x9, #0xe
10012e880:     	str	x9, [sp, #0x168]
10012e884:     	mov	w24, #0x6               ; =6
10012e888:     	ldr	q0, [x8, #0x160]
10012e88c:     	str	q0, [sp, #0x150]
10012e890:     	and	w8, w20, #0xffff
10012e894:     	str	w8, [sp, #0x34]
10012e898:     	add	x26, sp, #0xd00
10012e89c:     	mov	w27, #0xffff            ; =65535
10012e8a0:     	b	0x10012e8c8 <_render.TerminalRenderer.drawPane+0x40c>
10012e8a4:     	ldr	x9, [sp, #0x1c8]
10012e8a8:     	add	x9, x9, #0x1
10012e8ac:     	ldr	x8, [sp, #0xf8]
10012e8b0:     	add	x8, x8, #0x20
10012e8b4:     	str	x8, [sp, #0xf8]
10012e8b8:     	ldr	x8, [sp, #0x138]
10012e8bc:     	str	x9, [sp, #0x1c8]
10012e8c0:     	cmp	x9, x8
10012e8c4:     	b.eq	0x100133590 <_render.TerminalRenderer.drawPane+0x50d4>
10012e8c8:     	ldr	w8, [sp, #0xdc]
10012e8cc:     	tbz	w8, #0x0, 0x10012e8e0 <_render.TerminalRenderer.drawPane+0x424>
10012e8d0:     	mov	w13, #0x0               ; =0
10012e8d4:     	ldr	x7, [sp, #0x278]
10012e8d8:     	ldr	x22, [sp, #0x280]
10012e8dc:     	b	0x10012e924 <_render.TerminalRenderer.drawPane+0x468>
10012e8e0:     	ldr	x8, [sp, #0x1c8]
10012e8e4:     	ldr	w9, [sp, #0x34]
10012e8e8:     	cmp	w9, w8, uxth
10012e8ec:     	adrp	x8, 0x100597000 <___anon_33948+0x60>
10012e8f0:     	add	x8, x8, #0x3b0
10012e8f4:     	ldr	x22, [sp, #0x280]
10012e8f8:     	b.ne	0x10012e91c <_render.TerminalRenderer.drawPane+0x460>
10012e8fc:     	add	x8, sp, #0x2, lsl #12   ; =0x2000
10012e900:     	add	x8, x8, #0x300
10012e904:     	ldr	w9, [sp, #0x5c]
10012e908:     	strh	w9, [x8]
10012e90c:     	mov	w9, #0x1                ; =1
10012e910:     	strb	w9, [x8, #0x2]
10012e914:     	add	x8, sp, #0x2, lsl #12   ; =0x2000
10012e918:     	add	x8, x8, #0x300
10012e91c:     	ldr	w13, [x8]
10012e920:     	ldr	x7, [sp, #0x278]
10012e924:     	mov	x8, #0x0                ; =0
10012e928:     	mov	x1, #0x0                ; =0
10012e92c:     	ubfx	w9, w13, #16, #8
10012e930:     	str	w9, [sp, #0x2a0]
10012e934:     	ldr	x9, [x7]
10012e938:     	ldrh	w19, [x7, #0x18]
10012e93c:     	ldrh	w20, [x7, #0x1a]
10012e940:     	ldrh	w10, [x7, #0x1c]
10012e944:     	ldrh	w17, [x9, #0x50]
10012e948:     	cmp	w10, w17
10012e94c:     	csel	w23, w10, w17, lo
10012e950:     	ldr	x16, [sp, #0x1c8]
10012e954:     	mul	x10, x16, x17
10012e958:     	ldr	x0, [x9, #0x30]
10012e95c:     	add	x10, x0, x10, lsl #5
10012e960:     	str	x10, [sp, #0x250]
10012e964:     	add	w12, w20, w16, uxth
10012e968:     	ldr	x10, [sp, #0x188]
10012e96c:     	ldrh	w11, [x10, #0x60]
10012e970:     	ldr	x10, [x10]
10012e974:     	and	w14, w16, #0xffff
10012e978:     	str	w14, [sp, #0x1a0]
10012e97c:     	and	w15, w13, #0xffff
10012e980:     	ubfiz	x13, x23, #6, #32
10012e984:     	sub	x14, x13, #0x40
10012e988:     	str	x15, [sp, #0x2b8]
10012e98c:     	ubfiz	x15, x15, #6, #32
10012e990:     	add	x16, x16, x20
10012e994:     	mul	x16, x16, x11
10012e998:     	lsl	x16, x16, #6
10012e99c:     	add	x16, x16, x19, lsl #6
10012e9a0:     	add	x16, x10, x16
10012e9a4:     	ldr	x2, [sp, #0xf8]
10012e9a8:     	madd	x17, x2, x17, x0
10012e9ac:     	str	x17, [sp, #0xe8]
10012e9b0:     	cmp	x13, x8
10012e9b4:     	b.eq	0x10012ec30 <_render.TerminalRenderer.drawPane+0x774>
10012e9b8:     	mov	x0, x1
10012e9bc:     	ldrb	w2, [x7, #0x40]
10012e9c0:     	mov	x1, x17
10012e9c4:     	cbz	w2, 0x10012eac8 <_render.TerminalRenderer.drawPane+0x60c>
10012e9c8:     	ldrb	w2, [x7, #0x38]
10012e9cc:     	mov	x1, x17
10012e9d0:     	cbz	w2, 0x10012eac8 <_render.TerminalRenderer.drawPane+0x60c>
10012e9d4:     	ldr	w1, [x7, #0x28]
10012e9d8:     	ldr	x2, [x7, #0x30]
10012e9dc:     	ldrb	w4, [x7, #0x3d]
10012e9e0:     	ldr	w3, [x9, #0xfc]
10012e9e4:     	ldr	w5, [sp, #0x1a0]
10012e9e8:     	add	w3, w3, w5
10012e9ec:     	tbz	w4, #0x0, 0x10012ea3c <_render.TerminalRenderer.drawPane+0x580>
10012e9f0:     	cmp	w2, w1
10012e9f4:     	csel	w4, w2, w1, lo
10012e9f8:     	csel	w1, w2, w1, hi
10012e9fc:     	cmp	w3, w4
10012ea00:     	ccmp	w3, w1, #0x2, hs
10012ea04:     	mov	x1, x17
10012ea08:     	b.hi	0x10012eac8 <_render.TerminalRenderer.drawPane+0x60c>
10012ea0c:     	ldr	q0, [x17]
10012ea10:     	str	q0, [sp, #0x2300]
10012ea14:     	ldr	q0, [x17, #0x10]
10012ea18:     	str	q0, [sp, #0x2310]
10012ea1c:     	add	x2, sp, #0x2, lsl #12   ; =0x2000
10012ea20:     	add	x2, x2, #0x300
10012ea24:     	ldrh	w1, [x2]
10012ea28:     	eor	w1, w1, #0x10
10012ea2c:     	strh	w1, [x2]
10012ea30:     	add	x1, sp, #0x2, lsl #12   ; =0x2000
10012ea34:     	add	x1, x1, #0x300
10012ea38:     	b	0x10012eac8 <_render.TerminalRenderer.drawPane+0x60c>
10012ea3c:     	ldr	w4, [x7, #0x2c]
10012ea40:     	lsr	x6, x2, #32
10012ea44:     	cmp	w1, w2
10012ea48:     	b.lo	0x10012ea60 <_render.TerminalRenderer.drawPane+0x5a4>
10012ea4c:     	cmp	w1, w2
10012ea50:     	b.ne	0x10012ea7c <_render.TerminalRenderer.drawPane+0x5c0>
10012ea54:     	and	w5, w4, #0xffff
10012ea58:     	cmp	w5, w6, uxth
10012ea5c:     	b.hs	0x10012ea7c <_render.TerminalRenderer.drawPane+0x5c0>
10012ea60:     	mov	x5, x4
10012ea64:     	mov	x4, x6
10012ea68:     	mov	x6, x1
10012ea6c:     	mov	x1, x17
10012ea70:     	cmp	w3, w6
10012ea74:     	b.hs	0x10012ea94 <_render.TerminalRenderer.drawPane+0x5d8>
10012ea78:     	b	0x10012eac8 <_render.TerminalRenderer.drawPane+0x60c>
10012ea7c:     	mov	x5, x6
10012ea80:     	mov	x6, x2
10012ea84:     	mov	x2, x1
10012ea88:     	mov	x1, x17
10012ea8c:     	cmp	w3, w6
10012ea90:     	b.lo	0x10012eac8 <_render.TerminalRenderer.drawPane+0x60c>
10012ea94:     	and	w1, w0, #0xffff
10012ea98:     	cmp	w1, w5, uxth
10012ea9c:     	ccmp	w3, w6, #0x0, lo
10012eaa0:     	mov	x1, x17
10012eaa4:     	b.eq	0x10012eac8 <_render.TerminalRenderer.drawPane+0x60c>
10012eaa8:     	mov	x1, x17
10012eaac:     	cmp	w2, w3
10012eab0:     	b.lo	0x10012eac8 <_render.TerminalRenderer.drawPane+0x60c>
10012eab4:     	b.ne	0x10012ea0c <_render.TerminalRenderer.drawPane+0x550>
10012eab8:     	and	w1, w0, #0xffff
10012eabc:     	cmp	w1, w4, uxth
10012eac0:     	mov	x1, x17
10012eac4:     	b.ls	0x10012ea0c <_render.TerminalRenderer.drawPane+0x550>
10012eac8:     	add	x2, x16, x8
10012eacc:     	ldrb	w2, [x2, #0x3a]
10012ead0:     	ldr	w3, [sp, #0x2a0]
10012ead4:     	cbz	w3, 0x10012eae4 <_render.TerminalRenderer.drawPane+0x628>
10012ead8:     	cmp	x15, x8
10012eadc:     	cset	w3, eq
10012eae0:     	eor	w2, w3, w2
10012eae4:     	tbnz	w2, #0x0, 0x10012ebcc <_render.TerminalRenderer.drawPane+0x710>
10012eae8:     	add	x3, x16, x8
10012eaec:     	ldrb	w2, [x3, #0x3b]
10012eaf0:     	cmp	x14, x8
10012eaf4:     	cset	w4, eq
10012eaf8:     	eor	w2, w4, w2
10012eafc:     	tbnz	w2, #0x0, 0x10012ebcc <_render.TerminalRenderer.drawPane+0x710>
10012eb00:     	ldrb	w2, [x1, #0x1f]
10012eb04:     	cmp	w2, #0x1
10012eb08:     	csinc	w2, w2, wzr, hi
10012eb0c:     	sub	w4, w23, w0
10012eb10:     	and	w4, w4, #0xffff
10012eb14:     	cmp	w2, w4
10012eb18:     	csel	w2, w2, w4, lo
10012eb1c:     	ldrb	w3, [x3, #0x38]
10012eb20:     	cmp	w3, #0x1
10012eb24:     	b.ne	0x10012ebcc <_render.TerminalRenderer.drawPane+0x710>
10012eb28:     	ldrh	w3, [x22, #0x4]
10012eb2c:     	ldr	x4, [sp, #0x260]
10012eb30:     	ldr	x5, [x4]
10012eb34:     	add	w4, w19, w0
10012eb38:     	and	w4, w4, #0xffff
10012eb3c:     	madd	w4, w3, w4, w5
10012eb40:     	ucvtf	s0, w4
10012eb44:     	add	x6, x16, x8
10012eb48:     	ldr	s1, [x6, #0x8]
10012eb4c:     	fcmp	s1, s0
10012eb50:     	b.ne	0x10012ebcc <_render.TerminalRenderer.drawPane+0x710>
10012eb54:     	ldrh	w4, [x22, #0x6]
10012eb58:     	lsr	x5, x5, #32
10012eb5c:     	madd	w5, w4, w12, w5
10012eb60:     	ucvtf	s0, w5
10012eb64:     	ldr	s1, [x6, #0xc]
10012eb68:     	fcmp	s1, s0
10012eb6c:     	b.ne	0x10012ebcc <_render.TerminalRenderer.drawPane+0x710>
10012eb70:     	mul	w2, w2, w3
10012eb74:     	ucvtf	s0, w2
10012eb78:     	add	x2, x16, x8
10012eb7c:     	ldr	s1, [x2, #0x10]
10012eb80:     	fcmp	s1, s0
10012eb84:     	b.ne	0x10012ebcc <_render.TerminalRenderer.drawPane+0x710>
10012eb88:     	ucvtf	s0, w4
10012eb8c:     	ldr	s1, [x2, #0x14]
10012eb90:     	fcmp	s1, s0
10012eb94:     	b.ne	0x10012ebcc <_render.TerminalRenderer.drawPane+0x710>
10012eb98:     	add	x2, x16, x8
10012eb9c:     	ldur	q0, [x2, #0x18]
10012eba0:     	ldur	q1, [x2, #0x28]
10012eba4:     	ldp	q2, q3, [x1]
10012eba8:     	eor.16b	v0, v2, v0
10012ebac:     	eor.16b	v1, v3, v1
10012ebb0:     	orr.16b	v0, v1, v0
10012ebb4:     	umaxv.16b	b0, v0
10012ebb8:     	fmov	w2, s0
10012ebbc:     	add	x8, x8, #0x40
10012ebc0:     	add	x17, x17, #0x20
10012ebc4:     	add	x1, x0, #0x1
10012ebc8:     	cbz	w2, 0x10012e9b0 <_render.TerminalRenderer.drawPane+0x4f4>
10012ebcc:     	cmp	x0, x23
10012ebd0:     	b.hs	0x10012ec30 <_render.TerminalRenderer.drawPane+0x774>
10012ebd4:     	str	x23, [sp, #0x108]
10012ebd8:     	cbz	w23, 0x10012ec1c <_render.TerminalRenderer.drawPane+0x760>
10012ebdc:     	ldr	x8, [sp, #0xe8]
10012ebe0:     	add	x8, x8, #0x1e
10012ebe4:     	mov	x9, x23
10012ebe8:     	ldrb	w10, [x8]
10012ebec:     	cmp	w10, #0x1
10012ebf0:     	b.ne	0x10012ed60 <_render.TerminalRenderer.drawPane+0x8a4>
10012ebf4:     	ldursb	x10, [x8, #-0x10]
10012ebf8:     	tbnz	x10, #0x3f, 0x10012ed60 <_render.TerminalRenderer.drawPane+0x8a4>
10012ebfc:     	ldr	x11, [sp, #0xf0]
10012ec00:     	ldrb	w10, [x11, x10]
10012ec04:     	and	w10, w10, #0x3
10012ec08:     	cmp	w10, #0x2
10012ec0c:     	b.eq	0x10012ed60 <_render.TerminalRenderer.drawPane+0x8a4>
10012ec10:     	add	x8, x8, #0x20
10012ec14:     	subs	x9, x9, #0x1
10012ec18:     	b.ne	0x10012ebe8 <_render.TerminalRenderer.drawPane+0x72c>
10012ec1c:     	str	wzr, [sp, #0xd8]
10012ec20:     	str	xzr, [x30, #0x30]
10012ec24:     	strh	wzr, [x30, #0x60]
10012ec28:     	cbnz	w23, 0x10012f438 <_render.TerminalRenderer.drawPane+0xf7c>
10012ec2c:     	b	0x10012e8a4 <_render.TerminalRenderer.drawPane+0x3e8>
10012ec30:     	cbz	w23, 0x10012e8a4 <_render.TerminalRenderer.drawPane+0x3e8>
10012ec34:     	ldr	x8, [sp, #0x188]
10012ec38:     	ldr	x8, [x8, #0x18]
10012ec3c:     	ldr	x9, [sp, #0x1c8]
10012ec40:     	add	x9, x9, x20
10012ec44:     	madd	x9, x9, x11, x19
10012ec48:     	mov	w11, #0x50              ; =80
10012ec4c:     	madd	x19, x9, x11, x8
10012ec50:     	add	x8, x10, x9, lsl #6
10012ec54:     	add	x20, x8, #0x39
10012ec58:     	b	0x10012eca8 <_render.TerminalRenderer.drawPane+0x7ec>
10012ec5c:     	add	x9, x8, #0x1
10012ec60:     	str	x9, [x30, #0x80]
10012ec64:     	ldr	x9, [x30, #0x78]
10012ec68:     	mov	w10, #0x50              ; =80
10012ec6c:     	madd	x8, x8, x10, x9
10012ec70:     	ldr	q0, [sp, #0x2310]
10012ec74:     	str	q0, [x8, #0x10]
10012ec78:     	ldr	q0, [sp, #0x2320]
10012ec7c:     	str	q0, [x8, #0x20]
10012ec80:     	ldr	q0, [sp, #0x2330]
10012ec84:     	str	q0, [x8, #0x30]
10012ec88:     	ldr	q0, [sp, #0x2340]
10012ec8c:     	str	q0, [x8, #0x40]
10012ec90:     	ldr	q0, [sp, #0x2300]
10012ec94:     	str	q0, [x8]
10012ec98:     	add	x19, x19, #0x50
10012ec9c:     	add	x20, x20, #0x40
10012eca0:     	subs	x23, x23, #0x1
10012eca4:     	b.eq	0x10012e8a4 <_render.TerminalRenderer.drawPane+0x3e8>
10012eca8:     	ldrb	w8, [x20]
10012ecac:     	tbz	w8, #0x0, 0x10012ec98 <_render.TerminalRenderer.drawPane+0x7dc>
10012ecb0:     	ldr	q0, [x19, #0x10]
10012ecb4:     	str	q0, [sp, #0x2310]
10012ecb8:     	ldr	q0, [x19, #0x20]
10012ecbc:     	str	q0, [sp, #0x2320]
10012ecc0:     	ldr	q0, [x19, #0x30]
10012ecc4:     	str	q0, [sp, #0x2330]
10012ecc8:     	ldr	q0, [x19, #0x40]
10012eccc:     	str	q0, [sp, #0x2340]
10012ecd0:     	ldr	q0, [x19]
10012ecd4:     	str	q0, [sp, #0x2300]
10012ecd8:     	ldrb	w8, [x30, #0x98]
10012ecdc:     	cbz	w8, 0x10012ed00 <_render.TerminalRenderer.drawPane+0x844>
10012ece0:     	ldr	x9, [x30, #0x90]
10012ece4:     	ldr	x8, [x30, #0x80]
10012ece8:     	cmp	x8, x9
10012ecec:     	b.lo	0x10012ec5c <_render.TerminalRenderer.drawPane+0x7a0>
10012ecf0:     	ldr	x8, [x30, #0xa0]
10012ecf4:     	add	x8, x8, #0x1
10012ecf8:     	str	x8, [x30, #0xa0]
10012ecfc:     	b	0x10012ec98 <_render.TerminalRenderer.drawPane+0x7dc>
10012ed00:     	mov	w8, #0x2958             ; =10584
10012ed04:     	movk	w8, #0x1, lsl #16
10012ed08:     	ldr	x9, [sp, #0x290]
10012ed0c:     	ldr	q0, [x9, x8]
10012ed10:     	str	q0, [sp, #0xf00]
10012ed14:     	ldp	x8, x9, [x30, #0x80]
10012ed18:     	cmp	x9, x8
10012ed1c:     	b.hi	0x10012ec5c <_render.TerminalRenderer.drawPane+0x7a0>
10012ed20:     	add	x8, x8, #0x1
10012ed24:     	lsr	x9, x8, #1
10012ed28:     	add	x9, x9, #0x1
10012ed2c:     	adds	x8, x8, x9
10012ed30:     	csinv	x2, x8, xzr, lo
10012ed34:     	mov	w8, #0x2968             ; =10600
10012ed38:     	movk	w8, #0x1, lsl #16
10012ed3c:     	ldr	x9, [sp, #0x290]
10012ed40:     	add	x0, x9, x8
10012ed44:     	add	x1, sp, #0xf00
10012ed48:     	bl	0x1001aece0 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
10012ed4c:     	ands	w0, w0, #0xffff
10012ed50:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
10012ed54:     	ldr	x30, [sp, #0x298]
10012ed58:     	ldr	x8, [x30, #0x80]
10012ed5c:     	b	0x10012ec5c <_render.TerminalRenderer.drawPane+0x7a0>
10012ed60:     	str	x20, [sp, #0x230]
10012ed64:     	str	x19, [sp, #0x240]
10012ed68:     	mov	x25, #0x0               ; =0
10012ed6c:     	str	xzr, [x30, #0x30]
10012ed70:     	strh	wzr, [x30, #0x60]
10012ed74:     	ldr	x15, [sp, #0x2b8]
10012ed78:     	ldr	x16, [sp, #0x250]
10012ed7c:     	b	0x10012ede8 <_render.TerminalRenderer.drawPane+0x92c>
10012ed80:     	mov	w8, #0x0                ; =0
10012ed84:     	mov	w9, #0x0                ; =0
10012ed88:     	ldp	x11, x10, [x30, #0x28]
10012ed8c:     	add	x12, x10, #0x1
10012ed90:     	str	x12, [x30, #0x30]
10012ed94:     	strb	w8, [sp, #0xd00]
10012ed98:     	add	x12, sp, #0x3, lsl #12  ; =0x3000
10012ed9c:     	add	x12, x12, #0x900
10012eda0:     	strb	w9, [x12, #0x20]
10012eda4:     	add	x12, sp, #0x3, lsl #12  ; =0x3000
10012eda8:     	add	x12, x12, #0x720
10012edac:     	strb	wzr, [x12, #0xc0]
10012edb0:     	madd	x10, x10, x24, x11
10012edb4:     	strh	w27, [x10]
10012edb8:     	strb	w8, [x10, #0x2]
10012edbc:     	strb	w9, [x10, #0x3]
10012edc0:     	strb	wzr, [x10, #0x4]
10012edc4:     	ldp	q1, q0, [x28]
10012edc8:     	stp	q1, q0, [x30, #0x40]
10012edcc:     	ldrh	w9, [x30, #0x60]
10012edd0:     	cmp	w8, #0x2
10012edd4:     	cinc	w8, w9, eq
10012edd8:     	strh	w8, [x30, #0x60]
10012eddc:     	add	x25, x25, #0x1
10012ede0:     	cmp	x25, x23
10012ede4:     	b.eq	0x10012f2fc <_render.TerminalRenderer.drawPane+0xe40>
10012ede8:     	add	x28, x16, x25, lsl #5
10012edec:     	ldrb	w8, [x7, #0x40]
10012edf0:     	cbz	w8, 0x10012eec0 <_render.TerminalRenderer.drawPane+0xa04>
10012edf4:     	ldrb	w8, [x7, #0x38]
10012edf8:     	cbz	w8, 0x10012eec0 <_render.TerminalRenderer.drawPane+0xa04>
10012edfc:     	ldr	w11, [x7, #0x28]
10012ee00:     	ldr	x8, [x7, #0x30]
10012ee04:     	ldrb	w10, [x7, #0x3d]
10012ee08:     	ldr	x9, [x7]
10012ee0c:     	ldr	w9, [x9, #0xfc]
10012ee10:     	ldr	w12, [sp, #0x1a0]
10012ee14:     	add	w9, w9, w12
10012ee18:     	tbz	w10, #0x0, 0x10012ee50 <_render.TerminalRenderer.drawPane+0x994>
10012ee1c:     	cmp	w8, w11
10012ee20:     	csel	w10, w8, w11, lo
10012ee24:     	csel	w8, w8, w11, hi
10012ee28:     	cmp	w9, w10
10012ee2c:     	ccmp	w9, w8, #0x2, hs
10012ee30:     	b.hi	0x10012eec0 <_render.TerminalRenderer.drawPane+0xa04>
10012ee34:     	ldp	q1, q0, [x28]
10012ee38:     	stp	q1, q0, [sp, #0x3a0]
10012ee3c:     	ldrh	w8, [sp, #0x3a0]
10012ee40:     	eor	w8, w8, #0x10
10012ee44:     	strh	w8, [sp, #0x3a0]
10012ee48:     	add	x28, sp, #0x3a0
10012ee4c:     	b	0x10012eec0 <_render.TerminalRenderer.drawPane+0xa04>
10012ee50:     	ldr	w10, [x7, #0x2c]
10012ee54:     	lsr	x12, x8, #32
10012ee58:     	cmp	w11, w8
10012ee5c:     	b.lo	0x10012ee74 <_render.TerminalRenderer.drawPane+0x9b8>
10012ee60:     	cmp	w11, w8
10012ee64:     	b.ne	0x10012ee8c <_render.TerminalRenderer.drawPane+0x9d0>
10012ee68:     	and	w13, w10, #0xffff
10012ee6c:     	cmp	w13, w12, uxth
10012ee70:     	b.hs	0x10012ee8c <_render.TerminalRenderer.drawPane+0x9d0>
10012ee74:     	mov	x13, x10
10012ee78:     	mov	x10, x12
10012ee7c:     	mov	x12, x11
10012ee80:     	cmp	w9, w12
10012ee84:     	b.hs	0x10012eea0 <_render.TerminalRenderer.drawPane+0x9e4>
10012ee88:     	b	0x10012eec0 <_render.TerminalRenderer.drawPane+0xa04>
10012ee8c:     	mov	x13, x12
10012ee90:     	mov	x12, x8
10012ee94:     	mov	x8, x11
10012ee98:     	cmp	w9, w12
10012ee9c:     	b.lo	0x10012eec0 <_render.TerminalRenderer.drawPane+0xa04>
10012eea0:     	cmp	w25, w13, uxth
10012eea4:     	ccmp	w9, w12, #0x0, lo
10012eea8:     	ccmp	w8, w9, #0x0, ne
10012eeac:     	b.lo	0x10012eec0 <_render.TerminalRenderer.drawPane+0xa04>
10012eeb0:     	and	w10, w10, #0xffff
10012eeb4:     	cmp	w8, w9
10012eeb8:     	ccmp	w25, w10, #0x0, eq
10012eebc:     	b.ls	0x10012ee34 <_render.TerminalRenderer.drawPane+0x978>
10012eec0:     	ldr	w8, [sp, #0x2a0]
10012eec4:     	cbz	w8, 0x10012eed0 <_render.TerminalRenderer.drawPane+0xa14>
10012eec8:     	cmp	x25, x15
10012eecc:     	b.eq	0x10012ed80 <_render.TerminalRenderer.drawPane+0x8c4>
10012eed0:     	ldrb	w8, [x28, #0x1f]
10012eed4:     	cmp	w8, #0x1
10012eed8:     	b.ne	0x10012ed80 <_render.TerminalRenderer.drawPane+0x8c4>
10012eedc:     	ldrh	w8, [x28]
10012eee0:     	tbnz	w8, #0x5, 0x10012ed80 <_render.TerminalRenderer.drawPane+0x8c4>
10012eee4:     	ldrb	w19, [x28, #0x1e]
10012eee8:     	add	x23, x28, #0xe
10012eeec:     	cmp	w19, #0x3
10012eef0:     	b.ne	0x10012ef38 <_render.TerminalRenderer.drawPane+0xa7c>
10012eef4:     	ldrb	w8, [x23]
10012eef8:     	cmp	w8, #0xe2
10012eefc:     	b.ne	0x10012f1a0 <_render.TerminalRenderer.drawPane+0xce4>
10012ef00:     	ldrb	w8, [x28, #0xf]
10012ef04:     	sub	w9, w8, #0xa4
10012ef08:     	cmn	w9, #0x4
10012ef0c:     	b.lo	0x10012ef1c <_render.TerminalRenderer.drawPane+0xa60>
10012ef10:     	ldrsb	w9, [x28, #0x10]
10012ef14:     	cmn	w9, #0x40
10012ef18:     	b.lt	0x10012f1b4 <_render.TerminalRenderer.drawPane+0xcf8>
10012ef1c:     	and	w9, w8, #0xfe
10012ef20:     	cmp	w9, #0x94
10012ef24:     	b.ne	0x10012f18c <_render.TerminalRenderer.drawPane+0xcd0>
10012ef28:     	ldrsb	w8, [x28, #0x10]
10012ef2c:     	cmn	w8, #0x41
10012ef30:     	b.gt	0x10012f1a0 <_render.TerminalRenderer.drawPane+0xce4>
10012ef34:     	b	0x10012f1b4 <_render.TerminalRenderer.drawPane+0xcf8>
10012ef38:     	cmp	w19, #0x1
10012ef3c:     	b.ne	0x10012ef54 <_render.TerminalRenderer.drawPane+0xa98>
10012ef40:     	ldrsb	x8, [x23]
10012ef44:     	tbnz	x8, #0x3f, 0x10012f1c0 <_render.TerminalRenderer.drawPane+0xd04>
10012ef48:     	ldr	x9, [sp, #0xf0]
10012ef4c:     	add	x8, x9, x8
10012ef50:     	b	0x10012f0ac <_render.TerminalRenderer.drawPane+0xbf0>
10012ef54:     	ldr	x8, [sp, #0x290]
10012ef58:     	ldr	x26, [x8, #0xfe8]
10012ef5c:     	cbz	x26, 0x10012f2b4 <_render.TerminalRenderer.drawPane+0xdf8>
10012ef60:     	ldr	x8, [sp, #0x290]
10012ef64:     	ldr	x27, [x8, #0xff0]
10012ef68:     	mov	x9, x19
10012ef6c:     	mov	x8, x23
10012ef70:     	cmp	w19, #0x10
10012ef74:     	b.lo	0x10012ef9c <_render.TerminalRenderer.drawPane+0xae0>
10012ef78:     	ldr	q0, [x8]
10012ef7c:     	cmlt.16b	v0, v0, #0
10012ef80:     	umaxv.16b	b0, v0
10012ef84:     	fmov	w10, s0
10012ef88:     	tbnz	w10, #0x0, 0x10012f1e0 <_render.TerminalRenderer.drawPane+0xd24>
10012ef8c:     	add	x8, x8, #0x10
10012ef90:     	sub	x9, x9, #0x10
10012ef94:     	cmp	x9, #0xf
10012ef98:     	b.hi	0x10012ef78 <_render.TerminalRenderer.drawPane+0xabc>
10012ef9c:     	cbnz	x9, 0x10012f1e0 <_render.TerminalRenderer.drawPane+0xd24>
10012efa0:     	mov	w8, #0x0                ; =0
10012efa4:     	mov	x24, #0x0               ; =0
10012efa8:     	and	w20, w8, #0x3
10012efac:     	strb	w20, [sp, #0x500]
10012efb0:     	b	0x10012efc4 <_render.TerminalRenderer.drawPane+0xb08>
10012efb4:     	mov	w8, #0x2                ; =2
10012efb8:     	ldr	x30, [sp, #0x298]
10012efbc:     	cmp	w8, w20
10012efc0:     	b.hi	0x10012efa8 <_render.TerminalRenderer.drawPane+0xaec>
10012efc4:     	cmp	x24, x19
10012efc8:     	b.hs	0x10012f03c <_render.TerminalRenderer.drawPane+0xb80>
10012efcc:     	add	x1, x23, x24
10012efd0:     	ldrsb	w9, [x1]
10012efd4:     	adrp	x8, 0x100597000 <___anon_33948+0x60>
10012efd8:     	add	x8, x8, #0x39c
10012efdc:     	tbz	w9, #0x1f, 0x10012f028 <_render.TerminalRenderer.drawPane+0xb6c>
10012efe0:     	and	w9, w9, #0xff
10012efe4:     	and	w10, w9, #0xe0
10012efe8:     	adrp	x8, 0x100597000 <___anon_33948+0x60>
10012efec:     	add	x8, x8, #0x3a0
10012eff0:     	cmp	w10, #0xc0
10012eff4:     	b.eq	0x10012f028 <_render.TerminalRenderer.drawPane+0xb6c>
10012eff8:     	and	w8, w9, #0xf0
10012effc:     	and	w9, w9, #0xf8
10012f000:     	cmp	w9, #0xf0
10012f004:     	adrp	x9, 0x100597000 <___anon_33948+0x60>
10012f008:     	add	x9, x9, #0x3ac
10012f00c:     	adrp	x10, 0x100597000 <___anon_33948+0x60>
10012f010:     	add	x10, x10, #0x3a8
10012f014:     	csel	x9, x10, x9, eq
10012f018:     	cmp	w8, #0xe0
10012f01c:     	adrp	x8, 0x100597000 <___anon_33948+0x60>
10012f020:     	add	x8, x8, #0x3a4
10012f024:     	csel	x8, x8, x9, eq
10012f028:     	ldrb	w8, [x8, #0x2]
10012f02c:     	and	x2, x8, #0x7
10012f030:     	add	x24, x24, x2
10012f034:     	cbnz	x1, 0x10012f048 <_render.TerminalRenderer.drawPane+0xb8c>
10012f038:     	b	0x10012f0a0 <_render.TerminalRenderer.drawPane+0xbe4>
10012f03c:     	mov	x1, #0x0                ; =0
10012f040:     	mov	x2, #0x0                ; =0
10012f044:     	cbz	x1, 0x10012f0a0 <_render.TerminalRenderer.drawPane+0xbe4>
10012f048:     	add	x0, sp, #0x2, lsl #12   ; =0x2000
10012f04c:     	add	x0, x0, #0x300
10012f050:     	bl	0x10019bb14 <_unicode.utf8Decode>
10012f054:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
10012f058:     	add	x9, x9, #0x300
10012f05c:     	ldrb	w8, [x9, #0x2]
10012f060:     	ldrh	w22, [x9]
10012f064:     	bfi	w22, w8, #16, #5
10012f068:     	mov	x0, x26
10012f06c:     	mov	x1, x22
10012f070:     	bl	0x10009f6f8 <_hb_set_has>
10012f074:     	cbnz	w0, 0x10012efb4 <_render.TerminalRenderer.drawPane+0xaf8>
10012f078:     	mov	x0, x27
10012f07c:     	mov	x1, x22
10012f080:     	bl	0x10009f6f8 <_hb_set_has>
10012f084:     	ldr	x30, [sp, #0x298]
10012f088:     	ldr	x22, [sp, #0x280]
10012f08c:     	cbz	w0, 0x10012f2b4 <_render.TerminalRenderer.drawPane+0xdf8>
10012f090:     	mov	w8, #0x1                ; =1
10012f094:     	cmp	w8, w20
10012f098:     	b.ls	0x10012efc4 <_render.TerminalRenderer.drawPane+0xb08>
10012f09c:     	b	0x10012efa8 <_render.TerminalRenderer.drawPane+0xaec>
10012f0a0:     	add	x8, sp, #0x500
10012f0a4:     	ldr	x22, [sp, #0x280]
10012f0a8:     	add	x26, sp, #0xd00
10012f0ac:     	ldrb	w8, [x8]
10012f0b0:     	and	w8, w8, #0x3
10012f0b4:     	ldr	x9, [x30, #0x30]
10012f0b8:     	cmp	w8, #0x0
10012f0bc:     	ccmp	x9, #0x0, #0x4, ne
10012f0c0:     	ldr	x7, [sp, #0x278]
10012f0c4:     	mov	w24, #0x6               ; =6
10012f0c8:     	mov	w27, #0xffff            ; =65535
10012f0cc:     	ldr	x15, [sp, #0x2b8]
10012f0d0:     	ldr	x16, [sp, #0x250]
10012f0d4:     	b.eq	0x10012f184 <_render.TerminalRenderer.drawPane+0xcc8>
10012f0d8:     	ldr	x10, [x30, #0x28]
10012f0dc:     	madd	x9, x9, x24, x10
10012f0e0:     	ldurb	w9, [x9, #-0x4]
10012f0e4:     	tst	w9, #0x3
10012f0e8:     	b.eq	0x10012f184 <_render.TerminalRenderer.drawPane+0xcc8>
10012f0ec:     	mov	w9, #0x0                ; =0
10012f0f0:     	ldrh	w10, [x30, #0x40]
10012f0f4:     	ldur	w12, [x30, #0x42]
10012f0f8:     	ldrh	w11, [x28]
10012f0fc:     	ldur	w13, [x28, #0x2]
10012f100:     	tst	w10, #0x10
10012f104:     	csel	w12, w12, wzr, eq
10012f108:     	tst	w11, #0x10
10012f10c:     	csel	w13, w13, wzr, eq
10012f110:     	eor	w14, w11, w10
10012f114:     	tst	w14, #0xfffff83f
10012f118:     	b.ne	0x10012f2e4 <_render.TerminalRenderer.drawPane+0xe28>
10012f11c:     	cmp	w12, w13
10012f120:     	b.ne	0x10012f2e4 <_render.TerminalRenderer.drawPane+0xe28>
10012f124:     	ldur	w12, [x30, #0x46]
10012f128:     	ldur	w13, [x28, #0x6]
10012f12c:     	lsl	w10, w10, #27
10012f130:     	and	w10, w12, w10, asr #31
10012f134:     	lsl	w11, w11, #27
10012f138:     	and	w11, w13, w11, asr #31
10012f13c:     	cmp	w10, w11
10012f140:     	b.ne	0x10012f2e4 <_render.TerminalRenderer.drawPane+0xe28>
10012f144:     	ldrb	w9, [x30, #0x5e]
10012f148:     	cmp	w9, #0x1
10012f14c:     	b.ne	0x10012f2dc <_render.TerminalRenderer.drawPane+0xe20>
10012f150:     	ldrb	w9, [x28, #0x1e]
10012f154:     	cmp	w9, #0x1
10012f158:     	b.ne	0x10012f2dc <_render.TerminalRenderer.drawPane+0xe20>
10012f15c:     	ldrb	w9, [x30, #0x4e]
10012f160:     	cmp	w9, #0x73
10012f164:     	b.eq	0x10012f2ec <_render.TerminalRenderer.drawPane+0xe30>
10012f168:     	cmp	w9, #0x66
10012f16c:     	b.ne	0x10012f2dc <_render.TerminalRenderer.drawPane+0xe20>
10012f170:     	ldrb	w9, [x23]
10012f174:     	cmp	w9, #0x69
10012f178:     	mov	w10, #0x6c              ; =108
10012f17c:     	ccmp	w9, w10, #0x4, ne
10012f180:     	b	0x10012f2f4 <_render.TerminalRenderer.drawPane+0xe38>
10012f184:     	mov	w9, #0x0                ; =0
10012f188:     	b	0x10012f2e4 <_render.TerminalRenderer.drawPane+0xe28>
10012f18c:     	cmp	w8, #0x96
10012f190:     	b.ne	0x10012f1a0 <_render.TerminalRenderer.drawPane+0xce4>
10012f194:     	ldrsb	w8, [x28, #0x10]
10012f198:     	cmn	w8, #0x61
10012f19c:     	b.le	0x10012f1b4 <_render.TerminalRenderer.drawPane+0xcf8>
10012f1a0:     	ldr	x8, [sp, #0x290]
10012f1a4:     	ldr	x26, [x8, #0xfe8]
10012f1a8:     	cbz	x26, 0x10012f2b4 <_render.TerminalRenderer.drawPane+0xdf8>
10012f1ac:     	mov	w19, #0x3               ; =3
10012f1b0:     	b	0x10012f1d0 <_render.TerminalRenderer.drawPane+0xd14>
10012f1b4:     	mov	w8, #0x0                ; =0
10012f1b8:     	mov	w9, #0x0                ; =0
10012f1bc:     	b	0x10012f2e4 <_render.TerminalRenderer.drawPane+0xe28>
10012f1c0:     	ldr	x8, [sp, #0x290]
10012f1c4:     	ldr	x26, [x8, #0xfe8]
10012f1c8:     	cbz	x26, 0x10012f2b4 <_render.TerminalRenderer.drawPane+0xdf8>
10012f1cc:     	mov	w19, #0x1               ; =1
10012f1d0:     	ldr	x8, [sp, #0x290]
10012f1d4:     	ldr	x27, [x8, #0xff0]
10012f1d8:     	mov	x8, x23
10012f1dc:     	mov	x9, x19
10012f1e0:     	mov	x10, #0x0               ; =0
10012f1e4:     	b	0x10012f1f8 <_render.TerminalRenderer.drawPane+0xd3c>
10012f1e8:     	mov	w11, #0x1               ; =1
10012f1ec:     	add	x10, x11, x10
10012f1f0:     	cmp	x10, x9
10012f1f4:     	b.hs	0x10012efa0 <_render.TerminalRenderer.drawPane+0xae4>
10012f1f8:     	add	x11, x8, x10
10012f1fc:     	ldrsb	w12, [x11]
10012f200:     	tbz	w12, #0x1f, 0x10012f1e8 <_render.TerminalRenderer.drawPane+0xd2c>
10012f204:     	and	x12, x12, #0xff
10012f208:     	adrp	x13, 0x10059b000 <___anon_64768+0x8e0>
10012f20c:     	add	x13, x13, #0x92b
10012f210:     	ldrb	w13, [x13, x12]
10012f214:     	cmp	w13, #0xf1
10012f218:     	and	x12, x13, #0x7
10012f21c:     	add	x14, x10, x12
10012f220:     	ccmp	x14, x9, #0x2, ne
10012f224:     	b.hi	0x10012f2b4 <_render.TerminalRenderer.drawPane+0xdf8>
10012f228:     	lsr	w13, w13, #1
10012f22c:     	and	w13, w13, #0x78
10012f230:     	mov	x14, #0xa080            ; =41088
10012f234:     	movk	x14, #0x9080, lsl #16
10012f238:     	movk	x14, #0x80, lsl #32
10012f23c:     	lsr	x14, x14, x13
10012f240:     	and	w14, w14, #0xff0
10012f244:     	mov	x15, #0xbfbf            ; =49087
10012f248:     	movk	x15, #0xbf9f, lsl #16
10012f24c:     	movk	x15, #0x8f, lsl #32
10012f250:     	lsr	x13, x15, x13
10012f254:     	and	w13, w13, #0xff
10012f258:     	ldrb	w15, [x11, #0x1]
10012f25c:     	cmp	w15, w14
10012f260:     	ccmp	w15, w13, #0x2, hs
10012f264:     	b.hi	0x10012f2b4 <_render.TerminalRenderer.drawPane+0xdf8>
10012f268:     	cmp	w12, #0x2
10012f26c:     	b.eq	0x10012f298 <_render.TerminalRenderer.drawPane+0xddc>
10012f270:     	cmp	w12, #0x4
10012f274:     	b.ne	0x10012f2a0 <_render.TerminalRenderer.drawPane+0xde4>
10012f278:     	ldrsb	w12, [x11, #0x2]
10012f27c:     	cmn	w12, #0x41
10012f280:     	b.gt	0x10012f2b4 <_render.TerminalRenderer.drawPane+0xdf8>
10012f284:     	ldrsb	w11, [x11, #0x3]
10012f288:     	cmn	w11, #0x41
10012f28c:     	b.gt	0x10012f2b4 <_render.TerminalRenderer.drawPane+0xdf8>
10012f290:     	mov	w11, #0x4               ; =4
10012f294:     	b	0x10012f1ec <_render.TerminalRenderer.drawPane+0xd30>
10012f298:     	mov	w11, w12
10012f29c:     	b	0x10012f1ec <_render.TerminalRenderer.drawPane+0xd30>
10012f2a0:     	ldrsb	w11, [x11, #0x2]
10012f2a4:     	cmn	w11, #0x41
10012f2a8:     	b.gt	0x10012f2b4 <_render.TerminalRenderer.drawPane+0xdf8>
10012f2ac:     	mov	w11, #0x3               ; =3
10012f2b0:     	b	0x10012f1ec <_render.TerminalRenderer.drawPane+0xd30>
10012f2b4:     	mov	w8, #0x0                ; =0
10012f2b8:     	mov	w9, #0x0                ; =0
10012f2bc:     	ldr	x7, [sp, #0x278]
10012f2c0:     	mov	w24, #0x6               ; =6
10012f2c4:     	add	x26, sp, #0xd00
10012f2c8:     	mov	w27, #0xffff            ; =65535
10012f2cc:     	ldr	x23, [sp, #0x108]
10012f2d0:     	ldr	x15, [sp, #0x2b8]
10012f2d4:     	ldr	x16, [sp, #0x250]
10012f2d8:     	b	0x10012ed88 <_render.TerminalRenderer.drawPane+0x8cc>
10012f2dc:     	mov	w9, #0x0                ; =0
10012f2e0:     	eor	w9, w9, #0x1
10012f2e4:     	ldr	x23, [sp, #0x108]
10012f2e8:     	b	0x10012ed88 <_render.TerminalRenderer.drawPane+0x8cc>
10012f2ec:     	ldrb	w9, [x23]
10012f2f0:     	cmp	w9, #0x74
10012f2f4:     	cset	w9, eq
10012f2f8:     	b	0x10012f2e0 <_render.TerminalRenderer.drawPane+0xe24>
10012f2fc:     	tst	w8, #0xffff
10012f300:     	b.eq	0x10012f420 <_render.TerminalRenderer.drawPane+0xf64>
10012f304:     	ldr	x8, [sp, #0x290]
10012f308:     	ldrh	w8, [x8, #0xff8]
10012f30c:     	sub	w9, w8, #0x81
10012f310:     	ubfx	w9, w9, #7, #9
10012f314:     	cmp	w9, #0x1ff
10012f318:     	mov	w9, #0x80               ; =128
10012f31c:     	csel	w8, w9, w8, lo
10012f320:     	ldr	x9, [x30, #0x30]
10012f324:     	add	x25, sp, #0x500
10012f328:     	ldr	x19, [sp, #0x240]
10012f32c:     	ldr	x20, [sp, #0x230]
10012f330:     	cbz	x9, 0x10012f410 <_render.TerminalRenderer.drawPane+0xf54>
10012f334:     	ldr	x10, [x30, #0x28]
10012f338:     	add	x10, x10, #0x3
10012f33c:     	mov	w11, #0xffff            ; =65535
10012f340:     	ldrb	w12, [x10]
10012f344:     	ldurb	w13, [x10, #-0x1]
10012f348:     	and	w13, w13, #0x3
10012f34c:     	and	w11, w11, #0xffff
10012f350:     	add	w14, w11, #0x1
10012f354:     	cmp	w14, w27
10012f358:     	csinc	w11, w27, w11, hs
10012f35c:     	cmp	w12, #0x0
10012f360:     	csinv	w11, w11, wzr, ne
10012f364:     	cmp	w13, #0x2
10012f368:     	csel	w11, wzr, w11, eq
10012f36c:     	sturh	w11, [x10, #-0x3]
10012f370:     	add	x10, x10, #0x6
10012f374:     	subs	x9, x9, #0x1
10012f378:     	b.ne	0x10012f340 <_render.TerminalRenderer.drawPane+0xe84>
10012f37c:     	ldr	x9, [x30, #0x30]
10012f380:     	cbz	x9, 0x10012f410 <_render.TerminalRenderer.drawPane+0xf54>
10012f384:     	cmp	x9, #0x8
10012f388:     	b.hs	0x100132464 <_render.TerminalRenderer.drawPane+0x3fa8>
10012f38c:     	mov	w13, #0xffff            ; =65535
10012f390:     	mov	x10, x9
10012f394:     	and	x9, x9, #0x7
10012f398:     	cbz	x9, 0x10012f410 <_render.TerminalRenderer.drawPane+0xf54>
10012f39c:     	add	x10, x10, x10, lsl #1
10012f3a0:     	lsl	x10, x10, #1
10012f3a4:     	b	0x10012f3dc <_render.TerminalRenderer.drawPane+0xf20>
10012f3a8:     	ldurh	w13, [x11, #-0x6]
10012f3ac:     	and	w14, w12, #0xffff
10012f3b0:     	cmp	w13, w14
10012f3b4:     	csel	w13, w13, w14, lo
10012f3b8:     	cmp	w13, w8, uxth
10012f3bc:     	cset	w13, lo
10012f3c0:     	sturb	w13, [x11, #-0x2]
10012f3c4:     	ldurb	w11, [x11, #-0x3]
10012f3c8:     	cmp	w11, #0x0
10012f3cc:     	csinv	w13, w12, wzr, ne
10012f3d0:     	sub	x10, x10, #0x6
10012f3d4:     	subs	x9, x9, #0x1
10012f3d8:     	b.eq	0x10012f410 <_render.TerminalRenderer.drawPane+0xf54>
10012f3dc:     	ldr	x11, [x30, #0x28]
10012f3e0:     	add	x11, x11, x10
10012f3e4:     	ldurb	w12, [x11, #-0x4]
10012f3e8:     	and	w14, w12, #0x3
10012f3ec:     	and	w12, w13, #0xffff
10012f3f0:     	add	w13, w12, #0x1
10012f3f4:     	cmp	w13, w27
10012f3f8:     	csinc	w12, w27, w12, hs
10012f3fc:     	cmp	w14, #0x2
10012f400:     	csel	w12, wzr, w12, eq
10012f404:     	cbnz	w14, 0x10012f3a8 <_render.TerminalRenderer.drawPane+0xeec>
10012f408:     	mov	w13, #0x0               ; =0
10012f40c:     	b	0x10012f3c0 <_render.TerminalRenderer.drawPane+0xf04>
10012f410:     	mov	w8, #0x1                ; =1
10012f414:     	str	w8, [sp, #0xd8]
10012f418:     	cbnz	w23, 0x10012f438 <_render.TerminalRenderer.drawPane+0xf7c>
10012f41c:     	b	0x10012e8a4 <_render.TerminalRenderer.drawPane+0x3e8>
10012f420:     	mov	w8, #0x1                ; =1
10012f424:     	str	w8, [sp, #0xd8]
10012f428:     	add	x25, sp, #0x500
10012f42c:     	ldr	x19, [sp, #0x240]
10012f430:     	ldr	x20, [sp, #0x230]
10012f434:     	cbz	w23, 0x10012e8a4 <_render.TerminalRenderer.drawPane+0x3e8>
10012f438:     	mov	w28, #0x0               ; =0
10012f43c:     	ldr	x10, [sp, #0x188]
10012f440:     	ldrh	w8, [x10, #0x60]
10012f444:     	ldr	x9, [x10]
10012f448:     	ldr	x11, [x10, #0x18]
10012f44c:     	str	x11, [sp, #0xb0]
10012f450:     	ldr	x11, [x10, #0x30]
10012f454:     	str	x11, [sp, #0xa8]
10012f458:     	ldr	x10, [x10, #0x48]
10012f45c:     	mov	w11, #0x1               ; =1
10012f460:     	sub	x11, x11, x23
10012f464:     	str	x11, [sp, #0xa0]
10012f468:     	ldr	x11, [sp, #0x2b8]
10012f46c:     	neg	x11, x11
10012f470:     	str	x11, [sp, #0x98]
10012f474:     	ldr	x11, [sp, #0x1c8]
10012f478:     	add	x11, x11, x20
10012f47c:     	madd	x8, x11, x8, x19
10012f480:     	mov	w11, #0x6e0             ; =1760
10012f484:     	madd	x10, x8, x11, x10
10012f488:     	str	x10, [sp, #0x90]
10012f48c:     	add	x10, x8, x8, lsl #2
10012f490:     	lsl	x10, x10, #4
10012f494:     	str	x10, [sp, #0x2b8]
10012f498:     	add	x8, x9, x8, lsl #6
10012f49c:     	str	x8, [sp, #0x88]
10012f4a0:     	b	0x10012f4c8 <_render.TerminalRenderer.drawPane+0x100c>
10012f4a4:     	add	x25, sp, #0x500
10012f4a8:     	add	x26, sp, #0xd00
10012f4ac:     	mov	w27, #0xffff            ; =65535
10012f4b0:     	ldp	x8, x23, [sp, #0x100]
10012f4b4:     	ldr	x28, [sp, #0x148]
10012f4b8:     	add	w28, w8, w28
10012f4bc:     	cmp	w23, w28, uxth
10012f4c0:     	mov	w24, #0x6               ; =6
10012f4c4:     	b.ls	0x10012e8a4 <_render.TerminalRenderer.drawPane+0x3e8>
10012f4c8:     	mov	w8, #0x437f0000         ; =1132396544
10012f4cc:     	dup.2s	v0, w8
10012f4d0:     	str	d0, [sp, #0x190]
10012f4d4:     	mov	w8, #0xaaab             ; =43691
10012f4d8:     	movk	w8, #0x2aaa, lsl #16
10012f4dc:     	dup.2s	v0, w8
10012f4e0:     	str	d0, [sp, #0x110]
10012f4e4:     	ldr	w8, [sp, #0xd8]
10012f4e8:     	str	x28, [sp, #0x148]
10012f4ec:     	tbz	w8, #0x0, 0x10012f594 <_render.TerminalRenderer.drawPane+0x10d8>
10012f4f0:     	ldr	x10, [x30, #0x28]
10012f4f4:     	and	x8, x28, #0xffff
10012f4f8:     	str	x8, [sp, #0x118]
10012f4fc:     	umaddl	x8, w8, w24, x10
10012f500:     	ldrb	w8, [x8, #0x4]
10012f504:     	cmp	w8, #0x1
10012f508:     	b.ne	0x10012f5a8 <_render.TerminalRenderer.drawPane+0x10ec>
10012f50c:     	ldr	x9, [x30, #0x30]
10012f510:     	add	w8, w28, #0x1
10012f514:     	and	x8, x8, #0xffff
10012f518:     	cmp	x9, x8
10012f51c:     	b.ls	0x10012f554 <_render.TerminalRenderer.drawPane+0x1098>
10012f520:     	umaddl	x10, w8, w24, x10
10012f524:     	add	x10, x10, #0x4
10012f528:     	ldrb	w11, [x10]
10012f52c:     	cmp	w11, #0x1
10012f530:     	b.ne	0x10012f554 <_render.TerminalRenderer.drawPane+0x1098>
10012f534:     	ldurb	w11, [x10, #-0x1]
10012f538:     	cmp	w11, #0x1
10012f53c:     	b.ne	0x10012f554 <_render.TerminalRenderer.drawPane+0x1098>
10012f540:     	add	x8, x8, #0x1
10012f544:     	add	x10, x10, #0x6
10012f548:     	cmp	x9, x8
10012f54c:     	b.ne	0x10012f528 <_render.TerminalRenderer.drawPane+0x106c>
10012f550:     	mov	x8, x9
10012f554:     	ldr	x9, [sp, #0x118]
10012f558:     	sub	x9, x8, x9
10012f55c:     	sub	x8, x9, #0x2
10012f560:     	cmp	x8, #0x7f
10012f564:     	cset	w8, lo
10012f568:     	strb	w8, [sp, #0x3ce]
10012f56c:     	b.hs	0x100130410 <_render.TerminalRenderer.drawPane+0x1f54>
10012f570:     	ldr	x10, [x7]
10012f574:     	ldrh	w8, [x7, #0x18]
10012f578:     	str	w8, [sp, #0x1d0]
10012f57c:     	ldrh	w8, [x7, #0x1a]
10012f580:     	str	w8, [sp, #0x250]
10012f584:     	cbz	x9, 0x100131480 <_render.TerminalRenderer.drawPane+0x2fc4>
10012f588:     	mov	x27, x9
10012f58c:     	mov	x19, x9
10012f590:     	b	0x10012f5d0 <_render.TerminalRenderer.drawPane+0x1114>
10012f594:     	str	wzr, [sp, #0x240]
10012f598:     	and	x10, x28, #0xffff
10012f59c:     	mov	x9, x23
10012f5a0:     	str	x23, [sp, #0x1b0]
10012f5a4:     	b	0x100130428 <_render.TerminalRenderer.drawPane+0x1f6c>
10012f5a8:     	strb	wzr, [sp, #0x3ce]
10012f5ac:     	tbz	wzr, #0x0, 0x10013040c <_render.TerminalRenderer.drawPane+0x1f50>
10012f5b0:     	ldr	x10, [x7]
10012f5b4:     	ldrh	w8, [x7, #0x18]
10012f5b8:     	str	w8, [sp, #0x1d0]
10012f5bc:     	ldrh	w8, [x7, #0x1a]
10012f5c0:     	str	w8, [sp, #0x250]
10012f5c4:     	mov	w8, #0x1                ; =1
10012f5c8:     	mov	w27, #0x1               ; =1
10012f5cc:     	mov	x19, x8
10012f5d0:     	mov	x20, #0x0               ; =0
10012f5d4:     	mov	x23, #0x0               ; =0
10012f5d8:     	ldrh	w8, [x10, #0x50]
10012f5dc:     	str	x10, [sp, #0x1e0]
10012f5e0:     	ldr	x9, [x10, #0x30]
10012f5e4:     	ldr	x10, [sp, #0x1c8]
10012f5e8:     	mul	x8, x10, x8
10012f5ec:     	add	x24, x9, x8, lsl #5
10012f5f0:     	add	w8, w28, w20
10012f5f4:     	and	x8, x8, #0xffff
10012f5f8:     	add	x8, x24, x8, lsl #5
10012f5fc:     	ldrb	w22, [x8, #0x1e]
10012f600:     	add	x0, x25, x23
10012f604:     	add	x1, x8, #0xe
10012f608:     	mov	x2, x22
10012f60c:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
10012f610:     	add	x23, x23, x22
10012f614:     	str	w23, [x26, x20, lsl #2]
10012f618:     	add	x20, x20, #0x1
10012f61c:     	cmp	x27, x20
10012f620:     	b.ne	0x10012f5f0 <_render.TerminalRenderer.drawPane+0x1134>
10012f624:     	mov	w20, #0x0               ; =0
10012f628:     	ldr	x22, [sp, #0x280]
10012f62c:     	mov	x24, x27
10012f630:     	str	x19, [sp, #0x100]
10012f634:     	and	w8, w19, #0xffff
10012f638:     	ldrh	w3, [x22, #0x8]
10012f63c:     	str	x25, [sp, #0x3900]
10012f640:     	str	x23, [sp, #0x3908]
10012f644:     	ldr	x9, [sp, #0xb8]
10012f648:     	str	x9, [sp, #0x3910]
10012f64c:     	str	w8, [sp, #0x3918]
10012f650:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10012f654:     	add	x8, x8, #0x720
10012f658:     	strb	wzr, [x8, #0x1fc]
10012f65c:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
10012f660:     	add	x0, x0, #0x920
10012f664:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
10012f668:     	add	x2, x2, #0x900
10012f66c:     	ldr	x1, [sp, #0x290]
10012f670:     	bl	0x100120a0c <_text.GlyphAtlas.shape>
10012f674:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10012f678:     	add	x8, x8, #0x900
10012f67c:     	ldrh	w0, [x8, #0x48]
10012f680:     	cbnz	w0, 0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
10012f684:     	ldrb	w23, [x8, #0x45]
10012f688:     	ldr	x30, [sp, #0x298]
10012f68c:     	str	x24, [sp, #0x1b0]
10012f690:     	tbnz	w23, #0x0, 0x10012f6e0 <_render.TerminalRenderer.drawPane+0x1224>
10012f694:     	ldr	x1, [sp, #0x3920]
10012f698:     	ldr	x19, [sp, #0x3928]
10012f69c:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10012f6a0:     	add	x8, x8, #0x900
10012f6a4:     	ldrh	w24, [x8, #0x46]
10012f6a8:     	cmp	x19, #0x2
10012f6ac:     	b.lo	0x10012f6d4 <_render.TerminalRenderer.drawPane+0x1218>
10012f6b0:     	add	x8, x1, #0x1c
10012f6b4:     	sub	x9, x19, #0x1
10012f6b8:     	ldr	w10, [x8]
10012f6bc:     	ldur	w11, [x8, #-0x14]
10012f6c0:     	cmp	w10, w11
10012f6c4:     	b.lo	0x10012f6e0 <_render.TerminalRenderer.drawPane+0x1224>
10012f6c8:     	add	x8, x8, #0x14
10012f6cc:     	subs	x9, x9, #0x1
10012f6d0:     	b.ne	0x10012f6b8 <_render.TerminalRenderer.drawPane+0x11fc>
10012f6d4:     	sub	x8, x19, #0x101
10012f6d8:     	cmn	x8, #0x101
10012f6dc:     	b.hi	0x100131498 <_render.TerminalRenderer.drawPane+0x2fdc>
10012f6e0:     	tbnz	w20, #0x0, 0x1001314e4 <_render.TerminalRenderer.drawPane+0x3028>
10012f6e4:     	mov	x27, #0x0               ; =0
10012f6e8:     	add	w8, w28, w27
10012f6ec:     	ldr	x17, [sp, #0x278]
10012f6f0:     	ldr	x12, [x17]
10012f6f4:     	ldrh	w10, [x12, #0x50]
10012f6f8:     	ldr	x9, [sp, #0x1c8]
10012f6fc:     	mul	x9, x9, x10
10012f700:     	and	x11, x8, #0xffff
10012f704:     	ldr	x13, [x12, #0x30]
10012f708:     	add	x9, x13, x9, lsl #5
10012f70c:     	add	x9, x9, x11, lsl #5
10012f710:     	ldrb	w11, [x17, #0x40]
10012f714:     	cbz	w11, 0x10012f784 <_render.TerminalRenderer.drawPane+0x12c8>
10012f718:     	ldrb	w11, [x17, #0x38]
10012f71c:     	cbz	w11, 0x10012f784 <_render.TerminalRenderer.drawPane+0x12c8>
10012f720:     	ldr	w14, [x17, #0x28]
10012f724:     	ldr	x11, [x17, #0x30]
10012f728:     	ldrb	w13, [x17, #0x3d]
10012f72c:     	ldr	w12, [x12, #0xfc]
10012f730:     	ldr	w15, [sp, #0x1a0]
10012f734:     	add	w12, w12, w15
10012f738:     	tbz	w13, #0x0, 0x10012f9e4 <_render.TerminalRenderer.drawPane+0x1528>
10012f73c:     	cmp	w11, w14
10012f740:     	csel	w13, w11, w14, lo
10012f744:     	csel	w11, w11, w14, hi
10012f748:     	cmp	w12, w13
10012f74c:     	ccmp	w12, w11, #0x2, hs
10012f750:     	ldr	x0, [sp, #0x1b0]
10012f754:     	b.hi	0x10012f788 <_render.TerminalRenderer.drawPane+0x12cc>
10012f758:     	ldp	q0, q1, [x9]
10012f75c:     	str	q0, [sp, #0x3890]
10012f760:     	str	q1, [sp, #0x38a0]
10012f764:     	add	x11, sp, #0x3, lsl #12  ; =0x3000
10012f768:     	add	x11, x11, #0x720
10012f76c:     	ldrh	w9, [x11, #0x170]
10012f770:     	eor	w9, w9, #0x10
10012f774:     	strh	w9, [x11, #0x170]
10012f778:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012f77c:     	add	x9, x9, #0x890
10012f780:     	b	0x10012f788 <_render.TerminalRenderer.drawPane+0x12cc>
10012f784:     	ldr	x0, [sp, #0x1b0]
10012f788:     	ldrh	w11, [x17, #0x18]
10012f78c:     	ldrh	w12, [x17, #0x1a]
10012f790:     	ldr	q3, [x9, #0x10]
10012f794:     	umov.b	w28, v3[15]
10012f798:     	add	w11, w11, w8, uxth
10012f79c:     	ldr	x13, [sp, #0x1c8]
10012f7a0:     	add	w12, w12, w13, uxth
10012f7a4:     	tst	w28, #0xfe
10012f7a8:     	csinc	w13, w28, wzr, ne
10012f7ac:     	ldrh	w14, [x17, #0x1c]
10012f7b0:     	cmp	w14, w10
10012f7b4:     	csel	w10, w14, w10, lo
10012f7b8:     	sub	w10, w10, w8
10012f7bc:     	ldrh	w8, [x22, #0x4]
10012f7c0:     	ldr	x15, [sp, #0x260]
10012f7c4:     	ldp	w15, w14, [x15]
10012f7c8:     	madd	w15, w8, w11, w15
10012f7cc:     	ucvtf	s15, w15
10012f7d0:     	ldrh	w15, [x22, #0x6]
10012f7d4:     	madd	w14, w15, w12, w14
10012f7d8:     	ucvtf	s11, w14
10012f7dc:     	and	w10, w10, #0xffff
10012f7e0:     	cmp	w13, w10
10012f7e4:     	csel	w10, w13, w10, lo
10012f7e8:     	mul	w10, w10, w8
10012f7ec:     	ucvtf	s14, w10
10012f7f0:     	ucvtf	s9, w15
10012f7f4:     	ldr	q4, [x9]
10012f7f8:     	ldr	x13, [sp, #0x188]
10012f7fc:     	ldrh	w9, [x13, #0x60]
10012f800:     	and	x10, x12, #0xffff
10012f804:     	umull	x9, w9, w10
10012f808:     	add	x26, x9, w11, uxth
10012f80c:     	ldr	x9, [x13]
10012f810:     	add	x23, x9, x26, lsl #6
10012f814:     	ldr	x9, [x13, #0x18]
10012f818:     	str	x9, [sp, #0x230]
10012f81c:     	ldr	x9, [x13, #0x30]
10012f820:     	str	x9, [sp, #0x210]
10012f824:     	ldr	x16, [x13, #0x48]
10012f828:     	ldrb	w9, [x23, #0x38]
10012f82c:     	cmp	w9, #0x1
10012f830:     	b.ne	0x10012f88c <_render.TerminalRenderer.drawPane+0x13d0>
10012f834:     	ldr	s0, [x23, #0x8]
10012f838:     	fcmp	s0, s15
10012f83c:     	b.ne	0x10012f88c <_render.TerminalRenderer.drawPane+0x13d0>
10012f840:     	ldr	s0, [x23, #0xc]
10012f844:     	fcmp	s0, s11
10012f848:     	b.ne	0x10012f88c <_render.TerminalRenderer.drawPane+0x13d0>
10012f84c:     	ldr	s0, [x23, #0x10]
10012f850:     	fcmp	s0, s14
10012f854:     	b.ne	0x10012f88c <_render.TerminalRenderer.drawPane+0x13d0>
10012f858:     	ldr	s0, [x23, #0x14]
10012f85c:     	fcmp	s0, s9
10012f860:     	b.ne	0x10012f88c <_render.TerminalRenderer.drawPane+0x13d0>
10012f864:     	ldur	q0, [x23, #0x18]
10012f868:     	ldur	q1, [x23, #0x28]
10012f86c:     	eor.16b	v0, v0, v4
10012f870:     	eor.16b	v1, v1, v3
10012f874:     	orr.16b	v0, v1, v0
10012f878:     	umaxv.16b	b0, v0
10012f87c:     	fmov	w9, s0
10012f880:     	cbnz	w9, 0x10012f88c <_render.TerminalRenderer.drawPane+0x13d0>
10012f884:     	ldr	x9, [x23]
10012f888:     	cbz	x9, 0x1001303f8 <_render.TerminalRenderer.drawPane+0x1f3c>
10012f88c:     	str	q4, [sp, #0x3900]
10012f890:     	str	q3, [sp, #0x3910]
10012f894:     	str	xzr, [x30, #0xc0]
10012f898:     	mov.d	x25, v4[1]
10012f89c:     	fmov	x20, d4
10012f8a0:     	umov.b	w19, v4[2]
10012f8a4:     	tbnz	w20, #0x4, 0x10012f8cc <_render.TerminalRenderer.drawPane+0x1410>
10012f8a8:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012f8ac:     	add	x9, x9, #0x8c0
10012f8b0:     	mov	w10, #0x7               ; =7
10012f8b4:     	mov	w11, #0x8               ; =8
10012f8b8:     	mov	w13, #0x9               ; =9
10012f8bc:     	mov	w12, #0x6b90            ; =27536
10012f8c0:     	movk	w12, #0x1, lsl #16
10012f8c4:     	extr	x14, x25, x20, #0x30
10012f8c8:     	b	0x10012f8f0 <_render.TerminalRenderer.drawPane+0x1434>
10012f8cc:     	mov	w9, #0x6b90             ; =27536
10012f8d0:     	movk	w9, #0x1, lsl #16
10012f8d4:     	add	x12, x9, #0x10
10012f8d8:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012f8dc:     	add	x9, x9, #0x8b0
10012f8e0:     	mov	x14, x19
10012f8e4:     	mov	w10, #0x3               ; =3
10012f8e8:     	mov	w11, #0x4               ; =4
10012f8ec:     	mov	w13, #0x5               ; =5
10012f8f0:     	str	q4, [sp, #0x2f0]
10012f8f4:     	add	x15, sp, #0x2f0
10012f8f8:     	orr	x10, x15, x10
10012f8fc:     	ldrb	w10, [x10]
10012f900:     	ldr	x15, [sp, #0x290]
10012f904:     	ldr	q0, [x15, x12]
10012f908:     	str	q0, [x9]
10012f90c:     	and	w12, w14, #0xff
10012f910:     	cmp	w12, #0x2
10012f914:     	str	q3, [sp, #0x250]
10012f918:     	b.eq	0x10012f96c <_render.TerminalRenderer.drawPane+0x14b0>
10012f91c:     	cmp	w12, #0x1
10012f920:     	b.ne	0x10012f9b8 <_render.TerminalRenderer.drawPane+0x14fc>
10012f924:     	and	w9, w10, #0xff
10012f928:     	cmp	w9, #0x10
10012f92c:     	b.hs	0x10012fa24 <_render.TerminalRenderer.drawPane+0x1568>
10012f930:     	and	x9, x10, #0xff
10012f934:     	add	x9, x9, w10, uxtb #1
10012f938:     	ldr	x10, [sp, #0x1c0]
10012f93c:     	add	x9, x10, x9
10012f940:     	ldr	b0, [x9]
10012f944:     	ucvtf	s0, s0
10012f948:     	mov	w10, #0x437f0000        ; =1132396544
10012f94c:     	fmov	s1, w10
10012f950:     	fdiv	s5, s0, s1
10012f954:     	ldr	b0, [x9, #0x1]
10012f958:     	ucvtf	s0, s0
10012f95c:     	fdiv	s0, s0, s1
10012f960:     	stp	s5, s0, [x29, #-0xb0]
10012f964:     	ldr	b0, [x9, #0x2]
10012f968:     	b	0x10012f9a8 <_render.TerminalRenderer.drawPane+0x14ec>
10012f96c:     	add	x12, sp, #0x2e0
10012f970:     	orr	x9, x12, x13
10012f974:     	str	q4, [sp, #0x2e0]
10012f978:     	orr	x11, x12, x11
10012f97c:     	and	w10, w10, #0xff
10012f980:     	ucvtf	s0, w10
10012f984:     	mov	w10, #0x437f0000        ; =1132396544
10012f988:     	fmov	s1, w10
10012f98c:     	fdiv	s5, s0, s1
10012f990:     	stur	s5, [x29, #-0xb0]
10012f994:     	ldr	b0, [x11]
10012f998:     	ucvtf	s0, s0
10012f99c:     	fdiv	s0, s0, s1
10012f9a0:     	stur	s0, [x29, #-0xac]
10012f9a4:     	ldr	b0, [x9]
10012f9a8:     	ucvtf	s0, s0
10012f9ac:     	fdiv	s0, s0, s1
10012f9b0:     	stur	s0, [x29, #-0xa8]
10012f9b4:     	b	0x10012fb84 <_render.TerminalRenderer.drawPane+0x16c8>
10012f9b8:     	ldr	s5, [x9]
10012f9bc:     	ldp	s12, s10, [x9, #0x4]
10012f9c0:     	ldr	s8, [x9, #0xc]
10012f9c4:     	ucvtf	s13, w8
10012f9c8:     	ldrb	w8, [x30, #0xd8]
10012f9cc:     	str	q4, [sp, #0x240]
10012f9d0:     	cbnz	w8, 0x10012fba8 <_render.TerminalRenderer.drawPane+0x16ec>
10012f9d4:     	ldr	x8, [x30, #0xc8]
10012f9d8:     	cbz	x8, 0x10012fac0 <_render.TerminalRenderer.drawPane+0x1604>
10012f9dc:     	mov	x8, #0x0                ; =0
10012f9e0:     	b	0x10012fb38 <_render.TerminalRenderer.drawPane+0x167c>
10012f9e4:     	ldr	w13, [x17, #0x2c]
10012f9e8:     	lsr	x15, x11, #32
10012f9ec:     	cmp	w14, w11
10012f9f0:     	ldr	x0, [sp, #0x1b0]
10012f9f4:     	b.lo	0x10012fa0c <_render.TerminalRenderer.drawPane+0x1550>
10012f9f8:     	cmp	w14, w11
10012f9fc:     	b.ne	0x10012fdb8 <_render.TerminalRenderer.drawPane+0x18fc>
10012fa00:     	and	w16, w13, #0xffff
10012fa04:     	cmp	w16, w15, uxth
10012fa08:     	b.hs	0x10012fdb8 <_render.TerminalRenderer.drawPane+0x18fc>
10012fa0c:     	mov	x16, x13
10012fa10:     	mov	x13, x15
10012fa14:     	mov	x15, x14
10012fa18:     	cmp	w12, w15
10012fa1c:     	b.hs	0x10012fdcc <_render.TerminalRenderer.drawPane+0x1910>
10012fa20:     	b	0x10012f788 <_render.TerminalRenderer.drawPane+0x12cc>
10012fa24:     	cmp	w9, #0xe7
10012fa28:     	b.hi	0x10012fb50 <_render.TerminalRenderer.drawPane+0x1694>
10012fa2c:     	sub	w9, w10, #0x10
10012fa30:     	and	w10, w9, #0xff
10012fa34:     	mov	w11, #0x39              ; =57
10012fa38:     	mul	w11, w10, w11
10012fa3c:     	lsr	w11, w11, #11
10012fa40:     	mov	w12, #0x28              ; =40
10012fa44:     	mov	w13, #0x37              ; =55
10012fa48:     	madd	w11, w11, w12, w13
10012fa4c:     	cmp	w10, #0x24
10012fa50:     	csel	w11, wzr, w11, lo
10012fa54:     	and	w11, w11, #0xff
10012fa58:     	mov	w12, #0xab              ; =171
10012fa5c:     	mul	w10, w10, w12
10012fa60:     	lsr	w10, w10, #10
10012fa64:     	ucvtf	s0, w11
10012fa68:     	mov	w11, #0x437f0000        ; =1132396544
10012fa6c:     	fmov	s1, w11
10012fa70:     	fmov	s2, w10
10012fa74:     	mov.s	v2[1], w9
10012fa78:     	fdiv	s5, s0, s1
10012fa7c:     	movi	d0, #0x0000ff000000ff
10012fa80:     	and.8b	v0, v2, v0
10012fa84:     	ldr	d1, [sp, #0x110]
10012fa88:     	umull.2d	v1, v0, v1
10012fa8c:     	shrn.2s	v1, v1, #0x20
10012fa90:     	movi.2s	v2, #0x6
10012fa94:     	mls.2s	v0, v1, v2
10012fa98:     	movi.2s	v1, #0x37
10012fa9c:     	movi.2s	v2, #0x28
10012faa0:     	mla.2s	v1, v0, v2
10012faa4:     	cmeq.2s	v0, v0, #0
10012faa8:     	bic.8b	v0, v1, v0
10012faac:     	bic.2s	v0, #0x3, lsl #8
10012fab0:     	ucvtf.2s	v0, v0
10012fab4:     	ldr	d1, [sp, #0x190]
10012fab8:     	fdiv.2s	v0, v0, v1
10012fabc:     	b	0x10012fb74 <_render.TerminalRenderer.drawPane+0x16b8>
10012fac0:     	ldp	x0, x8, [x30, #0xa8]
10012fac4:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012fac8:     	add	x9, x9, #0x900
10012facc:     	strb	wzr, [x9, #0xb0]
10012fad0:     	tbnz	wzr, #0x0, 0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
10012fad4:     	str	q5, [sp, #0x200]
10012fad8:     	mov	x24, x16
10012fadc:     	ldr	x8, [x8]
10012fae0:     	mov	w1, #0xa0               ; =160
10012fae4:     	mov	w2, #0x2                ; =2
10012fae8:     	ldr	x3, [sp, #0x198]
10012faec:     	blr	x8
10012faf0:     	cbz	x0, 0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
10012faf4:     	mov	x22, x0
10012faf8:     	str	x27, [sp, #0x1f0]
10012fafc:     	ldr	x27, [sp, #0x298]
10012fb00:     	ldp	x1, x8, [x27, #0xb8]
10012fb04:     	add	x8, x8, x8, lsl #2
10012fb08:     	lsl	x2, x8, #4
10012fb0c:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
10012fb10:     	mov	x30, x27
10012fb14:     	ldr	x27, [sp, #0x1f0]
10012fb18:     	ldr	x8, [x30, #0xc0]
10012fb1c:     	str	x22, [x30, #0xb8]
10012fb20:     	mov	w9, #0x2                ; =2
10012fb24:     	str	x9, [x30, #0xc8]
10012fb28:     	ldr	x22, [sp, #0x280]
10012fb2c:     	ldr	q4, [sp, #0x240]
10012fb30:     	mov	x16, x24
10012fb34:     	ldr	q5, [sp, #0x200]
10012fb38:     	add	x9, x8, #0x1
10012fb3c:     	str	x9, [x30, #0xc0]
10012fb40:     	ldr	x9, [x30, #0xb8]
10012fb44:     	mov	w10, #0x50              ; =80
10012fb48:     	madd	x8, x8, x10, x9
10012fb4c:     	b	0x10012fbbc <_render.TerminalRenderer.drawPane+0x1700>
10012fb50:     	mov	w9, #0xa                ; =10
10012fb54:     	mov	w11, #-0x8              ; =-8
10012fb58:     	madd	w9, w10, w9, w11
10012fb5c:     	and	w9, w9, #0xfe
10012fb60:     	ucvtf	s0, w9
10012fb64:     	mov	w9, #0x437f0000         ; =1132396544
10012fb68:     	fmov	s1, w9
10012fb6c:     	fdiv	s5, s0, s1
10012fb70:     	dup.2s	v0, v5[0]
10012fb74:     	stur	s5, [x29, #-0xb0]
10012fb78:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012fb7c:     	add	x9, x9, #0x900
10012fb80:     	stur	d0, [x9, #0xb4]
10012fb84:     	sub	x9, x29, #0xb0
10012fb88:     	mov	w10, #0x3f800000        ; =1065353216
10012fb8c:     	str	w10, [x9, #0xc]
10012fb90:     	ldp	s12, s10, [x9, #0x4]
10012fb94:     	ldr	s8, [x9, #0xc]
10012fb98:     	ucvtf	s13, w8
10012fb9c:     	ldrb	w8, [x30, #0xd8]
10012fba0:     	str	q4, [sp, #0x240]
10012fba4:     	cbz	w8, 0x10012f9d4 <_render.TerminalRenderer.drawPane+0x1518>
10012fba8:     	ldr	x8, [x30, #0xd0]
10012fbac:     	cbz	x8, 0x10012fbe8 <_render.TerminalRenderer.drawPane+0x172c>
10012fbb0:     	mov	w8, #0x1                ; =1
10012fbb4:     	str	x8, [x30, #0xc0]
10012fbb8:     	ldr	x8, [x30, #0xb8]
10012fbbc:     	stp	s15, s11, [x8]
10012fbc0:     	stp	s13, s9, [x8, #0x8]
10012fbc4:     	movi.4s	v0, #0x3a, lsl #24
10012fbc8:     	str	q0, [x8, #0x10]
10012fbcc:     	stp	s5, s12, [x8, #0x20]
10012fbd0:     	stp	s10, s8, [x8, #0x28]
10012fbd4:     	movi.2d	v0, #0000000000000000
10012fbd8:     	stp	q0, q0, [x8, #0x30]
10012fbdc:     	tst	w28, #0xff
10012fbe0:     	b.ne	0x10012fbfc <_render.TerminalRenderer.drawPane+0x1740>
10012fbe4:     	b	0x100130304 <_render.TerminalRenderer.drawPane+0x1e48>
10012fbe8:     	ldr	x8, [x30, #0xe0]
10012fbec:     	add	x8, x8, #0x1
10012fbf0:     	str	x8, [x30, #0xe0]
10012fbf4:     	tst	w28, #0xff
10012fbf8:     	b.eq	0x100130304 <_render.TerminalRenderer.drawPane+0x1e48>
10012fbfc:     	and	w8, w20, #0xffff
10012fc00:     	tbnz	w8, #0x5, 0x100130304 <_render.TerminalRenderer.drawPane+0x1e48>
10012fc04:     	tbnz	w8, #0x4, 0x10012fc2c <_render.TerminalRenderer.drawPane+0x1770>
10012fc08:     	mov	w9, #0x6b90             ; =27536
10012fc0c:     	movk	w9, #0x1, lsl #16
10012fc10:     	add	x12, x9, #0x10
10012fc14:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012fc18:     	add	x9, x9, #0x8e0
10012fc1c:     	mov	w10, #0x3               ; =3
10012fc20:     	mov	w11, #0x4               ; =4
10012fc24:     	mov	w13, #0x5               ; =5
10012fc28:     	b	0x10012fc4c <_render.TerminalRenderer.drawPane+0x1790>
10012fc2c:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012fc30:     	add	x9, x9, #0x8d0
10012fc34:     	mov	w10, #0x7               ; =7
10012fc38:     	mov	w11, #0x8               ; =8
10012fc3c:     	mov	w13, #0x9               ; =9
10012fc40:     	mov	w12, #0x6b90            ; =27536
10012fc44:     	movk	w12, #0x1, lsl #16
10012fc48:     	extr	x19, x25, x20, #0x30
10012fc4c:     	ldr	q3, [sp, #0x250]
10012fc50:     	str	q4, [sp, #0x2d0]
10012fc54:     	add	x14, sp, #0x2d0
10012fc58:     	orr	x10, x14, x10
10012fc5c:     	ldrb	w10, [x10]
10012fc60:     	ldr	x14, [sp, #0x290]
10012fc64:     	ldr	q0, [x14, x12]
10012fc68:     	str	q0, [x9]
10012fc6c:     	and	w12, w19, #0xff
10012fc70:     	cmp	w12, #0x2
10012fc74:     	b.eq	0x10012fcc8 <_render.TerminalRenderer.drawPane+0x180c>
10012fc78:     	cmp	w12, #0x1
10012fc7c:     	b.ne	0x10012fd14 <_render.TerminalRenderer.drawPane+0x1858>
10012fc80:     	and	w9, w10, #0xff
10012fc84:     	cmp	w9, #0x10
10012fc88:     	b.hs	0x10012fd1c <_render.TerminalRenderer.drawPane+0x1860>
10012fc8c:     	and	x9, x10, #0xff
10012fc90:     	add	x9, x9, w10, uxtb #1
10012fc94:     	ldr	x10, [sp, #0x1c0]
10012fc98:     	add	x9, x10, x9
10012fc9c:     	ldr	b0, [x9]
10012fca0:     	ucvtf	s0, s0
10012fca4:     	mov	w10, #0x437f0000        ; =1132396544
10012fca8:     	fmov	s1, w10
10012fcac:     	fdiv	s5, s0, s1
10012fcb0:     	ldr	b0, [x9, #0x1]
10012fcb4:     	ucvtf	s0, s0
10012fcb8:     	fdiv	s0, s0, s1
10012fcbc:     	stp	s5, s0, [x29, #-0xb0]
10012fcc0:     	ldr	b0, [x9, #0x2]
10012fcc4:     	b	0x10012fd04 <_render.TerminalRenderer.drawPane+0x1848>
10012fcc8:     	add	x12, sp, #0x2c0
10012fccc:     	orr	x9, x12, x13
10012fcd0:     	str	q4, [sp, #0x2c0]
10012fcd4:     	orr	x11, x12, x11
10012fcd8:     	and	w10, w10, #0xff
10012fcdc:     	ucvtf	s0, w10
10012fce0:     	mov	w10, #0x437f0000        ; =1132396544
10012fce4:     	fmov	s1, w10
10012fce8:     	fdiv	s5, s0, s1
10012fcec:     	stur	s5, [x29, #-0xb0]
10012fcf0:     	ldr	b0, [x11]
10012fcf4:     	ucvtf	s0, s0
10012fcf8:     	fdiv	s0, s0, s1
10012fcfc:     	stur	s0, [x29, #-0xac]
10012fd00:     	ldr	b0, [x9]
10012fd04:     	ucvtf	s0, s0
10012fd08:     	fdiv	s0, s0, s1
10012fd0c:     	stur	s0, [x29, #-0xa8]
10012fd10:     	b	0x10012fe2c <_render.TerminalRenderer.drawPane+0x1970>
10012fd14:     	ldr	s5, [x9]
10012fd18:     	b	0x10012fe38 <_render.TerminalRenderer.drawPane+0x197c>
10012fd1c:     	cmp	w9, #0xe7
10012fd20:     	b.hi	0x10012fdf8 <_render.TerminalRenderer.drawPane+0x193c>
10012fd24:     	sub	w9, w10, #0x10
10012fd28:     	and	w10, w9, #0xff
10012fd2c:     	mov	w11, #0x39              ; =57
10012fd30:     	mul	w11, w10, w11
10012fd34:     	lsr	w11, w11, #11
10012fd38:     	mov	w12, #0x28              ; =40
10012fd3c:     	mov	w13, #0x37              ; =55
10012fd40:     	madd	w11, w11, w12, w13
10012fd44:     	cmp	w10, #0x24
10012fd48:     	csel	w11, wzr, w11, lo
10012fd4c:     	and	w11, w11, #0xff
10012fd50:     	mov	w12, #0xab              ; =171
10012fd54:     	mul	w10, w10, w12
10012fd58:     	lsr	w10, w10, #10
10012fd5c:     	ucvtf	s0, w11
10012fd60:     	mov	w11, #0x437f0000        ; =1132396544
10012fd64:     	fmov	s1, w11
10012fd68:     	fmov	s2, w10
10012fd6c:     	mov.s	v2[1], w9
10012fd70:     	fdiv	s5, s0, s1
10012fd74:     	movi	d0, #0x0000ff000000ff
10012fd78:     	and.8b	v0, v2, v0
10012fd7c:     	ldr	d1, [sp, #0x110]
10012fd80:     	umull.2d	v1, v0, v1
10012fd84:     	shrn.2s	v1, v1, #0x20
10012fd88:     	movi.2s	v2, #0x6
10012fd8c:     	mls.2s	v0, v1, v2
10012fd90:     	movi.2s	v1, #0x37
10012fd94:     	movi.2s	v2, #0x28
10012fd98:     	mla.2s	v1, v0, v2
10012fd9c:     	cmeq.2s	v0, v0, #0
10012fda0:     	bic.8b	v0, v1, v0
10012fda4:     	bic.2s	v0, #0x3, lsl #8
10012fda8:     	ucvtf.2s	v0, v0
10012fdac:     	ldr	d1, [sp, #0x190]
10012fdb0:     	fdiv.2s	v0, v0, v1
10012fdb4:     	b	0x10012fe1c <_render.TerminalRenderer.drawPane+0x1960>
10012fdb8:     	mov	x16, x15
10012fdbc:     	mov	x15, x11
10012fdc0:     	mov	x11, x14
10012fdc4:     	cmp	w12, w15
10012fdc8:     	b.lo	0x10012f788 <_render.TerminalRenderer.drawPane+0x12cc>
10012fdcc:     	and	w14, w8, #0xffff
10012fdd0:     	cmp	w14, w16, uxth
10012fdd4:     	ccmp	w12, w15, #0x0, lo
10012fdd8:     	ccmp	w11, w12, #0x0, ne
10012fddc:     	b.lo	0x10012f788 <_render.TerminalRenderer.drawPane+0x12cc>
10012fde0:     	cmp	w11, w12
10012fde4:     	b.ne	0x10012f758 <_render.TerminalRenderer.drawPane+0x129c>
10012fde8:     	and	w11, w8, #0xffff
10012fdec:     	cmp	w11, w13, uxth
10012fdf0:     	b.hi	0x10012f788 <_render.TerminalRenderer.drawPane+0x12cc>
10012fdf4:     	b	0x10012f758 <_render.TerminalRenderer.drawPane+0x129c>
10012fdf8:     	mov	w9, #0xa                ; =10
10012fdfc:     	mov	w11, #-0x8              ; =-8
10012fe00:     	madd	w9, w10, w9, w11
10012fe04:     	and	w9, w9, #0xfe
10012fe08:     	ucvtf	s0, w9
10012fe0c:     	mov	w9, #0x437f0000         ; =1132396544
10012fe10:     	fmov	s1, w9
10012fe14:     	fdiv	s5, s0, s1
10012fe18:     	dup.2s	v0, v5[0]
10012fe1c:     	stur	s5, [x29, #-0xb0]
10012fe20:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10012fe24:     	add	x9, x9, #0x900
10012fe28:     	stur	d0, [x9, #0xb4]
10012fe2c:     	sub	x9, x29, #0xb0
10012fe30:     	mov	w10, #0x3f800000        ; =1065353216
10012fe34:     	str	w10, [x9, #0xc]
10012fe38:     	umov.b	w11, v3[14]
10012fe3c:     	ldp	s12, s10, [x9, #0x4]
10012fe40:     	ldr	s0, [x9, #0xc]
10012fe44:     	fmov	s1, #0.50000000
10012fe48:     	fmul	s1, s0, s1
10012fe4c:     	tst	w8, #0x4
10012fe50:     	fcsel	s13, s0, s1, eq
10012fe54:     	and	x10, x11, #0xff
10012fe58:     	and	w11, w11, #0xff
10012fe5c:     	ldr	s0, [x22]
10012fe60:     	ldrh	w9, [x22, #0x8]
10012fe64:     	ldr	h2, [x22, #0x4]
10012fe68:     	ldr	h1, [x22, #0x6]
10012fe6c:     	and	w12, w20, #0x1
10012fe70:     	add	x13, sp, #0x3, lsl #12  ; =0x3000
10012fe74:     	add	x13, x13, #0x720
10012fe78:     	strb	w12, [x13, #0x1d6]
10012fe7c:     	ubfx	w12, w8, #1, #1
10012fe80:     	strb	w12, [x13, #0x1d5]
10012fe84:     	strb	wzr, [x13, #0x1d0]
10012fe88:     	cmp	w11, #0x1
10012fe8c:     	add	x22, sp, #0x3, lsl #12  ; =0x3000
10012fe90:     	add	x22, x22, #0x900
10012fe94:     	str	q5, [sp, #0x200]
10012fe98:     	b.ne	0x10012ff5c <_render.TerminalRenderer.drawPane+0x1aa0>
10012fe9c:     	umov.b	w11, v4[14]
10012fea0:     	and	w11, w11, #0xff
10012fea4:     	cmp	w11, #0x20
10012fea8:     	b.ne	0x10012ff5c <_render.TerminalRenderer.drawPane+0x1aa0>
10012feac:     	sub	x11, x10, #0x1
10012feb0:     	ldr	x12, [sp, #0xe0]
10012feb4:     	ldrb	w12, [x12, x11]
10012feb8:     	adrp	x13, 0x100687000 <___anon_33682+0x119f>
10012febc:     	add	x13, x13, #0xee4
10012fec0:     	ldrb	w11, [x13, x11]
10012fec4:     	cmp	w12, w11
10012fec8:     	b.ne	0x10012ff5c <_render.TerminalRenderer.drawPane+0x1aa0>
10012fecc:     	tst	w8, #0x700
10012fed0:     	b.eq	0x10013000c <_render.TerminalRenderer.drawPane+0x1b50>
10012fed4:     	str	s9, [sp, #0x1f0]
10012fed8:     	str	s14, [sp, #0x1e0]
10012fedc:     	fmov	d8, d13
10012fee0:     	ldur	w8, [x22, #0xa]
10012fee4:     	str	s10, [sp, #0x1d0]
10012fee8:     	fmov	d14, d12
10012feec:     	fmov	d3, d5
10012fef0:     	ands	w9, w8, #0xff
10012fef4:     	b.eq	0x100130148 <_render.TerminalRenderer.drawPane+0x1c8c>
10012fef8:     	cmp	w9, #0x1
10012fefc:     	b.ne	0x100130014 <_render.TerminalRenderer.drawPane+0x1b58>
10012ff00:     	ubfx	w9, w8, #8, #8
10012ff04:     	cmp	w9, #0x10
10012ff08:     	b.hs	0x10013005c <_render.TerminalRenderer.drawPane+0x1ba0>
10012ff0c:     	ubfx	x8, x8, #8, #4
10012ff10:     	add	x8, x8, x8, lsl #1
10012ff14:     	ldr	x9, [sp, #0x1c0]
10012ff18:     	add	x8, x9, x8
10012ff1c:     	ldr	b0, [x8]
10012ff20:     	ucvtf	s0, s0
10012ff24:     	mov	w9, #0x437f0000         ; =1132396544
10012ff28:     	fmov	s1, w9
10012ff2c:     	fdiv	s3, s0, s1
10012ff30:     	ldr	b0, [x8, #0x1]
10012ff34:     	ucvtf	s0, s0
10012ff38:     	fdiv	s2, s0, s1
10012ff3c:     	ldr	b0, [x8, #0x2]
10012ff40:     	ucvtf	s0, s0
10012ff44:     	fdiv	s0, s0, s1
10012ff48:     	stp	s0, s2, [x29, #-0xb8]
10012ff4c:     	sub	x8, x29, #0xbc
10012ff50:     	sub	x10, x29, #0xb8
10012ff54:     	sub	x9, x29, #0xb4
10012ff58:     	b	0x100130134 <_render.TerminalRenderer.drawPane+0x1c78>
10012ff5c:     	mov	x24, x16
10012ff60:     	fneg	s3, s0
10012ff64:     	ucvtf	s2, s2
10012ff68:     	ucvtf	s1, s1
10012ff6c:     	ldr	x8, [sp, #0xe0]
10012ff70:     	str	x8, [sp, #0x3920]
10012ff74:     	str	x10, [sp, #0x3928]
10012ff78:     	fadd	s0, s0, s11
10012ff7c:     	str	s15, [sp, #0x3930]
10012ff80:     	str	s0, [sp, #0x3934]
10012ff84:     	str	s5, [sp, #0x3938]
10012ff88:     	str	s12, [sp, #0x393c]
10012ff8c:     	str	s10, [sp, #0x3940]
10012ff90:     	str	s13, [sp, #0x3944]
10012ff94:     	str	wzr, [sp, #0x3948]
10012ff98:     	str	s3, [sp, #0x394c]
10012ff9c:     	str	s2, [sp, #0x3950]
10012ffa0:     	str	s1, [sp, #0x3954]
10012ffa4:     	mov	w8, #0x1                ; =1
10012ffa8:     	strb	w8, [x22, #0x58]
10012ffac:     	strh	w9, [x22, #0x5c]
10012ffb0:     	add	x20, sp, #0x3, lsl #12  ; =0x3000
10012ffb4:     	add	x20, x20, #0x720
10012ffb8:     	ldrb	w8, [x20, #0x1d6]
10012ffbc:     	strb	w8, [x22, #0x5e]
10012ffc0:     	ldrb	w8, [x20, #0x1d5]
10012ffc4:     	strb	w8, [x22, #0x5f]
10012ffc8:     	ldrb	w8, [x20, #0x1d0]
10012ffcc:     	strb	w8, [x22, #0x60]
10012ffd0:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
10012ffd4:     	add	x0, x0, #0x8f8
10012ffd8:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
10012ffdc:     	add	x2, x2, #0x920
10012ffe0:     	add	x3, x30, #0xa8
10012ffe4:     	ldr	x1, [sp, #0x290]
10012ffe8:     	bl	0x100127dc8 <_text.GlyphAtlas.place>
10012ffec:     	ldrh	w0, [x20, #0x1dc]
10012fff0:     	cbnz	w0, 0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
10012fff4:     	ldrh	w8, [x20, #0x1e0]
10012fff8:     	ldr	x30, [sp, #0x298]
10012fffc:     	mov	x16, x24
100130000:     	ldr	q5, [sp, #0x200]
100130004:     	tst	w8, #0x700
100130008:     	b.ne	0x10012fed4 <_render.TerminalRenderer.drawPane+0x1a18>
10013000c:     	tbnz	w8, #0x6, 0x100130240 <_render.TerminalRenderer.drawPane+0x1d84>
100130010:     	b	0x100130304 <_render.TerminalRenderer.drawPane+0x1e48>
100130014:     	ubfx	w9, w8, #8, #8
100130018:     	dup.2s	v0, w8
10013001c:     	adrp	x8, 0x1001ff000 <__ZL18_hb_ucd_dm1_p2_map+0x16e>
100130020:     	ldr	d1, [x8, #0x3d8]
100130024:     	ushl.2s	v0, v0, v1
100130028:     	ucvtf	s1, w9
10013002c:     	mov	w8, #0x437f0000         ; =1132396544
100130030:     	fmov	s2, w8
100130034:     	fdiv	s3, s1, s2
100130038:     	bic.2s	v0, #0xff, lsl #8
10013003c:     	ucvtf.2s	v0, v0
100130040:     	ldr	d1, [sp, #0x190]
100130044:     	fdiv.2s	v0, v0, v1
100130048:     	stur	d0, [x29, #-0xc8]
10013004c:     	sub	x8, x29, #0xb4
100130050:     	sub	x9, x29, #0xc8
100130054:     	ldr	x10, [sp, #0x20]
100130058:     	b	0x100130134 <_render.TerminalRenderer.drawPane+0x1c78>
10013005c:     	ubfx	w9, w8, #8, #8
100130060:     	lsr	w8, w8, #8
100130064:     	cmp	w9, #0xe7
100130068:     	b.hi	0x100130100 <_render.TerminalRenderer.drawPane+0x1c44>
10013006c:     	sub	w8, w8, #0x10
100130070:     	and	w9, w8, #0xff
100130074:     	mov	w10, #0x39              ; =57
100130078:     	mul	w10, w9, w10
10013007c:     	lsr	w10, w10, #11
100130080:     	mov	w11, #0x28              ; =40
100130084:     	mov	w12, #0x37              ; =55
100130088:     	madd	w10, w10, w11, w12
10013008c:     	cmp	w9, #0x24
100130090:     	csel	w10, wzr, w10, lo
100130094:     	and	w10, w10, #0xff
100130098:     	mov	w11, #0xab              ; =171
10013009c:     	mul	w9, w9, w11
1001300a0:     	lsr	w9, w9, #10
1001300a4:     	ucvtf	s0, w10
1001300a8:     	mov	w10, #0x437f0000        ; =1132396544
1001300ac:     	fmov	s1, w10
1001300b0:     	fmov	s2, w9
1001300b4:     	mov.s	v2[1], w8
1001300b8:     	fdiv	s3, s0, s1
1001300bc:     	movi	d0, #0x0000ff000000ff
1001300c0:     	and.8b	v0, v2, v0
1001300c4:     	ldr	d1, [sp, #0x110]
1001300c8:     	umull.2d	v1, v0, v1
1001300cc:     	shrn.2s	v1, v1, #0x20
1001300d0:     	movi.2s	v2, #0x6
1001300d4:     	mls.2s	v0, v1, v2
1001300d8:     	movi.2s	v1, #0x37
1001300dc:     	movi.2s	v2, #0x28
1001300e0:     	mla.2s	v1, v0, v2
1001300e4:     	cmeq.2s	v0, v0, #0
1001300e8:     	bic.8b	v0, v1, v0
1001300ec:     	bic.2s	v0, #0x3, lsl #8
1001300f0:     	ucvtf.2s	v0, v0
1001300f4:     	ldr	d1, [sp, #0x190]
1001300f8:     	fdiv.2s	v0, v0, v1
1001300fc:     	b	0x100130124 <_render.TerminalRenderer.drawPane+0x1c68>
100130100:     	mov	w9, #0xa                ; =10
100130104:     	mov	w10, #-0x8              ; =-8
100130108:     	madd	w8, w8, w9, w10
10013010c:     	and	w8, w8, #0xfe
100130110:     	ucvtf	s0, w8
100130114:     	mov	w8, #0x437f0000         ; =1132396544
100130118:     	fmov	s1, w8
10013011c:     	fdiv	s3, s0, s1
100130120:     	dup.2s	v0, v3[0]
100130124:     	stur	d0, [x29, #-0xb0]
100130128:     	sub	x8, x29, #0xb4
10013012c:     	sub	x9, x29, #0xb0
100130130:     	ldr	x10, [sp, #0x8]
100130134:     	mov	w11, #0x3f800000        ; =1065353216
100130138:     	str	w11, [x8]
10013013c:     	ldr	s14, [x9]
100130140:     	fmov	s8, #1.00000000
100130144:     	ldr	s10, [x10]
100130148:     	fmov	d9, d13
10013014c:     	fmov	d13, d12
100130150:     	ldr	s0, [sp, #0x1f0]
100130154:     	fadd	s0, s0, s11
100130158:     	fmov	s1, #-2.00000000
10013015c:     	fadd	s12, s0, s1
100130160:     	ldrb	w8, [x30, #0xd8]
100130164:     	cbz	w8, 0x100130188 <_render.TerminalRenderer.drawPane+0x1ccc>
100130168:     	ldr	x9, [x30, #0xd0]
10013016c:     	ldr	x8, [x30, #0xc0]
100130170:     	cmp	x8, x9
100130174:     	b.lo	0x1001301e4 <_render.TerminalRenderer.drawPane+0x1d28>
100130178:     	ldr	x8, [x30, #0xe0]
10013017c:     	add	x8, x8, #0x1
100130180:     	str	x8, [x30, #0xe0]
100130184:     	b	0x100130224 <_render.TerminalRenderer.drawPane+0x1d68>
100130188:     	ldur	q0, [x30, #0xa8]
10013018c:     	stur	q0, [x29, #-0xb0]
100130190:     	ldp	x8, x9, [x30, #0xc0]
100130194:     	cmp	x9, x8
100130198:     	b.hi	0x1001301e4 <_render.TerminalRenderer.drawPane+0x1d28>
10013019c:     	str	q3, [sp, #0x170]
1001301a0:     	mov	x21, x16
1001301a4:     	add	x8, x8, #0x1
1001301a8:     	lsr	x9, x8, #1
1001301ac:     	add	x9, x9, #0x1
1001301b0:     	adds	x8, x8, x9
1001301b4:     	csinv	x2, x8, xzr, lo
1001301b8:     	add	x0, x30, #0xb8
1001301bc:     	sub	x1, x29, #0xb0
1001301c0:     	mov	x20, x30
1001301c4:     	bl	0x1001aece0 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
1001301c8:     	ands	w0, w0, #0xffff
1001301cc:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
1001301d0:     	ldr	x8, [x20, #0xc0]
1001301d4:     	mov	x30, x20
1001301d8:     	mov	x16, x21
1001301dc:     	ldr	q5, [sp, #0x200]
1001301e0:     	ldr	q3, [sp, #0x170]
1001301e4:     	add	x9, x8, #0x1
1001301e8:     	str	x9, [x30, #0xc0]
1001301ec:     	ldr	x9, [x30, #0xb8]
1001301f0:     	mov	w10, #0x50              ; =80
1001301f4:     	madd	x8, x8, x10, x9
1001301f8:     	stp	s15, s12, [x8]
1001301fc:     	ldr	s0, [sp, #0x1e0]
100130200:     	str	s0, [x8, #0x8]
100130204:     	ldr	q0, [sp, #0x150]
100130208:     	stur	q0, [x8, #0xc]
10013020c:     	mov	w9, #0x3a000000         ; =973078528
100130210:     	str	w9, [x8, #0x1c]
100130214:     	stp	s3, s14, [x8, #0x20]
100130218:     	stp	s10, s8, [x8, #0x28]
10013021c:     	movi.2d	v0, #0000000000000000
100130220:     	stp	q0, q0, [x8, #0x30]
100130224:     	ldrh	w8, [x22]
100130228:     	ldr	s14, [sp, #0x1e0]
10013022c:     	ldr	s10, [sp, #0x1d0]
100130230:     	fmov	d12, d13
100130234:     	fmov	d13, d9
100130238:     	ldr	s9, [sp, #0x1f0]
10013023c:     	tbz	w8, #0x6, 0x100130304 <_render.TerminalRenderer.drawPane+0x1e48>
100130240:     	fmov	s0, #0.50000000
100130244:     	fmul	s0, s9, s0
100130248:     	fadd	s8, s0, s11
10013024c:     	ldrb	w8, [x30, #0xd8]
100130250:     	cbz	w8, 0x100130274 <_render.TerminalRenderer.drawPane+0x1db8>
100130254:     	ldr	x9, [x30, #0xd0]
100130258:     	ldr	x8, [x30, #0xc0]
10013025c:     	cmp	x8, x9
100130260:     	b.lo	0x1001302c8 <_render.TerminalRenderer.drawPane+0x1e0c>
100130264:     	ldr	x8, [x30, #0xe0]
100130268:     	add	x8, x8, #0x1
10013026c:     	str	x8, [x30, #0xe0]
100130270:     	b	0x100130304 <_render.TerminalRenderer.drawPane+0x1e48>
100130274:     	ldur	q0, [x30, #0xa8]
100130278:     	stur	q0, [x29, #-0xb0]
10013027c:     	ldp	x8, x9, [x30, #0xc0]
100130280:     	cmp	x9, x8
100130284:     	b.hi	0x1001302c8 <_render.TerminalRenderer.drawPane+0x1e0c>
100130288:     	mov	x21, x16
10013028c:     	add	x8, x8, #0x1
100130290:     	lsr	x9, x8, #1
100130294:     	add	x9, x9, #0x1
100130298:     	adds	x8, x8, x9
10013029c:     	csinv	x2, x8, xzr, lo
1001302a0:     	add	x0, x30, #0xb8
1001302a4:     	sub	x1, x29, #0xb0
1001302a8:     	mov	x20, x30
1001302ac:     	bl	0x1001aece0 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
1001302b0:     	ands	w0, w0, #0xffff
1001302b4:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
1001302b8:     	ldr	x8, [x20, #0xc0]
1001302bc:     	mov	x30, x20
1001302c0:     	mov	x16, x21
1001302c4:     	ldr	q5, [sp, #0x200]
1001302c8:     	add	x9, x8, #0x1
1001302cc:     	str	x9, [x30, #0xc0]
1001302d0:     	ldr	x9, [x30, #0xb8]
1001302d4:     	mov	w10, #0x50              ; =80
1001302d8:     	madd	x8, x8, x10, x9
1001302dc:     	stp	s15, s8, [x8]
1001302e0:     	str	s14, [x8, #0x8]
1001302e4:     	ldr	q0, [sp, #0x150]
1001302e8:     	stur	q0, [x8, #0xc]
1001302ec:     	mov	w9, #0x3a000000         ; =973078528
1001302f0:     	str	w9, [x8, #0x1c]
1001302f4:     	stp	s5, s12, [x8, #0x20]
1001302f8:     	stp	s10, s13, [x8, #0x28]
1001302fc:     	movi.2d	v0, #0000000000000000
100130300:     	stp	q0, q0, [x8, #0x30]
100130304:     	ldp	x21, x24, [x30, #0xb8]
100130308:     	add	x8, x26, x26, lsl #2
10013030c:     	lsl	x8, x8, #4
100130310:     	ldr	x9, [sp, #0x230]
100130314:     	add	x20, x9, x8
100130318:     	mov	w9, #0x6e0              ; =1760
10013031c:     	madd	x22, x26, x9, x16
100130320:     	cmp	x24, #0x2
100130324:     	mov	w9, #0x2                ; =2
100130328:     	csel	x25, x24, x9, lo
10013032c:     	ldp	q0, q1, [x21]
100130330:     	ldp	q2, q3, [x21, #0x20]
100130334:     	ldr	q4, [x21, #0x40]
100130338:     	stp	q3, q4, [x20, #0x30]
10013033c:     	stp	q1, q2, [x20, #0x10]
100130340:     	str	q0, [x20]
100130344:     	sub	w9, w25, #0x1
100130348:     	and	x10, x9, #0x3
10013034c:     	lsl	x2, x10, #4
100130350:     	bfi	x2, x9, #6, #2
100130354:     	ldr	x9, [sp, #0x210]
100130358:     	add	x0, x9, x8
10013035c:     	add	x1, x21, #0x50
100130360:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
100130364:     	sub	x8, x24, x25
100130368:     	mov	w9, #0x50               ; =80
10013036c:     	madd	x1, x25, x9, x21
100130370:     	add	x8, x8, x8, lsl #2
100130374:     	lsl	x2, x8, #4
100130378:     	mov	x0, x22
10013037c:     	ldr	x22, [sp, #0x280]
100130380:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
100130384:     	strb	w24, [x23, #0x3c]
100130388:     	str	xzr, [x23]
10013038c:     	stp	s15, s11, [x23, #0x8]
100130390:     	stp	s14, s9, [x23, #0x10]
100130394:     	ldp	q1, q0, [sp, #0x240]
100130398:     	stur	q1, [x23, #0x18]
10013039c:     	stur	q0, [x23, #0x28]
1001303a0:     	mov	w8, #0x1                ; =1
1001303a4:     	strb	w8, [x23, #0x38]
1001303a8:     	ldr	s0, [x22, #0x1ac]
1001303ac:     	ldr	s1, [x20, #0x20]
1001303b0:     	fcmp	s1, s0
1001303b4:     	b.ne	0x1001303e0 <_render.TerminalRenderer.drawPane+0x1f24>
1001303b8:     	ldr	s0, [x22, #0x1b0]
1001303bc:     	ldr	s1, [x20, #0x24]
1001303c0:     	fcmp	s1, s0
1001303c4:     	ldr	x0, [sp, #0x1b0]
1001303c8:     	b.ne	0x1001303e4 <_render.TerminalRenderer.drawPane+0x1f28>
1001303cc:     	ldr	s0, [x22, #0x1b4]
1001303d0:     	ldr	s1, [x20, #0x28]
1001303d4:     	fcmp	s1, s0
1001303d8:     	cset	w8, ne
1001303dc:     	b	0x1001303e4 <_render.TerminalRenderer.drawPane+0x1f28>
1001303e0:     	ldr	x0, [sp, #0x1b0]
1001303e4:     	strb	w8, [x23, #0x39]
1001303e8:     	ldr	x30, [sp, #0x298]
1001303ec:     	ldr	x8, [x30, #0x10]
1001303f0:     	add	x8, x8, #0x1
1001303f4:     	str	x8, [x30, #0x10]
1001303f8:     	add	x27, x27, #0x1
1001303fc:     	cmp	x0, x27
100130400:     	ldr	x28, [sp, #0x148]
100130404:     	b.ne	0x10012f6e8 <_render.TerminalRenderer.drawPane+0x122c>
100130408:     	b	0x1001314e4 <_render.TerminalRenderer.drawPane+0x3028>
10013040c:     	mov	w9, #0x1                ; =1
100130410:     	str	wzr, [sp, #0x240]
100130414:     	and	x8, x9, #0xffff
100130418:     	str	x8, [sp, #0x1b0]
10013041c:     	tst	w9, #0xffff
100130420:     	ldr	x10, [sp, #0x118]
100130424:     	b.eq	0x10013150c <_render.TerminalRenderer.drawPane+0x3050>
100130428:     	str	x9, [sp, #0x100]
10013042c:     	mov	x25, #0x0               ; =0
100130430:     	ldr	x8, [sp, #0xe8]
100130434:     	add	x27, x8, x10, lsl #5
100130438:     	ldr	x8, [sp, #0xa0]
10013043c:     	add	x8, x8, x10
100130440:     	str	x8, [sp, #0x230]
100130444:     	ldp	x9, x8, [sp, #0x90]
100130448:     	add	x8, x8, x10
10013044c:     	str	x8, [sp, #0x210]
100130450:     	mov	w8, #0x6e0              ; =1760
100130454:     	umaddl	x20, w10, w8, x9
100130458:     	add	x8, x10, x10, lsl #2
10013045c:     	lsl	x8, x8, #4
100130460:     	ldp	x11, x9, [sp, #0xa8]
100130464:     	add	x16, x11, x8
100130468:     	add	x28, x9, x8
10013046c:     	ldr	x8, [sp, #0x88]
100130470:     	add	x17, x8, x10, lsl #6
100130474:     	mov	x24, x10
100130478:     	ldr	x26, [sp, #0x1b0]
10013047c:     	str	x10, [sp, #0x118]
100130480:     	b	0x1001304b0 <_render.TerminalRenderer.drawPane+0x1ff4>
100130484:     	ldr	x8, [x30, #0xa0]
100130488:     	add	x8, x8, #0x1
10013048c:     	str	x8, [x30, #0xa0]
100130490:     	add	x25, x25, #0x1
100130494:     	add	x27, x27, #0x20
100130498:     	add	x20, x20, #0x6e0
10013049c:     	add	x16, x16, #0x50
1001304a0:     	add	x28, x28, #0x50
1001304a4:     	add	x17, x17, #0x40
1001304a8:     	cmp	x26, x25
1001304ac:     	b.eq	0x10012f4a4 <_render.TerminalRenderer.drawPane+0xfe8>
1001304b0:     	ldr	x8, [sp, #0x2b8]
1001304b4:     	add	x1, x28, x8
1001304b8:     	ldr	w8, [sp, #0x240]
1001304bc:     	tbnz	w8, #0x0, 0x1001311e8 <_render.TerminalRenderer.drawPane+0x2d2c>
1001304c0:     	add	x8, x24, x25
1001304c4:     	ldrb	w10, [x7, #0x40]
1001304c8:     	ldr	x9, [x7]
1001304cc:     	mov	x13, x27
1001304d0:     	cbz	w10, 0x1001305bc <_render.TerminalRenderer.drawPane+0x2100>
1001304d4:     	ldrb	w10, [x7, #0x38]
1001304d8:     	mov	x13, x27
1001304dc:     	cbz	w10, 0x1001305bc <_render.TerminalRenderer.drawPane+0x2100>
1001304e0:     	ldr	w13, [x7, #0x28]
1001304e4:     	ldr	x10, [x7, #0x30]
1001304e8:     	ldrb	w12, [x7, #0x3d]
1001304ec:     	ldr	w11, [x9, #0xfc]
1001304f0:     	ldr	w14, [sp, #0x1a0]
1001304f4:     	add	w11, w11, w14
1001304f8:     	tbz	w12, #0x0, 0x100130534 <_render.TerminalRenderer.drawPane+0x2078>
1001304fc:     	cmp	w10, w13
100130500:     	csel	w12, w10, w13, lo
100130504:     	csel	w10, w10, w13, hi
100130508:     	cmp	w11, w12
10013050c:     	ccmp	w11, w10, #0x2, hs
100130510:     	mov	x13, x27
100130514:     	b.hi	0x1001305bc <_render.TerminalRenderer.drawPane+0x2100>
100130518:     	ldp	q0, q1, [x27]
10013051c:     	stp	q0, q1, [sp, #0x3d0]
100130520:     	ldrh	w10, [sp, #0x3d0]
100130524:     	eor	w10, w10, #0x10
100130528:     	strh	w10, [sp, #0x3d0]
10013052c:     	add	x13, sp, #0x3d0
100130530:     	b	0x1001305bc <_render.TerminalRenderer.drawPane+0x2100>
100130534:     	ldr	w12, [x7, #0x2c]
100130538:     	lsr	x15, x10, #32
10013053c:     	cmp	w13, w10
100130540:     	b.lo	0x100130558 <_render.TerminalRenderer.drawPane+0x209c>
100130544:     	cmp	w13, w10
100130548:     	b.ne	0x100130574 <_render.TerminalRenderer.drawPane+0x20b8>
10013054c:     	and	w14, w12, #0xffff
100130550:     	cmp	w14, w15, uxth
100130554:     	b.hs	0x100130574 <_render.TerminalRenderer.drawPane+0x20b8>
100130558:     	mov	x14, x12
10013055c:     	mov	x12, x15
100130560:     	mov	x15, x13
100130564:     	mov	x13, x27
100130568:     	cmp	w11, w15
10013056c:     	b.hs	0x10013058c <_render.TerminalRenderer.drawPane+0x20d0>
100130570:     	b	0x1001305bc <_render.TerminalRenderer.drawPane+0x2100>
100130574:     	mov	x14, x15
100130578:     	mov	x15, x10
10013057c:     	mov	x10, x13
100130580:     	mov	x13, x27
100130584:     	cmp	w11, w15
100130588:     	b.lo	0x1001305bc <_render.TerminalRenderer.drawPane+0x2100>
10013058c:     	and	w13, w8, #0xffff
100130590:     	cmp	w13, w14, uxth
100130594:     	ccmp	w11, w15, #0x0, lo
100130598:     	ccmp	w10, w11, #0x0, ne
10013059c:     	mov	x13, x27
1001305a0:     	b.lo	0x1001305bc <_render.TerminalRenderer.drawPane+0x2100>
1001305a4:     	cmp	w10, w11
1001305a8:     	b.ne	0x100130518 <_render.TerminalRenderer.drawPane+0x205c>
1001305ac:     	and	w10, w8, #0xffff
1001305b0:     	cmp	w10, w12, uxth
1001305b4:     	mov	x13, x27
1001305b8:     	b.ls	0x100130518 <_render.TerminalRenderer.drawPane+0x205c>
1001305bc:     	ldp	q3, q4, [x13]
1001305c0:     	umov.b	w10, v4[15]
1001305c4:     	ldrh	w11, [x7, #0x18]
1001305c8:     	ldrh	w12, [x7, #0x1a]
1001305cc:     	add	w11, w11, w8, uxth
1001305d0:     	ldr	x13, [sp, #0x1c8]
1001305d4:     	add	w12, w12, w13, uxth
1001305d8:     	tst	w10, #0xfe
1001305dc:     	csinc	w10, w10, wzr, ne
1001305e0:     	ldrh	w13, [x7, #0x1c]
1001305e4:     	ldrh	w9, [x9, #0x50]
1001305e8:     	cmp	w13, w9
1001305ec:     	csel	w9, w13, w9, lo
1001305f0:     	sub	w8, w9, w8
1001305f4:     	and	w8, w8, #0xffff
1001305f8:     	cmp	w10, w8
1001305fc:     	csel	w9, w10, w8, lo
100130600:     	ldrh	w8, [x22, #0x4]
100130604:     	ldrh	w10, [x22, #0x6]
100130608:     	ldr	x14, [sp, #0x260]
10013060c:     	ldp	w14, w13, [x14]
100130610:     	madd	w11, w8, w11, w14
100130614:     	ucvtf	s9, w11
100130618:     	madd	w11, w10, w12, w13
10013061c:     	ucvtf	s11, w11
100130620:     	mul	w9, w9, w8
100130624:     	ucvtf	s0, w9
100130628:     	str	s0, [sp, #0x250]
10013062c:     	ucvtf	s15, w10
100130630:     	ldrb	w9, [x17, #0x38]
100130634:     	cmp	w9, #0x1
100130638:     	b.ne	0x100130698 <_render.TerminalRenderer.drawPane+0x21dc>
10013063c:     	ldr	s0, [x17, #0x8]
100130640:     	fcmp	s0, s9
100130644:     	b.ne	0x100130698 <_render.TerminalRenderer.drawPane+0x21dc>
100130648:     	ldr	s0, [x17, #0xc]
10013064c:     	fcmp	s0, s11
100130650:     	b.ne	0x100130698 <_render.TerminalRenderer.drawPane+0x21dc>
100130654:     	ldr	s0, [x17, #0x10]
100130658:     	ldr	s1, [sp, #0x250]
10013065c:     	fcmp	s0, s1
100130660:     	b.ne	0x100130698 <_render.TerminalRenderer.drawPane+0x21dc>
100130664:     	ldr	s0, [x17, #0x14]
100130668:     	fcmp	s0, s15
10013066c:     	b.ne	0x100130698 <_render.TerminalRenderer.drawPane+0x21dc>
100130670:     	ldur	q0, [x17, #0x18]
100130674:     	ldur	q1, [x17, #0x28]
100130678:     	eor.16b	v0, v0, v3
10013067c:     	eor.16b	v1, v1, v4
100130680:     	orr.16b	v0, v1, v0
100130684:     	umaxv.16b	b0, v0
100130688:     	fmov	w9, s0
10013068c:     	cbnz	w9, 0x100130698 <_render.TerminalRenderer.drawPane+0x21dc>
100130690:     	ldr	x9, [x17]
100130694:     	cbz	x9, 0x1001311e8 <_render.TerminalRenderer.drawPane+0x2d2c>
100130698:     	stp	q3, q4, [sp, #0x3f0]
10013069c:     	fmov	x9, d3
1001306a0:     	str	xzr, [x30, #0xc0]
1001306a4:     	tbnz	w9, #0x4, 0x100130740 <_render.TerminalRenderer.drawPane+0x2284>
1001306a8:     	ldr	x9, [sp, #0x228]
1001306ac:     	ldr	q0, [x9]
1001306b0:     	str	q0, [sp, #0x420]
1001306b4:     	mov	b0, v3[8]
1001306b8:     	mov.b	v0[4], v3[9]
1001306bc:     	mov	b1, v3[6]
1001306c0:     	mov.b	v1[4], v3[7]
1001306c4:     	add	x9, sp, #0x420
1001306c8:     	fmov	w10, s1
1001306cc:     	and	w10, w10, #0xff
1001306d0:     	cmp	w10, #0x2
1001306d4:     	stp	q4, q3, [sp, #0x1f0]
1001306d8:     	b.eq	0x100130778 <_render.TerminalRenderer.drawPane+0x22bc>
1001306dc:     	cmp	w10, #0x1
1001306e0:     	b.ne	0x1001307ac <_render.TerminalRenderer.drawPane+0x22f0>
1001306e4:     	mov.s	w9, v1[1]
1001306e8:     	and	w10, w9, #0xff
1001306ec:     	cmp	w10, #0x10
1001306f0:     	b.hs	0x1001307d8 <_render.TerminalRenderer.drawPane+0x231c>
1001306f4:     	and	x10, x9, #0xff
1001306f8:     	add	x9, x10, w9, uxtb #1
1001306fc:     	ldr	x10, [sp, #0x1c0]
100130700:     	add	x9, x10, x9
100130704:     	ldr	b0, [x9]
100130708:     	ucvtf	s0, s0
10013070c:     	mov	w10, #0x437f0000        ; =1132396544
100130710:     	fmov	s1, w10
100130714:     	fdiv	s5, s0, s1
100130718:     	ldr	b0, [x9, #0x1]
10013071c:     	ucvtf	s0, s0
100130720:     	fdiv	s0, s0, s1
100130724:     	str	s5, [sp, #0x2300]
100130728:     	str	s0, [sp, #0x2304]
10013072c:     	ldr	b0, [x9, #0x2]
100130730:     	ucvtf	s0, s0
100130734:     	fdiv	s0, s0, s1
100130738:     	str	s0, [sp, #0x2308]
10013073c:     	b	0x100130970 <_render.TerminalRenderer.drawPane+0x24b4>
100130740:     	ldr	x10, [sp, #0x290]
100130744:     	add	x9, x10, #0x10, lsl #12 ; =0x10000
100130748:     	ldr	q0, [x9, #0x6ba0]
10013074c:     	str	q0, [sp, #0x410]
100130750:     	mov	b0, v3[4]
100130754:     	mov.b	v0[4], v3[5]
100130758:     	mov	b1, v3[2]
10013075c:     	mov.b	v1[4], v3[3]
100130760:     	add	x9, sp, #0x410
100130764:     	fmov	w10, s1
100130768:     	and	w10, w10, #0xff
10013076c:     	cmp	w10, #0x2
100130770:     	stp	q4, q3, [sp, #0x1f0]
100130774:     	b.ne	0x1001306dc <_render.TerminalRenderer.drawPane+0x2220>
100130778:     	mov.s	w9, v1[1]
10013077c:     	and	w9, w9, #0xff
100130780:     	ucvtf	s1, w9
100130784:     	mov	w9, #0x437f0000         ; =1132396544
100130788:     	fmov	s2, w9
10013078c:     	fdiv	s5, s1, s2
100130790:     	str	s5, [sp, #0x2300]
100130794:     	movi	d1, #0x0000ff000000ff
100130798:     	and.8b	v0, v0, v1
10013079c:     	ucvtf.2s	v0, v0
1001307a0:     	ldr	d1, [sp, #0x190]
1001307a4:     	fdiv.2s	v0, v0, v1
1001307a8:     	b	0x100130964 <_render.TerminalRenderer.drawPane+0x24a8>
1001307ac:     	ldr	s5, [x9]
1001307b0:     	ldp	s13, s10, [x9, #0x4]
1001307b4:     	ldr	s8, [x9, #0xc]
1001307b8:     	ucvtf	s12, w8
1001307bc:     	ldrb	w8, [x30, #0xd8]
1001307c0:     	cbnz	w8, 0x100130994 <_render.TerminalRenderer.drawPane+0x24d8>
1001307c4:     	ldr	x8, [x30, #0xc8]
1001307c8:     	cbz	x8, 0x100130874 <_render.TerminalRenderer.drawPane+0x23b8>
1001307cc:     	mov	x8, #0x0                ; =0
1001307d0:     	ldur	x22, [x30, #0xb8]
1001307d4:     	b	0x1001308fc <_render.TerminalRenderer.drawPane+0x2440>
1001307d8:     	cmp	w10, #0xe7
1001307dc:     	b.hi	0x10013093c <_render.TerminalRenderer.drawPane+0x2480>
1001307e0:     	sub	w9, w9, #0x10
1001307e4:     	and	w10, w9, #0xff
1001307e8:     	mov	w11, #0x39              ; =57
1001307ec:     	mul	w11, w10, w11
1001307f0:     	lsr	w11, w11, #11
1001307f4:     	mov	w12, #0x28              ; =40
1001307f8:     	mov	w13, #0x37              ; =55
1001307fc:     	madd	w11, w11, w12, w13
100130800:     	cmp	w10, #0x24
100130804:     	csel	w11, wzr, w11, lo
100130808:     	and	w11, w11, #0xff
10013080c:     	mov	w12, #0xab              ; =171
100130810:     	mul	w10, w10, w12
100130814:     	lsr	w10, w10, #10
100130818:     	ucvtf	s0, w11
10013081c:     	mov	w11, #0x437f0000        ; =1132396544
100130820:     	fmov	s1, w11
100130824:     	fmov	s2, w10
100130828:     	mov.s	v2[1], w9
10013082c:     	fdiv	s5, s0, s1
100130830:     	movi	d0, #0x0000ff000000ff
100130834:     	and.8b	v0, v2, v0
100130838:     	ldr	d1, [sp, #0x110]
10013083c:     	umull.2d	v1, v0, v1
100130840:     	shrn.2s	v1, v1, #0x20
100130844:     	movi.2s	v2, #0x6
100130848:     	mls.2s	v0, v1, v2
10013084c:     	movi.2s	v1, #0x37
100130850:     	movi.2s	v2, #0x28
100130854:     	mla.2s	v1, v0, v2
100130858:     	cmeq.2s	v0, v0, #0
10013085c:     	bic.8b	v0, v1, v0
100130860:     	bic.2s	v0, #0x3, lsl #8
100130864:     	ucvtf.2s	v0, v0
100130868:     	ldr	d1, [sp, #0x190]
10013086c:     	fdiv.2s	v0, v0, v1
100130870:     	b	0x100130960 <_render.TerminalRenderer.drawPane+0x24a4>
100130874:     	ldp	x0, x8, [x30, #0xa8]
100130878:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
10013087c:     	add	x9, x9, #0x300
100130880:     	strb	wzr, [x9]
100130884:     	tbnz	wzr, #0x0, 0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
100130888:     	str	q5, [sp, #0x1e0]
10013088c:     	mov	x26, x24
100130890:     	mov	x24, x1
100130894:     	mov	x23, x17
100130898:     	mov	x19, x16
10013089c:     	ldr	x8, [x8]
1001308a0:     	mov	w1, #0xa0               ; =160
1001308a4:     	mov	w2, #0x2                ; =2
1001308a8:     	ldr	x3, [sp, #0x198]
1001308ac:     	blr	x8
1001308b0:     	cbz	x0, 0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
1001308b4:     	mov	x22, x0
1001308b8:     	mov	x21, x20
1001308bc:     	ldr	x20, [sp, #0x298]
1001308c0:     	ldp	x1, x8, [x20, #0xb8]
1001308c4:     	add	x8, x8, x8, lsl #2
1001308c8:     	lsl	x2, x8, #4
1001308cc:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
1001308d0:     	mov	x30, x20
1001308d4:     	mov	x20, x21
1001308d8:     	ldr	x8, [x30, #0xc0]
1001308dc:     	str	x22, [x30, #0xb8]
1001308e0:     	mov	w9, #0x2                ; =2
1001308e4:     	str	x9, [x30, #0xc8]
1001308e8:     	mov	x16, x19
1001308ec:     	mov	x17, x23
1001308f0:     	mov	x1, x24
1001308f4:     	mov	x24, x26
1001308f8:     	ldr	q5, [sp, #0x1e0]
1001308fc:     	add	x9, x8, #0x1
100130900:     	str	x9, [x30, #0xc0]
100130904:     	mov	w9, #0x50               ; =80
100130908:     	madd	x8, x8, x9, x22
10013090c:     	stp	s9, s11, [x8]
100130910:     	stp	s12, s15, [x8, #0x8]
100130914:     	movi.4s	v0, #0x3a, lsl #24
100130918:     	str	q0, [x8, #0x10]
10013091c:     	stp	s5, s13, [x8, #0x20]
100130920:     	stp	s10, s8, [x8, #0x28]
100130924:     	movi.2d	v0, #0000000000000000
100130928:     	stp	q0, q0, [x8, #0x30]
10013092c:     	ldr	x22, [sp, #0x280]
100130930:     	ldrb	w8, [sp, #0x40f]
100130934:     	cbnz	w8, 0x1001309e8 <_render.TerminalRenderer.drawPane+0x252c>
100130938:     	b	0x1001310ac <_render.TerminalRenderer.drawPane+0x2bf0>
10013093c:     	mov	w10, #0xa               ; =10
100130940:     	mov	w11, #-0x8              ; =-8
100130944:     	madd	w9, w9, w10, w11
100130948:     	and	w9, w9, #0xfe
10013094c:     	ucvtf	s0, w9
100130950:     	mov	w9, #0x437f0000         ; =1132396544
100130954:     	fmov	s1, w9
100130958:     	fdiv	s5, s0, s1
10013095c:     	dup.2s	v0, v5[0]
100130960:     	str	s5, [sp, #0x2300]
100130964:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
100130968:     	add	x9, x9, #0x300
10013096c:     	stur	d0, [x9, #0x4]
100130970:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
100130974:     	add	x9, x9, #0x300
100130978:     	mov	w10, #0x3f800000        ; =1065353216
10013097c:     	str	w10, [x9, #0xc]
100130980:     	ldp	s13, s10, [x9, #0x4]
100130984:     	ldr	s8, [x9, #0xc]
100130988:     	ucvtf	s12, w8
10013098c:     	ldrb	w8, [x30, #0xd8]
100130990:     	cbz	w8, 0x1001307c4 <_render.TerminalRenderer.drawPane+0x2308>
100130994:     	ldr	x8, [x30, #0xd0]
100130998:     	cbz	x8, 0x1001309d4 <_render.TerminalRenderer.drawPane+0x2518>
10013099c:     	mov	w8, #0x1                ; =1
1001309a0:     	str	x8, [x30, #0xc0]
1001309a4:     	ldr	x8, [x30, #0xb8]
1001309a8:     	stp	s9, s11, [x8]
1001309ac:     	stp	s12, s15, [x8, #0x8]
1001309b0:     	movi.4s	v0, #0x3a, lsl #24
1001309b4:     	str	q0, [x8, #0x10]
1001309b8:     	stp	s5, s13, [x8, #0x20]
1001309bc:     	stp	s10, s8, [x8, #0x28]
1001309c0:     	movi.2d	v0, #0000000000000000
1001309c4:     	stp	q0, q0, [x8, #0x30]
1001309c8:     	ldrb	w8, [sp, #0x40f]
1001309cc:     	cbnz	w8, 0x1001309e8 <_render.TerminalRenderer.drawPane+0x252c>
1001309d0:     	b	0x1001310ac <_render.TerminalRenderer.drawPane+0x2bf0>
1001309d4:     	ldr	x8, [x30, #0xe0]
1001309d8:     	add	x8, x8, #0x1
1001309dc:     	str	x8, [x30, #0xe0]
1001309e0:     	ldrb	w8, [sp, #0x40f]
1001309e4:     	cbz	w8, 0x1001310ac <_render.TerminalRenderer.drawPane+0x2bf0>
1001309e8:     	ldrh	w8, [sp, #0x3f0]
1001309ec:     	tbnz	w8, #0x5, 0x1001310ac <_render.TerminalRenderer.drawPane+0x2bf0>
1001309f0:     	tbnz	w8, #0x4, 0x100130a74 <_render.TerminalRenderer.drawPane+0x25b8>
1001309f4:     	ldrb	w11, [sp, #0x3f2]
1001309f8:     	ldrb	w10, [sp, #0x3f3]
1001309fc:     	ldrb	w12, [sp, #0x3f4]
100130a00:     	ldrb	w13, [sp, #0x3f5]
100130a04:     	ldr	x14, [sp, #0x290]
100130a08:     	add	x9, x14, #0x10, lsl #12 ; =0x10000
100130a0c:     	ldr	q0, [x9, #0x6ba0]
100130a10:     	str	q0, [sp, #0x440]
100130a14:     	add	x9, sp, #0x440
100130a18:     	cmp	w11, #0x2
100130a1c:     	b.eq	0x100130a9c <_render.TerminalRenderer.drawPane+0x25e0>
100130a20:     	cmp	w11, #0x1
100130a24:     	b.ne	0x100130acc <_render.TerminalRenderer.drawPane+0x2610>
100130a28:     	subs	w9, w10, #0x10
100130a2c:     	b.hs	0x100130adc <_render.TerminalRenderer.drawPane+0x2620>
100130a30:     	mov	w9, w10
100130a34:     	add	x9, x9, w10, uxtw #1
100130a38:     	ldr	x10, [sp, #0x1c0]
100130a3c:     	add	x9, x10, x9
100130a40:     	ldr	b0, [x9]
100130a44:     	ucvtf	s0, s0
100130a48:     	mov	w10, #0x437f0000        ; =1132396544
100130a4c:     	fmov	s1, w10
100130a50:     	fdiv	s4, s0, s1
100130a54:     	ldr	b0, [x9, #0x1]
100130a58:     	ucvtf	s0, s0
100130a5c:     	fdiv	s0, s0, s1
100130a60:     	str	s4, [sp, #0x2300]
100130a64:     	str	s0, [sp, #0x2304]
100130a68:     	ldr	b0, [x9, #0x2]
100130a6c:     	ucvtf	s0, s0
100130a70:     	b	0x100130ac0 <_render.TerminalRenderer.drawPane+0x2604>
100130a74:     	ldrb	w11, [sp, #0x3f6]
100130a78:     	ldrb	w10, [sp, #0x3f7]
100130a7c:     	ldrb	w12, [sp, #0x3f8]
100130a80:     	ldrb	w13, [sp, #0x3f9]
100130a84:     	ldr	x9, [sp, #0x228]
100130a88:     	ldr	q0, [x9]
100130a8c:     	str	q0, [sp, #0x430]
100130a90:     	add	x9, sp, #0x430
100130a94:     	cmp	w11, #0x2
100130a98:     	b.ne	0x100130a20 <_render.TerminalRenderer.drawPane+0x2564>
100130a9c:     	ucvtf	s0, w10
100130aa0:     	mov	w9, #0x437f0000         ; =1132396544
100130aa4:     	fmov	s1, w9
100130aa8:     	fdiv	s4, s0, s1
100130aac:     	ucvtf	s0, w12
100130ab0:     	fdiv	s0, s0, s1
100130ab4:     	str	s4, [sp, #0x2300]
100130ab8:     	str	s0, [sp, #0x2304]
100130abc:     	ucvtf	s0, w13
100130ac0:     	fdiv	s0, s0, s1
100130ac4:     	str	s0, [sp, #0x2308]
100130ac8:     	b	0x100130ba8 <_render.TerminalRenderer.drawPane+0x26ec>
100130acc:     	mov	x26, x1
100130ad0:     	mov	x23, x17
100130ad4:     	ldr	s4, [x9]
100130ad8:     	b	0x100130bc0 <_render.TerminalRenderer.drawPane+0x2704>
100130adc:     	cmp	w10, #0xe7
100130ae0:     	b.hi	0x100130b74 <_render.TerminalRenderer.drawPane+0x26b8>
100130ae4:     	and	w10, w9, #0xff
100130ae8:     	mov	w11, #0x39              ; =57
100130aec:     	mul	w11, w10, w11
100130af0:     	lsr	w11, w11, #11
100130af4:     	mov	w12, #0x28              ; =40
100130af8:     	mov	w13, #0x37              ; =55
100130afc:     	madd	w11, w11, w12, w13
100130b00:     	cmp	w9, #0x24
100130b04:     	csel	w11, wzr, w11, lo
100130b08:     	and	w11, w11, #0xff
100130b0c:     	mov	w12, #0xab              ; =171
100130b10:     	mul	w10, w10, w12
100130b14:     	lsr	w10, w10, #10
100130b18:     	ucvtf	s0, w11
100130b1c:     	mov	w11, #0x437f0000        ; =1132396544
100130b20:     	fmov	s1, w11
100130b24:     	fmov	s2, w10
100130b28:     	mov.s	v2[1], w9
100130b2c:     	fdiv	s4, s0, s1
100130b30:     	movi	d0, #0x0000ff000000ff
100130b34:     	and.8b	v0, v2, v0
100130b38:     	ldr	d1, [sp, #0x110]
100130b3c:     	umull.2d	v1, v0, v1
100130b40:     	shrn.2s	v1, v1, #0x20
100130b44:     	movi.2s	v2, #0x6
100130b48:     	mls.2s	v0, v1, v2
100130b4c:     	movi.2s	v1, #0x37
100130b50:     	movi.2s	v2, #0x28
100130b54:     	mla.2s	v1, v0, v2
100130b58:     	cmeq.2s	v0, v0, #0
100130b5c:     	bic.8b	v0, v1, v0
100130b60:     	bic.2s	v0, #0x3, lsl #8
100130b64:     	ucvtf.2s	v0, v0
100130b68:     	ldr	d1, [sp, #0x190]
100130b6c:     	fdiv.2s	v0, v0, v1
100130b70:     	b	0x100130b98 <_render.TerminalRenderer.drawPane+0x26dc>
100130b74:     	mov	w9, #0xa                ; =10
100130b78:     	mov	w11, #-0x8              ; =-8
100130b7c:     	madd	w9, w10, w9, w11
100130b80:     	and	w9, w9, #0xfe
100130b84:     	ucvtf	s0, w9
100130b88:     	mov	w9, #0x437f0000         ; =1132396544
100130b8c:     	fmov	s1, w9
100130b90:     	fdiv	s4, s0, s1
100130b94:     	dup.2s	v0, v4[0]
100130b98:     	str	s4, [sp, #0x2300]
100130b9c:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
100130ba0:     	add	x9, x9, #0x300
100130ba4:     	stur	d0, [x9, #0x4]
100130ba8:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
100130bac:     	add	x9, x9, #0x300
100130bb0:     	mov	x26, x1
100130bb4:     	mov	x23, x17
100130bb8:     	mov	w10, #0x3f800000        ; =1065353216
100130bbc:     	str	w10, [x9, #0xc]
100130bc0:     	ldp	s14, s10, [x9, #0x4]
100130bc4:     	ldr	s0, [x9, #0xc]
100130bc8:     	fmov	s1, #0.50000000
100130bcc:     	fmul	s1, s0, s1
100130bd0:     	tst	w8, #0x4
100130bd4:     	fcsel	s13, s0, s1, eq
100130bd8:     	ldrb	w10, [sp, #0x40e]
100130bdc:     	ldr	s0, [x22]
100130be0:     	ldrh	w9, [x22, #0x8]
100130be4:     	ldr	h2, [x22, #0x4]
100130be8:     	ldr	h1, [x22, #0x6]
100130bec:     	and	w11, w8, #0x1
100130bf0:     	strb	w11, [sp, #0x45e]
100130bf4:     	ubfx	w11, w8, #1, #1
100130bf8:     	strb	w11, [sp, #0x45d]
100130bfc:     	strb	wzr, [sp, #0x458]
100130c00:     	subs	x11, x10, #0x1
100130c04:     	str	q4, [sp, #0x1e0]
100130c08:     	b.ne	0x100130cd4 <_render.TerminalRenderer.drawPane+0x2818>
100130c0c:     	ldrb	w12, [sp, #0x3fe]
100130c10:     	cmp	w12, #0x20
100130c14:     	b.ne	0x100130cd4 <_render.TerminalRenderer.drawPane+0x2818>
100130c18:     	ldr	x12, [sp, #0x168]
100130c1c:     	ldrb	w12, [x12, x11]
100130c20:     	adrp	x13, 0x100687000 <___anon_33682+0x119f>
100130c24:     	add	x13, x13, #0xee4
100130c28:     	ldrb	w11, [x13, x11]
100130c2c:     	cmp	w12, w11
100130c30:     	b.ne	0x100130cd4 <_render.TerminalRenderer.drawPane+0x2818>
100130c34:     	tst	w8, #0x700
100130c38:     	mov	x17, x23
100130c3c:     	mov	x1, x26
100130c40:     	b.eq	0x100130d7c <_render.TerminalRenderer.drawPane+0x28c0>
100130c44:     	str	s13, [sp, #0x170]
100130c48:     	add	x8, sp, #0x32c
100130c4c:     	ldur	w8, [x8, #0xce]
100130c50:     	str	s10, [sp, #0x1d0]
100130c54:     	fmov	d8, d10
100130c58:     	fmov	d10, d14
100130c5c:     	fmov	d3, d4
100130c60:     	ands	w9, w8, #0xff
100130c64:     	b.eq	0x100130ebc <_render.TerminalRenderer.drawPane+0x2a00>
100130c68:     	cmp	w9, #0x1
100130c6c:     	b.ne	0x100130d84 <_render.TerminalRenderer.drawPane+0x28c8>
100130c70:     	ubfx	w9, w8, #8, #8
100130c74:     	cmp	w9, #0x10
100130c78:     	b.hs	0x100130dcc <_render.TerminalRenderer.drawPane+0x2910>
100130c7c:     	ubfx	x8, x8, #8, #4
100130c80:     	add	x8, x8, x8, lsl #1
100130c84:     	ldr	x9, [sp, #0x1c0]
100130c88:     	add	x8, x9, x8
100130c8c:     	ldr	b0, [x8]
100130c90:     	ucvtf	s0, s0
100130c94:     	mov	w9, #0x437f0000         ; =1132396544
100130c98:     	fmov	s1, w9
100130c9c:     	fdiv	s3, s0, s1
100130ca0:     	ldr	b0, [x8, #0x1]
100130ca4:     	ucvtf	s0, s0
100130ca8:     	fdiv	s0, s0, s1
100130cac:     	str	s0, [sp, #0x500]
100130cb0:     	ldr	b0, [x8, #0x2]
100130cb4:     	ucvtf	s0, s0
100130cb8:     	fdiv	s0, s0, s1
100130cbc:     	str	s0, [sp, #0xd00]
100130cc0:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100130cc4:     	add	x8, x8, #0x920
100130cc8:     	add	x10, sp, #0xd00
100130ccc:     	add	x9, sp, #0x500
100130cd0:     	b	0x100130ea8 <_render.TerminalRenderer.drawPane+0x29ec>
100130cd4:     	mov	x19, x16
100130cd8:     	fneg	s3, s0
100130cdc:     	ucvtf	s2, s2
100130ce0:     	ucvtf	s1, s1
100130ce4:     	ldr	x8, [sp, #0x168]
100130ce8:     	str	x8, [sp, #0x460]
100130cec:     	str	x10, [sp, #0x468]
100130cf0:     	fadd	s0, s0, s11
100130cf4:     	str	s9, [sp, #0x470]
100130cf8:     	str	s0, [sp, #0x474]
100130cfc:     	str	s4, [sp, #0x478]
100130d00:     	str	s14, [sp, #0x47c]
100130d04:     	str	s10, [sp, #0x480]
100130d08:     	str	s13, [sp, #0x484]
100130d0c:     	str	wzr, [sp, #0x488]
100130d10:     	str	s3, [sp, #0x48c]
100130d14:     	str	s2, [sp, #0x490]
100130d18:     	str	s1, [sp, #0x494]
100130d1c:     	mov	w8, #0x1                ; =1
100130d20:     	strb	w8, [sp, #0x498]
100130d24:     	strh	w9, [sp, #0x49c]
100130d28:     	ldrb	w8, [sp, #0x45e]
100130d2c:     	strb	w8, [sp, #0x49e]
100130d30:     	ldrb	w8, [sp, #0x45d]
100130d34:     	strb	w8, [sp, #0x49f]
100130d38:     	ldrb	w8, [sp, #0x458]
100130d3c:     	strb	w8, [sp, #0x4a0]
100130d40:     	add	x0, sp, #0x4a8
100130d44:     	add	x2, sp, #0x460
100130d48:     	add	x3, x30, #0xa8
100130d4c:     	ldr	x1, [sp, #0x290]
100130d50:     	bl	0x100127dc8 <_text.GlyphAtlas.place>
100130d54:     	ldrh	w0, [sp, #0x4ac]
100130d58:     	cbnz	w0, 0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
100130d5c:     	ldrh	w8, [sp, #0x3f0]
100130d60:     	ldr	x30, [sp, #0x298]
100130d64:     	mov	x16, x19
100130d68:     	ldr	q4, [sp, #0x1e0]
100130d6c:     	tst	w8, #0x700
100130d70:     	mov	x17, x23
100130d74:     	mov	x1, x26
100130d78:     	b.ne	0x100130c44 <_render.TerminalRenderer.drawPane+0x2788>
100130d7c:     	tbnz	w8, #0x6, 0x100130fc8 <_render.TerminalRenderer.drawPane+0x2b0c>
100130d80:     	b	0x1001310ac <_render.TerminalRenderer.drawPane+0x2bf0>
100130d84:     	ubfx	w9, w8, #8, #8
100130d88:     	dup.2s	v0, w8
100130d8c:     	adrp	x8, 0x1001ff000 <__ZL18_hb_ucd_dm1_p2_map+0x16e>
100130d90:     	ldr	d1, [x8, #0x3d8]
100130d94:     	ushl.2s	v0, v0, v1
100130d98:     	ucvtf	s1, w9
100130d9c:     	mov	w8, #0x437f0000         ; =1132396544
100130da0:     	fmov	s2, w8
100130da4:     	fdiv	s3, s1, s2
100130da8:     	bic.2s	v0, #0xff, lsl #8
100130dac:     	ucvtf.2s	v0, v0
100130db0:     	ldr	d1, [sp, #0x190]
100130db4:     	fdiv.2s	v0, v0, v1
100130db8:     	str	d0, [sp, #0xf00]
100130dbc:     	add	x8, sp, #0x500
100130dc0:     	add	x9, sp, #0xf00
100130dc4:     	ldr	x10, [sp, #0xd0]
100130dc8:     	b	0x100130ea8 <_render.TerminalRenderer.drawPane+0x29ec>
100130dcc:     	ubfx	w9, w8, #8, #8
100130dd0:     	lsr	w8, w8, #8
100130dd4:     	cmp	w9, #0xe7
100130dd8:     	b.hi	0x100130e70 <_render.TerminalRenderer.drawPane+0x29b4>
100130ddc:     	sub	w8, w8, #0x10
100130de0:     	and	w9, w8, #0xff
100130de4:     	mov	w10, #0x39              ; =57
100130de8:     	mul	w10, w9, w10
100130dec:     	lsr	w10, w10, #11
100130df0:     	mov	w11, #0x28              ; =40
100130df4:     	mov	w12, #0x37              ; =55
100130df8:     	madd	w10, w10, w11, w12
100130dfc:     	cmp	w9, #0x24
100130e00:     	csel	w10, wzr, w10, lo
100130e04:     	and	w10, w10, #0xff
100130e08:     	mov	w11, #0xab              ; =171
100130e0c:     	mul	w9, w9, w11
100130e10:     	lsr	w9, w9, #10
100130e14:     	ucvtf	s0, w10
100130e18:     	mov	w10, #0x437f0000        ; =1132396544
100130e1c:     	fmov	s1, w10
100130e20:     	fmov	s2, w9
100130e24:     	mov.s	v2[1], w8
100130e28:     	fdiv	s3, s0, s1
100130e2c:     	movi	d0, #0x0000ff000000ff
100130e30:     	and.8b	v0, v2, v0
100130e34:     	ldr	d1, [sp, #0x110]
100130e38:     	umull.2d	v1, v0, v1
100130e3c:     	shrn.2s	v1, v1, #0x20
100130e40:     	movi.2s	v2, #0x6
100130e44:     	mls.2s	v0, v1, v2
100130e48:     	movi.2s	v1, #0x37
100130e4c:     	movi.2s	v2, #0x28
100130e50:     	mla.2s	v1, v0, v2
100130e54:     	cmeq.2s	v0, v0, #0
100130e58:     	bic.8b	v0, v1, v0
100130e5c:     	bic.2s	v0, #0x3, lsl #8
100130e60:     	ucvtf.2s	v0, v0
100130e64:     	ldr	d1, [sp, #0x190]
100130e68:     	fdiv.2s	v0, v0, v1
100130e6c:     	b	0x100130e94 <_render.TerminalRenderer.drawPane+0x29d8>
100130e70:     	mov	w9, #0xa                ; =10
100130e74:     	mov	w10, #-0x8              ; =-8
100130e78:     	madd	w8, w8, w9, w10
100130e7c:     	and	w8, w8, #0xfe
100130e80:     	ucvtf	s0, w8
100130e84:     	mov	w8, #0x437f0000         ; =1132396544
100130e88:     	fmov	s1, w8
100130e8c:     	fdiv	s3, s0, s1
100130e90:     	dup.2s	v0, v3[0]
100130e94:     	str	d0, [sp, #0x2300]
100130e98:     	add	x8, sp, #0x500
100130e9c:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
100130ea0:     	add	x9, x9, #0x300
100130ea4:     	ldr	x10, [sp, #0x70]
100130ea8:     	mov	w11, #0x3f800000        ; =1065353216
100130eac:     	str	w11, [x8]
100130eb0:     	ldr	s10, [x9]
100130eb4:     	fmov	s13, #1.00000000
100130eb8:     	ldr	s8, [x10]
100130ebc:     	fadd	s0, s15, s11
100130ec0:     	fmov	s1, #-2.00000000
100130ec4:     	fadd	s12, s0, s1
100130ec8:     	ldrb	w8, [x30, #0xd8]
100130ecc:     	cbz	w8, 0x100130f00 <_render.TerminalRenderer.drawPane+0x2a44>
100130ed0:     	ldr	x9, [x30, #0xd0]
100130ed4:     	ldr	x8, [x30, #0xc0]
100130ed8:     	cmp	x8, x9
100130edc:     	b.lo	0x100130f78 <_render.TerminalRenderer.drawPane+0x2abc>
100130ee0:     	ldr	x8, [x30, #0xe0]
100130ee4:     	add	x8, x8, #0x1
100130ee8:     	str	x8, [x30, #0xe0]
100130eec:     	ldrh	w8, [sp, #0x3f0]
100130ef0:     	ldr	s10, [sp, #0x1d0]
100130ef4:     	ldr	s13, [sp, #0x170]
100130ef8:     	tbnz	w8, #0x6, 0x100130fc8 <_render.TerminalRenderer.drawPane+0x2b0c>
100130efc:     	b	0x1001310ac <_render.TerminalRenderer.drawPane+0x2bf0>
100130f00:     	ldur	q0, [x30, #0xa8]
100130f04:     	str	q0, [sp, #0x2300]
100130f08:     	ldp	x8, x9, [x30, #0xc0]
100130f0c:     	cmp	x9, x8
100130f10:     	b.hi	0x100130f78 <_render.TerminalRenderer.drawPane+0x2abc>
100130f14:     	str	q3, [sp, #0xc0]
100130f18:     	mov	x23, x1
100130f1c:     	mov	x22, x17
100130f20:     	mov	x19, x16
100130f24:     	mov	x21, x20
100130f28:     	add	x8, x8, #0x1
100130f2c:     	lsr	x9, x8, #1
100130f30:     	add	x9, x9, #0x1
100130f34:     	adds	x8, x8, x9
100130f38:     	csinv	x2, x8, xzr, lo
100130f3c:     	add	x0, x30, #0xb8
100130f40:     	add	x1, sp, #0x2, lsl #12   ; =0x2000
100130f44:     	add	x1, x1, #0x300
100130f48:     	mov	x20, x30
100130f4c:     	bl	0x1001aece0 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
100130f50:     	ands	w0, w0, #0xffff
100130f54:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
100130f58:     	ldr	x8, [x20, #0xc0]
100130f5c:     	mov	x30, x20
100130f60:     	mov	x20, x21
100130f64:     	mov	x16, x19
100130f68:     	mov	x17, x22
100130f6c:     	mov	x1, x23
100130f70:     	ldr	q4, [sp, #0x1e0]
100130f74:     	ldr	q3, [sp, #0xc0]
100130f78:     	add	x9, x8, #0x1
100130f7c:     	str	x9, [x30, #0xc0]
100130f80:     	ldr	x9, [x30, #0xb8]
100130f84:     	mov	w10, #0x50              ; =80
100130f88:     	madd	x8, x8, x10, x9
100130f8c:     	stp	s9, s12, [x8]
100130f90:     	ldr	s0, [sp, #0x250]
100130f94:     	str	s0, [x8, #0x8]
100130f98:     	ldr	q0, [sp, #0x150]
100130f9c:     	stur	q0, [x8, #0xc]
100130fa0:     	mov	w9, #0x3a000000         ; =973078528
100130fa4:     	str	w9, [x8, #0x1c]
100130fa8:     	stp	s3, s10, [x8, #0x20]
100130fac:     	stp	s8, s13, [x8, #0x28]
100130fb0:     	movi.2d	v0, #0000000000000000
100130fb4:     	stp	q0, q0, [x8, #0x30]
100130fb8:     	ldrh	w8, [sp, #0x3f0]
100130fbc:     	ldr	s10, [sp, #0x1d0]
100130fc0:     	ldr	s13, [sp, #0x170]
100130fc4:     	tbz	w8, #0x6, 0x1001310ac <_render.TerminalRenderer.drawPane+0x2bf0>
100130fc8:     	fmov	s0, #0.50000000
100130fcc:     	fmul	s0, s15, s0
100130fd0:     	fadd	s8, s0, s11
100130fd4:     	ldrb	w8, [x30, #0xd8]
100130fd8:     	cbz	w8, 0x100130ffc <_render.TerminalRenderer.drawPane+0x2b40>
100130fdc:     	ldr	x9, [x30, #0xd0]
100130fe0:     	ldr	x8, [x30, #0xc0]
100130fe4:     	cmp	x8, x9
100130fe8:     	b.lo	0x10013106c <_render.TerminalRenderer.drawPane+0x2bb0>
100130fec:     	ldr	x8, [x30, #0xe0]
100130ff0:     	add	x8, x8, #0x1
100130ff4:     	str	x8, [x30, #0xe0]
100130ff8:     	b	0x1001310ac <_render.TerminalRenderer.drawPane+0x2bf0>
100130ffc:     	ldur	q0, [x30, #0xa8]
100131000:     	str	q0, [sp, #0x2300]
100131004:     	ldp	x8, x9, [x30, #0xc0]
100131008:     	cmp	x9, x8
10013100c:     	b.hi	0x10013106c <_render.TerminalRenderer.drawPane+0x2bb0>
100131010:     	mov	x23, x1
100131014:     	mov	x22, x17
100131018:     	mov	x19, x16
10013101c:     	mov	x21, x20
100131020:     	add	x8, x8, #0x1
100131024:     	lsr	x9, x8, #1
100131028:     	add	x9, x9, #0x1
10013102c:     	adds	x8, x8, x9
100131030:     	csinv	x2, x8, xzr, lo
100131034:     	add	x0, x30, #0xb8
100131038:     	add	x1, sp, #0x2, lsl #12   ; =0x2000
10013103c:     	add	x1, x1, #0x300
100131040:     	mov	x20, x30
100131044:     	bl	0x1001aece0 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
100131048:     	ands	w0, w0, #0xffff
10013104c:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
100131050:     	ldr	x8, [x20, #0xc0]
100131054:     	mov	x30, x20
100131058:     	mov	x20, x21
10013105c:     	mov	x16, x19
100131060:     	mov	x17, x22
100131064:     	mov	x1, x23
100131068:     	ldr	q4, [sp, #0x1e0]
10013106c:     	add	x9, x8, #0x1
100131070:     	str	x9, [x30, #0xc0]
100131074:     	ldr	x9, [x30, #0xb8]
100131078:     	mov	w10, #0x50              ; =80
10013107c:     	madd	x8, x8, x10, x9
100131080:     	stp	s9, s8, [x8]
100131084:     	ldr	s0, [sp, #0x250]
100131088:     	str	s0, [x8, #0x8]
10013108c:     	ldr	q0, [sp, #0x150]
100131090:     	stur	q0, [x8, #0xc]
100131094:     	mov	w9, #0x3a000000         ; =973078528
100131098:     	str	w9, [x8, #0x1c]
10013109c:     	stp	s4, s14, [x8, #0x20]
1001310a0:     	stp	s10, s13, [x8, #0x28]
1001310a4:     	movi.2d	v0, #0000000000000000
1001310a8:     	stp	q0, q0, [x8, #0x30]
1001310ac:     	str	x25, [sp, #0x1e0]
1001310b0:     	mov	x23, x27
1001310b4:     	mov	x26, x24
1001310b8:     	mov	x27, x20
1001310bc:     	ldp	x20, x21, [x30, #0xb8]
1001310c0:     	cmp	x21, #0x2
1001310c4:     	mov	w8, #0x2                ; =2
1001310c8:     	csel	x22, x21, x8, lo
1001310cc:     	ldp	q0, q1, [x20]
1001310d0:     	ldp	q2, q3, [x20, #0x20]
1001310d4:     	ldr	q4, [x20, #0x40]
1001310d8:     	stp	q3, q4, [x1, #0x30]
1001310dc:     	stp	q1, q2, [x1, #0x10]
1001310e0:     	str	x1, [sp, #0x1d0]
1001310e4:     	str	q0, [x1]
1001310e8:     	sub	w8, w22, #0x1
1001310ec:     	and	x9, x8, #0x3
1001310f0:     	lsl	x2, x9, #4
1001310f4:     	bfi	x2, x8, #6, #2
1001310f8:     	mov	x25, x28
1001310fc:     	ldr	x28, [sp, #0x2b8]
100131100:     	mov	x19, x16
100131104:     	add	x0, x16, x28
100131108:     	add	x1, x20, #0x50
10013110c:     	mov	x24, x17
100131110:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
100131114:     	sub	x8, x21, x22
100131118:     	mov	w9, #0x50               ; =80
10013111c:     	madd	x1, x22, x9, x20
100131120:     	mov	x20, x27
100131124:     	ldr	x22, [sp, #0x280]
100131128:     	add	x8, x8, x8, lsl #2
10013112c:     	lsl	x2, x8, #4
100131130:     	mov	x0, x27
100131134:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
100131138:     	mov	x17, x24
10013113c:     	strb	w21, [x24, #0x3c]
100131140:     	str	xzr, [x24]
100131144:     	stp	s9, s11, [x24, #0x8]
100131148:     	ldr	s0, [sp, #0x250]
10013114c:     	stp	s0, s15, [x24, #0x10]
100131150:     	ldp	q0, q1, [sp, #0x1f0]
100131154:     	stur	q1, [x24, #0x18]
100131158:     	stur	q0, [x24, #0x28]
10013115c:     	mov	w8, #0x1                ; =1
100131160:     	strb	w8, [x24, #0x38]
100131164:     	ldr	s0, [x22, #0x1ac]
100131168:     	add	x9, x25, x28
10013116c:     	mov	x28, x25
100131170:     	ldr	s1, [x9, #0x20]
100131174:     	fcmp	s1, s0
100131178:     	b.ne	0x1001311b8 <_render.TerminalRenderer.drawPane+0x2cfc>
10013117c:     	ldr	s0, [x22, #0x1b0]
100131180:     	ldr	s1, [x9, #0x24]
100131184:     	fcmp	s1, s0
100131188:     	ldr	x7, [sp, #0x278]
10013118c:     	mov	x24, x26
100131190:     	mov	x27, x23
100131194:     	ldr	x25, [sp, #0x1e0]
100131198:     	b.ne	0x1001311c8 <_render.TerminalRenderer.drawPane+0x2d0c>
10013119c:     	ldr	s0, [x22, #0x1b4]
1001311a0:     	ldr	x8, [sp, #0x2b8]
1001311a4:     	add	x8, x28, x8
1001311a8:     	ldr	s1, [x8, #0x28]
1001311ac:     	fcmp	s1, s0
1001311b0:     	cset	w8, ne
1001311b4:     	b	0x1001311c8 <_render.TerminalRenderer.drawPane+0x2d0c>
1001311b8:     	ldr	x7, [sp, #0x278]
1001311bc:     	mov	x24, x26
1001311c0:     	mov	x27, x23
1001311c4:     	ldr	x25, [sp, #0x1e0]
1001311c8:     	strb	w8, [x17, #0x39]
1001311cc:     	ldr	x30, [sp, #0x298]
1001311d0:     	ldr	x8, [x30, #0x10]
1001311d4:     	add	x8, x8, #0x1
1001311d8:     	str	x8, [x30, #0x10]
1001311dc:     	ldr	x26, [sp, #0x1b0]
1001311e0:     	mov	x16, x19
1001311e4:     	ldr	x1, [sp, #0x1d0]
1001311e8:     	ldr	x8, [sp, #0x210]
1001311ec:     	add	x8, x8, x25
1001311f0:     	ldr	w9, [sp, #0x2a0]
1001311f4:     	cmp	w9, #0x0
1001311f8:     	ccmp	x8, #0x0, #0x0, ne
1001311fc:     	cset	w8, eq
100131200:     	strb	w8, [x17, #0x3a]
100131204:     	ldr	x8, [sp, #0x230]
100131208:     	cmn	x8, x25
10013120c:     	cset	w8, eq
100131210:     	strb	w8, [x17, #0x3b]
100131214:     	ldrb	w8, [x17, #0x39]
100131218:     	tbz	w8, #0x0, 0x100130490 <_render.TerminalRenderer.drawPane+0x1fd4>
10013121c:     	ldp	q0, q1, [x1, #0x20]
100131220:     	str	q0, [sp, #0x4d0]
100131224:     	str	q1, [sp, #0x4e0]
100131228:     	ldr	q0, [x1, #0x40]
10013122c:     	str	q0, [sp, #0x4f0]
100131230:     	ldp	q1, q0, [x1]
100131234:     	str	q0, [sp, #0x4c0]
100131238:     	str	q1, [sp, #0x4b0]
10013123c:     	ldrb	w8, [x30, #0x98]
100131240:     	cbz	w8, 0x10013128c <_render.TerminalRenderer.drawPane+0x2dd0>
100131244:     	ldr	x9, [x30, #0x90]
100131248:     	ldr	x8, [x30, #0x80]
10013124c:     	cmp	x8, x9
100131250:     	b.hs	0x100130484 <_render.TerminalRenderer.drawPane+0x1fc8>
100131254:     	add	x9, x8, #0x1
100131258:     	str	x9, [x30, #0x80]
10013125c:     	ldr	x9, [x30, #0x78]
100131260:     	mov	w10, #0x50              ; =80
100131264:     	madd	x8, x8, x10, x9
100131268:     	ldr	q0, [sp, #0x4d0]
10013126c:     	ldr	q1, [sp, #0x4e0]
100131270:     	stp	q0, q1, [x8, #0x20]
100131274:     	ldr	q0, [sp, #0x4f0]
100131278:     	str	q0, [x8, #0x40]
10013127c:     	ldr	q0, [sp, #0x4c0]
100131280:     	ldr	q1, [sp, #0x4b0]
100131284:     	stp	q1, q0, [x8]
100131288:     	b	0x100130490 <_render.TerminalRenderer.drawPane+0x1fd4>
10013128c:     	mov	x23, x28
100131290:     	mov	x21, x20
100131294:     	ldp	x8, x20, [x30, #0x80]
100131298:     	ldr	x22, [x30, #0x78]
10013129c:     	cmp	x20, x8
1001312a0:     	b.ls	0x1001312b0 <_render.TerminalRenderer.drawPane+0x2df4>
1001312a4:     	ldr	x7, [sp, #0x278]
1001312a8:     	mov	x20, x21
1001312ac:     	b	0x100131444 <_render.TerminalRenderer.drawPane+0x2f88>
1001312b0:     	ldp	x0, x19, [x30, #0x68]
1001312b4:     	add	x8, x8, #0x1
1001312b8:     	lsr	x9, x8, #1
1001312bc:     	add	x9, x9, #0x1
1001312c0:     	adds	x8, x8, x9
1001312c4:     	csinv	x10, x8, xzr, lo
1001312c8:     	add	x28, x10, x10, lsl #2
1001312cc:     	str	x27, [sp, #0x120]
1001312d0:     	cbz	x20, 0x1001312f4 <_render.TerminalRenderer.drawPane+0x2e38>
1001312d4:     	mov	w8, #0x50               ; =80
1001312d8:     	umulh	x8, x10, x8
1001312dc:     	cmp	xzr, x8
1001312e0:     	cset	w8, ne
1001312e4:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
1001312e8:     	add	x9, x9, #0x300
1001312ec:     	strb	w8, [x9]
1001312f0:     	b.eq	0x100131304 <_render.TerminalRenderer.drawPane+0x2e48>
1001312f4:     	mov	x27, #0x0               ; =0
1001312f8:     	mov	x8, #0x0                ; =0
1001312fc:     	cbnz	x27, 0x100131428 <_render.TerminalRenderer.drawPane+0x2f6c>
100131300:     	b	0x10013137c <_render.TerminalRenderer.drawPane+0x2ec0>
100131304:     	str	x10, [sp, #0x200]
100131308:     	str	x17, [sp, #0x1f0]
10013130c:     	str	x16, [sp, #0x250]
100131310:     	lsl	x4, x28, #4
100131314:     	add	x8, x20, x20, lsl #2
100131318:     	lsl	x2, x8, #4
10013131c:     	str	x19, [sp, #0x1e0]
100131320:     	ldr	x8, [x19, #0x10]
100131324:     	mov	x19, x0
100131328:     	mov	x1, x22
10013132c:     	mov	w3, #0x2                ; =2
100131330:     	mov	x24, x4
100131334:     	ldr	x5, [sp, #0x198]
100131338:     	blr	x8
10013133c:     	mov	x27, x0
100131340:     	cbz	x0, 0x100131358 <_render.TerminalRenderer.drawPane+0x2e9c>
100131344:     	lsr	x8, x24, #4
100131348:     	mov	x9, #-0x3333333333333334 ; =-3689348814741910324
10013134c:     	movk	x9, #0xcccd
100131350:     	mul	x8, x8, x9
100131354:     	b	0x10013135c <_render.TerminalRenderer.drawPane+0x2ea0>
100131358:     	mov	x8, #0x0                ; =0
10013135c:     	ldr	x30, [sp, #0x298]
100131360:     	ldr	x16, [sp, #0x250]
100131364:     	ldr	x17, [sp, #0x1f0]
100131368:     	ldr	x24, [sp, #0x118]
10013136c:     	ldr	x10, [sp, #0x200]
100131370:     	mov	x0, x19
100131374:     	ldr	x19, [sp, #0x1e0]
100131378:     	cbnz	x27, 0x100131428 <_render.TerminalRenderer.drawPane+0x2f6c>
10013137c:     	mov	w8, #0x50               ; =80
100131380:     	umulh	x8, x10, x8
100131384:     	cmp	xzr, x8
100131388:     	cset	w8, ne
10013138c:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
100131390:     	add	x9, x9, #0x300
100131394:     	strb	w8, [x9]
100131398:     	b.ne	0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
10013139c:     	str	x10, [sp, #0x200]
1001313a0:     	str	x17, [sp, #0x1f0]
1001313a4:     	str	x16, [sp, #0x250]
1001313a8:     	lsl	x1, x28, #4
1001313ac:     	cbz	x1, 0x1001313d0 <_render.TerminalRenderer.drawPane+0x2f14>
1001313b0:     	ldr	x8, [x19]
1001313b4:     	mov	x24, x0
1001313b8:     	mov	w2, #0x2                ; =2
1001313bc:     	ldr	x3, [sp, #0x198]
1001313c0:     	blr	x8
1001313c4:     	mov	x27, x0
1001313c8:     	cbnz	x0, 0x1001313d8 <_render.TerminalRenderer.drawPane+0x2f1c>
1001313cc:     	b	0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
1001313d0:     	mov	x24, x0
1001313d4:     	mov	x27, #-0x4              ; =-4
1001313d8:     	ldr	x9, [sp, #0x298]
1001313dc:     	ldp	x1, x8, [x9, #0x78]
1001313e0:     	add	x8, x8, x8, lsl #2
1001313e4:     	lsl	x2, x8, #4
1001313e8:     	mov	x0, x27
1001313ec:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
1001313f0:     	cbz	x20, 0x100131414 <_render.TerminalRenderer.drawPane+0x2f58>
1001313f4:     	add	x8, x20, x20, lsl #2
1001313f8:     	lsl	x2, x8, #4
1001313fc:     	ldr	x8, [x19, #0x18]
100131400:     	mov	x0, x24
100131404:     	mov	x1, x22
100131408:     	mov	w3, #0x2                ; =2
10013140c:     	ldr	x4, [sp, #0x198]
100131410:     	blr	x8
100131414:     	ldr	x30, [sp, #0x298]
100131418:     	ldr	x16, [sp, #0x250]
10013141c:     	ldr	x17, [sp, #0x1f0]
100131420:     	ldr	x24, [sp, #0x118]
100131424:     	ldr	x8, [sp, #0x200]
100131428:     	str	x27, [x30, #0x78]
10013142c:     	str	x8, [x30, #0x88]
100131430:     	mov	x22, x27
100131434:     	ldr	x8, [x30, #0x80]
100131438:     	ldr	x7, [sp, #0x278]
10013143c:     	mov	x20, x21
100131440:     	ldr	x27, [sp, #0x120]
100131444:     	add	x9, x8, #0x1
100131448:     	str	x9, [x30, #0x80]
10013144c:     	mov	w9, #0x50               ; =80
100131450:     	madd	x8, x8, x9, x22
100131454:     	ldr	q0, [sp, #0x4b0]
100131458:     	str	q0, [x8]
10013145c:     	ldr	q0, [sp, #0x4c0]
100131460:     	ldr	q1, [sp, #0x4d0]
100131464:     	ldr	q2, [sp, #0x4e0]
100131468:     	ldr	q3, [sp, #0x4f0]
10013146c:     	stp	q2, q3, [x8, #0x30]
100131470:     	stp	q0, q1, [x8, #0x10]
100131474:     	ldr	x22, [sp, #0x280]
100131478:     	mov	x28, x23
10013147c:     	b	0x100130490 <_render.TerminalRenderer.drawPane+0x1fd4>
100131480:     	str	x10, [sp, #0x1e0]
100131484:     	mov	x24, #0x0               ; =0
100131488:     	mov	w19, #0x0               ; =0
10013148c:     	mov	x23, #0x0               ; =0
100131490:     	mov	w20, #0x1               ; =1
100131494:     	b	0x10012f630 <_render.TerminalRenderer.drawPane+0x1174>
100131498:     	ldr	x22, [sp, #0x3930]
10013149c:     	ldr	x21, [sp, #0x3938]
1001314a0:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
1001314a4:     	add	x8, x8, #0x900
1001314a8:     	ldrb	w26, [x8, #0x44]
1001314ac:     	ldr	w27, [sp, #0x3940]
1001314b0:     	add	x8, x19, x19, lsl #2
1001314b4:     	lsl	x2, x8, #2
1001314b8:     	add	x0, sp, #0xf00
1001314bc:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
1001314c0:     	add	x8, x21, x21, lsl #2
1001314c4:     	lsl	x2, x8, #2
1001314c8:     	add	x0, sp, #0x2, lsl #12   ; =0x2000
1001314cc:     	add	x0, x0, #0x300
1001314d0:     	mov	x1, x22
1001314d4:     	ldr	x22, [sp, #0x280]
1001314d8:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
1001314dc:     	ldr	x30, [sp, #0x298]
1001314e0:     	tbz	w20, #0x0, 0x100131524 <_render.TerminalRenderer.drawPane+0x3068>
1001314e4:     	mov	w8, #0x1                ; =1
1001314e8:     	str	w8, [sp, #0x240]
1001314ec:     	ldr	x7, [sp, #0x278]
1001314f0:     	add	x25, sp, #0x500
1001314f4:     	add	x26, sp, #0xd00
1001314f8:     	mov	w27, #0xffff            ; =65535
1001314fc:     	ldp	x9, x23, [sp, #0x100]
100131500:     	tst	w9, #0xffff
100131504:     	ldr	x10, [sp, #0x118]
100131508:     	b.ne	0x100130428 <_render.TerminalRenderer.drawPane+0x1f6c>
10013150c:     	mov	w8, #0x0                ; =0
100131510:     	add	w28, w8, w28
100131514:     	cmp	w23, w28, uxth
100131518:     	mov	w24, #0x6               ; =6
10013151c:     	b.hi	0x10012f4c8 <_render.TerminalRenderer.drawPane+0x100c>
100131520:     	b	0x10012e8a4 <_render.TerminalRenderer.drawPane+0x3e8>
100131524:     	mov	x14, #0x0               ; =0
100131528:     	orr	x8, x27, x26, lsl #32
10013152c:     	lsl	x9, x23, #40
100131530:     	orr	x9, x9, x24, lsl #48
100131534:     	orr	x8, x9, x8
100131538:     	str	x8, [sp, #0x10]
10013153c:     	ubfx	x11, x8, #32, #4
100131540:     	mov	x8, #0x642f             ; =25647
100131544:     	movk	x8, #0x78bd, lsl #16
100131548:     	movk	x8, #0x1d64, lsl #32
10013154c:     	movk	x8, #0xa076, lsl #48
100131550:     	eor	x8, x11, x8
100131554:     	mov	x10, #0x28db            ; =10459
100131558:     	movk	x10, #0xa0b4, lsl #16
10013155c:     	movk	x10, #0x7ed1, lsl #32
100131560:     	movk	x10, #0xe703, lsl #48
100131564:     	mul	x9, x8, x10
100131568:     	umulh	x8, x8, x10
10013156c:     	eor	x8, x8, x9
100131570:     	str	x11, [sp]
100131574:     	eor	x8, x11, x8
100131578:     	str	x8, [sp, #0x18]
10013157c:     	ldr	x8, [sp, #0x1c8]
100131580:     	ldr	w9, [sp, #0x250]
100131584:     	add	w8, w9, w8
100131588:     	and	x8, x8, #0xffff
10013158c:     	str	x8, [sp, #0x170]
100131590:     	add	x8, sp, #0xf00
100131594:     	str	x8, [sp, #0x250]
100131598:     	add	x8, sp, #0x2, lsl #12   ; =0x2000
10013159c:     	add	x8, x8, #0x300
1001315a0:     	str	x8, [sp, #0x230]
1001315a4:     	mov	x24, x19
1001315a8:     	mov	x23, #0x0               ; =0
1001315ac:     	cbz	x19, 0x1001315e8 <_render.TerminalRenderer.drawPane+0x312c>
1001315b0:     	add	x8, sp, #0xd00
1001315b4:     	ldr	w8, [x8, x14, lsl #2]
1001315b8:     	ldr	x9, [sp, #0x250]
1001315bc:     	add	x9, x9, #0x8
1001315c0:     	ldr	x19, [sp, #0x278]
1001315c4:     	ldr	x11, [sp, #0x1e0]
1001315c8:     	ldr	w10, [x9], #0x14
1001315cc:     	cmp	w10, w8
1001315d0:     	b.hs	0x1001315f0 <_render.TerminalRenderer.drawPane+0x3134>
1001315d4:     	add	x23, x23, #0x1
1001315d8:     	cmp	x24, x23
1001315dc:     	b.ne	0x1001315c8 <_render.TerminalRenderer.drawPane+0x310c>
1001315e0:     	mov	x23, x24
1001315e4:     	b	0x1001315f0 <_render.TerminalRenderer.drawPane+0x3134>
1001315e8:     	ldr	x19, [sp, #0x278]
1001315ec:     	ldr	x11, [sp, #0x1e0]
1001315f0:     	add	w26, w28, w14
1001315f4:     	ldrh	w8, [x11, #0x50]
1001315f8:     	ldr	x9, [sp, #0x1c8]
1001315fc:     	mul	x8, x9, x8
100131600:     	and	x9, x26, #0xffff
100131604:     	ldr	x10, [x11, #0x30]
100131608:     	add	x8, x10, x8, lsl #5
10013160c:     	add	x22, x8, x9, lsl #5
100131610:     	ldrb	w8, [x19, #0x40]
100131614:     	str	x14, [sp, #0x200]
100131618:     	cbz	w8, 0x100131700 <_render.TerminalRenderer.drawPane+0x3244>
10013161c:     	ldrb	w8, [x19, #0x38]
100131620:     	cbz	w8, 0x100131700 <_render.TerminalRenderer.drawPane+0x3244>
100131624:     	ldr	w11, [x19, #0x28]
100131628:     	ldr	x8, [x19, #0x30]
10013162c:     	ldrb	w10, [x19, #0x3d]
100131630:     	ldr	x9, [x19]
100131634:     	ldr	w9, [x9, #0xfc]
100131638:     	ldr	w12, [sp, #0x1a0]
10013163c:     	add	w9, w9, w12
100131640:     	tbz	w10, #0x0, 0x100131688 <_render.TerminalRenderer.drawPane+0x31cc>
100131644:     	cmp	w8, w11
100131648:     	csel	w10, w8, w11, lo
10013164c:     	csel	w8, w8, w11, hi
100131650:     	cmp	w9, w10
100131654:     	ccmp	w9, w8, #0x2, hs
100131658:     	b.hi	0x100131700 <_render.TerminalRenderer.drawPane+0x3244>
10013165c:     	ldp	q1, q0, [x22]
100131660:     	str	q1, [sp, #0x3700]
100131664:     	str	q0, [sp, #0x3710]
100131668:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
10013166c:     	add	x9, x9, #0x300
100131670:     	ldrh	w8, [x9, #0x1400]
100131674:     	eor	w8, w8, #0x10
100131678:     	strh	w8, [x9, #0x1400]
10013167c:     	add	x22, sp, #0x3, lsl #12  ; =0x3000
100131680:     	add	x22, x22, #0x700
100131684:     	b	0x100131700 <_render.TerminalRenderer.drawPane+0x3244>
100131688:     	ldr	w10, [x19, #0x2c]
10013168c:     	lsr	x12, x8, #32
100131690:     	cmp	w11, w8
100131694:     	b.lo	0x1001316ac <_render.TerminalRenderer.drawPane+0x31f0>
100131698:     	cmp	w11, w8
10013169c:     	b.ne	0x1001316c4 <_render.TerminalRenderer.drawPane+0x3208>
1001316a0:     	and	w13, w10, #0xffff
1001316a4:     	cmp	w13, w12, uxth
1001316a8:     	b.hs	0x1001316c4 <_render.TerminalRenderer.drawPane+0x3208>
1001316ac:     	mov	x13, x10
1001316b0:     	mov	x10, x12
1001316b4:     	mov	x12, x11
1001316b8:     	cmp	w9, w12
1001316bc:     	b.hs	0x1001316d8 <_render.TerminalRenderer.drawPane+0x321c>
1001316c0:     	b	0x100131700 <_render.TerminalRenderer.drawPane+0x3244>
1001316c4:     	mov	x13, x12
1001316c8:     	mov	x12, x8
1001316cc:     	mov	x8, x11
1001316d0:     	cmp	w9, w12
1001316d4:     	b.lo	0x100131700 <_render.TerminalRenderer.drawPane+0x3244>
1001316d8:     	and	w11, w26, #0xffff
1001316dc:     	cmp	w11, w13, uxth
1001316e0:     	ccmp	w9, w12, #0x0, lo
1001316e4:     	b.eq	0x100131700 <_render.TerminalRenderer.drawPane+0x3244>
1001316e8:     	cmp	w8, w9
1001316ec:     	b.lo	0x100131700 <_render.TerminalRenderer.drawPane+0x3244>
1001316f0:     	b.ne	0x10013165c <_render.TerminalRenderer.drawPane+0x31a0>
1001316f4:     	and	w8, w26, #0xffff
1001316f8:     	cmp	w8, w10, uxth
1001316fc:     	b.ls	0x10013165c <_render.TerminalRenderer.drawPane+0x31a0>
100131700:     	add	x8, x22, #0xe
100131704:     	ldrb	w9, [x22, #0x1e]
100131708:     	ldr	x10, [sp, #0x280]
10013170c:     	ldrh	w3, [x10, #0x8]
100131710:     	str	x8, [sp, #0x3900]
100131714:     	str	x9, [sp, #0x3908]
100131718:     	ldr	x8, [sp, #0xb8]
10013171c:     	str	x8, [sp, #0x3910]
100131720:     	mov	w8, #0x1                ; =1
100131724:     	str	w8, [sp, #0x3918]
100131728:     	add	x20, sp, #0x3, lsl #12  ; =0x3000
10013172c:     	add	x20, x20, #0x900
100131730:     	strb	wzr, [x20, #0x1c]
100131734:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
100131738:     	add	x0, x0, #0x920
10013173c:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
100131740:     	add	x2, x2, #0x900
100131744:     	ldr	x1, [sp, #0x290]
100131748:     	bl	0x100120a0c <_text.GlyphAtlas.shape>
10013174c:     	ldrh	w0, [x20, #0x48]
100131750:     	cbnz	w0, 0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
100131754:     	ldrb	w8, [x20, #0x45]
100131758:     	ldr	x30, [sp, #0x298]
10013175c:     	tbnz	w8, #0x0, 0x1001317b4 <_render.TerminalRenderer.drawPane+0x32f8>
100131760:     	ldr	x8, [sp, #0x3920]
100131764:     	ldr	x9, [sp, #0x3928]
100131768:     	cmp	x9, #0x2
10013176c:     	b.lo	0x100131794 <_render.TerminalRenderer.drawPane+0x32d8>
100131770:     	add	x10, x8, #0x1c
100131774:     	sub	x11, x9, #0x1
100131778:     	ldr	w12, [x10]
10013177c:     	ldur	w13, [x10, #-0x14]
100131780:     	cmp	w12, w13
100131784:     	b.lo	0x1001317b4 <_render.TerminalRenderer.drawPane+0x32f8>
100131788:     	add	x10, x10, #0x14
10013178c:     	subs	x11, x11, #0x1
100131790:     	b.ne	0x100131778 <_render.TerminalRenderer.drawPane+0x32bc>
100131794:     	add	x10, sp, #0x3, lsl #12  ; =0x3000
100131798:     	add	x10, x10, #0x900
10013179c:     	ldrb	w10, [x10, #0x44]
1001317a0:     	and	w10, w10, #0xf
1001317a4:     	ldr	x11, [sp]
1001317a8:     	cmp	w11, w10
1001317ac:     	ccmp	x23, x9, #0x0, eq
1001317b0:     	b.eq	0x100131d40 <_render.TerminalRenderer.drawPane+0x3884>
1001317b4:     	mov	w28, #0x1               ; =1
1001317b8:     	str	x24, [sp, #0x1f0]
1001317bc:     	ldp	q3, q0, [x22]
1001317c0:     	str	q0, [sp, #0x240]
1001317c4:     	umov.b	w8, v0[15]
1001317c8:     	ldrh	w11, [x19, #0x18]
1001317cc:     	ldrh	w12, [x19, #0x1a]
1001317d0:     	tst	w8, #0xfe
1001317d4:     	csinc	w8, w8, wzr, ne
1001317d8:     	ldr	x9, [x19]
1001317dc:     	ldrh	w10, [x19, #0x1c]
1001317e0:     	ldrh	w9, [x9, #0x50]
1001317e4:     	cmp	w10, w9
1001317e8:     	csel	w9, w10, w9, lo
1001317ec:     	sub	w9, w9, w26
1001317f0:     	and	w9, w9, #0xffff
1001317f4:     	cmp	w8, w9
1001317f8:     	csel	w10, w8, w9, lo
1001317fc:     	ldr	x22, [sp, #0x280]
100131800:     	ldrh	w15, [x22, #0x4]
100131804:     	ldrh	w13, [x22, #0x6]
100131808:     	ldr	x8, [sp, #0x260]
10013180c:     	ldp	w16, w14, [x8]
100131810:     	str	q3, [sp, #0x210]
100131814:     	tbz	w28, #0x0, 0x100131af0 <_render.TerminalRenderer.drawPane+0x3634>
100131818:     	stp	w16, w14, [sp, #0x44]
10013181c:     	stp	w13, w10, [sp, #0x4c]
100131820:     	stp	w12, w11, [sp, #0x54]
100131824:     	str	w15, [sp, #0xc0]
100131828:     	str	x26, [sp, #0x120]
10013182c:     	str	xzr, [sp, #0x3928]
100131830:     	str	xzr, [sp, #0x3920]
100131834:     	ldr	x8, [sp, #0x18]
100131838:     	str	x8, [sp, #0x3930]
10013183c:     	str	x8, [sp, #0x3938]
100131840:     	str	x8, [sp, #0x3940]
100131844:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131848:     	add	x8, x8, #0x920
10013184c:     	movi.2d	v0, #0000000000000000
100131850:     	stur	q0, [x8, #0x28]
100131854:     	stur	q0, [x8, #0x38]
100131858:     	stur	q0, [x8, #0x48]
10013185c:     	stur	q0, [x8, #0x58]
100131860:     	cbz	x23, 0x100131abc <_render.TerminalRenderer.drawPane+0x3600>
100131864:     	mov	x26, #0x0               ; =0
100131868:     	ldr	x24, [sp, #0x250]
10013186c:     	ldr	x20, [sp, #0x230]
100131870:     	mov	x19, x23
100131874:     	b	0x100131960 <_render.TerminalRenderer.drawPane+0x34a4>
100131878:     	mov	w8, #0x30               ; =48
10013187c:     	sub	x22, x8, x27
100131880:     	ldr	x25, [sp, #0x1a8]
100131884:     	add	x0, x25, x27
100131888:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
10013188c:     	add	x1, x1, #0x890
100131890:     	mov	x2, x22
100131894:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
100131898:     	ldr	x8, [sp, #0x3958]
10013189c:     	ldr	x9, [sp, #0x3940]
1001318a0:     	mov	x10, #0x28db            ; =10459
1001318a4:     	movk	x10, #0xa0b4, lsl #16
1001318a8:     	movk	x10, #0x7ed1, lsl #32
1001318ac:     	movk	x10, #0xe703, lsl #48
1001318b0:     	eor	x8, x8, x10
1001318b4:     	ldr	x10, [sp, #0x3960]
1001318b8:     	ldr	x11, [sp, #0x3968]
1001318bc:     	ldr	x12, [sp, #0x3930]
1001318c0:     	ldr	x13, [sp, #0x3938]
1001318c4:     	eor	x10, x12, x10
1001318c8:     	mul	x12, x10, x8
1001318cc:     	umulh	x8, x10, x8
1001318d0:     	eor	x8, x8, x12
1001318d4:     	mov	x10, #0xc6e3            ; =50915
1001318d8:     	movk	x10, #0x9c88, lsl #16
1001318dc:     	movk	x10, #0x6af0, lsl #32
1001318e0:     	movk	x10, #0x8ebc, lsl #48
1001318e4:     	eor	x10, x11, x10
1001318e8:     	ldr	x11, [sp, #0x3970]
1001318ec:     	ldr	x12, [sp, #0x3978]
1001318f0:     	eor	x11, x13, x11
1001318f4:     	mul	x13, x11, x10
1001318f8:     	umulh	x10, x11, x10
1001318fc:     	eor	x10, x10, x13
100131900:     	str	x8, [sp, #0x3930]
100131904:     	str	x10, [sp, #0x3938]
100131908:     	ldr	x8, [sp, #0x3980]
10013190c:     	mov	x10, #0x4cc3            ; =19651
100131910:     	movk	x10, #0x7537, lsl #16
100131914:     	movk	x10, #0x65cc, lsl #32
100131918:     	movk	x10, #0x5899, lsl #48
10013191c:     	eor	x10, x12, x10
100131920:     	eor	x8, x9, x8
100131924:     	mul	x9, x8, x10
100131928:     	umulh	x8, x8, x10
10013192c:     	eor	x8, x8, x9
100131930:     	str	x8, [sp, #0x3940]
100131934:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131938:     	add	x8, x8, #0x890
10013193c:     	add	x1, x8, x22
100131940:     	mov	x0, x25
100131944:     	mov	x2, x26
100131948:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
10013194c:     	ldr	x22, [sp, #0x280]
100131950:     	str	x26, [sp, #0x3950]
100131954:     	add	x24, x24, #0x14
100131958:     	subs	x19, x19, #0x1
10013195c:     	b.eq	0x100131abc <_render.TerminalRenderer.drawPane+0x3600>
100131960:     	ldr	q0, [x24]
100131964:     	str	q0, [sp, #0x3900]
100131968:     	ldr	w8, [x24, #0x10]
10013196c:     	ldr	q0, [x20], #0x14
100131970:     	str	w8, [sp, #0x3910]
100131974:     	str	q0, [sp, #0x3890]
100131978:     	ldr	x8, [sp, #0x3948]
10013197c:     	add	x8, x8, #0x4
100131980:     	str	x8, [sp, #0x3948]
100131984:     	subs	x27, x26, #0x2c
100131988:     	b.ls	0x100131a78 <_render.TerminalRenderer.drawPane+0x35bc>
10013198c:     	mov	w8, #0x30               ; =48
100131990:     	sub	x22, x8, x26
100131994:     	ldr	x25, [sp, #0x1a8]
100131998:     	add	x0, x25, x26
10013199c:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
1001319a0:     	add	x1, x1, #0x900
1001319a4:     	mov	x2, x22
1001319a8:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
1001319ac:     	ldr	x8, [sp, #0x3958]
1001319b0:     	ldr	x9, [sp, #0x3940]
1001319b4:     	mov	x10, #0x28db            ; =10459
1001319b8:     	movk	x10, #0xa0b4, lsl #16
1001319bc:     	movk	x10, #0x7ed1, lsl #32
1001319c0:     	movk	x10, #0xe703, lsl #48
1001319c4:     	eor	x8, x8, x10
1001319c8:     	ldr	x10, [sp, #0x3960]
1001319cc:     	ldr	x11, [sp, #0x3968]
1001319d0:     	ldr	x12, [sp, #0x3930]
1001319d4:     	ldr	x13, [sp, #0x3938]
1001319d8:     	eor	x10, x12, x10
1001319dc:     	mul	x12, x10, x8
1001319e0:     	umulh	x8, x10, x8
1001319e4:     	eor	x8, x8, x12
1001319e8:     	mov	x10, #0xc6e3            ; =50915
1001319ec:     	movk	x10, #0x9c88, lsl #16
1001319f0:     	movk	x10, #0x6af0, lsl #32
1001319f4:     	movk	x10, #0x8ebc, lsl #48
1001319f8:     	eor	x10, x11, x10
1001319fc:     	ldr	x11, [sp, #0x3970]
100131a00:     	ldr	x12, [sp, #0x3978]
100131a04:     	eor	x11, x13, x11
100131a08:     	mul	x13, x11, x10
100131a0c:     	umulh	x10, x11, x10
100131a10:     	eor	x10, x10, x13
100131a14:     	str	x8, [sp, #0x3930]
100131a18:     	str	x10, [sp, #0x3938]
100131a1c:     	ldr	x8, [sp, #0x3980]
100131a20:     	mov	x10, #0x4cc3            ; =19651
100131a24:     	movk	x10, #0x7537, lsl #16
100131a28:     	movk	x10, #0x65cc, lsl #32
100131a2c:     	movk	x10, #0x5899, lsl #48
100131a30:     	eor	x10, x12, x10
100131a34:     	eor	x8, x9, x8
100131a38:     	mul	x9, x8, x10
100131a3c:     	umulh	x8, x8, x10
100131a40:     	eor	x8, x8, x9
100131a44:     	str	x8, [sp, #0x3940]
100131a48:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131a4c:     	add	x8, x8, #0x900
100131a50:     	add	x1, x8, x22
100131a54:     	mov	x0, x25
100131a58:     	mov	x2, x27
100131a5c:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
100131a60:     	ldr	x8, [sp, #0x3948]
100131a64:     	add	x8, x8, #0x10
100131a68:     	str	x8, [sp, #0x3948]
100131a6c:     	subs	x26, x27, #0x20
100131a70:     	b.hi	0x100131878 <_render.TerminalRenderer.drawPane+0x33bc>
100131a74:     	b	0x100131a98 <_render.TerminalRenderer.drawPane+0x35dc>
100131a78:     	ldr	w9, [sp, #0x3900]
100131a7c:     	ldr	x10, [sp, #0x1a8]
100131a80:     	str	w9, [x10, x26]
100131a84:     	add	x27, x26, #0x4
100131a88:     	add	x8, x8, #0x10
100131a8c:     	str	x8, [sp, #0x3948]
100131a90:     	subs	x26, x27, #0x20
100131a94:     	b.hi	0x100131878 <_render.TerminalRenderer.drawPane+0x33bc>
100131a98:     	ldr	q0, [sp, #0x3890]
100131a9c:     	ldr	x8, [sp, #0x1a8]
100131aa0:     	str	q0, [x8, x27]
100131aa4:     	add	x26, x27, #0x10
100131aa8:     	ldr	x22, [sp, #0x280]
100131aac:     	str	x26, [sp, #0x3950]
100131ab0:     	add	x24, x24, #0x14
100131ab4:     	subs	x19, x19, #0x1
100131ab8:     	b.ne	0x100131960 <_render.TerminalRenderer.drawPane+0x34a4>
100131abc:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
100131ac0:     	add	x0, x0, #0x920
100131ac4:     	bl	0x10019a938 <_hash.wyhash.Wyhash.final>
100131ac8:     	ldr	q3, [sp, #0x210]
100131acc:     	cmp	x0, #0x1
100131ad0:     	csinc	x25, x0, xzr, hi
100131ad4:     	ldr	x30, [sp, #0x298]
100131ad8:     	ldr	x26, [sp, #0x120]
100131adc:     	ldr	w15, [sp, #0xc0]
100131ae0:     	ldp	w12, w11, [sp, #0x54]
100131ae4:     	ldp	w13, w10, [sp, #0x4c]
100131ae8:     	ldp	w16, w14, [sp, #0x44]
100131aec:     	b	0x100131af4 <_render.TerminalRenderer.drawPane+0x3638>
100131af0:     	mov	x25, #0x0               ; =0
100131af4:     	add	w8, w11, w26, uxth
100131af8:     	ldr	x9, [sp, #0x1c8]
100131afc:     	add	w9, w12, w9, uxth
100131b00:     	madd	w8, w15, w8, w16
100131b04:     	ucvtf	s9, w8
100131b08:     	madd	w8, w13, w9, w14
100131b0c:     	ucvtf	s11, w8
100131b10:     	mul	w8, w10, w15
100131b14:     	ucvtf	s12, w8
100131b18:     	ucvtf	s15, w13
100131b1c:     	ldr	w8, [sp, #0x1d0]
100131b20:     	add	w8, w26, w8
100131b24:     	ldr	x10, [sp, #0x188]
100131b28:     	ldrh	w9, [x10, #0x60]
100131b2c:     	ldr	x11, [sp, #0x170]
100131b30:     	umull	x9, w9, w11
100131b34:     	add	x26, x9, w8, uxth
100131b38:     	ldr	x8, [x10]
100131b3c:     	add	x20, x8, x26, lsl #6
100131b40:     	ldr	x19, [x10, #0x18]
100131b44:     	ldr	x13, [x10, #0x30]
100131b48:     	ldr	x14, [x10, #0x48]
100131b4c:     	ldrb	w8, [x20, #0x38]
100131b50:     	cmp	w8, #0x1
100131b54:     	b.ne	0x100131bb8 <_render.TerminalRenderer.drawPane+0x36fc>
100131b58:     	ldr	s0, [x20, #0x8]
100131b5c:     	fcmp	s0, s9
100131b60:     	b.ne	0x100131bb8 <_render.TerminalRenderer.drawPane+0x36fc>
100131b64:     	ldr	s0, [x20, #0xc]
100131b68:     	fcmp	s0, s11
100131b6c:     	b.ne	0x100131bb8 <_render.TerminalRenderer.drawPane+0x36fc>
100131b70:     	ldr	s0, [x20, #0x10]
100131b74:     	fcmp	s0, s12
100131b78:     	b.ne	0x100131bb8 <_render.TerminalRenderer.drawPane+0x36fc>
100131b7c:     	ldr	s0, [x20, #0x14]
100131b80:     	fcmp	s0, s15
100131b84:     	b.ne	0x100131bb8 <_render.TerminalRenderer.drawPane+0x36fc>
100131b88:     	ldur	q0, [x20, #0x18]
100131b8c:     	ldur	q1, [x20, #0x28]
100131b90:     	eor.16b	v0, v0, v3
100131b94:     	ldr	q2, [sp, #0x240]
100131b98:     	eor.16b	v1, v1, v2
100131b9c:     	orr.16b	v0, v1, v0
100131ba0:     	umaxv.16b	b0, v0
100131ba4:     	fmov	w8, s0
100131ba8:     	cbnz	w8, 0x100131bb8 <_render.TerminalRenderer.drawPane+0x36fc>
100131bac:     	ldr	x8, [x20]
100131bb0:     	cmp	x8, x25
100131bb4:     	b.eq	0x100132418 <_render.TerminalRenderer.drawPane+0x3f5c>
100131bb8:     	adrp	x27, 0x100537000 <___anon_12856+0x136a4>
100131bbc:     	add	x27, x27, #0xba0
100131bc0:     	tbz	w28, #0x0, 0x100131bfc <_render.TerminalRenderer.drawPane+0x3740>
100131bc4:     	ldr	x8, [sp, #0x250]
100131bc8:     	str	x8, [sp, #0x3720]
100131bcc:     	str	x23, [sp, #0x3728]
100131bd0:     	ldr	x8, [sp, #0x230]
100131bd4:     	str	x8, [sp, #0x3730]
100131bd8:     	str	x23, [sp, #0x3738]
100131bdc:     	ldr	x8, [sp, #0x10]
100131be0:     	str	x8, [sp, #0x3740]
100131be4:     	add	x27, sp, #0x3, lsl #12  ; =0x3000
100131be8:     	add	x27, x27, #0x720
100131bec:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131bf0:     	add	x8, x8, #0x720
100131bf4:     	mov	w9, #0x1                ; =1
100131bf8:     	strb	w9, [x8, #0x28]
100131bfc:     	str	q3, [sp, #0x3750]
100131c00:     	ldr	q0, [sp, #0x240]
100131c04:     	str	q0, [sp, #0x3760]
100131c08:     	fmov	x8, d3
100131c0c:     	str	xzr, [x30, #0xc0]
100131c10:     	tbnz	w8, #0x4, 0x100131cac <_render.TerminalRenderer.drawPane+0x37f0>
100131c14:     	ldr	x8, [sp, #0x228]
100131c18:     	ldr	q0, [x8]
100131c1c:     	str	q0, [sp, #0x3780]
100131c20:     	mov	b0, v3[8]
100131c24:     	mov.b	v0[4], v3[9]
100131c28:     	mov	b1, v3[6]
100131c2c:     	mov.b	v1[4], v3[7]
100131c30:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131c34:     	add	x8, x8, #0x780
100131c38:     	fmov	w9, s1
100131c3c:     	and	w9, w9, #0xff
100131c40:     	cmp	w9, #0x2
100131c44:     	b.eq	0x100131ce4 <_render.TerminalRenderer.drawPane+0x3828>
100131c48:     	cmp	w9, #0x1
100131c4c:     	b.ne	0x100131d18 <_render.TerminalRenderer.drawPane+0x385c>
100131c50:     	mov.s	w8, v1[1]
100131c54:     	and	w9, w8, #0xff
100131c58:     	cmp	w9, #0x10
100131c5c:     	b.hs	0x100131da4 <_render.TerminalRenderer.drawPane+0x38e8>
100131c60:     	and	x9, x8, #0xff
100131c64:     	add	x8, x9, w8, uxtb #1
100131c68:     	ldr	x9, [sp, #0x1c0]
100131c6c:     	add	x8, x9, x8
100131c70:     	ldr	b0, [x8]
100131c74:     	ucvtf	s0, s0
100131c78:     	mov	w9, #0x437f0000         ; =1132396544
100131c7c:     	fmov	s1, w9
100131c80:     	fdiv	s3, s0, s1
100131c84:     	ldr	b0, [x8, #0x1]
100131c88:     	ucvtf	s0, s0
100131c8c:     	fdiv	s0, s0, s1
100131c90:     	str	s3, [sp, #0x3920]
100131c94:     	str	s0, [sp, #0x3924]
100131c98:     	ldr	b0, [x8, #0x2]
100131c9c:     	ucvtf	s0, s0
100131ca0:     	fdiv	s0, s0, s1
100131ca4:     	str	s0, [sp, #0x3928]
100131ca8:     	b	0x100131f10 <_render.TerminalRenderer.drawPane+0x3a54>
100131cac:     	ldr	x9, [sp, #0x290]
100131cb0:     	add	x8, x9, #0x10, lsl #12  ; =0x10000
100131cb4:     	ldr	q0, [x8, #0x6ba0]
100131cb8:     	str	q0, [sp, #0x3770]
100131cbc:     	mov	b0, v3[4]
100131cc0:     	mov.b	v0[4], v3[5]
100131cc4:     	mov	b1, v3[2]
100131cc8:     	mov.b	v1[4], v3[3]
100131ccc:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131cd0:     	add	x8, x8, #0x770
100131cd4:     	fmov	w9, s1
100131cd8:     	and	w9, w9, #0xff
100131cdc:     	cmp	w9, #0x2
100131ce0:     	b.ne	0x100131c48 <_render.TerminalRenderer.drawPane+0x378c>
100131ce4:     	mov.s	w8, v1[1]
100131ce8:     	and	w8, w8, #0xff
100131cec:     	ucvtf	s1, w8
100131cf0:     	mov	w8, #0x437f0000         ; =1132396544
100131cf4:     	fmov	s2, w8
100131cf8:     	fdiv	s3, s1, s2
100131cfc:     	str	s3, [sp, #0x3920]
100131d00:     	movi	d1, #0x0000ff000000ff
100131d04:     	and.8b	v0, v0, v1
100131d08:     	ucvtf.2s	v0, v0
100131d0c:     	ldr	d1, [sp, #0x190]
100131d10:     	fdiv.2s	v0, v0, v1
100131d14:     	b	0x100131f04 <_render.TerminalRenderer.drawPane+0x3a48>
100131d18:     	ldr	s3, [x8]
100131d1c:     	ldp	s13, s10, [x8, #0x4]
100131d20:     	ldr	s8, [x8, #0xc]
100131d24:     	ucvtf	s14, w15
100131d28:     	ldrb	w8, [x30, #0xd8]
100131d2c:     	cbnz	w8, 0x100131f34 <_render.TerminalRenderer.drawPane+0x3a78>
100131d30:     	ldr	x8, [x30, #0xc8]
100131d34:     	cbz	x8, 0x100131e40 <_render.TerminalRenderer.drawPane+0x3984>
100131d38:     	mov	x8, #0x0                ; =0
100131d3c:     	b	0x100131ec4 <_render.TerminalRenderer.drawPane+0x3a08>
100131d40:     	cbz	x23, 0x10013245c <_render.TerminalRenderer.drawPane+0x3fa0>
100131d44:     	ldr	x10, [sp, #0x3930]
100131d48:     	ldr	x9, [sp, #0x230]
100131d4c:     	add	x9, x9, #0x8
100131d50:     	add	x10, x10, #0x8
100131d54:     	ldr	x11, [sp, #0x250]
100131d58:     	mov	x12, x23
100131d5c:     	ldr	w13, [x11], #0x14
100131d60:     	ldr	w14, [x8], #0x14
100131d64:     	cmp	w13, w14
100131d68:     	b.ne	0x1001317b4 <_render.TerminalRenderer.drawPane+0x32f8>
100131d6c:     	ldp	w14, w13, [x10, #-0x8]
100131d70:     	ldp	w16, w15, [x9, #-0x8]
100131d74:     	cmp	w16, w14
100131d78:     	ccmp	w15, w13, #0x0, eq
100131d7c:     	b.ne	0x1001317b4 <_render.TerminalRenderer.drawPane+0x32f8>
100131d80:     	ldp	w13, w14, [x9], #0x14
100131d84:     	ldp	w15, w16, [x10], #0x14
100131d88:     	cmp	w13, w15
100131d8c:     	ccmp	w14, w16, #0x0, eq
100131d90:     	b.ne	0x1001317b4 <_render.TerminalRenderer.drawPane+0x32f8>
100131d94:     	mov	w28, #0x0               ; =0
100131d98:     	subs	x12, x12, #0x1
100131d9c:     	b.ne	0x100131d5c <_render.TerminalRenderer.drawPane+0x38a0>
100131da0:     	b	0x1001317b8 <_render.TerminalRenderer.drawPane+0x32fc>
100131da4:     	cmp	w9, #0xe7
100131da8:     	b.hi	0x100131edc <_render.TerminalRenderer.drawPane+0x3a20>
100131dac:     	sub	w8, w8, #0x10
100131db0:     	and	w9, w8, #0xff
100131db4:     	mov	w10, #0x39              ; =57
100131db8:     	mul	w10, w9, w10
100131dbc:     	lsr	w10, w10, #11
100131dc0:     	mov	w11, #0x28              ; =40
100131dc4:     	mov	w12, #0x37              ; =55
100131dc8:     	madd	w10, w10, w11, w12
100131dcc:     	cmp	w9, #0x24
100131dd0:     	csel	w10, wzr, w10, lo
100131dd4:     	and	w10, w10, #0xff
100131dd8:     	mov	w11, #0xab              ; =171
100131ddc:     	mul	w9, w9, w11
100131de0:     	lsr	w9, w9, #10
100131de4:     	ucvtf	s0, w10
100131de8:     	mov	w10, #0x437f0000        ; =1132396544
100131dec:     	fmov	s1, w10
100131df0:     	fmov	s2, w9
100131df4:     	mov.s	v2[1], w8
100131df8:     	fdiv	s3, s0, s1
100131dfc:     	movi	d0, #0x0000ff000000ff
100131e00:     	and.8b	v0, v2, v0
100131e04:     	ldr	d1, [sp, #0x110]
100131e08:     	umull.2d	v1, v0, v1
100131e0c:     	shrn.2s	v1, v1, #0x20
100131e10:     	movi.2s	v2, #0x6
100131e14:     	mls.2s	v0, v1, v2
100131e18:     	movi.2s	v1, #0x37
100131e1c:     	movi.2s	v2, #0x28
100131e20:     	mla.2s	v1, v0, v2
100131e24:     	cmeq.2s	v0, v0, #0
100131e28:     	bic.8b	v0, v1, v0
100131e2c:     	bic.2s	v0, #0x3, lsl #8
100131e30:     	ucvtf.2s	v0, v0
100131e34:     	ldr	d1, [sp, #0x190]
100131e38:     	fdiv.2s	v0, v0, v1
100131e3c:     	b	0x100131f00 <_render.TerminalRenderer.drawPane+0x3a44>
100131e40:     	ldp	x0, x8, [x30, #0xa8]
100131e44:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
100131e48:     	add	x9, x9, #0x900
100131e4c:     	strb	wzr, [x9, #0x20]
100131e50:     	tbnz	wzr, #0x0, 0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
100131e54:     	str	q3, [sp, #0x120]
100131e58:     	mov	x28, x25
100131e5c:     	mov	x25, x14
100131e60:     	mov	x21, x13
100131e64:     	ldr	x8, [x8]
100131e68:     	mov	w1, #0xa0               ; =160
100131e6c:     	mov	w2, #0x2                ; =2
100131e70:     	ldr	x3, [sp, #0x198]
100131e74:     	blr	x8
100131e78:     	cbz	x0, 0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
100131e7c:     	mov	x22, x0
100131e80:     	mov	x24, x19
100131e84:     	ldr	x19, [sp, #0x298]
100131e88:     	ldp	x1, x8, [x19, #0xb8]
100131e8c:     	add	x8, x8, x8, lsl #2
100131e90:     	lsl	x2, x8, #4
100131e94:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
100131e98:     	mov	x30, x19
100131e9c:     	mov	x19, x24
100131ea0:     	ldr	x8, [x30, #0xc0]
100131ea4:     	str	x22, [x30, #0xb8]
100131ea8:     	mov	w9, #0x2                ; =2
100131eac:     	str	x9, [x30, #0xc8]
100131eb0:     	ldr	x22, [sp, #0x280]
100131eb4:     	mov	x13, x21
100131eb8:     	mov	x14, x25
100131ebc:     	mov	x25, x28
100131ec0:     	ldr	q3, [sp, #0x120]
100131ec4:     	add	x9, x8, #0x1
100131ec8:     	str	x9, [x30, #0xc0]
100131ecc:     	ldr	x9, [x30, #0xb8]
100131ed0:     	mov	w10, #0x50              ; =80
100131ed4:     	madd	x8, x8, x10, x9
100131ed8:     	b	0x100131f48 <_render.TerminalRenderer.drawPane+0x3a8c>
100131edc:     	mov	w9, #0xa                ; =10
100131ee0:     	mov	w10, #-0x8              ; =-8
100131ee4:     	madd	w8, w8, w9, w10
100131ee8:     	and	w8, w8, #0xfe
100131eec:     	ucvtf	s0, w8
100131ef0:     	mov	w8, #0x437f0000         ; =1132396544
100131ef4:     	fmov	s1, w8
100131ef8:     	fdiv	s3, s0, s1
100131efc:     	dup.2s	v0, v3[0]
100131f00:     	str	s3, [sp, #0x3920]
100131f04:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131f08:     	add	x8, x8, #0x900
100131f0c:     	stur	d0, [x8, #0x24]
100131f10:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131f14:     	add	x8, x8, #0x920
100131f18:     	mov	w9, #0x3f800000         ; =1065353216
100131f1c:     	str	w9, [x8, #0xc]
100131f20:     	ldp	s13, s10, [x8, #0x4]
100131f24:     	ldr	s8, [x8, #0xc]
100131f28:     	ucvtf	s14, w15
100131f2c:     	ldrb	w8, [x30, #0xd8]
100131f30:     	cbz	w8, 0x100131d30 <_render.TerminalRenderer.drawPane+0x3874>
100131f34:     	ldr	x8, [x30, #0xd0]
100131f38:     	cbz	x8, 0x100131f7c <_render.TerminalRenderer.drawPane+0x3ac0>
100131f3c:     	mov	w8, #0x1                ; =1
100131f40:     	str	x8, [x30, #0xc0]
100131f44:     	ldr	x8, [x30, #0xb8]
100131f48:     	stp	s9, s11, [x8]
100131f4c:     	stp	s14, s15, [x8, #0x8]
100131f50:     	movi.4s	v0, #0x3a, lsl #24
100131f54:     	str	q0, [x8, #0x10]
100131f58:     	stp	s3, s13, [x8, #0x20]
100131f5c:     	stp	s10, s8, [x8, #0x28]
100131f60:     	movi.2d	v0, #0000000000000000
100131f64:     	stp	q0, q0, [x8, #0x30]
100131f68:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131f6c:     	add	x8, x8, #0x720
100131f70:     	ldrb	w8, [x8, #0x4f]
100131f74:     	cbnz	w8, 0x100131f98 <_render.TerminalRenderer.drawPane+0x3adc>
100131f78:     	b	0x100132334 <_render.TerminalRenderer.drawPane+0x3e78>
100131f7c:     	ldr	x8, [x30, #0xe0]
100131f80:     	add	x8, x8, #0x1
100131f84:     	str	x8, [x30, #0xe0]
100131f88:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131f8c:     	add	x8, x8, #0x720
100131f90:     	ldrb	w8, [x8, #0x4f]
100131f94:     	cbz	w8, 0x100132334 <_render.TerminalRenderer.drawPane+0x3e78>
100131f98:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100131f9c:     	add	x8, x8, #0x720
100131fa0:     	ldrh	w8, [x8, #0x30]
100131fa4:     	tbnz	w8, #0x5, 0x100132334 <_render.TerminalRenderer.drawPane+0x3e78>
100131fa8:     	str	x25, [sp, #0x120]
100131fac:     	mov	x28, x19
100131fb0:     	mov	x25, x14
100131fb4:     	mov	x24, x13
100131fb8:     	add	x21, sp, #0x3, lsl #12  ; =0x3000
100131fbc:     	add	x21, x21, #0x720
100131fc0:     	tbnz	w8, #0x4, 0x100131ff0 <_render.TerminalRenderer.drawPane+0x3b34>
100131fc4:     	ldur	w8, [x21, #0x32]
100131fc8:     	str	w8, [sp, #0x379c]
100131fcc:     	ldr	x19, [sp, #0x290]
100131fd0:     	add	x8, x19, #0x10, lsl #12 ; =0x10000
100131fd4:     	ldr	q0, [x8, #0x6ba0]
100131fd8:     	str	q0, [sp, #0x37b0]
100131fdc:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
100131fe0:     	add	x2, x2, #0x7b0
100131fe4:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
100131fe8:     	add	x1, x1, #0x79c
100131fec:     	b	0x100132018 <_render.TerminalRenderer.drawPane+0x3b5c>
100131ff0:     	ldur	w8, [x21, #0x36]
100131ff4:     	str	w8, [sp, #0x3798]
100131ff8:     	ldr	x8, [sp, #0x228]
100131ffc:     	ldr	q0, [x8]
100132000:     	str	q0, [sp, #0x37a0]
100132004:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
100132008:     	add	x2, x2, #0x7a0
10013200c:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
100132010:     	add	x1, x1, #0x798
100132014:     	ldr	x19, [sp, #0x290]
100132018:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
10013201c:     	add	x0, x0, #0x920
100132020:     	ldr	x3, [sp, #0x1c0]
100132024:     	bl	0x10019b980 <_render.cell_colors.withPalette>
100132028:     	ldr	x8, [sp, #0x3920]
10013202c:     	str	x8, [sp, #0x37c8]
100132030:     	ldr	w8, [sp, #0x3928]
100132034:     	str	w8, [sp, #0x37d0]
100132038:     	ldr	s0, [sp, #0x392c]
10013203c:     	ldrh	w10, [x21, #0x30]
100132040:     	fmov	s1, #0.50000000
100132044:     	fmul	s1, s0, s1
100132048:     	tst	w10, #0x4
10013204c:     	fcsel	s8, s0, s1, eq
100132050:     	ldrb	w9, [x21, #0x4e]
100132054:     	ldr	s0, [x22]
100132058:     	fadd	s3, s0, s11
10013205c:     	ldrh	w8, [x22, #0x8]
100132060:     	fneg	s0, s0
100132064:     	ldr	h1, [x22, #0x4]
100132068:     	ucvtf	s1, s1
10013206c:     	ldr	h2, [x22, #0x6]
100132070:     	ucvtf	s2, s2
100132074:     	and	w11, w10, #0x1
100132078:     	strb	w11, [x21, #0xbe]
10013207c:     	ubfx	w10, w10, #1, #1
100132080:     	strb	w10, [x21, #0xbd]
100132084:     	strb	wzr, [x21, #0xb8]
100132088:     	ldrb	w10, [x27, #0x28]
10013208c:     	add	x22, sp, #0x3, lsl #12  ; =0x3000
100132090:     	add	x22, x22, #0x720
100132094:     	cbz	w10, 0x100132144 <_render.TerminalRenderer.drawPane+0x3c88>
100132098:     	ldp	q4, q5, [x27]
10013209c:     	add	x11, sp, #0x3, lsl #12  ; =0x3000
1001320a0:     	add	x11, x11, #0x920
1001320a4:     	stur	q4, [x11, #0x48]
1001320a8:     	stur	q5, [x11, #0x58]
1001320ac:     	ldr	x10, [x27, #0x20]
1001320b0:     	stur	x10, [x11, #0x68]
1001320b4:     	ldr	x10, [sp, #0x37c8]
1001320b8:     	stur	x10, [x11, #0x18]
1001320bc:     	ldr	w10, [sp, #0x37d0]
1001320c0:     	stur	w10, [x11, #0x20]
1001320c4:     	ldrb	w10, [x22, #0xbe]
1001320c8:     	ldrb	w11, [x22, #0xbd]
1001320cc:     	ldrb	w12, [x22, #0xb8]
1001320d0:     	ldr	x13, [sp, #0x28]
1001320d4:     	str	x13, [sp, #0x3920]
1001320d8:     	str	x9, [sp, #0x3928]
1001320dc:     	str	s9, [sp, #0x3930]
1001320e0:     	str	s3, [sp, #0x3934]
1001320e4:     	str	s8, [sp, #0x3944]
1001320e8:     	str	wzr, [sp, #0x3948]
1001320ec:     	str	s0, [sp, #0x394c]
1001320f0:     	str	s1, [sp, #0x3950]
1001320f4:     	str	s2, [sp, #0x3954]
1001320f8:     	add	x21, sp, #0x3, lsl #12  ; =0x3000
1001320fc:     	add	x21, x21, #0x900
100132100:     	mov	w9, #0x1                ; =1
100132104:     	strb	w9, [x21, #0x58]
100132108:     	strh	w8, [x21, #0x5c]
10013210c:     	strb	w10, [x21, #0x5e]
100132110:     	strb	w11, [x21, #0x5f]
100132114:     	strb	w12, [x21, #0x60]
100132118:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
10013211c:     	add	x0, x0, #0x900
100132120:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
100132124:     	add	x2, x2, #0x920
100132128:     	ldr	x8, [sp, #0x298]
10013212c:     	add	x3, x8, #0xa8
100132130:     	mov	x1, x19
100132134:     	bl	0x100126c58 <_text.GlyphAtlas.paint>
100132138:     	ldrh	w0, [x21, #0x4]
10013213c:     	cbz	w0, 0x100132204 <_render.TerminalRenderer.drawPane+0x3d48>
100132140:     	b	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
100132144:     	cmp	w9, #0x1
100132148:     	b.ne	0x100132178 <_render.TerminalRenderer.drawPane+0x3cbc>
10013214c:     	ldrb	w10, [x22, #0x3e]
100132150:     	cmp	w10, #0x20
100132154:     	b.ne	0x100132178 <_render.TerminalRenderer.drawPane+0x3cbc>
100132158:     	sub	x10, x9, #0x1
10013215c:     	ldr	x11, [sp, #0x28]
100132160:     	ldrb	w11, [x11, x10]
100132164:     	adrp	x12, 0x100687000 <___anon_33682+0x119f>
100132168:     	add	x12, x12, #0xee4
10013216c:     	ldrb	w10, [x12, x10]
100132170:     	cmp	w11, w10
100132174:     	b.eq	0x100132204 <_render.TerminalRenderer.drawPane+0x3d48>
100132178:     	ldr	x10, [sp, #0x28]
10013217c:     	str	x10, [sp, #0x37e0]
100132180:     	str	x9, [sp, #0x37e8]
100132184:     	str	s9, [sp, #0x37f0]
100132188:     	str	s3, [sp, #0x37f4]
10013218c:     	ldr	x9, [sp, #0x37c8]
100132190:     	add	x10, sp, #0x3, lsl #12  ; =0x3000
100132194:     	add	x10, x10, #0x7e0
100132198:     	stur	x9, [x10, #0x18]
10013219c:     	ldr	w9, [sp, #0x37d0]
1001321a0:     	stur	w9, [x10, #0x20]
1001321a4:     	str	s8, [sp, #0x3804]
1001321a8:     	str	wzr, [sp, #0x3808]
1001321ac:     	str	s0, [sp, #0x380c]
1001321b0:     	str	s1, [sp, #0x3810]
1001321b4:     	str	s2, [sp, #0x3814]
1001321b8:     	mov	w9, #0x1                ; =1
1001321bc:     	strb	w9, [x22, #0xf8]
1001321c0:     	strh	w8, [x22, #0xfc]
1001321c4:     	ldrb	w8, [x22, #0xbe]
1001321c8:     	strb	w8, [x22, #0xfe]
1001321cc:     	ldrb	w8, [x22, #0xbd]
1001321d0:     	strb	w8, [x22, #0xff]
1001321d4:     	ldrb	w8, [x22, #0xb8]
1001321d8:     	strb	w8, [x22, #0x100]
1001321dc:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
1001321e0:     	add	x0, x0, #0x834
1001321e4:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
1001321e8:     	add	x2, x2, #0x7e0
1001321ec:     	ldr	x8, [sp, #0x298]
1001321f0:     	add	x3, x8, #0xa8
1001321f4:     	mov	x1, x19
1001321f8:     	bl	0x100127dc8 <_text.GlyphAtlas.place>
1001321fc:     	ldrh	w0, [x22, #0x118]
100132200:     	cbnz	w0, 0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
100132204:     	ldrh	w8, [x22, #0x30]
100132208:     	tst	w8, #0x700
10013220c:     	b.eq	0x1001322b0 <_render.TerminalRenderer.drawPane+0x3df4>
100132210:     	fadd	s0, s15, s11
100132214:     	fmov	s1, #-2.00000000
100132218:     	fadd	s0, s0, s1
10013221c:     	str	s9, [sp, #0x383c]
100132220:     	str	s0, [sp, #0x3840]
100132224:     	str	s12, [sp, #0x3844]
100132228:     	mov	w8, #0x3f800000         ; =1065353216
10013222c:     	str	w8, [sp, #0x3848]
100132230:     	ldur	w8, [x22, #0x3a]
100132234:     	str	w8, [sp, #0x384c]
100132238:     	ldr	x8, [sp, #0x37c8]
10013223c:     	str	x8, [sp, #0x3850]
100132240:     	ldr	w8, [sp, #0x37d0]
100132244:     	str	w8, [sp, #0x3858]
100132248:     	str	s8, [sp, #0x385c]
10013224c:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
100132250:     	add	x0, x0, #0x860
100132254:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
100132258:     	add	x1, x1, #0x84c
10013225c:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
100132260:     	add	x2, x2, #0x850
100132264:     	ldr	x3, [sp, #0x1c0]
100132268:     	bl	0x10019b980 <_render.cell_colors.withPalette>
10013226c:     	ldr	x8, [sp, #0x298]
100132270:     	add	x0, x8, #0xa8
100132274:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
100132278:     	add	x1, x1, #0x83c
10013227c:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
100132280:     	add	x2, x2, #0x860
100132284:     	bl	0x100121614 <_QuadList.pushRect>
100132288:     	ands	w0, w0, #0xffff
10013228c:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
100132290:     	mov	x19, x28
100132294:     	ldrh	w8, [x22, #0x30]
100132298:     	ldr	x30, [sp, #0x298]
10013229c:     	mov	x13, x24
1001322a0:     	mov	x14, x25
1001322a4:     	ldr	x25, [sp, #0x120]
1001322a8:     	tbnz	w8, #0x6, 0x1001322c8 <_render.TerminalRenderer.drawPane+0x3e0c>
1001322ac:     	b	0x100132334 <_render.TerminalRenderer.drawPane+0x3e78>
1001322b0:     	mov	x19, x28
1001322b4:     	ldr	x30, [sp, #0x298]
1001322b8:     	mov	x13, x24
1001322bc:     	mov	x14, x25
1001322c0:     	ldr	x25, [sp, #0x120]
1001322c4:     	tbz	w8, #0x6, 0x100132334 <_render.TerminalRenderer.drawPane+0x3e78>
1001322c8:     	fmov	s0, #0.50000000
1001322cc:     	fmul	s0, s15, s0
1001322d0:     	fadd	s0, s0, s11
1001322d4:     	str	s9, [sp, #0x3870]
1001322d8:     	str	s0, [sp, #0x3874]
1001322dc:     	str	s12, [sp, #0x3878]
1001322e0:     	mov	w8, #0x3f800000         ; =1065353216
1001322e4:     	str	w8, [sp, #0x387c]
1001322e8:     	ldr	x8, [sp, #0x37c8]
1001322ec:     	str	x8, [sp, #0x3880]
1001322f0:     	ldr	w8, [sp, #0x37d0]
1001322f4:     	str	w8, [sp, #0x3888]
1001322f8:     	str	s8, [sp, #0x388c]
1001322fc:     	add	x0, x30, #0xa8
100132300:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
100132304:     	add	x1, x1, #0x870
100132308:     	add	x2, sp, #0x3, lsl #12   ; =0x3000
10013230c:     	add	x2, x2, #0x880
100132310:     	mov	x19, x13
100132314:     	mov	x21, x14
100132318:     	bl	0x100121614 <_QuadList.pushRect>
10013231c:     	mov	x14, x21
100132320:     	mov	x13, x19
100132324:     	mov	x19, x28
100132328:     	ldr	x30, [sp, #0x298]
10013232c:     	ands	w0, w0, #0xffff
100132330:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
100132334:     	ldp	x21, x24, [x30, #0xb8]
100132338:     	add	x8, x26, x26, lsl #2
10013233c:     	lsl	x8, x8, #4
100132340:     	add	x19, x19, x8
100132344:     	mov	w9, #0x6e0              ; =1760
100132348:     	madd	x22, x26, x9, x14
10013234c:     	cmp	x24, #0x2
100132350:     	mov	w9, #0x2                ; =2
100132354:     	csel	x26, x24, x9, lo
100132358:     	ldp	q0, q1, [x21]
10013235c:     	ldp	q2, q3, [x21, #0x20]
100132360:     	ldr	q4, [x21, #0x40]
100132364:     	stp	q3, q4, [x19, #0x30]
100132368:     	stp	q1, q2, [x19, #0x10]
10013236c:     	str	q0, [x19]
100132370:     	sub	w9, w26, #0x1
100132374:     	and	x10, x9, #0x3
100132378:     	lsl	x2, x10, #4
10013237c:     	bfi	x2, x9, #6, #2
100132380:     	add	x0, x13, x8
100132384:     	add	x1, x21, #0x50
100132388:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
10013238c:     	sub	x8, x24, x26
100132390:     	mov	w9, #0x50               ; =80
100132394:     	madd	x1, x26, x9, x21
100132398:     	add	x8, x8, x8, lsl #2
10013239c:     	lsl	x2, x8, #4
1001323a0:     	mov	x0, x22
1001323a4:     	ldr	x22, [sp, #0x280]
1001323a8:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
1001323ac:     	strb	w24, [x20, #0x3c]
1001323b0:     	str	x25, [x20]
1001323b4:     	stp	s9, s11, [x20, #0x8]
1001323b8:     	stp	s12, s15, [x20, #0x10]
1001323bc:     	ldr	q0, [sp, #0x210]
1001323c0:     	stur	q0, [x20, #0x18]
1001323c4:     	ldr	q0, [sp, #0x240]
1001323c8:     	stur	q0, [x20, #0x28]
1001323cc:     	mov	w8, #0x1                ; =1
1001323d0:     	strb	w8, [x20, #0x38]
1001323d4:     	ldr	s0, [x22, #0x1ac]
1001323d8:     	ldr	s1, [x19, #0x20]
1001323dc:     	fcmp	s1, s0
1001323e0:     	b.ne	0x100132404 <_render.TerminalRenderer.drawPane+0x3f48>
1001323e4:     	ldr	s0, [x22, #0x1b0]
1001323e8:     	ldr	s1, [x19, #0x24]
1001323ec:     	fcmp	s1, s0
1001323f0:     	b.ne	0x100132404 <_render.TerminalRenderer.drawPane+0x3f48>
1001323f4:     	ldr	s0, [x22, #0x1b4]
1001323f8:     	ldr	s1, [x19, #0x28]
1001323fc:     	fcmp	s1, s0
100132400:     	cset	w8, ne
100132404:     	strb	w8, [x20, #0x39]
100132408:     	ldr	x30, [sp, #0x298]
10013240c:     	ldr	x8, [x30, #0x10]
100132410:     	add	x8, x8, #0x1
100132414:     	str	x8, [x30, #0x10]
100132418:     	add	x8, x23, x23, lsl #2
10013241c:     	lsl	x8, x8, #2
100132420:     	ldr	x9, [sp, #0x250]
100132424:     	add	x9, x9, x8
100132428:     	str	x9, [sp, #0x250]
10013242c:     	ldr	x19, [sp, #0x1f0]
100132430:     	sub	x19, x19, x23
100132434:     	ldr	x9, [sp, #0x230]
100132438:     	add	x9, x9, x8
10013243c:     	str	x9, [sp, #0x230]
100132440:     	ldr	x14, [sp, #0x200]
100132444:     	add	x14, x14, #0x1
100132448:     	ldr	x8, [sp, #0x1b0]
10013244c:     	cmp	x14, x8
100132450:     	ldr	x28, [sp, #0x148]
100132454:     	b.ne	0x1001315a4 <_render.TerminalRenderer.drawPane+0x30e8>
100132458:     	b	0x1001314e4 <_render.TerminalRenderer.drawPane+0x3028>
10013245c:     	mov	w28, #0x0               ; =0
100132460:     	b	0x1001317b8 <_render.TerminalRenderer.drawPane+0x32fc>
100132464:     	and	x11, x9, #0xfffffffffffffff8
100132468:     	mov	x10, #-0x18             ; =-24
10013246c:     	madd	x12, x9, x24, x10
100132470:     	mov	w13, #0xffff            ; =65535
100132474:     	mov	x10, x9
100132478:     	b	0x1001324b4 <_render.TerminalRenderer.drawPane+0x3ff8>
10013247c:     	ldurh	w15, [x13, #-0x18]
100132480:     	and	w16, w14, #0xffff
100132484:     	cmp	w15, w16
100132488:     	csel	w15, w15, w16, lo
10013248c:     	cmp	w15, w8, uxth
100132490:     	cset	w15, lo
100132494:     	ldurb	w16, [x13, #-0x15]
100132498:     	cmp	w16, #0x0
10013249c:     	sturb	w15, [x13, #-0x14]
1001324a0:     	csinv	w13, w14, wzr, ne
1001324a4:     	sub	x12, x12, #0x30
1001324a8:     	sub	x10, x10, #0x8
1001324ac:     	sub	x11, x11, #0x8
1001324b0:     	cbz	x11, 0x10012f394 <_render.TerminalRenderer.drawPane+0xed8>
1001324b4:     	ldr	x14, [x30, #0x28]
1001324b8:     	add	x14, x14, x12
1001324bc:     	ldrb	w15, [x14, #0x14]
1001324c0:     	and	w16, w15, #0x3
1001324c4:     	and	w13, w13, #0xffff
1001324c8:     	add	w15, w13, #0x1
1001324cc:     	cmp	w15, w27
1001324d0:     	csinc	w13, w27, w13, hs
1001324d4:     	cmp	w16, #0x2
1001324d8:     	csel	w15, wzr, w13, eq
1001324dc:     	cbz	w16, 0x1001324fc <_render.TerminalRenderer.drawPane+0x4040>
1001324e0:     	ldrh	w13, [x14, #0x12]
1001324e4:     	and	w16, w15, #0xffff
1001324e8:     	cmp	w13, w16
1001324ec:     	csel	w13, w13, w16, lo
1001324f0:     	cmp	w13, w8, uxth
1001324f4:     	cset	w13, lo
1001324f8:     	b	0x100132500 <_render.TerminalRenderer.drawPane+0x4044>
1001324fc:     	mov	w13, #0x0               ; =0
100132500:     	strb	w13, [x14, #0x16]
100132504:     	ldrb	w14, [x14, #0x15]
100132508:     	ldr	x13, [x30, #0x28]
10013250c:     	add	x13, x13, x12
100132510:     	ldrb	w16, [x13, #0xe]
100132514:     	and	w16, w16, #0x3
100132518:     	and	w15, w15, #0xffff
10013251c:     	add	w17, w15, #0x1
100132520:     	cmp	w17, w27
100132524:     	csinc	w15, w27, w15, hs
100132528:     	cmp	w14, #0x0
10013252c:     	csinv	w14, w15, wzr, ne
100132530:     	cmp	w16, #0x2
100132534:     	csel	w14, wzr, w14, eq
100132538:     	cbz	w16, 0x100132558 <_render.TerminalRenderer.drawPane+0x409c>
10013253c:     	ldrh	w15, [x13, #0xc]
100132540:     	and	w16, w14, #0xffff
100132544:     	cmp	w15, w16
100132548:     	csel	w15, w15, w16, lo
10013254c:     	cmp	w15, w8, uxth
100132550:     	cset	w15, lo
100132554:     	b	0x10013255c <_render.TerminalRenderer.drawPane+0x40a0>
100132558:     	mov	w15, #0x0               ; =0
10013255c:     	strb	w15, [x13, #0x10]
100132560:     	ldrb	w15, [x13, #0xf]
100132564:     	ldr	x13, [x30, #0x28]
100132568:     	add	x13, x13, x12
10013256c:     	ldrb	w16, [x13, #0x8]
100132570:     	and	w16, w16, #0x3
100132574:     	and	w14, w14, #0xffff
100132578:     	add	w17, w14, #0x1
10013257c:     	cmp	w17, w27
100132580:     	csinc	w14, w27, w14, hs
100132584:     	cmp	w15, #0x0
100132588:     	csinv	w14, w14, wzr, ne
10013258c:     	cmp	w16, #0x2
100132590:     	csel	w14, wzr, w14, eq
100132594:     	cbz	w16, 0x1001325b4 <_render.TerminalRenderer.drawPane+0x40f8>
100132598:     	ldrh	w15, [x13, #0x6]
10013259c:     	and	w16, w14, #0xffff
1001325a0:     	cmp	w15, w16
1001325a4:     	csel	w15, w15, w16, lo
1001325a8:     	cmp	w15, w8, uxth
1001325ac:     	cset	w15, lo
1001325b0:     	b	0x1001325b8 <_render.TerminalRenderer.drawPane+0x40fc>
1001325b4:     	mov	w15, #0x0               ; =0
1001325b8:     	strb	w15, [x13, #0xa]
1001325bc:     	ldrb	w16, [x13, #0x9]
1001325c0:     	ldr	x15, [x30, #0x28]
1001325c4:     	add	x13, x15, x12
1001325c8:     	ldrb	w17, [x13, #0x2]
1001325cc:     	and	w17, w17, #0x3
1001325d0:     	and	w14, w14, #0xffff
1001325d4:     	add	w0, w14, #0x1
1001325d8:     	cmp	w0, w27
1001325dc:     	csinc	w14, w27, w14, hs
1001325e0:     	cmp	w16, #0x0
1001325e4:     	csinv	w14, w14, wzr, ne
1001325e8:     	cmp	w17, #0x2
1001325ec:     	csel	w14, wzr, w14, eq
1001325f0:     	cbz	w17, 0x100132610 <_render.TerminalRenderer.drawPane+0x4154>
1001325f4:     	ldrh	w15, [x15, x12]
1001325f8:     	and	w16, w14, #0xffff
1001325fc:     	cmp	w15, w16
100132600:     	csel	w15, w15, w16, lo
100132604:     	cmp	w15, w8, uxth
100132608:     	cset	w15, lo
10013260c:     	b	0x100132614 <_render.TerminalRenderer.drawPane+0x4158>
100132610:     	mov	w15, #0x0               ; =0
100132614:     	strb	w15, [x13, #0x4]
100132618:     	ldrb	w15, [x13, #0x3]
10013261c:     	ldr	x13, [x30, #0x28]
100132620:     	add	x13, x13, x12
100132624:     	ldurb	w16, [x13, #-0x4]
100132628:     	and	w16, w16, #0x3
10013262c:     	and	w14, w14, #0xffff
100132630:     	add	w17, w14, #0x1
100132634:     	cmp	w17, w27
100132638:     	csinc	w14, w27, w14, hs
10013263c:     	cmp	w15, #0x0
100132640:     	csinv	w14, w14, wzr, ne
100132644:     	cmp	w16, #0x2
100132648:     	csel	w14, wzr, w14, eq
10013264c:     	cbz	w16, 0x10013266c <_render.TerminalRenderer.drawPane+0x41b0>
100132650:     	ldurh	w15, [x13, #-0x6]
100132654:     	and	w16, w14, #0xffff
100132658:     	cmp	w15, w16
10013265c:     	csel	w15, w15, w16, lo
100132660:     	cmp	w15, w8, uxth
100132664:     	cset	w15, lo
100132668:     	b	0x100132670 <_render.TerminalRenderer.drawPane+0x41b4>
10013266c:     	mov	w15, #0x0               ; =0
100132670:     	sturb	w15, [x13, #-0x2]
100132674:     	ldurb	w15, [x13, #-0x3]
100132678:     	ldr	x13, [x30, #0x28]
10013267c:     	add	x13, x13, x12
100132680:     	ldurb	w16, [x13, #-0xa]
100132684:     	and	w16, w16, #0x3
100132688:     	and	w14, w14, #0xffff
10013268c:     	add	w17, w14, #0x1
100132690:     	cmp	w17, w27
100132694:     	csinc	w14, w27, w14, hs
100132698:     	cmp	w15, #0x0
10013269c:     	csinv	w14, w14, wzr, ne
1001326a0:     	cmp	w16, #0x2
1001326a4:     	csel	w14, wzr, w14, eq
1001326a8:     	cbz	w16, 0x1001326c8 <_render.TerminalRenderer.drawPane+0x420c>
1001326ac:     	ldurh	w15, [x13, #-0xc]
1001326b0:     	and	w16, w14, #0xffff
1001326b4:     	cmp	w15, w16
1001326b8:     	csel	w15, w15, w16, lo
1001326bc:     	cmp	w15, w8, uxth
1001326c0:     	cset	w15, lo
1001326c4:     	b	0x1001326cc <_render.TerminalRenderer.drawPane+0x4210>
1001326c8:     	mov	w15, #0x0               ; =0
1001326cc:     	sturb	w15, [x13, #-0x8]
1001326d0:     	ldurb	w15, [x13, #-0x9]
1001326d4:     	ldr	x13, [x30, #0x28]
1001326d8:     	add	x13, x13, x12
1001326dc:     	ldurb	w16, [x13, #-0x10]
1001326e0:     	and	w16, w16, #0x3
1001326e4:     	and	w14, w14, #0xffff
1001326e8:     	add	w17, w14, #0x1
1001326ec:     	cmp	w17, w27
1001326f0:     	csinc	w14, w27, w14, hs
1001326f4:     	cmp	w15, #0x0
1001326f8:     	csinv	w14, w14, wzr, ne
1001326fc:     	cmp	w16, #0x2
100132700:     	csel	w14, wzr, w14, eq
100132704:     	cbz	w16, 0x100132724 <_render.TerminalRenderer.drawPane+0x4268>
100132708:     	ldurh	w15, [x13, #-0x12]
10013270c:     	and	w16, w14, #0xffff
100132710:     	cmp	w15, w16
100132714:     	csel	w15, w15, w16, lo
100132718:     	cmp	w15, w8, uxth
10013271c:     	cset	w15, lo
100132720:     	b	0x100132728 <_render.TerminalRenderer.drawPane+0x426c>
100132724:     	mov	w15, #0x0               ; =0
100132728:     	sturb	w15, [x13, #-0xe]
10013272c:     	ldurb	w15, [x13, #-0xf]
100132730:     	ldr	x13, [x30, #0x28]
100132734:     	add	x13, x13, x12
100132738:     	ldurb	w16, [x13, #-0x16]
10013273c:     	and	w16, w16, #0x3
100132740:     	and	w14, w14, #0xffff
100132744:     	add	w17, w14, #0x1
100132748:     	cmp	w17, w27
10013274c:     	csinc	w14, w27, w14, hs
100132750:     	cmp	w15, #0x0
100132754:     	csinv	w14, w14, wzr, ne
100132758:     	cmp	w16, #0x2
10013275c:     	csel	w14, wzr, w14, eq
100132760:     	cbnz	w16, 0x10013247c <_render.TerminalRenderer.drawPane+0x3fc0>
100132764:     	mov	w15, #0x0               ; =0
100132768:     	b	0x100132494 <_render.TerminalRenderer.drawPane+0x3fd8>
10013276c:     	str	xzr, [sp, #0x1c8]
100132770:     	str	xzr, [sp, #0x250]
100132774:     	add	x10, sp, #0x4b0
100132778:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
10013277c:     	add	x9, x9, #0x890
100132780:     	orr	x10, x10, #0x4
100132784:     	orr	x9, x9, #0x4
100132788:     	stp	x10, x9, [sp, #0x1a0]
10013278c:     	add	x9, x25, #0xe
100132790:     	str	x9, [sp, #0x1f0]
100132794:     	fmov	s15, #0.50000000
100132798:     	ldr	q0, [x8, #0x160]
10013279c:     	str	q0, [sp, #0x1d0]
1001327a0:     	b	0x1001327c8 <_render.TerminalRenderer.drawPane+0x430c>
1001327a4:     	ldr	x9, [sp, #0x250]
1001327a8:     	add	x9, x9, #0x1
1001327ac:     	ldr	x8, [sp, #0x1c8]
1001327b0:     	add	x8, x8, #0x20
1001327b4:     	str	x8, [sp, #0x1c8]
1001327b8:     	ldr	x8, [sp, #0x138]
1001327bc:     	str	x9, [sp, #0x250]
1001327c0:     	cmp	x9, x8
1001327c4:     	b.eq	0x100133590 <_render.TerminalRenderer.drawPane+0x50d4>
1001327c8:     	ldr	x20, [sp, #0x278]
1001327cc:     	ldr	x10, [x20]
1001327d0:     	ldrh	w9, [x20, #0x1c]
1001327d4:     	ldrh	w8, [x10, #0x50]
1001327d8:     	cmp	w9, w8
1001327dc:     	csel	w9, w9, w8, lo
1001327e0:     	ldr	x22, [sp, #0x280]
1001327e4:     	cbz	w9, 0x1001327a4 <_render.TerminalRenderer.drawPane+0x42e8>
1001327e8:     	mov	x19, #0x0               ; =0
1001327ec:     	mov	x28, #0x0               ; =0
1001327f0:     	ldrh	w11, [x20, #0x18]
1001327f4:     	ldrh	w12, [x20, #0x1a]
1001327f8:     	ldr	x10, [x10, #0x30]
1001327fc:     	ldr	x17, [sp, #0x188]
100132800:     	ldrh	w13, [x17, #0x60]
100132804:     	ldr	x14, [x17]
100132808:     	ldr	x15, [x17, #0x18]
10013280c:     	ldr	x16, [x17, #0x30]
100132810:     	ldr	x0, [sp, #0x250]
100132814:     	add	x12, x0, x12
100132818:     	madd	x11, x12, x13, x11
10013281c:     	ldr	x12, [x17, #0x48]
100132820:     	and	w13, w0, #0xffff
100132824:     	str	w13, [sp, #0x1e0]
100132828:     	lsl	x9, x9, #6
10013282c:     	str	x9, [sp, #0x240]
100132830:     	add	x9, x14, x11, lsl #6
100132834:     	str	x9, [sp, #0x2b8]
100132838:     	mov	w9, #0x6e0              ; =1760
10013283c:     	madd	x25, x11, x9, x12
100132840:     	add	x9, x11, x11, lsl #2
100132844:     	lsl	x9, x9, #4
100132848:     	add	x26, x16, x9
10013284c:     	add	x24, x15, x9
100132850:     	ldr	x9, [sp, #0x1c8]
100132854:     	madd	x23, x9, x8, x10
100132858:     	b	0x1001328bc <_render.TerminalRenderer.drawPane+0x4400>
10013285c:     	add	x9, x8, #0x1
100132860:     	str	x9, [x30, #0x80]
100132864:     	ldr	x9, [x30, #0x78]
100132868:     	mov	w10, #0x50              ; =80
10013286c:     	madd	x8, x8, x10, x9
100132870:     	ldr	q0, [sp, #0x2310]
100132874:     	str	q0, [x8, #0x10]
100132878:     	ldr	q0, [sp, #0x2320]
10013287c:     	str	q0, [x8, #0x20]
100132880:     	ldr	q0, [sp, #0x2330]
100132884:     	str	q0, [x8, #0x30]
100132888:     	ldr	q0, [sp, #0x2340]
10013288c:     	str	q0, [x8, #0x40]
100132890:     	ldr	q0, [sp, #0x2300]
100132894:     	str	q0, [x8]
100132898:     	add	x28, x28, #0x1
10013289c:     	add	x19, x19, #0x40
1001328a0:     	add	x25, x25, #0x6e0
1001328a4:     	add	x26, x26, #0x50
1001328a8:     	add	x24, x24, #0x50
1001328ac:     	add	x23, x23, #0x20
1001328b0:     	ldr	x8, [sp, #0x240]
1001328b4:     	cmp	x8, x19
1001328b8:     	b.eq	0x1001327a4 <_render.TerminalRenderer.drawPane+0x42e8>
1001328bc:     	ldrb	w10, [x20, #0x40]
1001328c0:     	ldr	x8, [x20]
1001328c4:     	mov	x9, x23
1001328c8:     	cbz	w10, 0x1001329c8 <_render.TerminalRenderer.drawPane+0x450c>
1001328cc:     	ldrb	w10, [x20, #0x38]
1001328d0:     	mov	x9, x23
1001328d4:     	cbz	w10, 0x1001329c8 <_render.TerminalRenderer.drawPane+0x450c>
1001328d8:     	ldr	w10, [x20, #0x28]
1001328dc:     	ldr	x9, [x20, #0x30]
1001328e0:     	ldrb	w12, [x20, #0x3d]
1001328e4:     	ldr	w11, [x8, #0xfc]
1001328e8:     	ldr	w13, [sp, #0x1e0]
1001328ec:     	add	w11, w11, w13
1001328f0:     	tbz	w12, #0x0, 0x100132940 <_render.TerminalRenderer.drawPane+0x4484>
1001328f4:     	cmp	w9, w10
1001328f8:     	csel	w12, w9, w10, lo
1001328fc:     	csel	w9, w9, w10, hi
100132900:     	cmp	w11, w12
100132904:     	ccmp	w11, w9, #0x2, hs
100132908:     	mov	x9, x23
10013290c:     	b.hi	0x1001329c8 <_render.TerminalRenderer.drawPane+0x450c>
100132910:     	ldr	q0, [x23]
100132914:     	str	q0, [sp, #0x3920]
100132918:     	ldr	q0, [x23, #0x10]
10013291c:     	str	q0, [sp, #0x3930]
100132920:     	add	x10, sp, #0x3, lsl #12  ; =0x3000
100132924:     	add	x10, x10, #0x900
100132928:     	ldrh	w9, [x10, #0x20]
10013292c:     	eor	w9, w9, #0x10
100132930:     	strh	w9, [x10, #0x20]
100132934:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
100132938:     	add	x9, x9, #0x920
10013293c:     	b	0x1001329c8 <_render.TerminalRenderer.drawPane+0x450c>
100132940:     	ldr	w12, [x20, #0x2c]
100132944:     	lsr	x13, x9, #32
100132948:     	cmp	w10, w9
10013294c:     	b.lo	0x100132964 <_render.TerminalRenderer.drawPane+0x44a8>
100132950:     	cmp	w10, w9
100132954:     	b.ne	0x100132988 <_render.TerminalRenderer.drawPane+0x44cc>
100132958:     	and	w14, w12, #0xffff
10013295c:     	cmp	w14, w13, uxth
100132960:     	b.hs	0x100132988 <_render.TerminalRenderer.drawPane+0x44cc>
100132964:     	mov	x0, x13
100132968:     	mov	x13, x12
10013296c:     	mov	x12, x0
100132970:     	mov	x14, x10
100132974:     	mov	x10, x9
100132978:     	mov	x9, x23
10013297c:     	cmp	w11, w14
100132980:     	b.hs	0x100132998 <_render.TerminalRenderer.drawPane+0x44dc>
100132984:     	b	0x1001329c8 <_render.TerminalRenderer.drawPane+0x450c>
100132988:     	mov	x14, x9
10013298c:     	mov	x9, x23
100132990:     	cmp	w11, w14
100132994:     	b.lo	0x1001329c8 <_render.TerminalRenderer.drawPane+0x450c>
100132998:     	and	w9, w28, #0xffff
10013299c:     	cmp	w9, w13, uxth
1001329a0:     	ccmp	w11, w14, #0x0, lo
1001329a4:     	ccmp	w10, w11, #0x0, ne
1001329a8:     	mov	x9, x23
1001329ac:     	b.lo	0x1001329c8 <_render.TerminalRenderer.drawPane+0x450c>
1001329b0:     	cmp	w10, w11
1001329b4:     	b.ne	0x100132910 <_render.TerminalRenderer.drawPane+0x4454>
1001329b8:     	and	w9, w28, #0xffff
1001329bc:     	cmp	w9, w12, uxth
1001329c0:     	mov	x9, x23
1001329c4:     	b.ls	0x100132910 <_render.TerminalRenderer.drawPane+0x4454>
1001329c8:     	ldrb	w10, [x9, #0x1f]
1001329cc:     	ldrh	w11, [x20, #0x18]
1001329d0:     	ldrh	w12, [x20, #0x1a]
1001329d4:     	add	w11, w11, w28, uxth
1001329d8:     	ldr	x13, [sp, #0x250]
1001329dc:     	add	w12, w12, w13
1001329e0:     	cmp	w10, #0x1
1001329e4:     	csinc	w10, w10, wzr, hi
1001329e8:     	ldrh	w13, [x20, #0x1c]
1001329ec:     	ldrh	w8, [x8, #0x50]
1001329f0:     	cmp	w13, w8
1001329f4:     	csel	w8, w13, w8, lo
1001329f8:     	sub	w8, w8, w28
1001329fc:     	and	w8, w8, #0xffff
100132a00:     	cmp	w10, w8
100132a04:     	csel	w10, w10, w8, lo
100132a08:     	ldrh	w8, [x22, #0x4]
100132a0c:     	ldrh	w13, [x22, #0x6]
100132a10:     	ldr	x15, [sp, #0x260]
100132a14:     	ldp	w15, w14, [x15]
100132a18:     	madd	w11, w8, w11, w15
100132a1c:     	ucvtf	s13, w11
100132a20:     	madd	w11, w13, w12, w14
100132a24:     	ucvtf	s14, w11
100132a28:     	mul	w10, w10, w8
100132a2c:     	ucvtf	s0, w10
100132a30:     	str	s0, [sp, #0x2a0]
100132a34:     	ucvtf	s10, w13
100132a38:     	ldr	x10, [sp, #0x2b8]
100132a3c:     	add	x20, x10, x19
100132a40:     	ldrb	w10, [x20, #0x38]
100132a44:     	cmp	w10, #0x1
100132a48:     	b.ne	0x100132ab4 <_render.TerminalRenderer.drawPane+0x45f8>
100132a4c:     	ldr	s0, [x20, #0x8]
100132a50:     	fcmp	s0, s13
100132a54:     	b.ne	0x100132ab4 <_render.TerminalRenderer.drawPane+0x45f8>
100132a58:     	ldr	x10, [sp, #0x2b8]
100132a5c:     	add	x10, x10, x19
100132a60:     	ldr	s0, [x10, #0xc]
100132a64:     	fcmp	s0, s14
100132a68:     	b.ne	0x100132ab4 <_render.TerminalRenderer.drawPane+0x45f8>
100132a6c:     	ldr	s0, [x10, #0x10]
100132a70:     	ldr	s1, [sp, #0x2a0]
100132a74:     	fcmp	s0, s1
100132a78:     	b.ne	0x100132ab4 <_render.TerminalRenderer.drawPane+0x45f8>
100132a7c:     	ldr	x10, [sp, #0x2b8]
100132a80:     	add	x10, x10, x19
100132a84:     	ldr	s0, [x10, #0x14]
100132a88:     	fcmp	s0, s10
100132a8c:     	b.ne	0x100132ab4 <_render.TerminalRenderer.drawPane+0x45f8>
100132a90:     	ldur	q0, [x10, #0x18]
100132a94:     	ldur	q1, [x10, #0x28]
100132a98:     	ldp	q2, q3, [x9]
100132a9c:     	eor.16b	v0, v2, v0
100132aa0:     	eor.16b	v1, v3, v1
100132aa4:     	orr.16b	v0, v1, v0
100132aa8:     	umaxv.16b	b0, v0
100132aac:     	fmov	w10, s0
100132ab0:     	cbz	w10, 0x1001334c8 <_render.TerminalRenderer.drawPane+0x500c>
100132ab4:     	ldp	q0, q1, [x9]
100132ab8:     	str	q1, [sp, #0xd10]
100132abc:     	str	q0, [sp, #0xd00]
100132ac0:     	ldp	q1, q0, [x9]
100132ac4:     	str	q1, [sp, #0x500]
100132ac8:     	str	q0, [sp, #0x510]
100132acc:     	str	xzr, [x30, #0xc0]
100132ad0:     	ldrb	w9, [sp, #0x500]
100132ad4:     	tbnz	w9, #0x4, 0x100132b58 <_render.TerminalRenderer.drawPane+0x469c>
100132ad8:     	ldrb	w11, [sp, #0x506]
100132adc:     	ldrb	w10, [sp, #0x507]
100132ae0:     	ldrb	w12, [sp, #0x508]
100132ae4:     	ldrb	w13, [sp, #0x509]
100132ae8:     	ldr	x9, [sp, #0x228]
100132aec:     	ldr	q0, [x9]
100132af0:     	str	q0, [sp, #0x3720]
100132af4:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
100132af8:     	add	x9, x9, #0x720
100132afc:     	cmp	w11, #0x2
100132b00:     	b.eq	0x100132b88 <_render.TerminalRenderer.drawPane+0x46cc>
100132b04:     	cmp	w11, #0x1
100132b08:     	b.ne	0x100132bb8 <_render.TerminalRenderer.drawPane+0x46fc>
100132b0c:     	subs	w9, w10, #0x10
100132b10:     	b.hs	0x100132be8 <_render.TerminalRenderer.drawPane+0x472c>
100132b14:     	mov	w9, w10
100132b18:     	add	x9, x9, w10, uxtw #1
100132b1c:     	ldr	x10, [sp, #0x1c0]
100132b20:     	add	x9, x10, x9
100132b24:     	ldr	b0, [x9]
100132b28:     	ucvtf	s0, s0
100132b2c:     	mov	w10, #0x437f0000        ; =1132396544
100132b30:     	fmov	s1, w10
100132b34:     	fdiv	s3, s0, s1
100132b38:     	ldr	b0, [x9, #0x1]
100132b3c:     	ucvtf	s0, s0
100132b40:     	fdiv	s0, s0, s1
100132b44:     	str	s3, [sp, #0x4b0]
100132b48:     	str	s0, [sp, #0x4b4]
100132b4c:     	ldr	b0, [x9, #0x2]
100132b50:     	ucvtf	s0, s0
100132b54:     	b	0x100132bac <_render.TerminalRenderer.drawPane+0x46f0>
100132b58:     	ldrb	w11, [sp, #0x502]
100132b5c:     	ldrb	w10, [sp, #0x503]
100132b60:     	ldrb	w12, [sp, #0x504]
100132b64:     	ldrb	w13, [sp, #0x505]
100132b68:     	ldr	x14, [sp, #0x290]
100132b6c:     	add	x9, x14, #0x10, lsl #12 ; =0x10000
100132b70:     	ldr	q0, [x9, #0x6ba0]
100132b74:     	str	q0, [sp, #0x3900]
100132b78:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
100132b7c:     	add	x9, x9, #0x900
100132b80:     	cmp	w11, #0x2
100132b84:     	b.ne	0x100132b04 <_render.TerminalRenderer.drawPane+0x4648>
100132b88:     	ucvtf	s0, w10
100132b8c:     	mov	w9, #0x437f0000         ; =1132396544
100132b90:     	fmov	s1, w9
100132b94:     	fdiv	s3, s0, s1
100132b98:     	ucvtf	s0, w12
100132b9c:     	fdiv	s0, s0, s1
100132ba0:     	str	s3, [sp, #0x4b0]
100132ba4:     	str	s0, [sp, #0x4b4]
100132ba8:     	ucvtf	s0, w13
100132bac:     	fdiv	s0, s0, s1
100132bb0:     	str	s0, [sp, #0x4b8]
100132bb4:     	b	0x100132d00 <_render.TerminalRenderer.drawPane+0x4844>
100132bb8:     	ldr	s3, [x9]
100132bbc:     	ldp	s11, s9, [x9, #0x4]
100132bc0:     	ldr	s8, [x9, #0xc]
100132bc4:     	ucvtf	s12, w8
100132bc8:     	ldrb	w8, [x30, #0xd8]
100132bcc:     	cbnz	w8, 0x100132d20 <_render.TerminalRenderer.drawPane+0x4864>
100132bd0:     	ldur	q0, [x30, #0xa8]
100132bd4:     	str	q0, [sp, #0x4b0]
100132bd8:     	ldr	x8, [x30, #0xc8]
100132bdc:     	cbz	x8, 0x100132c88 <_render.TerminalRenderer.drawPane+0x47cc>
100132be0:     	mov	x8, #0x0                ; =0
100132be4:     	b	0x100132cb8 <_render.TerminalRenderer.drawPane+0x47fc>
100132be8:     	cmp	w10, #0xe8
100132bec:     	b.hs	0x100132cd0 <_render.TerminalRenderer.drawPane+0x4814>
100132bf0:     	and	w10, w9, #0xff
100132bf4:     	mov	w11, #0x39              ; =57
100132bf8:     	mul	w11, w10, w11
100132bfc:     	lsr	w11, w11, #11
100132c00:     	mov	w12, #0x28              ; =40
100132c04:     	mov	w13, #0x37              ; =55
100132c08:     	madd	w11, w11, w12, w13
100132c0c:     	cmp	w9, #0x24
100132c10:     	csel	w11, wzr, w11, lo
100132c14:     	and	w11, w11, #0xff
100132c18:     	mov	w12, #0xab              ; =171
100132c1c:     	mul	w10, w10, w12
100132c20:     	lsr	w10, w10, #10
100132c24:     	ucvtf	s0, w11
100132c28:     	mov	w11, #0x437f0000        ; =1132396544
100132c2c:     	fmov	s1, w11
100132c30:     	fdiv	s3, s0, s1
100132c34:     	fmov	s0, w10
100132c38:     	mov.s	v0[1], w9
100132c3c:     	movi	d1, #0x0000ff000000ff
100132c40:     	and.8b	v0, v0, v1
100132c44:     	mov	w9, #0xaaab             ; =43691
100132c48:     	movk	w9, #0x2aaa, lsl #16
100132c4c:     	dup.2s	v1, w9
100132c50:     	umull.2d	v1, v0, v1
100132c54:     	shrn.2s	v1, v1, #0x20
100132c58:     	movi.2s	v2, #0x6
100132c5c:     	mls.2s	v0, v1, v2
100132c60:     	movi.2s	v1, #0x37
100132c64:     	movi.2s	v2, #0x28
100132c68:     	mla.2s	v1, v0, v2
100132c6c:     	cmeq.2s	v0, v0, #0
100132c70:     	bic.8b	v0, v1, v0
100132c74:     	bic.2s	v0, #0x3, lsl #8
100132c78:     	ucvtf.2s	v0, v0
100132c7c:     	dup.2s	v1, w11
100132c80:     	fdiv.2s	v0, v0, v1
100132c84:     	b	0x100132cf4 <_render.TerminalRenderer.drawPane+0x4838>
100132c88:     	str	q3, [sp, #0x230]
100132c8c:     	add	x0, x30, #0xb8
100132c90:     	add	x1, sp, #0x4b0
100132c94:     	mov	w2, #0x2                ; =2
100132c98:     	mov	x22, x30
100132c9c:     	bl	0x1001aece0 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
100132ca0:     	ands	w0, w0, #0xffff
100132ca4:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
100132ca8:     	ldr	x8, [x22, #0xc0]
100132cac:     	mov	x30, x22
100132cb0:     	ldr	x22, [sp, #0x280]
100132cb4:     	ldr	q3, [sp, #0x230]
100132cb8:     	add	x9, x8, #0x1
100132cbc:     	str	x9, [x30, #0xc0]
100132cc0:     	ldr	x9, [x30, #0xb8]
100132cc4:     	mov	w10, #0x50              ; =80
100132cc8:     	madd	x8, x8, x10, x9
100132ccc:     	b	0x100132d34 <_render.TerminalRenderer.drawPane+0x4878>
100132cd0:     	mov	w9, #0xa                ; =10
100132cd4:     	mov	w11, #-0x8              ; =-8
100132cd8:     	madd	w9, w10, w9, w11
100132cdc:     	and	w9, w9, #0xfe
100132ce0:     	ucvtf	s0, w9
100132ce4:     	mov	w9, #0x437f0000         ; =1132396544
100132ce8:     	fmov	s1, w9
100132cec:     	fdiv	s3, s0, s1
100132cf0:     	dup.2s	v0, v3[0]
100132cf4:     	str	s3, [sp, #0x4b0]
100132cf8:     	add	x9, sp, #0x4b0
100132cfc:     	stur	d0, [x9, #0x4]
100132d00:     	add	x9, sp, #0x4b0
100132d04:     	mov	w10, #0x3f800000        ; =1065353216
100132d08:     	str	w10, [x9, #0xc]
100132d0c:     	ldp	s11, s9, [x9, #0x4]
100132d10:     	ldr	s8, [x9, #0xc]
100132d14:     	ucvtf	s12, w8
100132d18:     	ldrb	w8, [x30, #0xd8]
100132d1c:     	cbz	w8, 0x100132bd0 <_render.TerminalRenderer.drawPane+0x4714>
100132d20:     	ldr	x8, [x30, #0xd0]
100132d24:     	cbz	x8, 0x100132d60 <_render.TerminalRenderer.drawPane+0x48a4>
100132d28:     	mov	w8, #0x1                ; =1
100132d2c:     	str	x8, [x30, #0xc0]
100132d30:     	ldr	x8, [x30, #0xb8]
100132d34:     	stp	s13, s14, [x8]
100132d38:     	stp	s12, s10, [x8, #0x8]
100132d3c:     	movi.4s	v0, #0x3a, lsl #24
100132d40:     	str	q0, [x8, #0x10]
100132d44:     	stp	s3, s11, [x8, #0x20]
100132d48:     	stp	s9, s8, [x8, #0x28]
100132d4c:     	movi.2d	v0, #0000000000000000
100132d50:     	stp	q0, q0, [x8, #0x30]
100132d54:     	ldrb	w8, [sp, #0x51f]
100132d58:     	cbnz	w8, 0x100132d74 <_render.TerminalRenderer.drawPane+0x48b8>
100132d5c:     	b	0x1001333ec <_render.TerminalRenderer.drawPane+0x4f30>
100132d60:     	ldr	x8, [x30, #0xe0]
100132d64:     	add	x8, x8, #0x1
100132d68:     	str	x8, [x30, #0xe0]
100132d6c:     	ldrb	w8, [sp, #0x51f]
100132d70:     	cbz	w8, 0x1001333ec <_render.TerminalRenderer.drawPane+0x4f30>
100132d74:     	ldrh	w8, [sp, #0x500]
100132d78:     	tbnz	w8, #0x5, 0x1001333ec <_render.TerminalRenderer.drawPane+0x4f30>
100132d7c:     	tbnz	w8, #0x4, 0x100132e04 <_render.TerminalRenderer.drawPane+0x4948>
100132d80:     	ldrb	w11, [sp, #0x502]
100132d84:     	ldrb	w10, [sp, #0x503]
100132d88:     	ldrb	w12, [sp, #0x504]
100132d8c:     	ldrb	w13, [sp, #0x505]
100132d90:     	ldr	x14, [sp, #0x290]
100132d94:     	add	x9, x14, #0x10, lsl #12 ; =0x10000
100132d98:     	ldr	q0, [x9, #0x6ba0]
100132d9c:     	str	q0, [sp, #0x37e0]
100132da0:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
100132da4:     	add	x9, x9, #0x7e0
100132da8:     	cmp	w11, #0x2
100132dac:     	b.eq	0x100132e2c <_render.TerminalRenderer.drawPane+0x4970>
100132db0:     	cmp	w11, #0x1
100132db4:     	b.ne	0x100132e5c <_render.TerminalRenderer.drawPane+0x49a0>
100132db8:     	subs	w9, w10, #0x10
100132dbc:     	b.hs	0x100132e64 <_render.TerminalRenderer.drawPane+0x49a8>
100132dc0:     	mov	w9, w10
100132dc4:     	add	x9, x9, w10, uxtw #1
100132dc8:     	ldr	x10, [sp, #0x1c0]
100132dcc:     	add	x9, x10, x9
100132dd0:     	ldr	b0, [x9]
100132dd4:     	ucvtf	s0, s0
100132dd8:     	mov	w10, #0x437f0000        ; =1132396544
100132ddc:     	fmov	s1, w10
100132de0:     	fdiv	s4, s0, s1
100132de4:     	ldr	b0, [x9, #0x1]
100132de8:     	ucvtf	s0, s0
100132dec:     	fdiv	s0, s0, s1
100132df0:     	str	s4, [sp, #0x4b0]
100132df4:     	str	s0, [sp, #0x4b4]
100132df8:     	ldr	b0, [x9, #0x2]
100132dfc:     	ucvtf	s0, s0
100132e00:     	b	0x100132e50 <_render.TerminalRenderer.drawPane+0x4994>
100132e04:     	ldrb	w11, [sp, #0x506]
100132e08:     	ldrb	w10, [sp, #0x507]
100132e0c:     	ldrb	w12, [sp, #0x508]
100132e10:     	ldrb	w13, [sp, #0x509]
100132e14:     	ldr	x9, [sp, #0x228]
100132e18:     	ldr	q0, [x9]
100132e1c:     	str	q0, [sp, #0x460]
100132e20:     	add	x9, sp, #0x460
100132e24:     	cmp	w11, #0x2
100132e28:     	b.ne	0x100132db0 <_render.TerminalRenderer.drawPane+0x48f4>
100132e2c:     	ucvtf	s0, w10
100132e30:     	mov	w9, #0x437f0000         ; =1132396544
100132e34:     	fmov	s1, w9
100132e38:     	fdiv	s4, s0, s1
100132e3c:     	ucvtf	s0, w12
100132e40:     	fdiv	s0, s0, s1
100132e44:     	str	s4, [sp, #0x4b0]
100132e48:     	str	s0, [sp, #0x4b4]
100132e4c:     	ucvtf	s0, w13
100132e50:     	fdiv	s0, s0, s1
100132e54:     	str	s0, [sp, #0x4b8]
100132e58:     	b	0x100132f34 <_render.TerminalRenderer.drawPane+0x4a78>
100132e5c:     	ldr	s4, [x9]
100132e60:     	b	0x100132f40 <_render.TerminalRenderer.drawPane+0x4a84>
100132e64:     	cmp	w10, #0xe8
100132e68:     	b.hs	0x100132f04 <_render.TerminalRenderer.drawPane+0x4a48>
100132e6c:     	and	w10, w9, #0xff
100132e70:     	mov	w11, #0x39              ; =57
100132e74:     	mul	w11, w10, w11
100132e78:     	lsr	w11, w11, #11
100132e7c:     	mov	w12, #0x28              ; =40
100132e80:     	mov	w13, #0x37              ; =55
100132e84:     	madd	w11, w11, w12, w13
100132e88:     	cmp	w9, #0x24
100132e8c:     	csel	w11, wzr, w11, lo
100132e90:     	and	w11, w11, #0xff
100132e94:     	mov	w12, #0xab              ; =171
100132e98:     	mul	w10, w10, w12
100132e9c:     	lsr	w10, w10, #10
100132ea0:     	ucvtf	s0, w11
100132ea4:     	mov	w11, #0x437f0000        ; =1132396544
100132ea8:     	fmov	s1, w11
100132eac:     	fdiv	s4, s0, s1
100132eb0:     	fmov	s0, w10
100132eb4:     	mov.s	v0[1], w9
100132eb8:     	movi	d1, #0x0000ff000000ff
100132ebc:     	and.8b	v0, v0, v1
100132ec0:     	mov	w9, #0xaaab             ; =43691
100132ec4:     	movk	w9, #0x2aaa, lsl #16
100132ec8:     	dup.2s	v1, w9
100132ecc:     	umull.2d	v1, v0, v1
100132ed0:     	shrn.2s	v1, v1, #0x20
100132ed4:     	movi.2s	v2, #0x6
100132ed8:     	mls.2s	v0, v1, v2
100132edc:     	movi.2s	v1, #0x37
100132ee0:     	movi.2s	v2, #0x28
100132ee4:     	mla.2s	v1, v0, v2
100132ee8:     	cmeq.2s	v0, v0, #0
100132eec:     	bic.8b	v0, v1, v0
100132ef0:     	bic.2s	v0, #0x3, lsl #8
100132ef4:     	ucvtf.2s	v0, v0
100132ef8:     	dup.2s	v1, w11
100132efc:     	fdiv.2s	v0, v0, v1
100132f00:     	b	0x100132f28 <_render.TerminalRenderer.drawPane+0x4a6c>
100132f04:     	mov	w9, #0xa                ; =10
100132f08:     	mov	w11, #-0x8              ; =-8
100132f0c:     	madd	w9, w10, w9, w11
100132f10:     	and	w9, w9, #0xfe
100132f14:     	ucvtf	s0, w9
100132f18:     	mov	w9, #0x437f0000         ; =1132396544
100132f1c:     	fmov	s1, w9
100132f20:     	fdiv	s4, s0, s1
100132f24:     	dup.2s	v0, v4[0]
100132f28:     	str	s4, [sp, #0x4b0]
100132f2c:     	add	x9, sp, #0x4b0
100132f30:     	stur	d0, [x9, #0x4]
100132f34:     	add	x9, sp, #0x4b0
100132f38:     	mov	w10, #0x3f800000        ; =1065353216
100132f3c:     	str	w10, [x9, #0xc]
100132f40:     	ldp	s12, s11, [x9, #0x4]
100132f44:     	ldr	s0, [x9, #0xc]
100132f48:     	fmul	s1, s0, s15
100132f4c:     	tst	w8, #0x4
100132f50:     	fcsel	s8, s0, s1, eq
100132f54:     	ldrb	w10, [sp, #0x51e]
100132f58:     	ldr	s0, [x22]
100132f5c:     	ldrh	w9, [x22, #0x8]
100132f60:     	ldr	h2, [x22, #0x4]
100132f64:     	ldr	h1, [x22, #0x6]
100132f68:     	and	w11, w8, #0x1
100132f6c:     	strb	w11, [sp, #0x3a0]
100132f70:     	ubfx	w11, w8, #1, #1
100132f74:     	add	x13, sp, #0x3, lsl #12  ; =0x3000
100132f78:     	add	x13, x13, #0x900
100132f7c:     	strb	w11, [x13, #0xb0]
100132f80:     	add	x22, sp, #0x3, lsl #12  ; =0x3000
100132f84:     	add	x22, x22, #0x720
100132f88:     	strb	wzr, [x22, #0x1c0]
100132f8c:     	subs	x11, x10, #0x1
100132f90:     	str	q4, [sp, #0x230]
100132f94:     	b.ne	0x100133040 <_render.TerminalRenderer.drawPane+0x4b84>
100132f98:     	ldrb	w12, [sp, #0x50e]
100132f9c:     	cmp	w12, #0x20
100132fa0:     	b.ne	0x100133040 <_render.TerminalRenderer.drawPane+0x4b84>
100132fa4:     	ldr	x12, [sp, #0x1f0]
100132fa8:     	ldrb	w12, [x12, x11]
100132fac:     	adrp	x14, 0x100687000 <___anon_33682+0x119f>
100132fb0:     	add	x14, x14, #0xee4
100132fb4:     	ldrb	w11, [x14, x11]
100132fb8:     	cmp	w12, w11
100132fbc:     	b.ne	0x100133040 <_render.TerminalRenderer.drawPane+0x4b84>
100132fc0:     	tst	w8, #0x700
100132fc4:     	b.eq	0x1001330dc <_render.TerminalRenderer.drawPane+0x4c20>
100132fc8:     	fmov	d9, d8
100132fcc:     	add	x8, sp, #0x4b0
100132fd0:     	ldur	w8, [x8, #0x5a]
100132fd4:     	str	s11, [sp, #0x210]
100132fd8:     	str	s12, [sp, #0x200]
100132fdc:     	fmov	d3, d4
100132fe0:     	ands	w9, w8, #0xff
100132fe4:     	b.eq	0x100133240 <_render.TerminalRenderer.drawPane+0x4d84>
100132fe8:     	cmp	w9, #0x2
100132fec:     	b.ne	0x1001330e4 <_render.TerminalRenderer.drawPane+0x4c28>
100132ff0:     	ubfx	w9, w8, #8, #8
100132ff4:     	dup.2s	v0, w8
100132ff8:     	adrp	x8, 0x1001ff000 <__ZL18_hb_ucd_dm1_p2_map+0x16e>
100132ffc:     	ldr	d1, [x8, #0x3d8]
100133000:     	ucvtf	s2, w9
100133004:     	ushl.2s	v0, v0, v1
100133008:     	mov	w8, #0x437f0000         ; =1132396544
10013300c:     	fmov	s1, w8
100133010:     	fdiv	s3, s2, s1
100133014:     	bic.2s	v0, #0xff, lsl #8
100133018:     	dup.2s	v1, w8
10013301c:     	ucvtf.2s	v0, v0
100133020:     	fdiv.2s	v0, v0, v1
100133024:     	str	d0, [sp, #0x3890]
100133028:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10013302c:     	add	x8, x8, #0x700
100133030:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
100133034:     	add	x9, x9, #0x890
100133038:     	ldr	x10, [sp, #0x1a8]
10013303c:     	b	0x10013322c <_render.TerminalRenderer.drawPane+0x4d70>
100133040:     	fneg	s3, s0
100133044:     	ucvtf	s2, s2
100133048:     	ucvtf	s1, s1
10013304c:     	ldr	x8, [sp, #0x1f0]
100133050:     	str	x8, [sp, #0xf00]
100133054:     	str	x10, [sp, #0xf08]
100133058:     	fadd	s0, s0, s14
10013305c:     	str	s13, [sp, #0xf10]
100133060:     	str	s0, [sp, #0xf14]
100133064:     	str	s4, [sp, #0xf18]
100133068:     	str	s12, [sp, #0xf1c]
10013306c:     	str	s11, [sp, #0xf20]
100133070:     	str	s8, [sp, #0xf24]
100133074:     	str	wzr, [sp, #0xf28]
100133078:     	str	s3, [sp, #0xf2c]
10013307c:     	str	s2, [sp, #0xf30]
100133080:     	str	s1, [sp, #0xf34]
100133084:     	mov	w8, #0x1                ; =1
100133088:     	strb	w8, [sp, #0xf38]
10013308c:     	strh	w9, [sp, #0xf3c]
100133090:     	ldrb	w8, [sp, #0x3a0]
100133094:     	strb	w8, [sp, #0xf3e]
100133098:     	ldrb	w8, [x13, #0xb0]
10013309c:     	strb	w8, [sp, #0xf3f]
1001330a0:     	ldrb	w8, [x22, #0x1c0]
1001330a4:     	strb	w8, [sp, #0xf40]
1001330a8:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
1001330ac:     	add	x0, x0, #0x750
1001330b0:     	add	x2, sp, #0xf00
1001330b4:     	add	x3, x30, #0xa8
1001330b8:     	ldr	x1, [sp, #0x290]
1001330bc:     	bl	0x100127dc8 <_text.GlyphAtlas.place>
1001330c0:     	ldrh	w0, [x22, #0x34]
1001330c4:     	cbnz	w0, 0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
1001330c8:     	ldrh	w8, [sp, #0x500]
1001330cc:     	ldr	x30, [sp, #0x298]
1001330d0:     	ldr	q4, [sp, #0x230]
1001330d4:     	tst	w8, #0x700
1001330d8:     	b.ne	0x100132fc8 <_render.TerminalRenderer.drawPane+0x4b0c>
1001330dc:     	tbnz	w8, #0x6, 0x100133330 <_render.TerminalRenderer.drawPane+0x4e74>
1001330e0:     	b	0x1001333ec <_render.TerminalRenderer.drawPane+0x4f30>
1001330e4:     	ubfx	w9, w8, #8, #8
1001330e8:     	cmp	w9, #0x10
1001330ec:     	b.hs	0x100133148 <_render.TerminalRenderer.drawPane+0x4c8c>
1001330f0:     	ubfx	x8, x8, #8, #4
1001330f4:     	add	x8, x8, x8, lsl #1
1001330f8:     	ldr	x9, [sp, #0x1c0]
1001330fc:     	add	x8, x9, x8
100133100:     	ldr	b0, [x8]
100133104:     	ucvtf	s0, s0
100133108:     	mov	w9, #0x437f0000         ; =1132396544
10013310c:     	fmov	s1, w9
100133110:     	fdiv	s3, s0, s1
100133114:     	ldr	b0, [x8, #0x1]
100133118:     	ucvtf	s0, s0
10013311c:     	fdiv	s0, s0, s1
100133120:     	str	s0, [sp, #0x3700]
100133124:     	ldr	b0, [x8, #0x2]
100133128:     	ucvtf	s0, s0
10013312c:     	fdiv	s0, s0, s1
100133130:     	str	s0, [sp, #0x3f0]
100133134:     	add	x8, sp, #0x3d0
100133138:     	add	x10, sp, #0x3f0
10013313c:     	add	x9, sp, #0x3, lsl #12   ; =0x3000
100133140:     	add	x9, x9, #0x700
100133144:     	b	0x10013322c <_render.TerminalRenderer.drawPane+0x4d70>
100133148:     	ubfx	w9, w8, #8, #8
10013314c:     	lsr	w8, w8, #8
100133150:     	cmp	w9, #0xe8
100133154:     	b.hs	0x1001331f4 <_render.TerminalRenderer.drawPane+0x4d38>
100133158:     	sub	w8, w8, #0x10
10013315c:     	and	w9, w8, #0xff
100133160:     	mov	w10, #0x39              ; =57
100133164:     	mul	w10, w9, w10
100133168:     	lsr	w10, w10, #11
10013316c:     	mov	w11, #0x28              ; =40
100133170:     	mov	w12, #0x37              ; =55
100133174:     	madd	w10, w10, w11, w12
100133178:     	cmp	w9, #0x24
10013317c:     	csel	w10, wzr, w10, lo
100133180:     	and	w10, w10, #0xff
100133184:     	mov	w11, #0xab              ; =171
100133188:     	mul	w9, w9, w11
10013318c:     	lsr	w9, w9, #10
100133190:     	ucvtf	s0, w10
100133194:     	mov	w10, #0x437f0000        ; =1132396544
100133198:     	fmov	s1, w10
10013319c:     	fdiv	s3, s0, s1
1001331a0:     	fmov	s0, w9
1001331a4:     	mov.s	v0[1], w8
1001331a8:     	movi	d1, #0x0000ff000000ff
1001331ac:     	and.8b	v0, v0, v1
1001331b0:     	mov	w8, #0xaaab             ; =43691
1001331b4:     	movk	w8, #0x2aaa, lsl #16
1001331b8:     	dup.2s	v1, w8
1001331bc:     	umull.2d	v1, v0, v1
1001331c0:     	shrn.2s	v1, v1, #0x20
1001331c4:     	movi.2s	v2, #0x6
1001331c8:     	mls.2s	v0, v1, v2
1001331cc:     	movi.2s	v1, #0x37
1001331d0:     	movi.2s	v2, #0x28
1001331d4:     	mla.2s	v1, v0, v2
1001331d8:     	cmeq.2s	v0, v0, #0
1001331dc:     	bic.8b	v0, v1, v0
1001331e0:     	bic.2s	v0, #0x3, lsl #8
1001331e4:     	ucvtf.2s	v0, v0
1001331e8:     	dup.2s	v1, w10
1001331ec:     	fdiv.2s	v0, v0, v1
1001331f0:     	b	0x100133218 <_render.TerminalRenderer.drawPane+0x4d5c>
1001331f4:     	mov	w9, #0xa                ; =10
1001331f8:     	mov	w10, #-0x8              ; =-8
1001331fc:     	madd	w8, w8, w9, w10
100133200:     	and	w8, w8, #0xfe
100133204:     	ucvtf	s0, w8
100133208:     	mov	w8, #0x437f0000         ; =1132396544
10013320c:     	fmov	s1, w8
100133210:     	fdiv	s3, s0, s1
100133214:     	dup.2s	v0, v3[0]
100133218:     	str	d0, [sp, #0x4b0]
10013321c:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
100133220:     	add	x8, x8, #0x700
100133224:     	add	x9, sp, #0x4b0
100133228:     	ldr	x10, [sp, #0x1a0]
10013322c:     	mov	w11, #0x3f800000        ; =1065353216
100133230:     	str	w11, [x8]
100133234:     	ldr	s12, [x9]
100133238:     	fmov	s9, #1.00000000
10013323c:     	ldr	s11, [x10]
100133240:     	fadd	s0, s10, s14
100133244:     	fmov	s1, #-2.00000000
100133248:     	fadd	s15, s0, s1
10013324c:     	ldrb	w8, [x30, #0xd8]
100133250:     	cbz	w8, 0x100133288 <_render.TerminalRenderer.drawPane+0x4dcc>
100133254:     	ldr	x9, [x30, #0xd0]
100133258:     	ldr	x8, [x30, #0xc0]
10013325c:     	cmp	x8, x9
100133260:     	b.lo	0x1001332dc <_render.TerminalRenderer.drawPane+0x4e20>
100133264:     	ldr	x8, [x30, #0xe0]
100133268:     	add	x8, x8, #0x1
10013326c:     	str	x8, [x30, #0xe0]
100133270:     	fmov	s15, #0.50000000
100133274:     	ldr	s11, [sp, #0x210]
100133278:     	ldr	s12, [sp, #0x200]
10013327c:     	ldrh	w8, [sp, #0x500]
100133280:     	tbnz	w8, #0x6, 0x100133330 <_render.TerminalRenderer.drawPane+0x4e74>
100133284:     	b	0x1001333ec <_render.TerminalRenderer.drawPane+0x4f30>
100133288:     	ldur	q0, [x30, #0xa8]
10013328c:     	str	q0, [sp, #0x4b0]
100133290:     	ldp	x8, x9, [x30, #0xc0]
100133294:     	cmp	x9, x8
100133298:     	b.hi	0x1001332dc <_render.TerminalRenderer.drawPane+0x4e20>
10013329c:     	str	q3, [sp, #0x1b0]
1001332a0:     	add	x8, x8, #0x1
1001332a4:     	lsr	x9, x8, #1
1001332a8:     	add	x9, x9, #0x1
1001332ac:     	adds	x8, x8, x9
1001332b0:     	csinv	x2, x8, xzr, lo
1001332b4:     	add	x0, x30, #0xb8
1001332b8:     	add	x1, sp, #0x4b0
1001332bc:     	mov	x21, x30
1001332c0:     	bl	0x1001aece0 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
1001332c4:     	ands	w0, w0, #0xffff
1001332c8:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
1001332cc:     	ldr	x8, [x21, #0xc0]
1001332d0:     	mov	x30, x21
1001332d4:     	ldr	q4, [sp, #0x230]
1001332d8:     	ldr	q3, [sp, #0x1b0]
1001332dc:     	add	x9, x8, #0x1
1001332e0:     	str	x9, [x30, #0xc0]
1001332e4:     	ldr	x9, [x30, #0xb8]
1001332e8:     	mov	w10, #0x50              ; =80
1001332ec:     	madd	x8, x8, x10, x9
1001332f0:     	stp	s13, s15, [x8]
1001332f4:     	ldr	s0, [sp, #0x2a0]
1001332f8:     	str	s0, [x8, #0x8]
1001332fc:     	ldr	q0, [sp, #0x1d0]
100133300:     	stur	q0, [x8, #0xc]
100133304:     	mov	w9, #0x3a000000         ; =973078528
100133308:     	str	w9, [x8, #0x1c]
10013330c:     	stp	s3, s12, [x8, #0x20]
100133310:     	stp	s11, s9, [x8, #0x28]
100133314:     	movi.2d	v0, #0000000000000000
100133318:     	stp	q0, q0, [x8, #0x30]
10013331c:     	fmov	s15, #0.50000000
100133320:     	ldr	s11, [sp, #0x210]
100133324:     	ldr	s12, [sp, #0x200]
100133328:     	ldrh	w8, [sp, #0x500]
10013332c:     	tbz	w8, #0x6, 0x1001333ec <_render.TerminalRenderer.drawPane+0x4f30>
100133330:     	fmul	s0, s10, s15
100133334:     	fadd	s9, s0, s14
100133338:     	ldrb	w8, [x30, #0xd8]
10013333c:     	cbz	w8, 0x100133360 <_render.TerminalRenderer.drawPane+0x4ea4>
100133340:     	ldr	x9, [x30, #0xd0]
100133344:     	ldr	x8, [x30, #0xc0]
100133348:     	cmp	x8, x9
10013334c:     	b.lo	0x1001333ac <_render.TerminalRenderer.drawPane+0x4ef0>
100133350:     	ldr	x8, [x30, #0xe0]
100133354:     	add	x8, x8, #0x1
100133358:     	str	x8, [x30, #0xe0]
10013335c:     	b	0x1001333ec <_render.TerminalRenderer.drawPane+0x4f30>
100133360:     	ldur	q0, [x30, #0xa8]
100133364:     	str	q0, [sp, #0x4b0]
100133368:     	ldp	x8, x9, [x30, #0xc0]
10013336c:     	cmp	x9, x8
100133370:     	b.hi	0x1001333ac <_render.TerminalRenderer.drawPane+0x4ef0>
100133374:     	add	x8, x8, #0x1
100133378:     	lsr	x9, x8, #1
10013337c:     	add	x9, x9, #0x1
100133380:     	adds	x8, x8, x9
100133384:     	csinv	x2, x8, xzr, lo
100133388:     	add	x0, x30, #0xb8
10013338c:     	add	x1, sp, #0x4b0
100133390:     	mov	x21, x30
100133394:     	bl	0x1001aece0 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
100133398:     	ands	w0, w0, #0xffff
10013339c:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
1001333a0:     	ldr	x8, [x21, #0xc0]
1001333a4:     	mov	x30, x21
1001333a8:     	ldr	q4, [sp, #0x230]
1001333ac:     	add	x9, x8, #0x1
1001333b0:     	str	x9, [x30, #0xc0]
1001333b4:     	ldr	x9, [x30, #0xb8]
1001333b8:     	mov	w10, #0x50              ; =80
1001333bc:     	madd	x8, x8, x10, x9
1001333c0:     	stp	s13, s9, [x8]
1001333c4:     	ldr	s0, [sp, #0x2a0]
1001333c8:     	str	s0, [x8, #0x8]
1001333cc:     	ldr	q0, [sp, #0x1d0]
1001333d0:     	stur	q0, [x8, #0xc]
1001333d4:     	mov	w9, #0x3a000000         ; =973078528
1001333d8:     	str	w9, [x8, #0x1c]
1001333dc:     	stp	s4, s12, [x8, #0x20]
1001333e0:     	stp	s11, s8, [x8, #0x28]
1001333e4:     	movi.2d	v0, #0000000000000000
1001333e8:     	stp	q0, q0, [x8, #0x30]
1001333ec:     	ldp	x22, x27, [x30, #0xb8]
1001333f0:     	cmp	x27, #0x2
1001333f4:     	mov	w8, #0x2                ; =2
1001333f8:     	csel	x21, x27, x8, lo
1001333fc:     	ldp	q0, q1, [x22]
100133400:     	ldp	q2, q3, [x22, #0x20]
100133404:     	ldr	q4, [x22, #0x40]
100133408:     	stp	q3, q4, [x24, #0x30]
10013340c:     	stp	q1, q2, [x24, #0x10]
100133410:     	str	q0, [x24]
100133414:     	sub	w8, w21, #0x1
100133418:     	and	x9, x8, #0x3
10013341c:     	lsl	x2, x9, #4
100133420:     	bfi	x2, x8, #6, #2
100133424:     	add	x1, x22, #0x50
100133428:     	mov	x0, x26
10013342c:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
100133430:     	sub	x8, x27, x21
100133434:     	mov	w9, #0x50               ; =80
100133438:     	madd	x1, x21, x9, x22
10013343c:     	ldr	x22, [sp, #0x280]
100133440:     	add	x8, x8, x8, lsl #2
100133444:     	lsl	x2, x8, #4
100133448:     	mov	x0, x25
10013344c:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
100133450:     	ldr	x8, [sp, #0x2b8]
100133454:     	add	x8, x8, x19
100133458:     	strb	w27, [x8, #0x3c]
10013345c:     	str	xzr, [x8]
100133460:     	stp	s13, s14, [x8, #0x8]
100133464:     	ldr	s0, [sp, #0x2a0]
100133468:     	stp	s0, s10, [x8, #0x10]
10013346c:     	ldr	q0, [sp, #0xd00]
100133470:     	ldr	q1, [sp, #0xd10]
100133474:     	stur	q0, [x8, #0x18]
100133478:     	stur	q1, [x8, #0x28]
10013347c:     	mov	w9, #0x1                ; =1
100133480:     	strb	w9, [x20, #0x38]
100133484:     	ldr	s0, [x22, #0x1ac]
100133488:     	ldr	s1, [x24, #0x20]
10013348c:     	fcmp	s1, s0
100133490:     	b.ne	0x1001334b4 <_render.TerminalRenderer.drawPane+0x4ff8>
100133494:     	ldr	s0, [x22, #0x1b0]
100133498:     	ldr	s1, [x24, #0x24]
10013349c:     	fcmp	s1, s0
1001334a0:     	b.ne	0x1001334b4 <_render.TerminalRenderer.drawPane+0x4ff8>
1001334a4:     	ldr	s0, [x22, #0x1b4]
1001334a8:     	ldr	s1, [x24, #0x28]
1001334ac:     	fcmp	s1, s0
1001334b0:     	cset	w9, ne
1001334b4:     	strb	w9, [x8, #0x39]
1001334b8:     	ldr	x30, [sp, #0x298]
1001334bc:     	ldr	x8, [x30, #0x10]
1001334c0:     	add	x8, x8, #0x1
1001334c4:     	str	x8, [x30, #0x10]
1001334c8:     	ldr	x8, [sp, #0x2b8]
1001334cc:     	add	x8, x8, x19
1001334d0:     	ldrb	w8, [x8, #0x39]
1001334d4:     	cmp	w8, #0x1
1001334d8:     	ldr	x20, [sp, #0x278]
1001334dc:     	b.ne	0x100132898 <_render.TerminalRenderer.drawPane+0x43dc>
1001334e0:     	ldr	q0, [x24, #0x10]
1001334e4:     	str	q0, [sp, #0x2310]
1001334e8:     	ldr	q0, [x24, #0x20]
1001334ec:     	str	q0, [sp, #0x2320]
1001334f0:     	ldr	q0, [x24, #0x30]
1001334f4:     	str	q0, [sp, #0x2330]
1001334f8:     	ldr	q0, [x24, #0x40]
1001334fc:     	str	q0, [sp, #0x2340]
100133500:     	ldr	q0, [x24]
100133504:     	str	q0, [sp, #0x2300]
100133508:     	ldrb	w8, [x30, #0x98]
10013350c:     	cbz	w8, 0x100133530 <_render.TerminalRenderer.drawPane+0x5074>
100133510:     	ldr	x9, [x30, #0x90]
100133514:     	ldr	x8, [x30, #0x80]
100133518:     	cmp	x8, x9
10013351c:     	b.lo	0x10013285c <_render.TerminalRenderer.drawPane+0x43a0>
100133520:     	ldr	x8, [x30, #0xa0]
100133524:     	add	x8, x8, #0x1
100133528:     	str	x8, [x30, #0xa0]
10013352c:     	b	0x100132898 <_render.TerminalRenderer.drawPane+0x43dc>
100133530:     	mov	w8, #0x2958             ; =10584
100133534:     	movk	w8, #0x1, lsl #16
100133538:     	ldr	x9, [sp, #0x290]
10013353c:     	ldr	q0, [x9, x8]
100133540:     	str	q0, [sp, #0x4b0]
100133544:     	ldp	x8, x9, [x30, #0x80]
100133548:     	cmp	x9, x8
10013354c:     	b.hi	0x10013285c <_render.TerminalRenderer.drawPane+0x43a0>
100133550:     	add	x8, x8, #0x1
100133554:     	lsr	x9, x8, #1
100133558:     	add	x9, x9, #0x1
10013355c:     	adds	x8, x8, x9
100133560:     	csinv	x2, x8, xzr, lo
100133564:     	mov	w8, #0x2968             ; =10600
100133568:     	movk	w8, #0x1, lsl #16
10013356c:     	ldr	x9, [sp, #0x290]
100133570:     	add	x0, x9, x8
100133574:     	add	x1, sp, #0x4b0
100133578:     	bl	0x1001aece0 <_array_list.Aligned(Quad.Quad,null).ensureTotalCapacityPrecise>
10013357c:     	ands	w0, w0, #0xffff
100133580:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
100133584:     	ldr	x30, [sp, #0x298]
100133588:     	ldr	x8, [x30, #0x80]
10013358c:     	b	0x10013285c <_render.TerminalRenderer.drawPane+0x43a0>
100133590:     	ldr	x0, [sp, #0x290]
100133594:     	ldr	x19, [sp, #0x278]
100133598:     	mov	x1, x19
10013359c:     	ldp	x3, x2, [sp, #0x78]
1001335a0:     	mov	w4, #0x1                ; =1
1001335a4:     	bl	0x10012e174 <_render.TerminalRenderer.pushImages>
1001335a8:     	ands	w0, w0, #0xffff
1001335ac:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
1001335b0:     	ldr	x8, [sp, #0x280]
1001335b4:     	ldrb	w8, [x8, #0x249]
1001335b8:     	cmp	w8, #0x1
1001335bc:     	ldr	x2, [sp, #0x298]
1001335c0:     	ldr	x23, [sp, #0x140]
1001335c4:     	ldp	x22, x20, [sp, #0x60]
1001335c8:     	b.ne	0x10013371c <_render.TerminalRenderer.drawPane+0x5260>
1001335cc:     	ldr	x9, [x19]
1001335d0:     	ldr	w10, [x19, #0x28]
1001335d4:     	ldrb	w11, [x19, #0x3c]
1001335d8:     	ldrb	w12, [x19, #0x40]
1001335dc:     	ldrb	w14, [x19, #0x44]
1001335e0:     	cbz	w12, 0x1001335e8 <_render.TerminalRenderer.drawPane+0x512c>
1001335e4:     	tbz	w11, #0x0, 0x1001335f8 <_render.TerminalRenderer.drawPane+0x513c>
1001335e8:     	ldrh	w13, [x9, #0x100]
1001335ec:     	ldrh	w8, [x9, #0x102]
1001335f0:     	add	x15, x9, #0x104
1001335f4:     	b	0x100133634 <_render.TerminalRenderer.drawPane+0x5178>
1001335f8:     	ldr	w8, [x9, #0xfc]
1001335fc:     	subs	w8, w10, w8
100133600:     	b.lo	0x100133624 <_render.TerminalRenderer.drawPane+0x5168>
100133604:     	ldrh	w13, [x9, #0x52]
100133608:     	cmp	w8, w13
10013360c:     	b.hs	0x100133624 <_render.TerminalRenderer.drawPane+0x5168>
100133610:     	ldrh	w13, [x19, #0x2c]
100133614:     	mov	w15, #0x1               ; =1
100133618:     	strb	w15, [sp, #0x500]
10013361c:     	add	x15, sp, #0x500
100133620:     	b	0x100133634 <_render.TerminalRenderer.drawPane+0x5178>
100133624:     	mov	w13, #0x0               ; =0
100133628:     	mov	w8, #0x0                ; =0
10013362c:     	adrp	x15, 0x100537000 <___anon_12856+0x136a4>
100133630:     	add	x15, x15, #0xb94
100133634:     	tbnz	w14, #0x0, 0x10013371c <_render.TerminalRenderer.drawPane+0x5260>
100133638:     	ldrb	w14, [x19, #0x22]
10013363c:     	tbz	w14, #0x0, 0x10013371c <_render.TerminalRenderer.drawPane+0x5260>
100133640:     	ldrb	w14, [x15]
100133644:     	tbz	w14, #0x0, 0x10013371c <_render.TerminalRenderer.drawPane+0x5260>
100133648:     	ldrh	w14, [x19, #0x1c]
10013364c:     	ldrh	w15, [x9, #0x50]
100133650:     	cmp	w14, w15
100133654:     	csel	w14, w14, w15, lo
100133658:     	cmp	w13, w14
10013365c:     	b.hs	0x10013371c <_render.TerminalRenderer.drawPane+0x5260>
100133660:     	ldrh	w17, [x19, #0x1e]
100133664:     	ldrh	w16, [x9, #0x52]
100133668:     	cmp	w17, w16
10013366c:     	csel	w17, w17, w16, lo
100133670:     	cmp	w17, w8, uxth
100133674:     	b.ls	0x10013371c <_render.TerminalRenderer.drawPane+0x5260>
100133678:     	cbz	w13, 0x1001336a4 <_render.TerminalRenderer.drawPane+0x51e8>
10013367c:     	and	x17, x8, #0xffff
100133680:     	umull	x17, w15, w17
100133684:     	mov	w0, w13
100133688:     	ldr	x1, [x9, #0x30]
10013368c:     	add	x17, x1, x17, lsl #5
100133690:     	add	x17, x17, x0, lsl #5
100133694:     	ldrb	w17, [x17, #0x1f]
100133698:     	cmp	w17, #0x0
10013369c:     	cset	w17, eq
1001336a0:     	sub	w13, w13, w17
1001336a4:     	cbz	w12, 0x1001336ac <_render.TerminalRenderer.drawPane+0x51f0>
1001336a8:     	tbz	w11, #0x0, 0x100134734 <_render.TerminalRenderer.drawPane+0x6278>
1001336ac:     	ldrb	w12, [x9, #0x105]
1001336b0:     	and	x10, x8, #0xffff
1001336b4:     	umull	x10, w15, w10
1001336b8:     	and	x11, x13, #0xffff
1001336bc:     	ldr	x9, [x9, #0x30]
1001336c0:     	add	x9, x9, x10, lsl #5
1001336c4:     	add	x9, x9, x11, lsl #5
1001336c8:     	ldrb	w9, [x9, #0x1f]
1001336cc:     	ldrh	w11, [x19, #0x18]
1001336d0:     	ldrh	w10, [x19, #0x1a]
1001336d4:     	cmp	w9, #0x1
1001336d8:     	csinc	w9, w9, wzr, hi
1001336dc:     	sub	w14, w14, w13
1001336e0:     	and	w14, w14, #0xffff
1001336e4:     	cmp	w9, w14
1001336e8:     	csel	w9, w9, w14, lo
1001336ec:     	ldr	x14, [sp, #0x280]
1001336f0:     	ldrb	w14, [x14, #0x24a]
1001336f4:     	tbz	w14, #0x0, 0x100134560 <_render.TerminalRenderer.drawPane+0x60a4>
1001336f8:     	and	w12, w12, #0x7
1001336fc:     	cmp	w12, #0x1
100133700:     	b.le	0x100134748 <_render.TerminalRenderer.drawPane+0x628c>
100133704:     	cmp	w12, #0x2
100133708:     	b.eq	0x100134764 <_render.TerminalRenderer.drawPane+0x62a8>
10013370c:     	cmp	w12, #0x3
100133710:     	b.ne	0x100134560 <_render.TerminalRenderer.drawPane+0x60a4>
100133714:     	mov	w15, #0x2               ; =2
100133718:     	b	0x100134564 <_render.TerminalRenderer.drawPane+0x60a8>
10013371c:     	str	wzr, [sp, #0x1e0]
100133720:     	movi	d5, #0000000000000000
100133724:     	movi	d16, #0000000000000000
100133728:     	movi	d6, #0000000000000000
10013372c:     	str	xzr, [sp, #0x318]
100133730:     	str	xzr, [sp, #0x310]
100133734:     	mov	w8, #0x1                ; =1
100133738:     	str	w8, [sp, #0x2b8]
10013373c:     	strb	wzr, [sp, #0x30c]
100133740:     	movi	d7, #0000000000000000
100133744:     	movi	d0, #0000000000000000
100133748:     	str	s0, [sp, #0x148]
10013374c:     	strh	wzr, [sp, #0x308]
100133750:     	str	s0, [sp, #0x120]
100133754:     	str	s0, [sp, #0x118]
100133758:     	strb	wzr, [sp, #0x30a]
10013375c:     	str	s0, [sp, #0x1c8]
100133760:     	str	s0, [sp, #0x1c0]
100133764:     	ldr	x8, [sp, #0x138]
100133768:     	str	s5, [sp, #0x228]
10013376c:     	str	s6, [sp, #0x210]
100133770:     	str	s7, [sp, #0x200]
100133774:     	str	s16, [sp, #0x1f0]
100133778:     	cbz	w8, 0x10013446c <_render.TerminalRenderer.drawPane+0x5fb0>
10013377c:     	cbz	w23, 0x10013446c <_render.TerminalRenderer.drawPane+0x5fb0>
100133780:     	mov	x12, #0x0               ; =0
100133784:     	lsr	w13, w20, #16
100133788:     	ldr	x11, [sp, #0x280]
10013378c:     	ldrh	w8, [x11, #0x4]
100133790:     	ldr	w9, [x11, #0x17c]
100133794:     	and	w10, w20, #0xffff
100133798:     	madd	w9, w10, w8, w9
10013379c:     	ldrh	w10, [x11, #0x6]
1001337a0:     	ldr	w11, [x11, #0x180]
1001337a4:     	ucvtf	s17, w9
1001337a8:     	madd	w9, w13, w10, w11
1001337ac:     	ucvtf	s14, w9
1001337b0:     	mul	w9, w10, w22
1001337b4:     	ucvtf	s0, w9
1001337b8:     	ldr	x9, [sp, #0x38]
1001337bc:     	mul	w8, w9, w8
1001337c0:     	ucvtf	s1, w8
1001337c4:     	and	x8, x20, #0xffff
1001337c8:     	str	x8, [sp, #0x150]
1001337cc:     	fadd	s15, s1, s17
1001337d0:     	fadd	s12, s0, s14
1001337d4:     	str	x13, [sp, #0x168]
1001337d8:     	mov	w13, w13
1001337dc:     	mov	w14, #0x50              ; =80
1001337e0:     	str	s17, [sp, #0x1d0]
1001337e4:     	b	0x100133804 <_render.TerminalRenderer.drawPane+0x5348>
1001337e8:     	ldr	x12, [sp, #0x1a0]
1001337ec:     	add	x12, x12, #0x1
1001337f0:     	ldr	x13, [sp, #0x190]
1001337f4:     	add	x13, x13, #0x1
1001337f8:     	ldr	x8, [sp, #0x138]
1001337fc:     	cmp	x12, x8
100133800:     	b.eq	0x10013446c <_render.TerminalRenderer.drawPane+0x5fb0>
100133804:     	mov	x19, #0x0               ; =0
100133808:     	str	x12, [sp, #0x1a0]
10013380c:     	ldr	x8, [sp, #0x168]
100133810:     	add	w8, w12, w8
100133814:     	ldr	x11, [sp, #0x188]
100133818:     	ldrh	w9, [x11, #0x60]
10013381c:     	ldr	x12, [sp, #0x150]
100133820:     	umaddl	x8, w9, w8, x12
100133824:     	ldr	x10, [x11]
100133828:     	add	x15, x10, x8, lsl #6
10013382c:     	ldr	x10, [x11, #0x30]
100133830:     	madd	x16, x8, x14, x10
100133834:     	ldr	x8, [x11, #0x48]
100133838:     	str	x13, [sp, #0x190]
10013383c:     	madd	x9, x13, x9, x12
100133840:     	mov	w10, #0x6e0             ; =1760
100133844:     	madd	x26, x9, x10, x8
100133848:     	str	x15, [sp, #0x240]
10013384c:     	str	x16, [sp, #0x230]
100133850:     	b	0x100133864 <_render.TerminalRenderer.drawPane+0x53a8>
100133854:     	add	x19, x19, #0x1
100133858:     	add	x26, x26, #0x6e0
10013385c:     	cmp	x19, x23
100133860:     	b.eq	0x1001337e8 <_render.TerminalRenderer.drawPane+0x532c>
100133864:     	add	x20, x15, x19, lsl #6
100133868:     	ldrb	w8, [x20, #0x3c]
10013386c:     	cmp	w8, #0x2
100133870:     	b.lo	0x100133854 <_render.TerminalRenderer.drawPane+0x5398>
100133874:     	madd	x8, x19, x14, x16
100133878:     	ldr	w9, [sp, #0x2b8]
10013387c:     	tbnz	w9, #0x0, 0x100133980 <_render.TerminalRenderer.drawPane+0x54c4>
100133880:     	ldr	w9, [sp, #0x1e0]
100133884:     	tst	w9, #0x3
100133888:     	b.ne	0x100133980 <_render.TerminalRenderer.drawPane+0x54c4>
10013388c:     	ldp	s0, s1, [x20, #0x8]
100133890:     	ldr	s2, [sp, #0x1c0]
100133894:     	fcmp	s0, s2
100133898:     	ldr	s0, [sp, #0x1c8]
10013389c:     	fccmp	s1, s0, #0x0, eq
1001338a0:     	b.ne	0x100133980 <_render.TerminalRenderer.drawPane+0x54c4>
1001338a4:     	ldp	d0, d21, [x8]
1001338a8:     	ldr	q18, [x8, #0x10]
1001338ac:     	fmov	d20, d0
1001338b0:     	mov	s19, v0[1]
1001338b4:     	fadd	s1, s0, s21
1001338b8:     	mov	s8, v21[1]
1001338bc:     	fadd	s2, s19, s8
1001338c0:     	fcmp	s0, s17
1001338c4:     	fccmp	s19, s14, #0x8, ge
1001338c8:     	fccmp	s1, s15, #0x2, ge
1001338cc:     	fccmp	s2, s12, #0x2, ls
1001338d0:     	b.ls	0x100133938 <_render.TerminalRenderer.drawPane+0x547c>
1001338d4:     	fminnm	s1, s1, s15
1001338d8:     	fminnm	s2, s2, s12
1001338dc:     	fmaxnm	s20, s20, s17
1001338e0:     	fmaxnm	s19, s19, s14
1001338e4:     	fmaxnm	s1, s20, s1
1001338e8:     	fmaxnm	s2, s19, s2
1001338ec:     	fcmp	s21, #0.0
1001338f0:     	b.le	0x100133930 <_render.TerminalRenderer.drawPane+0x5474>
1001338f4:     	fcmp	s8, #0.0
1001338f8:     	b.le	0x100133930 <_render.TerminalRenderer.drawPane+0x5474>
1001338fc:     	mov.d	v0[1], v0[0]
100133900:     	ext.16b	v3, v18, v18, #0x8
100133904:     	fsub.2s	v3, v3, v18
100133908:     	mov.16b	v4, v20
10013390c:     	mov.s	v4[1], v19[0]
100133910:     	mov.s	v4[2], v1[0]
100133914:     	mov.s	v4[3], v2[0]
100133918:     	fsub.4s	v0, v4, v0
10013391c:     	fdiv.2s	v3, v3, v21
100133920:     	mov.d	v3[1], v3[0]
100133924:     	fmul.4s	v0, v0, v3
100133928:     	dup.2d	v3, v18[0]
10013392c:     	fadd.4s	v18, v3, v0
100133930:     	fsub	s21, s1, s20
100133934:     	fsub	s8, s2, s19
100133938:     	ldur	q0, [x8, #0x30]
10013393c:     	str	q0, [sp, #0x2300]
100133940:     	ldur	q0, [x8, #0x40]
100133944:     	str	q0, [sp, #0x2310]
100133948:     	fcmp	s21, #0.0
10013394c:     	b.le	0x100134158 <_render.TerminalRenderer.drawPane+0x5c9c>
100133950:     	fcmp	s8, #0.0
100133954:     	b.le	0x100134158 <_render.TerminalRenderer.drawPane+0x5c9c>
100133958:     	ldrb	w8, [x2, #0x98]
10013395c:     	cbz	w8, 0x100133ac8 <_render.TerminalRenderer.drawPane+0x560c>
100133960:     	ldr	x9, [x2, #0x90]
100133964:     	ldr	x8, [x2, #0x80]
100133968:     	cmp	x8, x9
10013396c:     	b.lo	0x100134124 <_render.TerminalRenderer.drawPane+0x5c68>
100133970:     	ldr	x8, [x2, #0xa0]
100133974:     	add	x8, x8, #0x1
100133978:     	str	x8, [x2, #0xa0]
10013397c:     	b	0x100134158 <_render.TerminalRenderer.drawPane+0x5c9c>
100133980:     	ldp	d0, d21, [x8]
100133984:     	ldr	q18, [x8, #0x10]
100133988:     	fmov	d20, d0
10013398c:     	mov	s19, v0[1]
100133990:     	fadd	s1, s0, s21
100133994:     	mov	s8, v21[1]
100133998:     	fadd	s2, s19, s8
10013399c:     	fcmp	s0, s17
1001339a0:     	fccmp	s19, s14, #0x8, ge
1001339a4:     	fccmp	s1, s15, #0x2, ge
1001339a8:     	fccmp	s2, s12, #0x2, ls
1001339ac:     	b.ls	0x100133a14 <_render.TerminalRenderer.drawPane+0x5558>
1001339b0:     	fminnm	s1, s1, s15
1001339b4:     	fminnm	s2, s2, s12
1001339b8:     	fmaxnm	s20, s20, s17
1001339bc:     	fmaxnm	s19, s19, s14
1001339c0:     	fmaxnm	s1, s20, s1
1001339c4:     	fmaxnm	s2, s19, s2
1001339c8:     	fcmp	s21, #0.0
1001339cc:     	b.le	0x100133a0c <_render.TerminalRenderer.drawPane+0x5550>
1001339d0:     	fcmp	s8, #0.0
1001339d4:     	b.le	0x100133a0c <_render.TerminalRenderer.drawPane+0x5550>
1001339d8:     	mov.d	v0[1], v0[0]
1001339dc:     	ext.16b	v3, v18, v18, #0x8
1001339e0:     	fsub.2s	v3, v3, v18
1001339e4:     	mov.16b	v4, v20
1001339e8:     	mov.s	v4[1], v19[0]
1001339ec:     	mov.s	v4[2], v1[0]
1001339f0:     	mov.s	v4[3], v2[0]
1001339f4:     	fsub.4s	v0, v4, v0
1001339f8:     	fdiv.2s	v3, v3, v21
1001339fc:     	mov.d	v3[1], v3[0]
100133a00:     	fmul.4s	v0, v0, v3
100133a04:     	dup.2d	v3, v18[0]
100133a08:     	fadd.4s	v18, v3, v0
100133a0c:     	fsub	s21, s1, s20
100133a10:     	fsub	s8, s2, s19
100133a14:     	ldp	s13, s11, [x8, #0x20]
100133a18:     	ldp	s10, s9, [x8, #0x28]
100133a1c:     	ldur	q0, [x8, #0x30]
100133a20:     	str	q0, [sp, #0x2300]
100133a24:     	ldur	q0, [x8, #0x40]
100133a28:     	str	q0, [sp, #0x2310]
100133a2c:     	fcmp	s21, #0.0
100133a30:     	b.le	0x100133cb8 <_render.TerminalRenderer.drawPane+0x57fc>
100133a34:     	fcmp	s8, #0.0
100133a38:     	b.le	0x100133cb8 <_render.TerminalRenderer.drawPane+0x57fc>
100133a3c:     	ldrb	w8, [x2, #0x98]
100133a40:     	cbz	w8, 0x100133a64 <_render.TerminalRenderer.drawPane+0x55a8>
100133a44:     	ldr	x9, [x2, #0x90]
100133a48:     	ldr	x8, [x2, #0x80]
100133a4c:     	cmp	x8, x9
100133a50:     	b.lo	0x100133c84 <_render.TerminalRenderer.drawPane+0x57c8>
100133a54:     	ldr	x8, [x2, #0xa0]
100133a58:     	add	x8, x8, #0x1
100133a5c:     	str	x8, [x2, #0xa0]
100133a60:     	b	0x100133cb8 <_render.TerminalRenderer.drawPane+0x57fc>
100133a64:     	ldp	x8, x27, [x2, #0x80]
100133a68:     	cmp	x27, x8
100133a6c:     	b.hi	0x100133c84 <_render.TerminalRenderer.drawPane+0x57c8>
100133a70:     	add	x8, x8, #0x1
100133a74:     	lsr	x9, x8, #1
100133a78:     	add	x9, x9, #0x1
100133a7c:     	adds	x8, x8, x9
100133a80:     	csinv	x23, x8, xzr, lo
100133a84:     	cmp	x27, x23
100133a88:     	b.hs	0x100133c7c <_render.TerminalRenderer.drawPane+0x57c0>
100133a8c:     	ldp	x24, x28, [x2, #0x68]
100133a90:     	ldr	x9, [sp, #0x290]
100133a94:     	add	x8, x9, #0x10, lsl #12  ; =0x10000
100133a98:     	ldr	x25, [x8, #0x2968]
100133a9c:     	cbz	x27, 0x100133ab4 <_render.TerminalRenderer.drawPane+0x55f8>
100133aa0:     	umulh	x8, x23, x14
100133aa4:     	cmp	xzr, x8
100133aa8:     	cset	w8, ne
100133aac:     	strb	w8, [sp, #0xf00]
100133ab0:     	b.eq	0x100133b30 <_render.TerminalRenderer.drawPane+0x5674>
100133ab4:     	mov	x22, #0x0               ; =0
100133ab8:     	mov	x8, #0x0                ; =0
100133abc:     	cbz	x22, 0x100133bb8 <_render.TerminalRenderer.drawPane+0x56fc>
100133ac0:     	mov	x23, x8
100133ac4:     	b	0x100133c74 <_render.TerminalRenderer.drawPane+0x57b8>
100133ac8:     	ldp	x8, x27, [x2, #0x80]
100133acc:     	cmp	x27, x8
100133ad0:     	b.hi	0x100134124 <_render.TerminalRenderer.drawPane+0x5c68>
100133ad4:     	add	x8, x8, #0x1
100133ad8:     	lsr	x9, x8, #1
100133adc:     	add	x9, x9, #0x1
100133ae0:     	adds	x8, x8, x9
100133ae4:     	csinv	x23, x8, xzr, lo
100133ae8:     	cmp	x27, x23
100133aec:     	b.hs	0x10013411c <_render.TerminalRenderer.drawPane+0x5c60>
100133af0:     	ldp	x24, x28, [x2, #0x68]
100133af4:     	ldr	x9, [sp, #0x290]
100133af8:     	add	x8, x9, #0x10, lsl #12  ; =0x10000
100133afc:     	ldr	x21, [x8, #0x2968]
100133b00:     	add	x25, x23, x23, lsl #2
100133b04:     	cbz	x27, 0x100133b1c <_render.TerminalRenderer.drawPane+0x5660>
100133b08:     	umulh	x8, x23, x14
100133b0c:     	cmp	xzr, x8
100133b10:     	cset	w8, ne
100133b14:     	strb	w8, [sp, #0xf00]
100133b18:     	b.eq	0x100133fd8 <_render.TerminalRenderer.drawPane+0x5b1c>
100133b1c:     	mov	x22, #0x0               ; =0
100133b20:     	mov	x8, #0x0                ; =0
100133b24:     	cbz	x22, 0x10013405c <_render.TerminalRenderer.drawPane+0x5ba0>
100133b28:     	mov	x23, x8
100133b2c:     	b	0x100134114 <_render.TerminalRenderer.drawPane+0x5c58>
100133b30:     	add	x8, x23, x23, lsl #2
100133b34:     	lsl	x22, x8, #4
100133b38:     	add	x8, x27, x27, lsl #2
100133b3c:     	lsl	x2, x8, #4
100133b40:     	ldr	x8, [x28, #0x10]
100133b44:     	mov	x0, x24
100133b48:     	mov	x1, x25
100133b4c:     	mov	w3, #0x2                ; =2
100133b50:     	mov	x4, x22
100133b54:     	ldr	x5, [sp, #0x198]
100133b58:     	str	q18, [sp, #0x2a0]
100133b5c:     	str	q19, [sp, #0x280]
100133b60:     	stp	q21, q20, [sp, #0x250]
100133b64:     	blr	x8
100133b68:     	ldp	q21, q20, [sp, #0x250]
100133b6c:     	ldr	q19, [sp, #0x280]
100133b70:     	ldr	q18, [sp, #0x2a0]
100133b74:     	ldr	x16, [sp, #0x230]
100133b78:     	ldr	x15, [sp, #0x240]
100133b7c:     	mov	w14, #0x50              ; =80
100133b80:     	ldr	s17, [sp, #0x1d0]
100133b84:     	ldr	s16, [sp, #0x1f0]
100133b88:     	ldr	s7, [sp, #0x200]
100133b8c:     	ldr	s6, [sp, #0x210]
100133b90:     	ldr	s5, [sp, #0x228]
100133b94:     	ldr	x2, [sp, #0x298]
100133b98:     	lsr	x8, x22, #4
100133b9c:     	mov	x9, #-0x3333333333333334 ; =-3689348814741910324
100133ba0:     	movk	x9, #0xcccd
100133ba4:     	mul	x8, x8, x9
100133ba8:     	cmp	x0, #0x0
100133bac:     	csel	x22, xzr, x0, eq
100133bb0:     	csel	x8, xzr, x8, eq
100133bb4:     	cbnz	x22, 0x100133ac0 <_render.TerminalRenderer.drawPane+0x5604>
100133bb8:     	umulh	x8, x23, x14
100133bbc:     	cmp	xzr, x8
100133bc0:     	cset	w8, ne
100133bc4:     	strb	w8, [sp, #0xf00]
100133bc8:     	b.ne	0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
100133bcc:     	stp	q21, q20, [sp, #0x250]
100133bd0:     	str	q19, [sp, #0x280]
100133bd4:     	str	q18, [sp, #0x2a0]
100133bd8:     	add	x8, x23, x23, lsl #2
100133bdc:     	lsl	x1, x8, #4
100133be0:     	cbz	x1, 0x100133c04 <_render.TerminalRenderer.drawPane+0x5748>
100133be4:     	ldr	x8, [x28]
100133be8:     	mov	x0, x24
100133bec:     	mov	w2, #0x2                ; =2
100133bf0:     	ldr	x3, [sp, #0x198]
100133bf4:     	blr	x8
100133bf8:     	mov	x22, x0
100133bfc:     	cbnz	x0, 0x100133c08 <_render.TerminalRenderer.drawPane+0x574c>
100133c00:     	b	0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
100133c04:     	mov	x22, #-0x4              ; =-4
100133c08:     	ldr	x9, [sp, #0x298]
100133c0c:     	ldp	x1, x8, [x9, #0x78]
100133c10:     	add	x8, x8, x8, lsl #2
100133c14:     	lsl	x2, x8, #4
100133c18:     	mov	x0, x22
100133c1c:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
100133c20:     	cbz	x27, 0x100133c44 <_render.TerminalRenderer.drawPane+0x5788>
100133c24:     	add	x8, x27, x27, lsl #2
100133c28:     	lsl	x2, x8, #4
100133c2c:     	ldr	x8, [x28, #0x18]
100133c30:     	mov	x0, x24
100133c34:     	mov	x1, x25
100133c38:     	mov	w3, #0x2                ; =2
100133c3c:     	ldr	x4, [sp, #0x198]
100133c40:     	blr	x8
100133c44:     	ldr	x2, [sp, #0x298]
100133c48:     	ldr	s5, [sp, #0x228]
100133c4c:     	ldr	s6, [sp, #0x210]
100133c50:     	ldr	s7, [sp, #0x200]
100133c54:     	ldr	s16, [sp, #0x1f0]
100133c58:     	ldr	s17, [sp, #0x1d0]
100133c5c:     	mov	w14, #0x50              ; =80
100133c60:     	ldr	x15, [sp, #0x240]
100133c64:     	ldr	x16, [sp, #0x230]
100133c68:     	ldr	q18, [sp, #0x2a0]
100133c6c:     	ldr	q19, [sp, #0x280]
100133c70:     	ldp	q21, q20, [sp, #0x250]
100133c74:     	str	x22, [x2, #0x78]
100133c78:     	str	x23, [x2, #0x88]
100133c7c:     	ldr	x8, [x2, #0x80]
100133c80:     	ldr	x23, [sp, #0x140]
100133c84:     	add	x9, x8, #0x1
100133c88:     	str	x9, [x2, #0x80]
100133c8c:     	ldr	x9, [x2, #0x78]
100133c90:     	madd	x8, x8, x14, x9
100133c94:     	stp	s20, s19, [x8]
100133c98:     	stp	s21, s8, [x8, #0x8]
100133c9c:     	str	q18, [x8, #0x10]
100133ca0:     	stp	s13, s11, [x8, #0x20]
100133ca4:     	stp	s10, s9, [x8, #0x28]
100133ca8:     	ldr	q0, [sp, #0x2300]
100133cac:     	str	q0, [x8, #0x30]
100133cb0:     	ldr	q0, [sp, #0x2310]
100133cb4:     	str	q0, [x8, #0x40]
100133cb8:     	ldrb	w8, [x20, #0x3c]
100133cbc:     	cmp	w8, #0x3
100133cc0:     	b.lo	0x100133854 <_render.TerminalRenderer.drawPane+0x5398>
100133cc4:     	mov	x20, #0x0               ; =0
100133cc8:     	sub	w8, w8, #0x2
100133ccc:     	and	x8, x8, #0xff
100133cd0:     	add	x8, x8, x8, lsl #2
100133cd4:     	lsl	x27, x8, #4
100133cd8:     	b	0x100133d38 <_render.TerminalRenderer.drawPane+0x587c>
100133cdc:     	mov	x22, #0x0               ; =0
100133ce0:     	mov	x8, #0x0                ; =0
100133ce4:     	cbz	x22, 0x100133f08 <_render.TerminalRenderer.drawPane+0x5a4c>
100133ce8:     	mov	x28, x8
100133cec:     	str	x22, [x2, #0x78]
100133cf0:     	str	x28, [x2, #0x88]
100133cf4:     	ldr	x8, [x2, #0x80]
100133cf8:     	add	x9, x8, #0x1
100133cfc:     	str	x9, [x2, #0x80]
100133d00:     	ldr	x9, [x2, #0x78]
100133d04:     	madd	x8, x8, x14, x9
100133d08:     	stp	s20, s19, [x8]
100133d0c:     	stp	s21, s8, [x8, #0x8]
100133d10:     	str	q18, [x8, #0x10]
100133d14:     	stp	s13, s11, [x8, #0x20]
100133d18:     	stp	s10, s9, [x8, #0x28]
100133d1c:     	ldr	q0, [sp, #0x2300]
100133d20:     	str	q0, [x8, #0x30]
100133d24:     	ldr	q0, [sp, #0x2310]
100133d28:     	str	q0, [x8, #0x40]
100133d2c:     	add	x20, x20, #0x50
100133d30:     	cmp	x27, x20
100133d34:     	b.eq	0x100133854 <_render.TerminalRenderer.drawPane+0x5398>
100133d38:     	add	x8, x26, x20
100133d3c:     	ldp	d0, d21, [x8]
100133d40:     	ldr	q18, [x8, #0x10]
100133d44:     	fmov	d20, d0
100133d48:     	mov	s19, v0[1]
100133d4c:     	fadd	s1, s0, s21
100133d50:     	mov	s8, v21[1]
100133d54:     	fadd	s2, s19, s8
100133d58:     	fcmp	s0, s17
100133d5c:     	fccmp	s19, s14, #0x8, ge
100133d60:     	fccmp	s1, s15, #0x2, ge
100133d64:     	fccmp	s2, s12, #0x2, ls
100133d68:     	b.ls	0x100133dd0 <_render.TerminalRenderer.drawPane+0x5914>
100133d6c:     	fminnm	s1, s1, s15
100133d70:     	fminnm	s2, s2, s12
100133d74:     	fmaxnm	s20, s20, s17
100133d78:     	fmaxnm	s19, s19, s14
100133d7c:     	fmaxnm	s1, s20, s1
100133d80:     	fmaxnm	s2, s19, s2
100133d84:     	fcmp	s21, #0.0
100133d88:     	b.le	0x100133dc8 <_render.TerminalRenderer.drawPane+0x590c>
100133d8c:     	fcmp	s8, #0.0
100133d90:     	b.le	0x100133dc8 <_render.TerminalRenderer.drawPane+0x590c>
100133d94:     	mov.d	v0[1], v0[0]
100133d98:     	ext.16b	v3, v18, v18, #0x8
100133d9c:     	fsub.2s	v3, v3, v18
100133da0:     	mov.16b	v4, v20
100133da4:     	mov.s	v4[1], v19[0]
100133da8:     	mov.s	v4[2], v1[0]
100133dac:     	mov.s	v4[3], v2[0]
100133db0:     	fsub.4s	v0, v4, v0
100133db4:     	fdiv.2s	v3, v3, v21
100133db8:     	mov.d	v3[1], v3[0]
100133dbc:     	fmul.4s	v0, v0, v3
100133dc0:     	dup.2d	v3, v18[0]
100133dc4:     	fadd.4s	v18, v3, v0
100133dc8:     	fsub	s21, s1, s20
100133dcc:     	fsub	s8, s2, s19
100133dd0:     	ldp	s13, s11, [x8, #0x20]
100133dd4:     	ldp	s10, s9, [x8, #0x28]
100133dd8:     	ldur	q0, [x8, #0x30]
100133ddc:     	str	q0, [sp, #0x2300]
100133de0:     	ldur	q0, [x8, #0x40]
100133de4:     	str	q0, [sp, #0x2310]
100133de8:     	fcmp	s21, #0.0
100133dec:     	b.le	0x100133d2c <_render.TerminalRenderer.drawPane+0x5870>
100133df0:     	fcmp	s8, #0.0
100133df4:     	b.le	0x100133d2c <_render.TerminalRenderer.drawPane+0x5870>
100133df8:     	ldrb	w8, [x2, #0x98]
100133dfc:     	cbz	w8, 0x100133e20 <_render.TerminalRenderer.drawPane+0x5964>
100133e00:     	ldr	x9, [x2, #0x90]
100133e04:     	ldr	x8, [x2, #0x80]
100133e08:     	cmp	x8, x9
100133e0c:     	b.lo	0x100133cf8 <_render.TerminalRenderer.drawPane+0x583c>
100133e10:     	ldr	x8, [x2, #0xa0]
100133e14:     	add	x8, x8, #0x1
100133e18:     	str	x8, [x2, #0xa0]
100133e1c:     	b	0x100133d2c <_render.TerminalRenderer.drawPane+0x5870>
100133e20:     	ldp	x8, x25, [x2, #0x80]
100133e24:     	cmp	x25, x8
100133e28:     	b.hi	0x100133cf8 <_render.TerminalRenderer.drawPane+0x583c>
100133e2c:     	add	x8, x8, #0x1
100133e30:     	lsr	x9, x8, #1
100133e34:     	add	x9, x9, #0x1
100133e38:     	adds	x8, x8, x9
100133e3c:     	csinv	x28, x8, xzr, lo
100133e40:     	cmp	x25, x28
100133e44:     	b.hs	0x100133cf4 <_render.TerminalRenderer.drawPane+0x5838>
100133e48:     	ldp	x0, x9, [x2, #0x68]
100133e4c:     	ldr	x10, [sp, #0x290]
100133e50:     	add	x8, x10, #0x10, lsl #12 ; =0x10000
100133e54:     	ldr	x1, [x8, #0x2968]
100133e58:     	add	x24, x28, x28, lsl #2
100133e5c:     	cbz	x25, 0x100133cdc <_render.TerminalRenderer.drawPane+0x5820>
100133e60:     	umulh	x8, x28, x14
100133e64:     	cmp	xzr, x8
100133e68:     	cset	w8, ne
100133e6c:     	strb	w8, [sp, #0xf00]
100133e70:     	b.ne	0x100133cdc <_render.TerminalRenderer.drawPane+0x5820>
100133e74:     	stp	q21, q20, [sp, #0x250]
100133e78:     	str	q19, [sp, #0x280]
100133e7c:     	str	q18, [sp, #0x2a0]
100133e80:     	lsl	x23, x24, #4
100133e84:     	add	x8, x25, x25, lsl #2
100133e88:     	lsl	x2, x8, #4
100133e8c:     	stp	x1, x9, [sp, #0x1a8]
100133e90:     	ldr	x8, [x9, #0x10]
100133e94:     	mov	x21, x0
100133e98:     	mov	w3, #0x2                ; =2
100133e9c:     	mov	x4, x23
100133ea0:     	ldr	x5, [sp, #0x198]
100133ea4:     	blr	x8
100133ea8:     	mov	x22, x0
100133eac:     	cbz	x0, 0x100133ec4 <_render.TerminalRenderer.drawPane+0x5a08>
100133eb0:     	lsr	x8, x23, #4
100133eb4:     	mov	x9, #-0x3333333333333334 ; =-3689348814741910324
100133eb8:     	movk	x9, #0xcccd
100133ebc:     	mul	x8, x8, x9
100133ec0:     	b	0x100133ec8 <_render.TerminalRenderer.drawPane+0x5a0c>
100133ec4:     	mov	x8, #0x0                ; =0
100133ec8:     	ldr	x2, [sp, #0x298]
100133ecc:     	ldr	x23, [sp, #0x140]
100133ed0:     	ldr	s5, [sp, #0x228]
100133ed4:     	ldr	s6, [sp, #0x210]
100133ed8:     	ldr	s7, [sp, #0x200]
100133edc:     	ldr	s16, [sp, #0x1f0]
100133ee0:     	ldr	s17, [sp, #0x1d0]
100133ee4:     	mov	w14, #0x50              ; =80
100133ee8:     	ldr	x15, [sp, #0x240]
100133eec:     	ldr	x16, [sp, #0x230]
100133ef0:     	ldr	q18, [sp, #0x2a0]
100133ef4:     	ldr	q19, [sp, #0x280]
100133ef8:     	ldp	q21, q20, [sp, #0x250]
100133efc:     	mov	x0, x21
100133f00:     	ldp	x1, x9, [sp, #0x1a8]
100133f04:     	cbnz	x22, 0x100133ce8 <_render.TerminalRenderer.drawPane+0x582c>
100133f08:     	umulh	x8, x28, x14
100133f0c:     	cmp	xzr, x8
100133f10:     	cset	w8, ne
100133f14:     	strb	w8, [sp, #0xf00]
100133f18:     	b.ne	0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
100133f1c:     	mov	x21, x1
100133f20:     	stp	q21, q20, [sp, #0x250]
100133f24:     	str	q19, [sp, #0x280]
100133f28:     	str	q18, [sp, #0x2a0]
100133f2c:     	lsl	x1, x24, #4
100133f30:     	cbz	x1, 0x100133f58 <_render.TerminalRenderer.drawPane+0x5a9c>
100133f34:     	mov	x23, x9
100133f38:     	ldr	x8, [x9]
100133f3c:     	mov	x24, x0
100133f40:     	mov	w2, #0x2                ; =2
100133f44:     	ldr	x3, [sp, #0x198]
100133f48:     	blr	x8
100133f4c:     	mov	x22, x0
100133f50:     	cbnz	x0, 0x100133f64 <_render.TerminalRenderer.drawPane+0x5aa8>
100133f54:     	b	0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
100133f58:     	mov	x23, x9
100133f5c:     	mov	x24, x0
100133f60:     	mov	x22, #-0x4              ; =-4
100133f64:     	ldr	x9, [sp, #0x298]
100133f68:     	ldp	x1, x8, [x9, #0x78]
100133f6c:     	add	x8, x8, x8, lsl #2
100133f70:     	lsl	x2, x8, #4
100133f74:     	mov	x0, x22
100133f78:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
100133f7c:     	cbz	x25, 0x100133fa0 <_render.TerminalRenderer.drawPane+0x5ae4>
100133f80:     	add	x8, x25, x25, lsl #2
100133f84:     	lsl	x2, x8, #4
100133f88:     	ldr	x8, [x23, #0x18]
100133f8c:     	mov	x0, x24
100133f90:     	mov	x1, x21
100133f94:     	mov	w3, #0x2                ; =2
100133f98:     	ldr	x4, [sp, #0x198]
100133f9c:     	blr	x8
100133fa0:     	ldr	x2, [sp, #0x298]
100133fa4:     	ldr	s5, [sp, #0x228]
100133fa8:     	ldr	s6, [sp, #0x210]
100133fac:     	ldr	s7, [sp, #0x200]
100133fb0:     	ldr	s16, [sp, #0x1f0]
100133fb4:     	ldr	s17, [sp, #0x1d0]
100133fb8:     	mov	w14, #0x50              ; =80
100133fbc:     	ldr	x15, [sp, #0x240]
100133fc0:     	ldr	x16, [sp, #0x230]
100133fc4:     	ldr	q18, [sp, #0x2a0]
100133fc8:     	ldr	q19, [sp, #0x280]
100133fcc:     	ldp	q21, q20, [sp, #0x250]
100133fd0:     	ldr	x23, [sp, #0x140]
100133fd4:     	b	0x100133cec <_render.TerminalRenderer.drawPane+0x5830>
100133fd8:     	lsl	x22, x25, #4
100133fdc:     	add	x8, x27, x27, lsl #2
100133fe0:     	lsl	x2, x8, #4
100133fe4:     	ldr	x8, [x28, #0x10]
100133fe8:     	mov	x0, x24
100133fec:     	mov	x1, x21
100133ff0:     	mov	w3, #0x2                ; =2
100133ff4:     	mov	x4, x22
100133ff8:     	ldr	x5, [sp, #0x198]
100133ffc:     	str	q18, [sp, #0x2a0]
100134000:     	str	q19, [sp, #0x280]
100134004:     	stp	q21, q20, [sp, #0x250]
100134008:     	blr	x8
10013400c:     	ldp	q21, q20, [sp, #0x250]
100134010:     	ldr	q19, [sp, #0x280]
100134014:     	ldr	q18, [sp, #0x2a0]
100134018:     	ldr	x16, [sp, #0x230]
10013401c:     	ldr	x15, [sp, #0x240]
100134020:     	mov	w14, #0x50              ; =80
100134024:     	ldr	s17, [sp, #0x1d0]
100134028:     	ldr	s16, [sp, #0x1f0]
10013402c:     	ldr	s7, [sp, #0x200]
100134030:     	ldr	s6, [sp, #0x210]
100134034:     	ldr	s5, [sp, #0x228]
100134038:     	ldr	x2, [sp, #0x298]
10013403c:     	lsr	x8, x22, #4
100134040:     	mov	x9, #-0x3333333333333334 ; =-3689348814741910324
100134044:     	movk	x9, #0xcccd
100134048:     	mul	x8, x8, x9
10013404c:     	cmp	x0, #0x0
100134050:     	csel	x22, xzr, x0, eq
100134054:     	csel	x8, xzr, x8, eq
100134058:     	cbnz	x22, 0x100133b28 <_render.TerminalRenderer.drawPane+0x566c>
10013405c:     	umulh	x8, x23, x14
100134060:     	cmp	xzr, x8
100134064:     	cset	w8, ne
100134068:     	strb	w8, [sp, #0xf00]
10013406c:     	b.ne	0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
100134070:     	stp	q21, q20, [sp, #0x250]
100134074:     	str	q19, [sp, #0x280]
100134078:     	str	q18, [sp, #0x2a0]
10013407c:     	lsl	x1, x25, #4
100134080:     	cbz	x1, 0x1001340a4 <_render.TerminalRenderer.drawPane+0x5be8>
100134084:     	ldr	x8, [x28]
100134088:     	mov	x0, x24
10013408c:     	mov	w2, #0x2                ; =2
100134090:     	ldr	x3, [sp, #0x198]
100134094:     	blr	x8
100134098:     	mov	x22, x0
10013409c:     	cbnz	x0, 0x1001340a8 <_render.TerminalRenderer.drawPane+0x5bec>
1001340a0:     	b	0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
1001340a4:     	mov	x22, #-0x4              ; =-4
1001340a8:     	ldr	x9, [sp, #0x298]
1001340ac:     	ldp	x1, x8, [x9, #0x78]
1001340b0:     	add	x8, x8, x8, lsl #2
1001340b4:     	lsl	x2, x8, #4
1001340b8:     	mov	x0, x22
1001340bc:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
1001340c0:     	cbz	x27, 0x1001340e4 <_render.TerminalRenderer.drawPane+0x5c28>
1001340c4:     	add	x8, x27, x27, lsl #2
1001340c8:     	lsl	x2, x8, #4
1001340cc:     	ldr	x8, [x28, #0x18]
1001340d0:     	mov	x0, x24
1001340d4:     	mov	x1, x21
1001340d8:     	mov	w3, #0x2                ; =2
1001340dc:     	ldr	x4, [sp, #0x198]
1001340e0:     	blr	x8
1001340e4:     	ldr	x2, [sp, #0x298]
1001340e8:     	ldr	s5, [sp, #0x228]
1001340ec:     	ldr	s6, [sp, #0x210]
1001340f0:     	ldr	s7, [sp, #0x200]
1001340f4:     	ldr	s16, [sp, #0x1f0]
1001340f8:     	ldr	s17, [sp, #0x1d0]
1001340fc:     	mov	w14, #0x50              ; =80
100134100:     	ldr	x15, [sp, #0x240]
100134104:     	ldr	x16, [sp, #0x230]
100134108:     	ldr	q18, [sp, #0x2a0]
10013410c:     	ldr	q19, [sp, #0x280]
100134110:     	ldp	q21, q20, [sp, #0x250]
100134114:     	str	x22, [x2, #0x78]
100134118:     	str	x23, [x2, #0x88]
10013411c:     	ldr	x8, [x2, #0x80]
100134120:     	ldr	x23, [sp, #0x140]
100134124:     	add	x9, x8, #0x1
100134128:     	str	x9, [x2, #0x80]
10013412c:     	ldr	x9, [x2, #0x78]
100134130:     	madd	x8, x8, x14, x9
100134134:     	stp	s20, s19, [x8]
100134138:     	stp	s21, s8, [x8, #0x8]
10013413c:     	str	q18, [x8, #0x10]
100134140:     	stp	s7, s6, [x8, #0x20]
100134144:     	stp	s16, s5, [x8, #0x28]
100134148:     	ldr	q0, [sp, #0x2300]
10013414c:     	str	q0, [x8, #0x30]
100134150:     	ldr	q0, [sp, #0x2310]
100134154:     	str	q0, [x8, #0x40]
100134158:     	ldrb	w8, [x20, #0x3c]
10013415c:     	subs	w9, w8, #0x2
100134160:     	csel	w20, wzr, w9, lo
100134164:     	cmp	w8, #0x3
100134168:     	b.lo	0x100133854 <_render.TerminalRenderer.drawPane+0x5398>
10013416c:     	mov	x27, x26
100134170:     	b	0x1001341d0 <_render.TerminalRenderer.drawPane+0x5d14>
100134174:     	mov	x22, #0x0               ; =0
100134178:     	mov	x8, #0x0                ; =0
10013417c:     	cbz	x22, 0x100134394 <_render.TerminalRenderer.drawPane+0x5ed8>
100134180:     	mov	x25, x8
100134184:     	str	x22, [x2, #0x78]
100134188:     	str	x25, [x2, #0x88]
10013418c:     	ldr	x8, [x2, #0x80]
100134190:     	add	x9, x8, #0x1
100134194:     	str	x9, [x2, #0x80]
100134198:     	ldr	x9, [x2, #0x78]
10013419c:     	madd	x8, x8, x14, x9
1001341a0:     	stp	s20, s19, [x8]
1001341a4:     	stp	s21, s8, [x8, #0x8]
1001341a8:     	str	q18, [x8, #0x10]
1001341ac:     	stp	s7, s6, [x8, #0x20]
1001341b0:     	stp	s16, s5, [x8, #0x28]
1001341b4:     	ldr	q0, [sp, #0x2300]
1001341b8:     	str	q0, [x8, #0x30]
1001341bc:     	ldr	q0, [sp, #0x2310]
1001341c0:     	str	q0, [x8, #0x40]
1001341c4:     	add	x27, x27, #0x50
1001341c8:     	subs	x20, x20, #0x1
1001341cc:     	b.eq	0x100133854 <_render.TerminalRenderer.drawPane+0x5398>
1001341d0:     	ldp	d0, d21, [x27]
1001341d4:     	ldr	q18, [x27, #0x10]
1001341d8:     	fmov	d20, d0
1001341dc:     	mov	s19, v0[1]
1001341e0:     	fadd	s1, s0, s21
1001341e4:     	mov	s8, v21[1]
1001341e8:     	fadd	s2, s19, s8
1001341ec:     	fcmp	s0, s17
1001341f0:     	fccmp	s19, s14, #0x8, ge
1001341f4:     	fccmp	s1, s15, #0x2, ge
1001341f8:     	fccmp	s2, s12, #0x2, ls
1001341fc:     	b.ls	0x100134264 <_render.TerminalRenderer.drawPane+0x5da8>
100134200:     	fminnm	s1, s1, s15
100134204:     	fminnm	s2, s2, s12
100134208:     	fmaxnm	s20, s20, s17
10013420c:     	fmaxnm	s19, s19, s14
100134210:     	fmaxnm	s1, s20, s1
100134214:     	fmaxnm	s2, s19, s2
100134218:     	fcmp	s21, #0.0
10013421c:     	b.le	0x10013425c <_render.TerminalRenderer.drawPane+0x5da0>
100134220:     	fcmp	s8, #0.0
100134224:     	b.le	0x10013425c <_render.TerminalRenderer.drawPane+0x5da0>
100134228:     	mov.d	v0[1], v0[0]
10013422c:     	ext.16b	v3, v18, v18, #0x8
100134230:     	fsub.2s	v3, v3, v18
100134234:     	mov.16b	v4, v20
100134238:     	mov.s	v4[1], v19[0]
10013423c:     	mov.s	v4[2], v1[0]
100134240:     	mov.s	v4[3], v2[0]
100134244:     	fsub.4s	v0, v4, v0
100134248:     	fdiv.2s	v3, v3, v21
10013424c:     	mov.d	v3[1], v3[0]
100134250:     	fmul.4s	v0, v0, v3
100134254:     	dup.2d	v3, v18[0]
100134258:     	fadd.4s	v18, v3, v0
10013425c:     	fsub	s21, s1, s20
100134260:     	fsub	s8, s2, s19
100134264:     	ldur	q0, [x27, #0x30]
100134268:     	str	q0, [sp, #0x2300]
10013426c:     	ldur	q0, [x27, #0x40]
100134270:     	str	q0, [sp, #0x2310]
100134274:     	fcmp	s21, #0.0
100134278:     	b.le	0x1001341c4 <_render.TerminalRenderer.drawPane+0x5d08>
10013427c:     	fcmp	s8, #0.0
100134280:     	b.le	0x1001341c4 <_render.TerminalRenderer.drawPane+0x5d08>
100134284:     	ldrb	w8, [x2, #0x98]
100134288:     	cbz	w8, 0x1001342ac <_render.TerminalRenderer.drawPane+0x5df0>
10013428c:     	ldr	x9, [x2, #0x90]
100134290:     	ldr	x8, [x2, #0x80]
100134294:     	cmp	x8, x9
100134298:     	b.lo	0x100134190 <_render.TerminalRenderer.drawPane+0x5cd4>
10013429c:     	ldr	x8, [x2, #0xa0]
1001342a0:     	add	x8, x8, #0x1
1001342a4:     	str	x8, [x2, #0xa0]
1001342a8:     	b	0x1001341c4 <_render.TerminalRenderer.drawPane+0x5d08>
1001342ac:     	ldp	x8, x28, [x2, #0x80]
1001342b0:     	cmp	x28, x8
1001342b4:     	b.hi	0x100134190 <_render.TerminalRenderer.drawPane+0x5cd4>
1001342b8:     	add	x8, x8, #0x1
1001342bc:     	lsr	x9, x8, #1
1001342c0:     	add	x9, x9, #0x1
1001342c4:     	adds	x8, x8, x9
1001342c8:     	csinv	x25, x8, xzr, lo
1001342cc:     	cmp	x28, x25
1001342d0:     	b.hs	0x10013418c <_render.TerminalRenderer.drawPane+0x5cd0>
1001342d4:     	ldp	x0, x9, [x2, #0x68]
1001342d8:     	ldr	x10, [sp, #0x290]
1001342dc:     	add	x8, x10, #0x10, lsl #12 ; =0x10000
1001342e0:     	ldr	x1, [x8, #0x2968]
1001342e4:     	add	x24, x25, x25, lsl #2
1001342e8:     	cbz	x28, 0x100134174 <_render.TerminalRenderer.drawPane+0x5cb8>
1001342ec:     	umulh	x8, x25, x14
1001342f0:     	cmp	xzr, x8
1001342f4:     	cset	w8, ne
1001342f8:     	strb	w8, [sp, #0xf00]
1001342fc:     	b.ne	0x100134174 <_render.TerminalRenderer.drawPane+0x5cb8>
100134300:     	stp	q21, q20, [sp, #0x250]
100134304:     	str	q19, [sp, #0x280]
100134308:     	str	q18, [sp, #0x2a0]
10013430c:     	lsl	x23, x24, #4
100134310:     	add	x8, x28, x28, lsl #2
100134314:     	lsl	x2, x8, #4
100134318:     	str	x9, [sp, #0x170]
10013431c:     	ldr	x8, [x9, #0x10]
100134320:     	stp	x0, x1, [sp, #0x1a8]
100134324:     	mov	w3, #0x2                ; =2
100134328:     	mov	x4, x23
10013432c:     	ldr	x5, [sp, #0x198]
100134330:     	blr	x8
100134334:     	mov	x22, x0
100134338:     	cbz	x0, 0x100134350 <_render.TerminalRenderer.drawPane+0x5e94>
10013433c:     	lsr	x8, x23, #4
100134340:     	mov	x9, #-0x3333333333333334 ; =-3689348814741910324
100134344:     	movk	x9, #0xcccd
100134348:     	mul	x8, x8, x9
10013434c:     	b	0x100134354 <_render.TerminalRenderer.drawPane+0x5e98>
100134350:     	mov	x8, #0x0                ; =0
100134354:     	ldr	x2, [sp, #0x298]
100134358:     	ldr	x23, [sp, #0x140]
10013435c:     	ldr	s5, [sp, #0x228]
100134360:     	ldr	s6, [sp, #0x210]
100134364:     	ldr	s7, [sp, #0x200]
100134368:     	ldr	s16, [sp, #0x1f0]
10013436c:     	ldr	s17, [sp, #0x1d0]
100134370:     	mov	w14, #0x50              ; =80
100134374:     	ldr	x15, [sp, #0x240]
100134378:     	ldr	x16, [sp, #0x230]
10013437c:     	ldr	q18, [sp, #0x2a0]
100134380:     	ldr	q19, [sp, #0x280]
100134384:     	ldp	q21, q20, [sp, #0x250]
100134388:     	ldp	x0, x1, [sp, #0x1a8]
10013438c:     	ldr	x9, [sp, #0x170]
100134390:     	cbnz	x22, 0x100134180 <_render.TerminalRenderer.drawPane+0x5cc4>
100134394:     	umulh	x8, x25, x14
100134398:     	cmp	xzr, x8
10013439c:     	cset	w8, ne
1001343a0:     	strb	w8, [sp, #0xf00]
1001343a4:     	b.ne	0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
1001343a8:     	str	x1, [sp, #0x1b0]
1001343ac:     	stp	q21, q20, [sp, #0x250]
1001343b0:     	str	q19, [sp, #0x280]
1001343b4:     	str	q18, [sp, #0x2a0]
1001343b8:     	lsl	x1, x24, #4
1001343bc:     	cbz	x1, 0x1001343e4 <_render.TerminalRenderer.drawPane+0x5f28>
1001343c0:     	mov	x23, x9
1001343c4:     	ldr	x8, [x9]
1001343c8:     	mov	x24, x0
1001343cc:     	mov	w2, #0x2                ; =2
1001343d0:     	ldr	x3, [sp, #0x198]
1001343d4:     	blr	x8
1001343d8:     	mov	x22, x0
1001343dc:     	cbnz	x0, 0x1001343f0 <_render.TerminalRenderer.drawPane+0x5f34>
1001343e0:     	b	0x100134464 <_render.TerminalRenderer.drawPane+0x5fa8>
1001343e4:     	mov	x23, x9
1001343e8:     	mov	x24, x0
1001343ec:     	mov	x22, #-0x4              ; =-4
1001343f0:     	ldr	x9, [sp, #0x298]
1001343f4:     	ldp	x1, x8, [x9, #0x78]
1001343f8:     	add	x8, x8, x8, lsl #2
1001343fc:     	lsl	x2, x8, #4
100134400:     	mov	x0, x22
100134404:     	bl	0x1001cc9bc <dyld_stub_binder+0x1001cc9bc>
100134408:     	cbz	x28, 0x10013442c <_render.TerminalRenderer.drawPane+0x5f70>
10013440c:     	add	x8, x28, x28, lsl #2
100134410:     	lsl	x2, x8, #4
100134414:     	ldr	x8, [x23, #0x18]
100134418:     	mov	x0, x24
10013441c:     	ldr	x1, [sp, #0x1b0]
100134420:     	mov	w3, #0x2                ; =2
100134424:     	ldr	x4, [sp, #0x198]
100134428:     	blr	x8
10013442c:     	ldr	x2, [sp, #0x298]
100134430:     	ldr	s5, [sp, #0x228]
100134434:     	ldr	s6, [sp, #0x210]
100134438:     	ldr	s7, [sp, #0x200]
10013443c:     	ldr	s16, [sp, #0x1f0]
100134440:     	ldr	s17, [sp, #0x1d0]
100134444:     	mov	w14, #0x50              ; =80
100134448:     	ldr	x15, [sp, #0x240]
10013444c:     	ldr	x16, [sp, #0x230]
100134450:     	ldr	q18, [sp, #0x2a0]
100134454:     	ldr	q19, [sp, #0x280]
100134458:     	ldp	q21, q20, [sp, #0x250]
10013445c:     	ldr	x23, [sp, #0x140]
100134460:     	b	0x100134184 <_render.TerminalRenderer.drawPane+0x5cc8>
100134464:     	mov	w0, #0x1a               ; =26
100134468:     	b	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
10013446c:     	ldr	x0, [sp, #0x290]
100134470:     	ldr	x1, [sp, #0x278]
100134474:     	ldp	x3, x2, [sp, #0x78]
100134478:     	mov	w4, #0x2                ; =2
10013447c:     	bl	0x10012e174 <_render.TerminalRenderer.pushImages>
100134480:     	ands	w0, w0, #0xffff
100134484:     	ldr	w8, [sp, #0x2b8]
100134488:     	csinc	w8, w8, wzr, eq
10013448c:     	tbnz	w8, #0x0, 0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
100134490:     	ldr	w8, [sp, #0x1e0]
100134494:     	tst	w8, #0x3
100134498:     	b.eq	0x100134528 <_render.TerminalRenderer.drawPane+0x606c>
10013449c:     	ldr	s0, [sp, #0x1c0]
1001344a0:     	str	s0, [sp, #0x364]
1001344a4:     	ldr	s0, [sp, #0x1c8]
1001344a8:     	str	s0, [sp, #0x368]
1001344ac:     	ldr	s0, [sp, #0x118]
1001344b0:     	str	s0, [sp, #0x36c]
1001344b4:     	ldr	s0, [sp, #0x120]
1001344b8:     	str	s0, [sp, #0x370]
1001344bc:     	ldr	q0, [sp, #0x310]
1001344c0:     	add	x9, sp, #0x32c
1001344c4:     	stur	q0, [x9, #0x48]
1001344c8:     	ldr	s0, [sp, #0x200]
1001344cc:     	str	s0, [sp, #0x384]
1001344d0:     	ldr	s0, [sp, #0x210]
1001344d4:     	str	s0, [sp, #0x388]
1001344d8:     	ldr	s0, [sp, #0x1f0]
1001344dc:     	str	s0, [sp, #0x38c]
1001344e0:     	ldr	s0, [sp, #0x228]
1001344e4:     	str	s0, [sp, #0x390]
1001344e8:     	ldr	s0, [sp, #0x148]
1001344ec:     	str	s0, [sp, #0x394]
1001344f0:     	strb	w8, [sp, #0x398]
1001344f4:     	ldrh	w8, [sp, #0x308]
1001344f8:     	sturh	w8, [x9, #0x6d]
1001344fc:     	ldrb	w8, [sp, #0x30a]
100134500:     	strb	w8, [sp, #0x39b]
100134504:     	add	x0, sp, #0x364
100134508:     	mov	w8, #0x2958             ; =10584
10013450c:     	movk	w8, #0x1, lsl #16
100134510:     	ldr	x9, [sp, #0x290]
100134514:     	add	x1, x9, x8
100134518:     	bl	0x10012e358 <_render.CursorPaint.paint>
10013451c:     	ands	w8, w0, #0xffff
100134520:     	csel	w0, wzr, w8, eq
100134524:     	b	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
100134528:     	mov	w0, #0x0                ; =0
10013452c:     	add	sp, sp, #0x3, lsl #12   ; =0x3000
100134530:     	add	sp, sp, #0x9d0
100134534:     	ldp	x29, x30, [sp, #0x90]
100134538:     	ldp	x20, x19, [sp, #0x80]
10013453c:     	ldp	x22, x21, [sp, #0x70]
100134540:     	ldp	x24, x23, [sp, #0x60]
100134544:     	ldp	x26, x25, [sp, #0x50]
100134548:     	ldp	x28, x27, [sp, #0x40]
10013454c:     	ldp	d9, d8, [sp, #0x30]
100134550:     	ldp	d11, d10, [sp, #0x20]
100134554:     	ldp	d13, d12, [sp, #0x10]
100134558:     	ldp	d15, d14, [sp], #0xa0
10013455c:     	ret
100134560:     	mov	w15, #0x3               ; =3
100134564:     	add	w11, w11, w13, uxth
100134568:     	ldr	x16, [sp, #0x280]
10013456c:     	ldrh	w12, [x16, #0x4]
100134570:     	add	w10, w10, w8, uxth
100134574:     	ldrh	w8, [x16, #0x6]
100134578:     	ldr	w13, [x16, #0x180]
10013457c:     	ldr	w14, [x16, #0x17c]
100134580:     	and	w15, w15, #0x3
100134584:     	strb	w15, [sp, #0x30c]
100134588:     	ldrb	w15, [x16, #0x1d5]
10013458c:     	cbz	w15, 0x1001345d8 <_render.TerminalRenderer.drawPane+0x611c>
100134590:     	ldr	b0, [x16, #0x1d2]
100134594:     	ucvtf	s0, s0
100134598:     	mov	w15, #0x437f0000        ; =1132396544
10013459c:     	fmov	s1, w15
1001345a0:     	fdiv	s0, s0, s1
1001345a4:     	ldr	b2, [x16, #0x1d3]
1001345a8:     	ucvtf	s2, s2
1001345ac:     	fdiv	s2, s2, s1
1001345b0:     	ldr	b3, [x16, #0x1d4]
1001345b4:     	ucvtf	s3, s3
1001345b8:     	str	s0, [sp, #0xf00]
1001345bc:     	str	s2, [sp, #0xf04]
1001345c0:     	fdiv	s0, s3, s1
1001345c4:     	str	s0, [sp, #0xf08]
1001345c8:     	mov	w15, #0x3f800000        ; =1065353216
1001345cc:     	str	w15, [sp, #0xf0c]
1001345d0:     	add	x15, sp, #0xf00
1001345d4:     	b	0x1001345f0 <_render.TerminalRenderer.drawPane+0x6134>
1001345d8:     	ldr	x17, [sp, #0x290]
1001345dc:     	add	x15, x17, #0x10, lsl #12 ; =0x10000
1001345e0:     	ldr	q0, [x15, #0x6ba0]
1001345e4:     	str	q0, [sp, #0x2300]
1001345e8:     	add	x15, sp, #0x2, lsl #12  ; =0x2000
1001345ec:     	add	x15, x15, #0x300
1001345f0:     	madd	w11, w12, w11, w14
1001345f4:     	madd	w10, w8, w10, w13
1001345f8:     	mul	w9, w9, w12
1001345fc:     	ldr	q0, [x15]
100134600:     	str	q0, [sp, #0x310]
100134604:     	ldrb	w12, [x16, #0x1d9]
100134608:     	cbz	w12, 0x100134640 <_render.TerminalRenderer.drawPane+0x6184>
10013460c:     	ldr	b0, [x16, #0x1d6]
100134610:     	ucvtf	s0, s0
100134614:     	mov	w12, #0x437f0000        ; =1132396544
100134618:     	fmov	s1, w12
10013461c:     	fdiv	s7, s0, s1
100134620:     	ldr	b0, [x16, #0x1d7]
100134624:     	ucvtf	s0, s0
100134628:     	fdiv	s6, s0, s1
10013462c:     	ldr	b0, [x16, #0x1d8]
100134630:     	ucvtf	s0, s0
100134634:     	fmov	s5, #1.00000000
100134638:     	fdiv	s16, s0, s1
10013463c:     	b	0x100134650 <_render.TerminalRenderer.drawPane+0x6194>
100134640:     	ldr	s7, [x16, #0x1ac]
100134644:     	ldr	s6, [x16, #0x1b0]
100134648:     	ldr	s16, [x16, #0x1b4]
10013464c:     	ldr	s5, [x16, #0x1b8]
100134650:     	ucvtf	s2, w11
100134654:     	ucvtf	s15, w10
100134658:     	ucvtf	s14, w9
10013465c:     	ucvtf	s13, w8
100134660:     	ldr	s0, [x16, #0x178]
100134664:     	fadd	s0, s0, s0
100134668:     	frinta	s0, s0
10013466c:     	fmov	s1, #1.00000000
100134670:     	fmaxnm	s12, s0, s1
100134674:     	ldrb	w19, [sp, #0x30c]
100134678:     	tst	w19, #0x3
10013467c:     	str	w19, [sp, #0x1e0]
100134680:     	str	s12, [sp, #0x148]
100134684:     	str	s13, [sp, #0x120]
100134688:     	str	s14, [sp, #0x118]
10013468c:     	str	s15, [sp, #0x1c8]
100134690:     	str	s2, [sp, #0x1c0]
100134694:     	b.eq	0x1001346a0 <_render.TerminalRenderer.drawPane+0x61e4>
100134698:     	str	wzr, [sp, #0x2b8]
10013469c:     	b	0x100133764 <_render.TerminalRenderer.drawPane+0x52a8>
1001346a0:     	str	s2, [sp, #0x32c]
1001346a4:     	str	s15, [sp, #0x330]
1001346a8:     	str	s14, [sp, #0x334]
1001346ac:     	str	s13, [sp, #0x338]
1001346b0:     	ldr	q0, [sp, #0x310]
1001346b4:     	add	x8, sp, #0x23d
1001346b8:     	stur	q0, [x8, #0xff]
1001346bc:     	fmov	d10, d7
1001346c0:     	str	s7, [sp, #0x34c]
1001346c4:     	fmov	d9, d6
1001346c8:     	str	s6, [sp, #0x350]
1001346cc:     	fmov	d11, d16
1001346d0:     	str	s16, [sp, #0x354]
1001346d4:     	fmov	d8, d5
1001346d8:     	str	s5, [sp, #0x358]
1001346dc:     	str	s12, [sp, #0x35c]
1001346e0:     	strb	w19, [sp, #0x360]
1001346e4:     	ldrh	w8, [sp, #0x308]
1001346e8:     	add	x9, sp, #0x32c
1001346ec:     	sturh	w8, [x9, #0x35]
1001346f0:     	ldrb	w8, [sp, #0x30a]
1001346f4:     	strb	w8, [sp, #0x363]
1001346f8:     	add	x0, sp, #0x32c
1001346fc:     	mov	w8, #0x2958             ; =10584
100134700:     	movk	w8, #0x1, lsl #16
100134704:     	ldr	x9, [sp, #0x290]
100134708:     	add	x1, x9, x8
10013470c:     	bl	0x10012e358 <_render.CursorPaint.paint>
100134710:     	ands	w0, w0, #0xffff
100134714:     	b.ne	0x10013452c <_render.TerminalRenderer.drawPane+0x6070>
100134718:     	str	wzr, [sp, #0x2b8]
10013471c:     	ldr	x2, [sp, #0x298]
100134720:     	fmov	d5, d8
100134724:     	fmov	d6, d9
100134728:     	fmov	d7, d10
10013472c:     	fmov	d16, d11
100134730:     	b	0x100133764 <_render.TerminalRenderer.drawPane+0x52a8>
100134734:     	ldr	w11, [x9, #0xfc]
100134738:     	subs	w10, w10, w11
10013473c:     	b.hs	0x100134758 <_render.TerminalRenderer.drawPane+0x629c>
100134740:     	mov	w12, #0x0               ; =0
100134744:     	b	0x1001336b0 <_render.TerminalRenderer.drawPane+0x51f4>
100134748:     	cbnz	w12, 0x10013476c <_render.TerminalRenderer.drawPane+0x62b0>
10013474c:     	ldr	x12, [sp, #0x280]
100134750:     	ldrb	w15, [x12, #0x13c]
100134754:     	b	0x100134564 <_render.TerminalRenderer.drawPane+0x60a8>
100134758:     	cmp	w10, w16
10013475c:     	cset	w12, lo
100134760:     	b	0x1001336b0 <_render.TerminalRenderer.drawPane+0x51f4>
100134764:     	mov	w15, #0x1               ; =1
100134768:     	b	0x100134564 <_render.TerminalRenderer.drawPane+0x60a8>
10013476c:     	mov	w15, #0x0               ; =0
100134770:     	b	0x100134564 <_render.TerminalRenderer.drawPane+0x60a8>

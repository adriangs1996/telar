stp	x28, x27, [sp, #-0x60]!
stp	x26, x25, [sp, #0x10]
stp	x24, x23, [sp, #0x20]
stp	x22, x21, [sp, #0x30]
stp	x20, x19, [sp, #0x40]
stp	x29, x30, [sp, #0x50]
add	x29, sp, #0x50
sub	sp, sp, #0xda0
mov	x19, x2
mov	x21, x0
ldp	x25, x27, [x1]
ldr	x23, [x1, #0x68]
ldr	x9, [x27, #0x2c0]
mov	w22, #0x1               ; =1
add	x8, sp, #0x930
mov	x0, x25
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [sp, #0x930]
str	x8, [sp, #0x40]
cbz	x19, <_main.timed__anon>
str	x19, [sp, #0x18]
mov	x9, #0x0                ; =0
add	x19, x23, #0x11, lsl #12 ; =0x11000
add	x28, x19, #0xaa0
add	x8, x19, #0xaa8
stp	xzr, x8, [sp, #0x60]
add	x8, x23, #0x11, lsl #12 ; =0x11000
add	x8, x8, #0x830
str	x8, [sp, #0x48]
add	x20, x19, #0xa38
add	x8, x23, #0x11, lsl #12 ; =0x11000
add	x8, x8, #0xae8
str	x8, [sp, #0x30]
add	x24, x19, #0xaa4
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [sp]
adrp x26, RELOC_PAGE
add	x26, x26, #RELOC_OFFSET
stp	x21, x28, [sp, #0x50]
stp	x27, x25, [sp, #0x20]
str	x9, [sp, #0x38]
mov	w8, #0x0                ; =0
ldr	x27, [x19, #0x800]
ldr	x21, [x19, #0x808]
casa	w8, w22, [x28]
cmp	w8, #0x0
cset	w9, eq
eor	w9, w9, #0x1
strb	w9, [sp, #0x930]
cbnz	w9, <_main.timed__anon>
ldrb	w8, [x19, #0xb28]
cmp	w8, #0x1
b.ne	<_main.timed__anon>
ldr	x8, [sp, #0x68]
ldrb	w8, [x8]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xaa9]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xaaa]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xaab]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xaac]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xaad]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xaae]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xaaf]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xab0]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xab1]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xab2]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xab3]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xab4]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xab5]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xab6]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xab7]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xab8]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xab9]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xaba]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xabb]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xabc]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xabd]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xabe]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xabf]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xac0]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xac1]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xac2]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xac3]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xac4]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xac5]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xac6]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xac7]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xac8]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xac9]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xaca]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xacb]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xacc]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xacd]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xace]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xacf]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xad0]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xad1]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xad2]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xad3]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xad4]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xad5]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xad6]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xad7]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xad8]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xad9]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xada]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xadb]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xadc]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xadd]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xade]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xadf]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xae0]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xae1]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xae2]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xae3]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xae4]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xae5]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xae6]
tst	w8, #0x3
b.eq	<_main.timed__anon>
ldrb	w8, [x19, #0xae7]
tst	w8, #0x3
b.eq	<_main.timed__anon>
mov	x28, #0x0               ; =0
mov	w27, #0x0               ; =0
ldr	x8, [x19, #0xa80]
adds	x8, x8, #0x1
csinv	x8, x8, xzr, lo
str	x8, [x19, #0xa80]
mov	w0, #0x262              ; =610
b	<_main.timed__anon>
mov	x28, #0x0               ; =0
mov	w27, #0x0               ; =0
mov	w0, #0x261              ; =609
b	<_main.timed__anon>
mov	x28, #0x0               ; =0
b	<_main.timed__anon>
mov	w28, #0x1               ; =1
b	<_main.timed__anon>
mov	w28, #0x2               ; =2
b	<_main.timed__anon>
mov	w28, #0x3               ; =3
b	<_main.timed__anon>
mov	w28, #0x4               ; =4
b	<_main.timed__anon>
mov	w28, #0x5               ; =5
b	<_main.timed__anon>
mov	w28, #0x6               ; =6
b	<_main.timed__anon>
mov	w28, #0x7               ; =7
b	<_main.timed__anon>
mov	w28, #0x8               ; =8
b	<_main.timed__anon>
mov	w28, #0x9               ; =9
b	<_main.timed__anon>
mov	w28, #0xa               ; =10
b	<_main.timed__anon>
mov	w28, #0xb               ; =11
b	<_main.timed__anon>
mov	w28, #0xc               ; =12
b	<_main.timed__anon>
cmp	w8, #0x2
b.eq	<_main.timed__anon>
b	<_main.timed__anon>
mov	w28, #0xd               ; =13
b	<_main.timed__anon>
mov	w28, #0xe               ; =14
b	<_main.timed__anon>
mov	w28, #0xf               ; =15
b	<_main.timed__anon>
mov	w28, #0x10              ; =16
b	<_main.timed__anon>
mov	w28, #0x11              ; =17
b	<_main.timed__anon>
mov	w28, #0x12              ; =18
b	<_main.timed__anon>
mov	w28, #0x13              ; =19
b	<_main.timed__anon>
mov	w28, #0x14              ; =20
b	<_main.timed__anon>
mov	w28, #0x15              ; =21
b	<_main.timed__anon>
mov	w28, #0x16              ; =22
b	<_main.timed__anon>
mov	w28, #0x17              ; =23
b	<_main.timed__anon>
mov	w28, #0x18              ; =24
b	<_main.timed__anon>
mov	w28, #0x19              ; =25
b	<_main.timed__anon>
mov	w28, #0x1a              ; =26
b	<_main.timed__anon>
mov	w28, #0x1b              ; =27
b	<_main.timed__anon>
mov	w28, #0x1c              ; =28
b	<_main.timed__anon>
mov	w28, #0x1d              ; =29
b	<_main.timed__anon>
mov	w28, #0x1e              ; =30
b	<_main.timed__anon>
mov	w28, #0x1f              ; =31
b	<_main.timed__anon>
mov	w28, #0x20              ; =32
b	<_main.timed__anon>
mov	w28, #0x21              ; =33
b	<_main.timed__anon>
mov	w28, #0x22              ; =34
b	<_main.timed__anon>
mov	w28, #0x23              ; =35
b	<_main.timed__anon>
mov	w28, #0x24              ; =36
b	<_main.timed__anon>
mov	w28, #0x25              ; =37
b	<_main.timed__anon>
mov	w28, #0x26              ; =38
b	<_main.timed__anon>
mov	w28, #0x27              ; =39
b	<_main.timed__anon>
mov	w28, #0x28              ; =40
b	<_main.timed__anon>
mov	w28, #0x29              ; =41
b	<_main.timed__anon>
mov	w28, #0x2a              ; =42
b	<_main.timed__anon>
mov	w28, #0x2b              ; =43
b	<_main.timed__anon>
mov	w28, #0x2c              ; =44
b	<_main.timed__anon>
mov	w28, #0x2d              ; =45
b	<_main.timed__anon>
mov	w28, #0x2e              ; =46
b	<_main.timed__anon>
mov	w28, #0x2f              ; =47
b	<_main.timed__anon>
mov	w28, #0x30              ; =48
b	<_main.timed__anon>
mov	w28, #0x31              ; =49
b	<_main.timed__anon>
mov	w28, #0x32              ; =50
b	<_main.timed__anon>
mov	w28, #0x33              ; =51
b	<_main.timed__anon>
mov	w28, #0x34              ; =52
b	<_main.timed__anon>
mov	w28, #0x35              ; =53
b	<_main.timed__anon>
mov	w28, #0x36              ; =54
b	<_main.timed__anon>
mov	w28, #0x37              ; =55
b	<_main.timed__anon>
mov	w28, #0x38              ; =56
b	<_main.timed__anon>
mov	w28, #0x39              ; =57
b	<_main.timed__anon>
mov	w28, #0x3a              ; =58
b	<_main.timed__anon>
mov	w28, #0x3b              ; =59
b	<_main.timed__anon>
mov	w28, #0x3c              ; =60
b	<_main.timed__anon>
mov	w28, #0x3d              ; =61
b	<_main.timed__anon>
mov	w28, #0x3e              ; =62
b	<_main.timed__anon>
mov	w28, #0x3f              ; =63
mov	w0, #0x0                ; =0
mov	w27, #0x1               ; =1
ldr	x8, [sp, #0x68]
strb	w27, [x8, x28]
ldr	x9, [sp, #0x48]
ldr	x8, [x9, x28, lsl #3]
add	x21, x8, #0x1
str	x21, [x9, x28, lsl #3]
ldr	x8, [x19, #0xa40]
add	x8, x8, #0x1
str	x8, [x19, #0xa40]
ldr	x9, [x19, #0xa60]
ldr	x10, [x19, #0xa38]
add	x8, x10, x8
cmp	x9, x8
csel	x8, x9, x8, hi
str	x8, [x19, #0xa60]
ldr	x8, [x19, #0x800]
ldr	x9, [x19, #0x808]
add	x10, x19, #0xaa0
swpl	wzr, w10, [x10]
cmp	w10, #0x2
b.eq	<_main.timed__anon>
cbz	w27, <_main.timed__anon>
mov	w8, #0x0                ; =0
ldr	x27, [x19, #0x800]
ldr	x25, [x19, #0x808]
add	x9, x19, #0xaa0
casa	w8, w22, [x9]
cmp	w8, #0x0
cset	w9, eq
eor	w9, w9, #0x1
strb	w9, [sp, #0x930]
cbnz	w9, <_main.timed__anon>
ldr	x8, [sp, #0x68]
ldrb	w8, [x8, x28]
and	w8, w8, #0x3
cmp	w8, #0x1
b.ne	<_main.timed__anon>
ldr	x8, [sp, #0x48]
ldr	x8, [x8, x28, lsl #3]
cmp	x8, x21
b.ne	<_main.timed__anon>
ldrb	w8, [x19, #0xb28]
tbz	w8, #0x0, <_main.timed__anon>
mov	w8, #0x460              ; =1120
umaddl	x0, w28, w8, x23
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	w2, #0x460              ; =1120
bl	<_memcpy>
ldr	x8, [sp, #0x68]
mov	w9, #0x2                ; =2
strb	w9, [x8, x28]
ldr	w8, [x19, #0xa30]
ldr	q0, [x20]
ldr	x9, [x19, #0xa38]
add	w8, w9, w8
and	x8, x8, #0x3f
ldr	x10, [sp, #0x30]
strb	w28, [x10, x8]
ldr	q1, [sp]
add.2d	v0, v0, v1
str	q0, [x20]
ldr	x8, [x19, #0xa68]
adds	x8, x8, #0x1
csinv	x8, x8, xzr, lo
str	x8, [x19, #0xa68]
ldr	x25, [sp, #0x58]
cbnz	x9, <_main.timed__anon>
ldr	x0, [x19, #0x800]
ldr	x8, [x19, #0x808]
add	x9, x19, #0xaa4
mov	w10, #0x2               ; =2
swpl	w10, w9, [x9]
cmp	w9, #0x1
b.ne	<_main.timed__anon>
ldr	x8, [x8, #0x70]
mov	x1, x24
mov	w2, #-0x1               ; =-1
blr	x8
ldr	x8, [x19, #0xa90]
adds	x8, x8, #0x1
csinv	x8, x8, xzr, lo
str	x8, [x19, #0xa90]
ldr	x8, [x19, #0x818]
cbz	x8, <_main.timed__anon>
ldr	x0, [x19, #0x810]
blr	x8
ldr	q0, [x19, #0x800]
add	x8, x19, #0xaa0
swpl	wzr, w8, [x8]
cmp	w8, #0x2
b.ne	<_main.timed__anon>
b	<_main.timed__anon>
ldr	x8, [sp, #0x68]
strb	wzr, [x8, x28]
ldr	x8, [x19, #0xa40]
sub	x8, x8, #0x1
str	x8, [x19, #0xa40]
ldr	x8, [x19, #0xa88]
adds	x8, x8, #0x1
csinv	x8, x8, xzr, lo
str	x8, [x19, #0xa88]
ldr	q0, [x19, #0x800]
add	x8, x19, #0xaa0
swpl	wzr, w8, [x8]
cmp	w8, #0x2
ldr	x25, [sp, #0x58]
b.ne	<_main.timed__anon>
mov.d	x8, v0[1]
ldr	x8, [x8, #0x70]
fmov	x0, d0
b	<_main.timed__anon>
ldr	x9, [x9, #0x70]
mov	x25, x0
mov	x0, x8
ldr	x1, [sp, #0x58]
mov	w2, #0x1                ; =1
blr	x9
mov	x0, x25
cbnz	w27, <_main.timed__anon>
b	<_main.timed__anon>
cmp	w8, #0x2
b.ne	<_main.timed__anon>
ldr	x8, [x25, #0x68]
mov	x0, x27
ldr	x1, [sp, #0x58]
mov	w2, #0x2                ; =2
blr	x8
ldr	x8, [sp, #0x58]
mov	w9, #0x2                ; =2
swpa	w9, w8, [x8]
cbz	w8, <_main.timed__anon>
ldr	x8, [x25, #0x68]
mov	x0, x27
ldr	x1, [sp, #0x58]
mov	w2, #0x2                ; =2
blr	x8
mov	w8, #0x2                ; =2
ldr	x9, [sp, #0x58]
swpa	w8, w8, [x9]
cbnz	w8, <_main.timed__anon>
b	<_main.timed__anon>
ldr	x8, [x21, #0x68]
mov	x0, x27
mov	x1, x28
mov	w2, #0x2                ; =2
blr	x8
mov	w8, #0x2                ; =2
swpa	w8, w8, [x28]
cbnz	w8, <_main.timed__anon>
b	<_main.timed__anon>
ldr	x0, [x19, #0x800]
ldr	x8, [x19, #0x808]
add	x9, x19, #0xaa0
swpl	wzr, w9, [x9]
cmp	w9, #0x2
b.eq	<_main.timed__anon>
mov	w8, #0x0                ; =0
ldr	x27, [x19, #0x800]
ldr	x21, [x19, #0x808]
add	x9, x19, #0xaa0
casa	w8, w22, [x9]
cmp	w8, #0x0
cset	w9, eq
eor	w9, w9, #0x1
sturb	w9, [x29, #-0x5c]
cbnz	w9, <_main.timed__anon>
ldr	x21, [x20]
cbnz	x21, <_main.timed__anon>
ldrb	w10, [x19, #0xb28]
ldr	x0, [x19, #0x800]
ldr	x8, [x19, #0x808]
add	x9, x19, #0xaa0
swpl	wzr, w9, [x9]
cmp	w9, #0x2
tbz	w10, #0x0, <_main.timed__anon>
b.eq	<_main.timed__anon>
add	x0, sp, #0x4d0
mov	w1, #0x460              ; =1120
bl	<dyld_stub_binder>
mov	w8, #0x0                ; =0
ldr	x27, [x19, #0x800]
ldr	x21, [x19, #0x808]
add	x9, x19, #0xaa4
casa	w8, w22, [x9]
cmp	w8, #0x0
cset	w9, eq
eor	w9, w9, #0x1
strb	w9, [sp, #0x930]
cmp	w9, #0x0
ccmp	w8, #0x2, #0x0, ne
b.eq	<_main.timed__anon>
ldr	x8, [x21, #0x60]
mov	x0, x27
mov	x1, x24
mov	w2, #0x1                ; =1
mov	x3, x26
blr	x8
tst	w0, #0xffff
b.ne	<_main.timed__anon>
ldapr	w8, [x24]
cmp	w8, #0x2
b.ne	<_main.timed__anon>
mov	w8, #0x0                ; =0
ldr	x27, [x19, #0x800]
ldr	x21, [x19, #0x808]
add	x9, x19, #0xaa0
casa	w8, w22, [x9]
cmp	w8, #0x0
cset	w9, eq
eor	w9, w9, #0x1
strb	w9, [sp, #0x930]
cbnz	w9, <_main.timed__anon>
ldrb	w8, [x19, #0xb28]
tbnz	w8, #0x0, <_main.timed__anon>
ldr	x8, [x20]
cbnz	x8, <_main.timed__anon>
b	<_main.timed__anon>
cmp	w8, #0x2
b.eq	<_main.timed__anon>
b	<_main.timed__anon>
ldr	x8, [x8, #0x70]
mov	x1, x25
mov	w2, #0x1                ; =1
blr	x8
b	<_main.timed__anon>
cmp	w8, #0x2
b.eq	<_main.timed__anon>
b	<_main.timed__anon>
ldr	x8, [x21, #0x68]
mov	x0, x27
mov	x1, x25
mov	w2, #0x2                ; =2
blr	x8
mov	w8, #0x2                ; =2
swpa	w8, w8, [x25]
cbnz	w8, <_main.timed__anon>
b	<_main.timed__anon>
ldr	x8, [x21, #0x68]
mov	x0, x27
mov	x1, x25
mov	w2, #0x2                ; =2
blr	x8
mov	w8, #0x2                ; =2
swpa	w8, w8, [x25]
cbnz	w8, <_main.timed__anon>
b	<_main.timed__anon>
ldr	x25, [x19, #0xa30]
ldr	x8, [sp, #0x30]
ldrb	w27, [x8, x25]
mov	x28, x23
mov	w8, #0x460              ; =1120
umaddl	x1, w27, w8, x23
add	x0, sp, #0x930
mov	w2, #0x460              ; =1120
bl	<_memcpy>
add	w8, w25, #0x1
and	x8, x8, #0x3f
str	x8, [x19, #0xa30]
ldr	x8, [sp, #0x68]
strb	wzr, [x8, x27]
ldr	x8, [x19, #0xa70]
adds	x8, x8, #0x1
csinv	x8, x8, xzr, lo
str	x8, [x19, #0xa70]
sub	x8, x21, #0x1
str	x8, [x19, #0xa38]
cbnz	x8, <_main.timed__anon>
ldrb	w8, [x19, #0xb28]
cmp	w8, #0x1
b.ne	<_main.timed__anon>
str	wzr, [x24]
ldr	x0, [x19, #0x800]
ldr	x8, [x19, #0x808]
add	x9, x19, #0xaa0
swpl	wzr, w9, [x9]
cmp	w9, #0x2
ldr	x21, [sp, #0x50]
ldp	x27, x25, [sp, #0x20]
ldr	x23, [sp, #0x38]
b.eq	<_main.timed__anon>
add	x0, sp, #0x4d0
add	x1, sp, #0x930
mov	w2, #0x460              ; =1120
bl	<_memcpy>
add	x0, sp, #0x70
add	x1, sp, #0x4d0
mov	w2, #0x460              ; =1120
bl	<_memcpy>
add	x1, sp, #0x70
mov	x0, x28
bl	<_InboxContext.handle>
ldr	x8, [x19, #0xb30]
ldr	x9, [sp, #0x60]
add	x9, x8, x9
str	x9, [sp, #0x60]
add	x9, x23, #0x1
ldr	x8, [sp, #0x18]
cmp	x9, x8
mov	x23, x28
ldr	x28, [sp, #0x58]
b.ne	<_main.timed__anon>
b	<_main.timed__anon>
ldr	x8, [x8, #0x70]
mov	x1, x25
mov	w2, #0x1                ; =1
blr	x8
b	<_main.timed__anon>
ldr	x8, [x8, #0x70]
ldr	x1, [sp, #0x58]
mov	w2, #0x1                ; =1
blr	x8
b	<_main.timed__anon>
str	xzr, [sp, #0x60]
ldr	x9, [x27, #0x2c0]
add	x8, sp, #0x930
mov	x0, x25
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [sp, #0x930]
ldr	x9, [sp, #0x40]
sub	x8, x8, x9
ldr	x9, [sp, #0x60]
strh	wzr, [x21, #0x8]
str	x8, [x21]
b	<_main.timed__anon>
b.eq	<_main.timed__anon>
mov	w0, #0x261              ; =609
ldr	x8, [sp, #0x50]
strh	w0, [x8, #0x8]
add	sp, sp, #0xda0
ldp	x29, x30, [sp, #0x50]
ldp	x20, x19, [sp, #0x40]
ldp	x22, x21, [sp, #0x30]
ldp	x24, x23, [sp, #0x20]
ldp	x26, x25, [sp, #0x10]
ldp	x28, x27, [sp], #0x60
ret
ldr	x0, [x19, #0x800]
ldr	x8, [x19, #0x808]
add	x9, x19, #0xaa0
swpl	wzr, w9, [x9]
cmp	w9, #0x2
b.ne	<_main.timed__anon>
ldr	x8, [x8, #0x70]
mov	x1, x25
mov	w2, #0x1                ; =1
blr	x8
b	<_main.timed__anon>

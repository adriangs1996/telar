stp	x28, x27, [sp, #-0x50]!
stp	x24, x23, [sp, #0x10]
stp	x22, x21, [sp, #0x20]
stp	x20, x19, [sp, #0x30]
stp	x29, x30, [sp, #0x40]
add	x29, sp, #0x40
sub	sp, sp, #0x1, lsl #12   ; =0x1000
sub	sp, sp, #0x940
mov	x19, x0
ldr	x22, [x1, #0xbe8]
cbz	x22, <_workspace.WorkspaceLayout.focusDirection>
mov	x20, x1
ldrb	w8, [x1, #0xbfb]
tbz	w8, #0x0, <_workspace.WorkspaceLayout.focusDirection>
tbnz	w2, #0x1, <_workspace.WorkspaceLayout.focusDirection>
ldrb	w8, [x20, #0xbf9]
cbz	w8, <_workspace.WorkspaceLayout.focusDirection>
mov	x8, #0x0                ; =0
ldrb	w9, [x20, #0xbf8]
strb	w9, [sp, #0xcd8]
mov	w12, #0x1               ; =1
add	x9, sp, #0xcd8
mov	w10, #0x18              ; =24
add	x11, sp, #0xd58
b	<_workspace.WorkspaceLayout.focusDirection>
str	x14, [x11, x8, lsl #3]
add	x8, x8, #0x1
mov	x12, x13
cbz	x13, <_workspace.WorkspaceLayout.focusDirection>
sub	x13, x12, #0x1
ldrb	w14, [x9, x13]
umaddl	x15, w14, w10, x20
ldr	x14, [x15]
ldrb	w15, [x15, #0x8]
and	w15, w15, #0x3
cmp	w15, #0x2
b.ne	<_workspace.WorkspaceLayout.focusDirection>
lsr	x15, x14, #24
lsr	x14, x14, #32
strb	w14, [x9, x13]
strb	w15, [x9, x12]
add	x12, x12, #0x1
cbnz	x12, <_workspace.WorkspaceLayout.focusDirection>
cbz	x8, <_workspace.WorkspaceLayout.focusDirection>
mov	x10, #0x0               ; =0
add	x9, sp, #0xd58
ldr	x11, [x9]
cmp	x11, x22
b.eq	<_workspace.WorkspaceLayout.focusDirection>
add	x10, x10, #0x1
add	x9, x9, #0x8
cmp	x8, x10
b.ne	<_workspace.WorkspaceLayout.focusDirection>
mov	w8, #0x0                ; =0
stp	xzr, xzr, [sp]
mov	x21, sp
cbnz	w8, <_workspace.WorkspaceLayout.focusDirection>
b	<_workspace.WorkspaceLayout.focusDirection>
stp	xzr, xzr, [x19]
b	<_workspace.WorkspaceLayout.focusDirection>
mov	x23, x2
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
add	x24, sp, #0x10
add	x0, sp, #0x10
mov	w2, #0xcb8              ; =3256
mov	x21, x3
bl	<_memcpy>
add	x2, sp, #0x10
mov	x0, x20
mov	x1, x21
bl	<_workspace.WorkspaceLayout.snapshotTiled>
add	x8, x24, #0x820
eor	x9, x22, x22, lsr #32
mov	x10, #0x556d            ; =21869
movk	x10, #0xeb34, lsl #16
movk	x10, #0x25f9, lsl #32
movk	x10, #0xbea2, lsl #48
mul	x9, x9, x10
eor	x9, x9, x9, lsr #29
mul	x9, x9, x10
eor	x9, x9, x9, lsr #32
mul	x9, x9, x10
eor	x10, x9, x9, lsr #29
mov	w9, #0x80               ; =128
and	x10, x10, #0x7f
ldr	x11, [x8, x10, lsl #3]
cmp	x11, x22
b.eq	<_workspace.WorkspaceLayout.focusDirection>
cbz	x11, <_workspace.WorkspaceLayout.focusDirection>
add	x10, x10, #0x1
subs	x9, x9, #0x1
b.ne	<_workspace.WorkspaceLayout.focusDirection>
str	xzr, [sp, #0xcd0]
str	xzr, [sp, #0xcc8]
add	x21, sp, #0xcc8
b	<_workspace.WorkspaceLayout.focusDirection>
ldrb	w9, [sp, #0xcc3]
cbz	x9, <_workspace.WorkspaceLayout.focusDirection>
mov	w8, #0x0                ; =0
add	x16, sp, #0x10
add	x10, x16, x10
ldrb	w10, [x10, #0xc20]
add	x12, x16, x10, lsl #5
ldrh	w10, [x12, #0x28]
ldrh	w11, [x12, #0x2a]
ldrh	w15, [x12, #0x2c]
ldrh	w14, [x12, #0x2e]
add	w12, w15, w10, lsl #1
add	w13, w14, w11, lsl #1
add	w14, w14, w11
add	w15, w15, w10
add	x16, x16, #0x2e
mov	x17, #-0x1              ; =-1
mov	x1, x23
b	<_workspace.WorkspaceLayout.focusDirection>
add	x16, x16, #0x20
subs	x9, x9, #0x1
b.eq	<_workspace.WorkspaceLayout.focusDirection>
ldur	x2, [x16, #-0xe]
cmp	x2, x22
b.eq	<_workspace.WorkspaceLayout.focusDirection>
ldrh	w3, [x16]
ldurh	w4, [x16, #-0x2]
ldurh	w5, [x16, #-0x4]
ldurh	w6, [x16, #-0x6]
and	w7, w1, #0x3
cmp	w7, #0x1
b.gt	<_workspace.WorkspaceLayout.focusDirection>
add	w5, w3, w5, lsl #1
cbnz	w7, <_workspace.WorkspaceLayout.focusDirection>
add	w6, w6, w4
subs	w3, w10, w6
csel	w3, wzr, w3, lo
subs	w4, w13, w5
cneg	w4, w4, mi
cmp	w6, w10
b.hi	<_workspace.WorkspaceLayout.focusDirection>
b	<_workspace.WorkspaceLayout.focusDirection>
add	w4, w4, w6, lsl #1
cmp	w7, #0x2
b.ne	<_workspace.WorkspaceLayout.focusDirection>
add	w5, w5, w3
subs	w3, w11, w5
csel	w3, wzr, w3, lo
subs	w4, w12, w4
cneg	w4, w4, mi
cmp	w5, w11
b.hi	<_workspace.WorkspaceLayout.focusDirection>
b	<_workspace.WorkspaceLayout.focusDirection>
subs	w3, w6, w15
csel	w3, wzr, w3, lo
subs	w4, w13, w5
cneg	w4, w4, mi
cmp	w15, w6
b.ls	<_workspace.WorkspaceLayout.focusDirection>
b	<_workspace.WorkspaceLayout.focusDirection>
subs	w3, w5, w14
csel	w3, wzr, w3, lo
subs	w4, w12, w4
cneg	w4, w4, mi
cmp	w14, w5
b.hi	<_workspace.WorkspaceLayout.focusDirection>
lsr	w4, w4, #1
mov	w3, w3
add	x3, x4, x3, lsl #16
cmp	x3, x17
b.hs	<_workspace.WorkspaceLayout.focusDirection>
mov	w8, #0x1                ; =1
mov	x17, x3
mov	x0, x2
b	<_workspace.WorkspaceLayout.focusDirection>
mov	w8, #0x0                ; =0
str	x0, [sp, #0xcc8]
strb	w8, [sp, #0xcd0]
add	x9, sp, #0xbd2
stur	wzr, [x9, #0xff]
add	x21, sp, #0xcc8
str	wzr, [sp, #0xcd4]
cbnz	w8, <_workspace.WorkspaceLayout.focusDirection>
b	<_workspace.WorkspaceLayout.focusDirection>
tst	w2, #0x3
b.eq	<_workspace.WorkspaceLayout.focusDirection>
add	x10, x10, #0x1
cmp	x10, x8
b.hs	<_workspace.WorkspaceLayout.focusDirection>
ldr	x8, [x9, #0x8]
b	<_workspace.WorkspaceLayout.focusDirection>
cbz	x10, <_workspace.WorkspaceLayout.focusDirection>
ldur	x8, [x9, #-0x8]
str	x8, [sp, #0xcd8]
add	x8, sp, #0xcd8
mov	w9, #0x1                ; =1
strb	w9, [x8, #0x8]
b	<_workspace.WorkspaceLayout.focusDirection>
adrp x8, RELOC_PAGE
add	x8, x8, #RELOC_OFFSET
ldr	q0, [x8]
str	q0, [sp]
ldrb	w8, [sp, #0x8]
mov	x21, sp
cbz	w8, <_workspace.WorkspaceLayout.focusDirection>
ldr	x23, [x21]
add	x24, sp, #0xd58
add	x0, sp, #0xd58
mov	x1, x20
mov	w2, #0xbe8              ; =3048
bl	<_memcpy>
mov	x8, #0x0                ; =0
add	x9, x24, x8
ldr	x10, [x9]
ldrb	w9, [x9, #0x8]
and	w9, w9, #0x3
cmp	w9, #0x1
ccmp	x10, x23, #0x0, eq
cset	w9, eq
b.eq	<_workspace.WorkspaceLayout.focusDirection>
cmp	x8, #0xbd0
add	x8, x8, #0x18
b.ne	<_workspace.WorkspaceLayout.focusDirection>
cmp	x22, x23
csel	w8, wzr, w9, eq
cmp	w8, #0x1
b.ne	<_workspace.WorkspaceLayout.focusDirection>
str	x23, [x20, #0xbe8]
ldr	x8, [x20, #0xbf0]
add	x9, x8, #0x1
cmp	x9, #0x1
mov	w9, #0x1                ; =1
csinc	x8, x9, x8, ls
str	x8, [x20, #0xbf0]
ldr	q0, [x21]
str	q0, [x19]
add	sp, sp, #0x1, lsl #12   ; =0x1000
add	sp, sp, #0x940
ldp	x29, x30, [sp, #0x40]
ldp	x20, x19, [sp, #0x30]
ldp	x22, x21, [sp, #0x20]
ldp	x24, x23, [sp, #0x10]
ldp	x28, x27, [sp], #0x50
ret

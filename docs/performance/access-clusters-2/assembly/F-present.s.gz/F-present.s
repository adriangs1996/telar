
/tmp/telar-access-clusters-2.QhXJGE/F/bin/telar-benchmarks:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010023eb10 <_main.timed__anon_62765>:
10023eb10:     	stp	x28, x27, [sp, #-0x60]!
10023eb14:     	stp	x26, x25, [sp, #0x10]
10023eb18:     	stp	x24, x23, [sp, #0x20]
10023eb1c:     	stp	x22, x21, [sp, #0x30]
10023eb20:     	stp	x20, x19, [sp, #0x40]
10023eb24:     	stp	x29, x30, [sp, #0x50]
10023eb28:     	add	x29, sp, #0x50
10023eb2c:     	sub	sp, sp, #0x4, lsl #12   ; =0x4000
10023eb30:     	sub	sp, sp, #0x110
10023eb34:     	mov	x19, x2
10023eb38:     	str	x0, [sp, #0x20]
10023eb3c:     	ldp	x0, x8, [x1]
10023eb40:     	ldr	x22, [x1, #0x68]
10023eb44:     	stp	x8, x0, [sp, #0x10]
10023eb48:     	ldr	x9, [x8, #0x2c0]
10023eb4c:     	add	x20, sp, #0xac0
10023eb50:     	add	x8, sp, #0xac0
10023eb54:     	mov	w1, #0x1                ; =1
10023eb58:     	blr	x9
10023eb5c:     	ldr	x8, [sp, #0xac0]
10023eb60:     	str	x8, [sp, #0x8]
10023eb64:     	str	x19, [sp, #0x38]
10023eb68:     	cbz	x19, 0x10023f6a0 <_main.timed__anon_62765+0xb90>
10023eb6c:     	mov	x23, #0x0               ; =0
10023eb70:     	mov	x21, #0x0               ; =0
10023eb74:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10023eb78:     	add	x8, x8, #0xd8
10023eb7c:     	add	x9, sp, #0x2, lsl #12   ; =0x2000
10023eb80:     	add	x9, x9, #0x280
10023eb84:     	add	x10, x9, #0x20
10023eb88:     	str	x10, [sp, #0x50]
10023eb8c:     	add	x10, x9, #0x38
10023eb90:     	add	x9, x20, #0x938
10023eb94:     	str	x9, [sp, #0x160]
10023eb98:     	add	x9, x20, #0x948
10023eb9c:     	stp	x10, x9, [sp, #0x28]
10023eba0:     	add	x8, x8, #0x20
10023eba4:     	str	x8, [sp, #0x40]
10023eba8:     	str	x22, [sp, #0x178]
10023ebac:     	ldr	x14, [x22, #0x20]
10023ebb0:     	mov	w8, #0x50b8             ; =20664
10023ebb4:     	movk	w8, #0x13, lsl #16
10023ebb8:     	add	x20, x14, x8
10023ebbc:     	ldrh	w8, [x20, #0x80]
10023ebc0:     	ldrh	w9, [x20, #0x82]
10023ebc4:     	ldrb	w10, [x20, #0x89]
10023ebc8:     	cmp	w10, #0x1
10023ebcc:     	stp	x23, x21, [sp, #0x58]
10023ebd0:     	b.ne	0x10023ec54 <_main.timed__anon_62765+0x144>
10023ebd4:     	mov	w10, #0x0               ; =0
10023ebd8:     	mov	w11, #0xfba2            ; =64418
10023ebdc:     	movk	w11, #0x26, lsl #16
10023ebe0:     	add	x11, x14, x11
10023ebe4:     	ldrb	w12, [x11, #0x1d9]
10023ebe8:     	cmp	w12, #0x1
10023ebec:     	b.ne	0x10023ec18 <_main.timed__anon_62765+0x108>
10023ebf0:     	cmp	w8, #0x3e
10023ebf4:     	b.lo	0x10023ec18 <_main.timed__anon_62765+0x108>
10023ebf8:     	ldrh	w10, [x11]
10023ebfc:     	sub	w11, w8, #0x14
10023ec00:     	and	w11, w11, #0xffff
10023ec04:     	cmp	w10, w11
10023ec08:     	csel	w10, w10, w11, lo
10023ec0c:     	cmp	w10, #0x2a
10023ec10:     	mov	w11, #0x2a              ; =42
10023ec14:     	csel	w10, w10, w11, hi
10023ec18:     	cmp	w9, #0x1
10023ec1c:     	cset	w11, hi
10023ec20:     	cmp	w9, #0x0
10023ec24:     	cset	w12, ne
10023ec28:     	cmp	w10, w8
10023ec2c:     	csel	w10, w10, w8, lo
10023ec30:     	sub	w8, w8, w10
10023ec34:     	cmp	w12, w9
10023ec38:     	csel	w12, w12, w9, lo
10023ec3c:     	sub	w9, w9, w12
10023ec40:     	and	w9, w9, #0xffff
10023ec44:     	subs	w9, w9, w11
10023ec48:     	csel	w9, wzr, w9, lo
10023ec4c:     	orr	x10, x10, x12, lsl #16
10023ec50:     	b	0x10023ec58 <_main.timed__anon_62765+0x148>
10023ec54:     	mov	x10, #0x0               ; =0
10023ec58:     	mov	w11, #0xeb80            ; =60288
10023ec5c:     	movk	w11, #0x26, lsl #16
10023ec60:     	add	x28, x14, x11
10023ec64:     	mov	w11, #0x908             ; =2312
10023ec68:     	movk	w11, #0x23, lsl #16
10023ec6c:     	add	x21, x14, x11
10023ec70:     	mov	w11, #0x5ef0            ; =24304
10023ec74:     	movk	w11, #0x20, lsl #16
10023ec78:     	add	x15, x14, x11
10023ec7c:     	mov	w11, #0xfcb8            ; =64696
10023ec80:     	movk	w11, #0x1d, lsl #16
10023ec84:     	add	x19, x14, x11
10023ec88:     	mov	w11, #0x99d8            ; =39384
10023ec8c:     	movk	w11, #0x17, lsl #16
10023ec90:     	add	x11, x14, x11
10023ec94:     	str	x11, [sp, #0x130]
10023ec98:     	mov	w11, #0x9600            ; =38400
10023ec9c:     	movk	w11, #0x16, lsl #16
10023eca0:     	add	x11, x14, x11
10023eca4:     	str	x11, [sp, #0x148]
10023eca8:     	mov	w11, #0x11c0            ; =4544
10023ecac:     	movk	w11, #0x16, lsl #16
10023ecb0:     	add	x11, x14, x11
10023ecb4:     	str	x11, [sp, #0x138]
10023ecb8:     	mov	w11, #0xaeb0            ; =44720
10023ecbc:     	movk	w11, #0x14, lsl #16
10023ecc0:     	add	x26, x14, x11
10023ecc4:     	mov	w11, #0x9bc8            ; =39880
10023ecc8:     	movk	w11, #0x14, lsl #16
10023eccc:     	add	x11, x14, x11
10023ecd0:     	str	x11, [sp, #0x128]
10023ecd4:     	mov	w11, #0xda70            ; =55920
10023ecd8:     	movk	w11, #0x12, lsl #16
10023ecdc:     	add	x6, x14, x11
10023ece0:     	mov	w11, #0x9340            ; =37696
10023ece4:     	movk	w11, #0x12, lsl #16
10023ece8:     	add	x12, x14, x11
10023ecec:     	mov	w11, #0x5ba8            ; =23464
10023ecf0:     	movk	w11, #0xf, lsl #16
10023ecf4:     	add	x25, x14, x11
10023ecf8:     	mov	w11, #0x30f0            ; =12528
10023ecfc:     	movk	w11, #0xc, lsl #16
10023ed00:     	add	x11, x14, x11
10023ed04:     	str	x11, [sp, #0x120]
10023ed08:     	mov	w11, #0xf0b8            ; =61624
10023ed0c:     	movk	w11, #0xb, lsl #16
10023ed10:     	add	x24, x14, x11
10023ed14:     	ldr	x13, [x20, #0x8]
10023ed18:     	ldr	x11, [x26]
10023ed1c:     	and	w8, w8, #0xffff
10023ed20:     	lsl	x8, x8, #32
10023ed24:     	orr	x8, x8, x9, lsl #48
10023ed28:     	add	x9, x13, x11
10023ed2c:     	add	x9, x9, #0x1
10023ed30:     	str	x9, [sp, #0x180]
10023ed34:     	orr	x8, x8, x10
10023ed38:     	ldr	x9, [x12]
10023ed3c:     	stp	x9, x14, [sp, #0x150]
10023ed40:     	str	x12, [sp, #0x48]
10023ed44:     	str	x8, [sp, #0x80]
10023ed48:     	cbz	x9, 0x10023ed90 <_main.timed__anon_62765+0x280>
10023ed4c:     	ldr	x1, [x12, #0x8]
10023ed50:     	str	x8, [sp, #0x2280]
10023ed54:     	add	x2, sp, #0x2, lsl #12   ; =0x2000
10023ed58:     	add	x2, x2, #0x280
10023ed5c:     	mov	x0, x24
10023ed60:     	str	x1, [sp, #0x168]
10023ed64:     	mov	x22, x15
10023ed68:     	mov	x23, x6
10023ed6c:     	bl	0x10029fd08 <_workspace.tab_layout.snapshot>
10023ed70:     	mov	x6, x23
10023ed74:     	mov	x15, x22
10023ed78:     	ldr	x13, [x20, #0x8]
10023ed7c:     	ldr	x11, [x26]
10023ed80:     	ldr	x8, [sp, #0x178]
10023ed84:     	ldr	x8, [x8, #0x20]
10023ed88:     	str	x8, [sp, #0x140]
10023ed8c:     	b	0x10023ed94 <_main.timed__anon_62765+0x284>
10023ed90:     	str	x14, [sp, #0x140]
10023ed94:     	ldr	x30, [x19]
10023ed98:     	ldr	x22, [x19, #0x50]
10023ed9c:     	ldr	x19, [x19, #0x460]
10023eda0:     	ldr	x8, [x20, #0x68]
10023eda4:     	str	x8, [sp, #0x170]
10023eda8:     	ldr	x12, [x15]
10023edac:     	ldr	x14, [x21]
10023edb0:     	ldr	x15, [x21, #0x28]
10023edb4:     	ldr	x16, [x21, #0x60]
10023edb8:     	ldr	x17, [x21, #0x88]
10023edbc:     	ldr	x0, [x24]
10023edc0:     	ldp	x1, x2, [x28]
10023edc4:     	ldr	x3, [x28, #0x10]
10023edc8:     	ldr	x4, [x6]
10023edcc:     	ldr	x5, [x20]
10023edd0:     	ldr	x23, [x6, #0xc38]
10023edd4:     	ldr	x6, [x25, #0x858]
10023edd8:     	ldr	x7, [x25]
10023eddc:     	ldp	x8, x10, [sp, #0x128]
10023ede0:     	ldr	x8, [x8]
10023ede4:     	ldr	x9, [x24, #0x28]
10023ede8:     	ldr	x10, [x10]
10023edec:     	add	x8, x9, x8
10023edf0:     	add	x27, x8, x10
10023edf4:     	ldr	x24, [x26, #0x8]
10023edf8:     	ldr	x9, [sp, #0x138]
10023edfc:     	ldr	x8, [x9]
10023ee00:     	ldr	x9, [x9, #0x418]
10023ee04:     	ldr	x10, [sp, #0x148]
10023ee08:     	ldr	x10, [x10]
10023ee0c:     	ldr	x25, [x21, #0x48]
10023ee10:     	ldr	x21, [sp, #0x120]
10023ee14:     	ldp	x28, x26, [x21]
10023ee18:     	ldr	x21, [x21, #0x228]
10023ee1c:     	ldr	x20, [x20, #0x80]
10023ee20:     	str	x20, [sp, #0x78]
10023ee24:     	ldr	x20, [sp, #0x170]
10023ee28:     	stp	x22, x30, [sp, #0xc0]
10023ee2c:     	stp	x30, x22, [sp, #0x188]
10023ee30:     	str	x19, [sp, #0xb8]
10023ee34:     	stp	x19, x13, [sp, #0x198]
10023ee38:     	stp	x12, x13, [sp, #0x130]
10023ee3c:     	stp	x20, x12, [sp, #0x1a8]
10023ee40:     	stp	x15, x14, [sp, #0x120]
10023ee44:     	stp	x14, x15, [sp, #0x1b8]
10023ee48:     	stp	x17, x16, [sp, #0x110]
10023ee4c:     	stp	x16, x17, [sp, #0x1c8]
10023ee50:     	stp	x1, x0, [sp, #0x100]
10023ee54:     	stp	x0, x1, [sp, #0x1d8]
10023ee58:     	stp	x3, x2, [sp, #0xf0]
10023ee5c:     	stp	x2, x3, [sp, #0x1e8]
10023ee60:     	stp	x5, x4, [sp, #0xe0]
10023ee64:     	stp	x4, x5, [sp, #0x1f8]
10023ee68:     	str	x23, [sp, #0x208]
10023ee6c:     	stp	x7, x6, [sp, #0xd0]
10023ee70:     	str	x6, [sp, #0x210]
10023ee74:     	str	x7, [sp, #0x218]
10023ee78:     	stp	x26, x28, [sp, #0x88]
10023ee7c:     	str	x26, [sp, #0x220]
10023ee80:     	mov	x26, x27
10023ee84:     	str	x11, [sp, #0x148]
10023ee88:     	str	x11, [sp, #0x228]
10023ee8c:     	str	x27, [sp, #0x230]
10023ee90:     	str	x24, [sp, #0x238]
10023ee94:     	stp	x9, x8, [sp, #0xa8]
10023ee98:     	str	x8, [sp, #0x240]
10023ee9c:     	str	x9, [sp, #0x248]
10023eea0:     	stp	x25, x10, [sp, #0x98]
10023eea4:     	str	x10, [sp, #0x250]
10023eea8:     	str	x25, [sp, #0x258]
10023eeac:     	str	x28, [sp, #0x260]
10023eeb0:     	add	x8, sp, #0x188
10023eeb4:     	stp	xzr, xzr, [x8, #0xe8]
10023eeb8:     	str	x21, [sp, #0x268]
10023eebc:     	ldr	x9, [sp, #0x180]
10023eec0:     	str	x9, [sp, #0x280]
10023eec4:     	stp	xzr, xzr, [x8, #0x100]
10023eec8:     	mov	w8, #0x4f38             ; =20280
10023eecc:     	movk	w8, #0x27, lsl #16
10023eed0:     	ldr	x19, [sp, #0x140]
10023eed4:     	add	x0, x19, x8
10023eed8:     	add	x1, sp, #0x188
10023eedc:     	bl	0x100287b1c <_meta.eql__anon_78340>
10023eee0:     	tbnz	w0, #0x0, 0x10023eefc <_main.timed__anon_62765+0x3ec>
10023eee4:     	mov	w8, #0x4f38             ; =20280
10023eee8:     	movk	w8, #0x27, lsl #16
10023eeec:     	add	x0, x19, x8
10023eef0:     	add	x1, sp, #0x188
10023eef4:     	mov	w2, #0x110              ; =272
10023eef8:     	bl	0x1004b6c18 <_memcpy>
10023eefc:     	ldr	x9, [sp, #0x178]
10023ef00:     	add	x25, sp, #0xac0
10023ef04:     	add	x28, sp, #0x2, lsl #12  ; =0x2000
10023ef08:     	add	x28, x28, #0x280
10023ef0c:     	ldp	x8, x22, [sp, #0x150]
10023ef10:     	cbz	x8, 0x10023f6dc <_main.timed__anon_62765+0xbcc>
10023ef14:     	ldr	x27, [sp, #0x78]
10023ef18:     	stp	x24, x26, [sp, #0x68]
10023ef1c:     	str	x21, [sp, #0x140]
10023ef20:     	str	x23, [sp, #0x150]
10023ef24:     	mov	w8, #0x8b50             ; =35664
10023ef28:     	movk	w8, #0xf, lsl #16
10023ef2c:     	add	x26, x22, x8
10023ef30:     	ldr	x23, [x9, #0x20]
10023ef34:     	mov	w8, #0x58b8             ; =22712
10023ef38:     	movk	w8, #0x27, lsl #16
10023ef3c:     	add	x20, x23, x8
10023ef40:     	mov	w8, #0x18               ; =24
10023ef44:     	ldr	x9, [sp, #0x168]
10023ef48:     	madd	x8, x9, x8, x22
10023ef4c:     	mov	w9, #0x8b40             ; =35648
10023ef50:     	movk	w9, #0xf, lsl #16
10023ef54:     	add	x21, x8, x9
10023ef58:     	ldr	x19, [x21, #0x10]
10023ef5c:     	add	x0, sp, #0x2, lsl #12   ; =0x2000
10023ef60:     	add	x0, x0, #0x280
10023ef64:     	mov	w1, #0x828              ; =2088
10023ef68:     	bl	0x1004bc430 <dyld_stub_binder+0x1004bc430>
10023ef6c:     	mov	x8, #0x0                ; =0
10023ef70:     	mov	w9, #0x0                ; =0
10023ef74:     	mov	x10, #0x0               ; =0
10023ef78:     	mov	w11, #0xc050            ; =49232
10023ef7c:     	movk	w11, #0x12, lsl #16
10023ef80:     	add	x24, x22, x11
10023ef84:     	b	0x10023ef94 <_main.timed__anon_62765+0x484>
10023ef88:     	add	x10, x10, #0x1
10023ef8c:     	cmp	x10, #0x100
10023ef90:     	b.eq	0x10023efe8 <_main.timed__anon_62765+0x4d8>
10023ef94:     	ldr	x11, [x24, x10, lsl #3]
10023ef98:     	cbz	x11, 0x10023ef88 <_main.timed__anon_62765+0x478>
10023ef9c:     	ldr	x12, [x11, #0x28]
10023efa0:     	cmp	x12, x19
10023efa4:     	b.ne	0x10023ef88 <_main.timed__anon_62765+0x478>
10023efa8:     	ldr	q0, [x21]
10023efac:     	str	q0, [x28]
10023efb0:     	ldr	x9, [sp, #0x50]
10023efb4:     	add	x9, x9, x8, lsl #5
10023efb8:     	ldr	x12, [x11, #0x10]
10023efbc:     	ldr	x13, [x11, #0xc8]
10023efc0:     	stp	x12, x13, [x9]
10023efc4:     	ldrb	w12, [x11, #0x106]
10023efc8:     	strb	w12, [x9, #0x18]
10023efcc:     	ldr	x11, [x11, #0xb8]
10023efd0:     	str	x11, [x9, #0x10]
10023efd4:     	add	x8, x8, #0x1
10023efd8:     	mov	w9, #0x1                ; =1
10023efdc:     	cmp	x10, #0xff
10023efe0:     	add	x10, x10, #0x1
10023efe4:     	b.lo	0x10023ef94 <_main.timed__anon_62765+0x484>
10023efe8:     	str	x19, [sp, #0x2290]
10023efec:     	strb	w9, [x28, #0x18]
10023eff0:     	strb	w8, [x28, #0x820]
10023eff4:     	add	x0, sp, #0x298
10023eff8:     	add	x1, sp, #0x2, lsl #12   ; =0x2000
10023effc:     	add	x1, x1, #0x280
10023f000:     	mov	w2, #0x828              ; =2088
10023f004:     	bl	0x1004b6c18 <_memcpy>
10023f008:     	mov	x9, #0x0                ; =0
10023f00c:     	mov	x8, #0x0                ; =0
10023f010:     	ldr	x10, [sp, #0x180]
10023f014:     	str	x10, [sp, #0x2280]
10023f018:     	ldr	x10, [sp, #0x80]
10023f01c:     	str	x10, [sp, #0x2288]
10023f020:     	strb	wzr, [x28, #0x640]
10023f024:     	movi.2d	v0, #0000000000000000
10023f028:     	stp	q0, q0, [x28, #0x10]
10023f02c:     	mov	w10, #0xc00             ; =3072
10023f030:     	ldr	x11, [sp, #0x168]
10023f034:     	madd	x10, x11, x10, x22
10023f038:     	add	x11, x10, #0xf8, lsl #12 ; =0xf8000
10023f03c:     	ldr	x10, [x11, #0x1d30]
10023f040:     	str	x27, [sp, #0x28b8]
10023f044:     	str	x10, [sp, #0x22b0]
10023f048:     	b	0x10023f058 <_main.timed__anon_62765+0x548>
10023f04c:     	add	x8, x8, #0x1
10023f050:     	cmp	x8, #0x100
10023f054:     	b.eq	0x10023f0a8 <_main.timed__anon_62765+0x598>
10023f058:     	ldr	x10, [x24, x8, lsl #3]
10023f05c:     	cbz	x10, 0x10023f04c <_main.timed__anon_62765+0x53c>
10023f060:     	ldr	x11, [x10, #0x28]
10023f064:     	cmp	x11, x19
10023f068:     	b.ne	0x10023f04c <_main.timed__anon_62765+0x53c>
10023f06c:     	ldr	x11, [sp, #0x28]
10023f070:     	mov	w12, #0x18              ; =24
10023f074:     	madd	x9, x9, x12, x11
10023f078:     	ldr	x11, [x10, #0x10]
10023f07c:     	ldr	x12, [x10, #0xb8]
10023f080:     	stp	x11, x12, [x9]
10023f084:     	ldr	w10, [x10, #0x50]
10023f088:     	str	w10, [x9, #0x10]
10023f08c:     	ldrb	w9, [x28, #0x640]
10023f090:     	add	x9, x9, #0x1
10023f094:     	strb	w9, [x28, #0x640]
10023f098:     	cmp	x8, #0xff
10023f09c:     	add	x8, x8, #0x1
10023f0a0:     	b.lo	0x10023f058 <_main.timed__anon_62765+0x548>
10023f0a4:     	b	0x10023f0ac <_main.timed__anon_62765+0x59c>
10023f0a8:     	cbz	x9, 0x10023f0c4 <_main.timed__anon_62765+0x5b4>
10023f0ac:     	ldr	q0, [x21]
10023f0b0:     	stur	q0, [x28, #0x10]
10023f0b4:     	ldr	x8, [x21, #0x10]
10023f0b8:     	stur	x8, [x28, #0x20]
10023f0bc:     	mov	w8, #0x1                ; =1
10023f0c0:     	strb	w8, [x28, #0x28]
10023f0c4:     	add	x1, sp, #0x2, lsl #12   ; =0x2000
10023f0c8:     	add	x1, x1, #0x280
10023f0cc:     	ldr	x0, [sp, #0x160]
10023f0d0:     	mov	w2, #0x648              ; =1608
10023f0d4:     	bl	0x1004b6c18 <_memcpy>
10023f0d8:     	ldp	x8, x9, [sp, #0xc0]
10023f0dc:     	str	x9, [sp, #0xac0]
10023f0e0:     	str	x8, [sp, #0xac8]
10023f0e4:     	ldr	x8, [sp, #0xb8]
10023f0e8:     	str	x8, [sp, #0xad0]
10023f0ec:     	ldr	x8, [sp, #0x138]
10023f0f0:     	str	x8, [sp, #0xad8]
10023f0f4:     	ldr	x8, [sp, #0x170]
10023f0f8:     	str	x8, [sp, #0xae0]
10023f0fc:     	ldp	x8, x9, [sp, #0x128]
10023f100:     	str	x9, [sp, #0xae8]
10023f104:     	str	x8, [sp, #0xaf0]
10023f108:     	ldp	x8, x9, [sp, #0x118]
10023f10c:     	str	x9, [sp, #0xaf8]
10023f110:     	str	x8, [sp, #0xb00]
10023f114:     	ldp	x8, x9, [sp, #0x108]
10023f118:     	str	x9, [sp, #0xb08]
10023f11c:     	str	x8, [sp, #0xb10]
10023f120:     	ldp	x8, x9, [sp, #0xf8]
10023f124:     	str	x9, [sp, #0xb18]
10023f128:     	str	x8, [sp, #0xb20]
10023f12c:     	ldp	x8, x9, [sp, #0xe8]
10023f130:     	str	x9, [sp, #0xb28]
10023f134:     	str	x8, [sp, #0xb30]
10023f138:     	ldr	x8, [sp, #0xe0]
10023f13c:     	str	x8, [sp, #0xb38]
10023f140:     	ldr	x8, [sp, #0x150]
10023f144:     	str	x8, [sp, #0xb40]
10023f148:     	ldp	x8, x9, [sp, #0xd0]
10023f14c:     	str	x9, [sp, #0xb48]
10023f150:     	str	x8, [sp, #0xb50]
10023f154:     	ldr	x8, [sp, #0x88]
10023f158:     	str	x8, [sp, #0xb58]
10023f15c:     	ldr	x8, [sp, #0x148]
10023f160:     	str	x8, [sp, #0xb60]
10023f164:     	ldp	x8, x9, [sp, #0x68]
10023f168:     	str	x9, [sp, #0xb68]
10023f16c:     	str	x8, [sp, #0xb70]
10023f170:     	ldp	x8, x9, [sp, #0xa8]
10023f174:     	str	x9, [sp, #0xb78]
10023f178:     	str	x8, [sp, #0xb80]
10023f17c:     	ldp	x8, x9, [sp, #0x98]
10023f180:     	str	x9, [sp, #0xb88]
10023f184:     	str	x8, [sp, #0xb90]
10023f188:     	ldr	x8, [sp, #0x90]
10023f18c:     	str	x8, [sp, #0xb98]
10023f190:     	stp	xzr, xzr, [x25, #0xe8]
10023f194:     	ldr	x8, [sp, #0x140]
10023f198:     	str	x8, [sp, #0xba0]
10023f19c:     	ldr	x8, [sp, #0x180]
10023f1a0:     	str	x8, [sp, #0xbb8]
10023f1a4:     	stp	xzr, xzr, [x25, #0x100]
10023f1a8:     	add	x0, x25, #0x110
10023f1ac:     	add	x1, sp, #0x298
10023f1b0:     	mov	w2, #0x828              ; =2088
10023f1b4:     	bl	0x1004b6c18 <_memcpy>
10023f1b8:     	strb	wzr, [x25, #0xf80]
10023f1bc:     	add	x0, sp, #0x2, lsl #12   ; =0x2000
10023f1c0:     	add	x0, x0, #0x280
10023f1c4:     	add	x1, x25, #0x130
10023f1c8:     	mov	w2, #0xe58              ; =3672
10023f1cc:     	bl	0x1004b6c18 <_memcpy>
10023f1d0:     	ldrb	w8, [x20, #0xf98]
10023f1d4:     	cbnz	w8, 0x10023f6e4 <_main.timed__anon_62765+0xbd4>
10023f1d8:     	add	x0, sp, #0xac0
10023f1dc:     	mov	w8, #0x4f38             ; =20280
10023f1e0:     	movk	w8, #0x27, lsl #16
10023f1e4:     	add	x1, x23, x8
10023f1e8:     	bl	0x100287b1c <_meta.eql__anon_78340>
10023f1ec:     	tbz	w0, #0x0, 0x10023f6ec <_main.timed__anon_62765+0xbdc>
10023f1f0:     	ldr	x21, [x20]
10023f1f4:     	cmn	x21, #0x1
10023f1f8:     	b.eq	0x10023f6f4 <_main.timed__anon_62765+0xbe4>
10023f1fc:     	ldrb	w19, [x28, #0x800]
10023f200:     	cmp	x19, #0x41
10023f204:     	b.hs	0x10023f6fc <_main.timed__anon_62765+0xbec>
10023f208:     	add	x8, x21, #0x1
10023f20c:     	str	x8, [x20]
10023f210:     	mov	w8, #0x5048             ; =20552
10023f214:     	movk	w8, #0x27, lsl #16
10023f218:     	add	x0, x23, x8
10023f21c:     	add	x1, sp, #0xac0
10023f220:     	mov	w2, #0x110              ; =272
10023f224:     	bl	0x1004b6c18 <_memcpy>
10023f228:     	strb	wzr, [x20, #0xfa0]
10023f22c:     	mov	w8, #0x1                ; =1
10023f230:     	strb	w8, [x20, #0xf98]
10023f234:     	str	x21, [x20, #0x8]
10023f238:     	mov	w8, #0x58c8             ; =22728
10023f23c:     	movk	w8, #0x27, lsl #16
10023f240:     	add	x0, x23, x8
10023f244:     	add	x1, sp, #0xac0
10023f248:     	mov	w2, #0x110              ; =272
10023f24c:     	bl	0x1004b6c18 <_memcpy>
10023f250:     	mov	w8, #0x6020             ; =24608
10023f254:     	movk	w8, #0x27, lsl #16
10023f258:     	add	x25, x23, x8
10023f25c:     	ldrb	w8, [x28, #0xe50]
10023f260:     	strb	w8, [x20, #0xf90]
10023f264:     	ldr	x8, [sp, #0x160]
10023f268:     	ldr	q0, [x8]
10023f26c:     	mov	w8, #0x59d8             ; =23000
10023f270:     	movk	w8, #0x27, lsl #16
10023f274:     	str	q0, [x23, x8]
10023f278:     	mov	w8, #0x59e8             ; =23016
10023f27c:     	movk	w8, #0x27, lsl #16
10023f280:     	add	x8, x23, x8
10023f284:     	ldr	x9, [sp, #0x30]
10023f288:     	ldp	q0, q1, [x9]
10023f28c:     	stp	q0, q1, [x8]
10023f290:     	ldr	x8, [sp, #0x2ab8]
10023f294:     	str	x8, [x20, #0x150]
10023f298:     	ldr	x8, [sp, #0x30c0]
10023f29c:     	str	x8, [x20, #0x758]
10023f2a0:     	ldrb	w8, [x28, #0xe48]
10023f2a4:     	strb	w8, [x20, #0x760]
10023f2a8:     	add	x8, x8, x8, lsl #1
10023f2ac:     	lsl	x2, x8, #3
10023f2b0:     	mov	w8, #0x5a10             ; =23056
10023f2b4:     	movk	w8, #0x27, lsl #16
10023f2b8:     	add	x0, x23, x8
10023f2bc:     	add	x1, x28, #0x840
10023f2c0:     	bl	0x1004b6c18 <_memcpy>
10023f2c4:     	add	x8, sp, #0x199
10023f2c8:     	ldur	q0, [x8, #0xff]
10023f2cc:     	add	x8, sp, #0x1a9
10023f2d0:     	ldur	q1, [x8, #0xff]
10023f2d4:     	stp	q0, q1, [x25]
10023f2d8:     	strb	w19, [x20, #0xf88]
10023f2dc:     	lsl	x2, x19, #5
10023f2e0:     	mov	w25, #0x6040            ; =24640
10023f2e4:     	movk	w25, #0x27, lsl #16
10023f2e8:     	add	x0, x23, x25
10023f2ec:     	add	x1, sp, #0x2, lsl #12   ; =0x2000
10023f2f0:     	add	x1, x1, #0x280
10023f2f4:     	bl	0x1004b6c18 <_memcpy>
10023f2f8:     	ldr	x8, [sp, #0x178]
10023f2fc:     	ldr	x19, [x8, #0x20]
10023f300:     	mov	w8, #0x6840             ; =26688
10023f304:     	movk	w8, #0x27, lsl #16
10023f308:     	add	x20, x19, x8
10023f30c:     	ldrb	w8, [x20, #0x10]
10023f310:     	cbz	w8, 0x10023f6d4 <_main.timed__anon_62765+0xbc4>
10023f314:     	add	x8, x19, #0x270, lsl #12 ; =0x270000
10023f318:     	ldr	x8, [x8, #0x58c0]
10023f31c:     	cmp	x8, x21
10023f320:     	b.ne	0x10023f6d4 <_main.timed__anon_62765+0xbc4>
10023f324:     	mov	w8, #0x5298             ; =21144
10023f328:     	movk	w8, #0x27, lsl #16
10023f32c:     	add	x21, x19, x8
10023f330:     	mov	w8, #0x5158             ; =20824
10023f334:     	movk	w8, #0x27, lsl #16
10023f338:     	add	x0, x19, x8
10023f33c:     	mov	w8, #0x58c8             ; =22728
10023f340:     	movk	w8, #0x27, lsl #16
10023f344:     	add	x1, x19, x8
10023f348:     	mov	w2, #0x110              ; =272
10023f34c:     	bl	0x1004b6c18 <_memcpy>
10023f350:     	ldrb	w8, [x21, #0x618]
10023f354:     	cbnz	w8, 0x10023f370 <_main.timed__anon_62765+0x860>
10023f358:     	mov	w8, #0x52a0             ; =21152
10023f35c:     	movk	w8, #0x27, lsl #16
10023f360:     	add	x0, x19, x8
10023f364:     	mov	w1, #0x1                ; =1
10023f368:     	mov	w2, #0x618              ; =1560
10023f36c:     	bl	0x1004b67b4 <_memset>
10023f370:     	mov	w8, #0x59d8             ; =23000
10023f374:     	movk	w8, #0x27, lsl #16
10023f378:     	ldr	q0, [x19, x8]
10023f37c:     	mov	w8, #0x5268             ; =21096
10023f380:     	movk	w8, #0x27, lsl #16
10023f384:     	str	q0, [x19, x8]
10023f388:     	mov	w8, #0x5278             ; =21112
10023f38c:     	movk	w8, #0x27, lsl #16
10023f390:     	add	x8, x19, x8
10023f394:     	mov	w9, #0x59e8             ; =23016
10023f398:     	movk	w9, #0x27, lsl #16
10023f39c:     	add	x9, x19, x9
10023f3a0:     	ldp	q0, q1, [x9]
10023f3a4:     	stp	q0, q1, [x8]
10023f3a8:     	ldr	x8, [x21, #0x770]
10023f3ac:     	str	x8, [x21]
10023f3b0:     	ldr	x8, [x21, #0xd78]
10023f3b4:     	str	x8, [x21, #0x608]
10023f3b8:     	ldrb	w8, [x21, #0xd80]
10023f3bc:     	strb	w8, [x21, #0x610]
10023f3c0:     	add	x8, x8, x8, lsl #1
10023f3c4:     	lsl	x2, x8, #3
10023f3c8:     	mov	w8, #0x52a0             ; =21152
10023f3cc:     	movk	w8, #0x27, lsl #16
10023f3d0:     	add	x0, x19, x8
10023f3d4:     	mov	w8, #0x5a10             ; =23056
10023f3d8:     	movk	w8, #0x27, lsl #16
10023f3dc:     	add	x1, x19, x8
10023f3e0:     	bl	0x1004b6c18 <_memcpy>
10023f3e4:     	mov	w8, #0x6020             ; =24608
10023f3e8:     	movk	w8, #0x27, lsl #16
10023f3ec:     	add	x8, x19, x8
10023f3f0:     	ldrb	w9, [x20, #0x8]
10023f3f4:     	add	x21, sp, #0x3, lsl #12  ; =0x3000
10023f3f8:     	add	x21, x21, #0xd8
10023f3fc:     	strb	w9, [x21, #0x808]
10023f400:     	ldp	q0, q1, [x8]
10023f404:     	stp	q0, q1, [x28]
10023f408:     	ldrb	w8, [x20]
10023f40c:     	strb	w8, [x21, #0x800]
10023f410:     	lsl	x2, x8, #5
10023f414:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
10023f418:     	add	x0, x0, #0xd8
10023f41c:     	add	x1, x19, x25
10023f420:     	bl	0x1004b6c18 <_memcpy>
10023f424:     	mov	w8, #0x58c0             ; =22720
10023f428:     	movk	w8, #0x27, lsl #16
10023f42c:     	add	x0, x19, x8
10023f430:     	mov	w1, #0xf98              ; =3992
10023f434:     	bl	0x1004bc430 <dyld_stub_binder+0x1004bc430>
10023f438:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
10023f43c:     	add	x1, x1, #0xd8
10023f440:     	ldr	x0, [sp, #0x50]
10023f444:     	mov	w2, #0x810              ; =2064
10023f448:     	bl	0x1004b6c18 <_memcpy>
10023f44c:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
10023f450:     	add	x0, x0, #0xa50
10023f454:     	add	x1, sp, #0x2, lsl #12   ; =0x2000
10023f458:     	add	x1, x1, #0x280
10023f45c:     	mov	w2, #0x830              ; =2096
10023f460:     	bl	0x1004b6c18 <_memcpy>
10023f464:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
10023f468:     	add	x0, x0, #0xd8
10023f46c:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
10023f470:     	add	x1, x1, #0xa50
10023f474:     	mov	w2, #0x828              ; =2088
10023f478:     	bl	0x1004b6c18 <_memcpy>
10023f47c:     	add	x20, sp, #0x3, lsl #12  ; =0x3000
10023f480:     	add	x20, x20, #0xd8
10023f484:     	ldrb	w8, [x21, #0x18]
10023f488:     	cbz	w8, 0x10023f4c0 <_main.timed__anon_62765+0x9b0>
10023f48c:     	ldr	x8, [sp, #0x48]
10023f490:     	ldr	x8, [x8]
10023f494:     	cbz	x8, 0x10023f4c4 <_main.timed__anon_62765+0x9b4>
10023f498:     	ldrb	w10, [x20, #0x8]
10023f49c:     	ldr	x9, [sp, #0x30d8]
10023f4a0:     	ldr	x19, [sp, #0x30e8]
10023f4a4:     	ldr	x11, [x26]
10023f4a8:     	cmp	x11, x19
10023f4ac:     	b.eq	0x10023f4e4 <_main.timed__anon_62765+0x9d4>
10023f4b0:     	add	x26, x26, #0x18
10023f4b4:     	subs	x8, x8, #0x1
10023f4b8:     	b.ne	0x10023f4a4 <_main.timed__anon_62765+0x994>
10023f4bc:     	b	0x10023f4c4 <_main.timed__anon_62765+0x9b4>
10023f4c0:     	mov	x8, #0x0                ; =0
10023f4c4:     	ldp	x23, x21, [sp, #0x58]
10023f4c8:     	add	x21, x8, x21
10023f4cc:     	add	x23, x23, #0x1
10023f4d0:     	ldr	x8, [sp, #0x38]
10023f4d4:     	cmp	x23, x8
10023f4d8:     	ldr	x22, [sp, #0x178]
10023f4dc:     	b.ne	0x10023ebac <_main.timed__anon_62765+0x9c>
10023f4e0:     	b	0x10023f6a4 <_main.timed__anon_62765+0xb94>
10023f4e4:     	mov	x8, #0x0                ; =0
10023f4e8:     	ldurb	w11, [x26, #-0x8]
10023f4ec:     	eor	w10, w11, w10
10023f4f0:     	tbnz	w10, #0x0, 0x10023f4c4 <_main.timed__anon_62765+0x9b4>
10023f4f4:     	ldur	x10, [x26, #-0x10]
10023f4f8:     	cmp	x10, x9
10023f4fc:     	ldp	x23, x21, [sp, #0x58]
10023f500:     	b.ne	0x10023f4c8 <_main.timed__anon_62765+0x9b8>
10023f504:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
10023f508:     	add	x0, x0, #0x900
10023f50c:     	mov	x1, x24
10023f510:     	mov	w2, #0x800              ; =2048
10023f514:     	bl	0x1004b6c18 <_memcpy>
10023f518:     	mov	x9, #0x0                ; =0
10023f51c:     	mov	x8, #0x0                ; =0
10023f520:     	add	x11, sp, #0x3, lsl #12  ; =0x3000
10023f524:     	add	x11, x11, #0x900
10023f528:     	b	0x10023f538 <_main.timed__anon_62765+0xa28>
10023f52c:     	add	x9, x9, #0x8
10023f530:     	cmp	x9, #0x800
10023f534:     	b.eq	0x10023f550 <_main.timed__anon_62765+0xa40>
10023f538:     	ldr	x10, [x11, x9]
10023f53c:     	cbz	x10, 0x10023f52c <_main.timed__anon_62765+0xa1c>
10023f540:     	ldr	x10, [x10, #0x28]
10023f544:     	cmp	x10, x19
10023f548:     	cinc	x8, x8, eq
10023f54c:     	b	0x10023f52c <_main.timed__anon_62765+0xa1c>
10023f550:     	cbz	x8, 0x10023f4c8 <_main.timed__anon_62765+0x9b8>
10023f554:     	strb	wzr, [x28, #0x820]
10023f558:     	ldrb	w9, [x20, #0x820]
10023f55c:     	cbz	x9, 0x10023f584 <_main.timed__anon_62765+0xa74>
10023f560:     	mov	x8, #0x0                ; =0
10023f564:     	mov	x10, #0x0               ; =0
10023f568:     	mov	w11, #0xc850            ; =51280
10023f56c:     	movk	w11, #0x12, lsl #16
10023f570:     	add	x11, x22, x11
10023f574:     	mov	w12, #0xd850            ; =55376
10023f578:     	movk	w12, #0x12, lsl #16
10023f57c:     	add	x12, x22, x12
10023f580:     	b	0x10023f5cc <_main.timed__anon_62765+0xabc>
10023f584:     	mov	x8, #0x0                ; =0
10023f588:     	b	0x10023f4c8 <_main.timed__anon_62765+0x9b8>
10023f58c:     	str	xzr, [x0, #0xc8]
10023f590:     	ldr	x0, [sp, #0x50]
10023f594:     	add	x8, x0, x8, lsl #5
10023f598:     	stp	x14, x15, [x8]
10023f59c:     	str	x16, [x8, #0x10]
10023f5a0:     	strb	w17, [x8, #0x18]
10023f5a4:     	ldur	w14, [x13, #0x19]
10023f5a8:     	stur	w14, [x8, #0x19]
10023f5ac:     	ldur	w13, [x13, #0x1c]
10023f5b0:     	str	w13, [x8, #0x1c]
10023f5b4:     	ldrb	w8, [x28, #0x820]
10023f5b8:     	add	x8, x8, #0x1
10023f5bc:     	strb	w8, [x28, #0x820]
10023f5c0:     	add	x10, x10, #0x1
10023f5c4:     	cmp	x10, x9
10023f5c8:     	b.eq	0x10023f4c8 <_main.timed__anon_62765+0x9b8>
10023f5cc:     	ldr	x13, [sp, #0x40]
10023f5d0:     	add	x13, x13, x10, lsl #5
10023f5d4:     	ldr	x14, [x13]
10023f5d8:     	cbz	x14, 0x10023f5c0 <_main.timed__anon_62765+0xab0>
10023f5dc:     	ldp	x15, x16, [x13, #0x8]
10023f5e0:     	ldrb	w17, [x13, #0x18]
10023f5e4:     	eor	x0, x14, x14, lsr #32
10023f5e8:     	mov	x1, #0x556d             ; =21869
10023f5ec:     	movk	x1, #0xeb34, lsl #16
10023f5f0:     	movk	x1, #0x25f9, lsl #32
10023f5f4:     	movk	x1, #0xbea2, lsl #48
10023f5f8:     	mul	x0, x0, x1
10023f5fc:     	eor	x0, x0, x0, lsr #29
10023f600:     	mul	x0, x0, x1
10023f604:     	eor	x0, x0, x0, lsr #32
10023f608:     	mul	x0, x0, x1
10023f60c:     	eor	x1, x0, x0, lsr #29
10023f610:     	mov	w0, #0x200              ; =512
10023f614:     	and	x1, x1, #0x1ff
10023f618:     	ldr	x2, [x11, x1, lsl #3]
10023f61c:     	cmp	x2, x14
10023f620:     	b.eq	0x10023f638 <_main.timed__anon_62765+0xb28>
10023f624:     	cbz	x2, 0x10023f5c0 <_main.timed__anon_62765+0xab0>
10023f628:     	add	x1, x1, #0x1
10023f62c:     	subs	x0, x0, #0x1
10023f630:     	b.ne	0x10023f614 <_main.timed__anon_62765+0xb04>
10023f634:     	b	0x10023f5c0 <_main.timed__anon_62765+0xab0>
10023f638:     	ldrb	w0, [x12, x1]
10023f63c:     	ldr	x0, [x24, x0, lsl #3]
10023f640:     	cbz	x0, 0x10023f5c0 <_main.timed__anon_62765+0xab0>
10023f644:     	ldr	x1, [x0, #0x28]
10023f648:     	cmp	x1, x19
10023f64c:     	b.ne	0x10023f5c0 <_main.timed__anon_62765+0xab0>
10023f650:     	and	w1, w17, #0x1
10023f654:     	ldrb	w2, [x0, #0x106]
10023f658:     	cmp	w2, w1
10023f65c:     	b.ne	0x10023f5c0 <_main.timed__anon_62765+0xab0>
10023f660:     	ldr	x1, [x0, #0xb8]
10023f664:     	cmp	x1, x16
10023f668:     	b.ne	0x10023f5c0 <_main.timed__anon_62765+0xab0>
10023f66c:     	ldr	x1, [x0, #0xc8]
10023f670:     	cmp	x1, x15
10023f674:     	b.ne	0x10023f590 <_main.timed__anon_62765+0xa80>
10023f678:     	ldr	x1, [x0, #0xb0]
10023f67c:     	mov	w4, #0xffff             ; =65535
10023f680:     	cbz	x1, 0x10023f58c <_main.timed__anon_62765+0xa7c>
10023f684:     	mov	x2, #0x0                ; =0
10023f688:     	ldr	x3, [x0, #0xa8]
10023f68c:     	str	w4, [x3, x2, lsl #2]
10023f690:     	add	x2, x2, #0x1
10023f694:     	cmp	x2, x1
10023f698:     	b.lo	0x10023f68c <_main.timed__anon_62765+0xb7c>
10023f69c:     	b	0x10023f58c <_main.timed__anon_62765+0xa7c>
10023f6a0:     	mov	x21, #0x0               ; =0
10023f6a4:     	ldp	x8, x0, [sp, #0x10]
10023f6a8:     	ldr	x9, [x8, #0x2c0]
10023f6ac:     	add	x8, sp, #0xac0
10023f6b0:     	mov	w1, #0x1                ; =1
10023f6b4:     	blr	x9
10023f6b8:     	ldr	x8, [sp, #0xac0]
10023f6bc:     	ldr	x9, [sp, #0x8]
10023f6c0:     	sub	x8, x8, x9
10023f6c4:     	ldr	x9, [sp, #0x20]
10023f6c8:     	strh	wzr, [x9, #0x8]
10023f6cc:     	str	x8, [x9]
10023f6d0:     	b	0x10023f708 <_main.timed__anon_62765+0xbf8>
10023f6d4:     	mov	w8, #0x267              ; =615
10023f6d8:     	b	0x10023f700 <_main.timed__anon_62765+0xbf0>
10023f6dc:     	mov	w8, #0x1b8              ; =440
10023f6e0:     	b	0x10023f700 <_main.timed__anon_62765+0xbf0>
10023f6e4:     	mov	w8, #0x263              ; =611
10023f6e8:     	b	0x10023f700 <_main.timed__anon_62765+0xbf0>
10023f6ec:     	mov	w8, #0x264              ; =612
10023f6f0:     	b	0x10023f700 <_main.timed__anon_62765+0xbf0>
10023f6f4:     	mov	w8, #0x265              ; =613
10023f6f8:     	b	0x10023f700 <_main.timed__anon_62765+0xbf0>
10023f6fc:     	mov	w8, #0x266              ; =614
10023f700:     	ldr	x9, [sp, #0x20]
10023f704:     	strh	w8, [x9, #0x8]
10023f708:     	add	sp, sp, #0x4, lsl #12   ; =0x4000
10023f70c:     	add	sp, sp, #0x110
10023f710:     	ldp	x29, x30, [sp, #0x50]
10023f714:     	ldp	x20, x19, [sp, #0x40]
10023f718:     	ldp	x22, x21, [sp, #0x30]
10023f71c:     	ldp	x24, x23, [sp, #0x20]
10023f720:     	ldp	x26, x25, [sp, #0x10]
10023f724:     	ldp	x28, x27, [sp], #0x60
10023f728:     	ret

stp	x28, x27, [sp, #-0x60]!
stp	x26, x25, [sp, #0x10]
stp	x24, x23, [sp, #0x20]
stp	x22, x21, [sp, #0x30]
stp	x20, x19, [sp, #0x40]
stp	x29, x30, [sp, #0x50]
add	x29, sp, #0x50
sub	sp, sp, #0x1b0
mov	x22, x2
str	x0, [sp, #0x38]
ldp	x0, x8, [x1]
ldr	x21, [x1, #0x68]
stp	x8, x0, [sp, #0x28]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0xb0
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [sp, #0xb0]
str	x8, [sp, #0x20]
cbz	x22, <_main.timed__anon>
mov	x19, #0x0               ; =0
mov	x25, #0x0               ; =0
adrp x8, RELOC_PAGE
ldrb	w26, [x8, #RELOC_OFFSET]
mov	w28, #0x5bd8            ; =23512
movk	w28, #0xf, lsl #16
mov	w23, #0xcfb0            ; =53168
movk	w23, #0xb, lsl #16
ldr	x24, [x21, #0x20]
mov	w8, #0x4ec0             ; =20160
movk	w8, #0x27, lsl #16
add	x27, x24, x8
ldrb	w8, [x27, #0x70]
cbz	w8, <_main.timed__anon>
ldr	x8, [x27, #0x30]
ldr	x0, [x27]
blr	x8
add	x8, x24, x28
add	x9, x24, #0x149, lsl #12 ; =0x149000
ldrb	w9, [x9, #0xbc0]
cmp	w9, #0x0
cset	w9, ne
strb	w9, [sp, #0x45]
ldrb	w9, [x8, #0x820]
cbz	w9, <_main.timed__anon>
ldrb	w8, [x8]
cmp	w8, #0x0
cset	w8, eq
strb	w8, [sp, #0x44]
ldrb	w8, [sp, #0x45]
tbz	w8, #0x0, <_main.timed__anon>
mov	w8, #0x6860             ; =26720
movk	w8, #0x27, lsl #16
add	x8, x24, x8
ldp	x0, x8, [x8]
adrp x1, RELOC_PAGE
add	x1, x1, #RELOC_OFFSET
mov	w2, #0x1                ; =1
blr	x8
tst	w0, #0xffff
b.ne	<_main.timed__anon>
mov	w8, #0x2                ; =2
b	<_main.timed__anon>
mov	w8, #0x0                ; =0
strb	w8, [sp, #0x44]
ldrb	w8, [sp, #0x45]
tbnz	w8, #0x0, <_main.timed__anon>
ldrb	w8, [sp, #0x44]
tbz	w8, #0x0, <_main.timed__anon>
mov	w8, #0x3                ; =3
b	<_main.timed__anon>
tbz	w26, #0x0, <_main.timed__anon>
adrp x10, RELOC_PAGE
add	x10, x10, #RELOC_OFFSET
ldr	q0, [x10]
add	x9, sp, #0x80
stur	q0, [x9, #0x10]
ldrh	w8, [x10, #0x12]
sturh	w8, [x9, #0x22]
ldrb	w8, [x10, #0x14]
sturb	w8, [x9, #0x24]
add	x8, sp, #0x80
b	<_main.timed__anon>
add	x8, sp, #0x50
adrp x9, RELOC_PAGE
add	x10, x9, #RELOC_OFFSET
mov	w9, #0x1                ; =1
stp	x10, x9, [x8]
and	w9, w26, #0x1
strb	w9, [x8, #0x28]
stp	xzr, xzr, [sp, #0xb8]
str	xzr, [sp, #0xb0]
strb	wzr, [sp, #0xf8]
ldp	q1, q0, [x8]
add	x9, sp, #0xb0
stur	q0, [x9, #0x28]
stur	q1, [x9, #0x18]
ldr	q0, [x8, #0x20]
stur	q0, [x9, #0x38]
add	x0, sp, #0x100
add	x2, sp, #0xb0
mov	x1, x24
bl	<_panes.pane_input.sendPaneInput>
ldrh	w0, [sp, #0x120]
cbnz	w0, <_main.timed__anon>
ldrb	w8, [sp, #0x118]
cbz	w8, <_main.timed__anon>
tbz	w26, #0x0, <_main.timed__anon>
ldrb	w8, [x27, #0x70]
cbz	w8, <_main.timed__anon>
add	x8, sp, #0x100
ldr	x8, [x8]
str	x8, [sp, #0x18]
ldr	x0, [x27]
ldr	x9, [x27, #0x48]
sub	x8, x29, #0x78
blr	x9
ldrb	w8, [x27, #0x70]
cbz	w8, <_main.timed__anon>
mov	w8, #0x5f00             ; =24320
movk	w8, #0x20, lsl #16
add	x20, x24, x8
mov	w8, #0x9340             ; =37696
movk	w8, #0x12, lsl #16
add	x28, x24, x8
ldr	x0, [x27]
ldr	x8, [x27, #0x28]
stp	x8, x0, [sp, #0x8]
ldr	x9, [x27, #0x48]
sub	x8, x29, #0x78
blr	x9
add	x10, sp, #0x100
ldur	q0, [x10, #0x88]
str	q0, [x10, #0x30]
ldurb	w8, [x29, #-0x68]
cbz	w8, <_main.timed__anon>
ldr	q0, [x10, #0x30]
str	q0, [x10, #0x40]
sub	x8, x29, #0xc0
mov	x27, x28
mov	w28, #0x5bd8            ; =23512
movk	w28, #0xf, lsl #16
ldr	q0, [x8]
str	q0, [x10, #0x70]
ldr	x8, [x10, #0x70]
ldr	x9, [sp, #0x18]
cmp	x8, x9
b.ne	<_main.timed__anon>
add	x8, sp, #0x100
ldr	x8, [x8, #0x78]
add	x9, x24, #0x230, lsl #12 ; =0x230000
ldrb	w9, [x9, #0x900]
ldr	x12, [sp, #0x18]
cbz	x9, <_main.timed__anon>
ldp	x10, x11, [x20]
cmp	x10, x12
ccmp	x11, x8, #0x0, eq
b.eq	<_main.timed__anon>
add	x20, x20, #0xaa8
subs	x9, x9, #0x1
b.ne	<_main.timed__anon>
b	<_main.timed__anon>
ldr	x8, [x28]
mov	x27, x28
mov	w28, #0x5bd8            ; =23512
movk	w28, #0xf, lsl #16
cbz	x8, <_main.timed__anon>
ldr	x10, [x27, #0x8]
mov	w8, #0xc00              ; =3072
madd	x8, x10, x8, x24
add	x9, x8, #0xf8, lsl #12  ; =0xf8000
ldr	x8, [x9, #0x1d28]
cbz	x8, <_main.timed__anon>
add	x9, x24, #0x230, lsl #12 ; =0x230000
ldrb	w9, [x9, #0x900]
cbz	x9, <_main.timed__anon>
mov	w11, #0x8b40            ; =35648
movk	w11, #0xf, lsl #16
add	x11, x24, x11
mov	w12, #0x18              ; =24
madd	x12, x10, x12, x11
ldr	x10, [x12]
ldrb	w11, [x12, #0x8]
ldr	x13, [x12, #0x10]
add	x12, x20, #0x20
b	<_main.timed__anon>
add	x12, x12, #0xaa8
subs	x9, x9, #0x1
b.eq	<_main.timed__anon>
ldur	x14, [x12, #-0x20]
cmp	x14, x8
b.ne	<_main.timed__anon>
ldurb	w14, [x12, #-0x8]
eor	w14, w14, w11
tbnz	w14, #0x0, <_main.timed__anon>
ldr	x14, [x12]
ldur	x15, [x12, #-0x10]
cmp	x15, x10
ccmp	x14, x13, #0x0, eq
b.ne	<_main.timed__anon>
ldur	x9, [x12, #-0x18]
ldp	x10, x11, [x20]
cmp	x10, x8
ccmp	x11, x9, #0x0, eq
mov	x10, x20
b.eq	<_main.timed__anon>
mov	x11, x20
add	x10, x11, #0xaa8
ldr	x12, [x11, #0xaa8]
ldr	x11, [x11, #0xab0]
cmp	x12, x8
ccmp	x11, x9, #0x0, eq
mov	x11, x10
b.ne	<_main.timed__anon>
ldrb	w10, [x10, #0x11b]
cbz	w10, <_main.timed__anon>
add	x10, sp, #0x100
stp	x8, x9, [x10, #0x58]
sub	x8, x29, #0xa8
ldr	q0, [x8]
str	q0, [x10, #0x70]
ldr	x8, [x10, #0x70]
ldr	x9, [sp, #0x18]
cmp	x8, x9
b.eq	<_main.timed__anon>
b	<_main.timed__anon>
ldrb	w9, [x20, #0x11b]
cbz	w9, <_main.timed__anon>
sturb	w9, [x29, #-0x78]
mov	w9, #0x1                ; =1
sturb	w9, [x29, #-0x77]
sub	x9, x29, #0x78
ldrh	w9, [x9]
and	w10, w9, #0xfe
cmp	w9, #0x100
ccmp	w10, #0x2, #0x0, hs
b.eq	<_main.timed__anon>
b	<_main.timed__anon>
adrp x9, RELOC_PAGE
add	x9, x9, #RELOC_OFFSET
ldrh	w9, [x9]
and	w10, w9, #0xfe
cmp	w9, #0x100
ccmp	w10, #0x2, #0x0, hs
b.ne	<_main.timed__anon>
ldr	x9, [x27]
cbz	x9, <_main.timed__anon>
ldr	x9, [sp, #0x18]
cbz	x9, <_main.timed__anon>
ldr	x9, [x27, #0x8]
mov	w10, #0x18              ; =24
madd	x10, x9, x10, x24
mov	w9, #0xc050             ; =49232
movk	w9, #0x12, lsl #16
add	x9, x24, x9
add	x11, x10, #0xf8, lsl #12 ; =0xf8000
ldr	x10, [x11, #0xb50]
mov	w11, #0xc850            ; =51280
movk	w11, #0x12, lsl #16
add	x11, x24, x11
ldr	x12, [sp, #0x18]
eor	x12, x12, x12, lsr #32
mov	x13, #0x556d            ; =21869
movk	x13, #0xeb34, lsl #16
movk	x13, #0x25f9, lsl #32
movk	x13, #0xbea2, lsl #48
mul	x12, x12, x13
eor	x12, x12, x12, lsr #29
mul	x12, x12, x13
eor	x12, x12, x12, lsr #32
mul	x12, x12, x13
eor	x13, x12, x12, lsr #29
mov	w12, #0x200             ; =512
and	x13, x13, #0x1ff
ldr	x14, [x11, x13, lsl #3]
ldr	x15, [sp, #0x18]
cmp	x14, x15
b.eq	<_main.timed__anon>
cbz	x14, <_main.timed__anon>
add	x13, x13, #0x1
subs	x12, x12, #0x1
b.ne	<_main.timed__anon>
b	<_main.timed__anon>
add	x11, x24, x13
add	x12, x11, #0x12d, lsl #12 ; =0x12d000
ldrb	w11, [x12, #0x850]
ldr	x9, [x9, x11, lsl #3]
cbz	x9, <_main.timed__anon>
ldr	x11, [x9, #0x28]
cmp	x11, x10
b.ne	<_main.timed__anon>
ldrb	w10, [x9, #0x104]
tbz	w10, #0x0, <_main.timed__anon>
ldrh	w14, [x9, #0x100]
ldrh	w10, [x9, #0x102]
b	<_main.timed__anon>
ldrh	w10, [x9, #0x52]
cbz	x10, <_main.timed__anon>
ldrh	w11, [x9, #0x50]
tst	w11, #0xffff
b.eq	<_main.timed__anon>
and	x13, x11, #0xffff
ldr	x12, [x9, #0x30]
cmp	w13, #0x1
b.ne	<_main.timed__anon>
mov	x11, #0x0               ; =0
ldrh	w13, [x12], #0x20
tbnz	w13, #0x4, <_main.timed__anon>
add	x11, x11, #0x1
cmp	x10, x11
b.ne	<_main.timed__anon>
b	<_main.timed__anon>
mov	x11, #0x0               ; =0
add	x15, x12, #0x40
lsl	x16, x13, #5
b	<_main.timed__anon>
add	x11, x11, #0x1
add	x15, x15, x16
cmp	x11, x10
b.eq	<_main.timed__anon>
mul	x14, x11, x13
add	x14, x12, x14, lsl #5
ldrh	w17, [x14]
tbz	w17, #0x4, <_main.timed__anon>
ldrh	w14, [x14, #0x20]
tbz	w14, #0x4, <_main.timed__anon>
mov	x17, x15
mov	w14, #0x1               ; =1
b	<_main.timed__anon>
add	x14, x14, #0x1
add	x17, x17, #0x20
cmp	x13, x14
b.eq	<_main.timed__anon>
ldurh	w0, [x17, #-0x20]
tbz	w0, #0x4, <_main.timed__anon>
add	x0, x14, #0x1
cmp	x0, x13
b.hs	<_main.timed__anon>
ldrh	w0, [x17]
tst	w0, #0x10
cset	w0, eq
b	<_main.timed__anon>
mov	w0, #0x1                ; =1
ldurh	w1, [x17, #-0x40]
tbnz	w1, #0x4, <_main.timed__anon>
tbz	w0, #0x0, <_main.timed__anon>
b	<_main.timed__anon>
mov	w14, #0x0               ; =0
and	w10, w11, #0xffff
tst	w14, #0xffff
b.eq	<_main.timed__anon>
ldrh	w11, [x9, #0x52]
cmp	w10, w11
b.hs	<_main.timed__anon>
sub	w11, w14, #0x1
ldrh	w12, [x9, #0x50]
cmp	w12, w11, uxth
b.ls	<_main.timed__anon>
ldr	x9, [x9, #0x30]
umull	x10, w12, w10
and	x11, x11, #0xffff
add	x9, x9, x10, lsl #5
add	x9, x9, x11, lsl #5
ldrb	w10, [x9, #0x1e]
ldrb	w11, [x9, #0x1f]
cmp	w11, #0x0
ccmp	w10, #0x1, #0x0, ne
b.ne	<_main.timed__anon>
ldrb	w9, [x9, #0xe]
cmp	w9, #0x5c
b.eq	<_main.timed__anon>
mov	w9, #0x5090             ; =20624
movk	w9, #0x13, lsl #16
add	x20, x24, x9
ldrb	w9, [x20, #0x10]
cbz	w9, <_main.timed__anon>
ldp	x10, x9, [x20]
ldr	x11, [sp, #0x18]
cmp	x10, x11
ccmp	x9, x8, #0x0, eq
b.ne	<_main.timed__anon>
mov	w8, #0x5088             ; =20616
movk	w8, #0x13, lsl #16
add	x8, x24, x8
movi.2d	v0, #0000000000000000
stp	q0, q0, [x8]
sub	x8, x29, #0x78
sub	x1, x29, #0x90
ldp	x9, x0, [sp, #0x8]
blr	x9
ldurb	w8, [x29, #-0x77]
cbz	w8, <_main.timed__anon>
ldurb	w8, [x29, #-0x78]
tbz	w8, #0x0, <_main.timed__anon>
mov	w8, #0x1                ; =1
strb	w8, [x20, #0x239]
ldr	x8, [x27]
cbz	x8, <_main.timed__anon>
ldrh	w8, [x20, #0xa8]
ldrh	w9, [x20, #0xaa]
ldrb	w10, [x20, #0xb1]
cmp	w10, #0x1
b.ne	<_main.timed__anon>
mov	w10, #0x0               ; =0
mov	w11, #0xfba2            ; =64418
movk	w11, #0x26, lsl #16
add	x11, x24, x11
ldrb	w12, [x11, #0x1d9]
cmp	w12, #0x1
b.ne	<_main.timed__anon>
cmp	w8, #0x3e
add	x13, sp, #0x100
b.lo	<_main.timed__anon>
ldrh	w10, [x11]
sub	w11, w8, #0x14
and	w11, w11, #0xffff
cmp	w10, w11
csel	w10, w10, w11, lo
cmp	w10, #0x2a
mov	w11, #0x2a              ; =42
csel	w10, w10, w11, hi
b	<_main.timed__anon>
mov	x10, #0x0               ; =0
add	x13, sp, #0x100
b	<_main.timed__anon>
add	x13, sp, #0x100
cmp	w9, #0x1
cset	w11, hi
cmp	w9, #0x0
cset	w12, ne
cmp	w10, w8
csel	w10, w10, w8, lo
sub	w8, w8, w10
cmp	w12, w9
csel	w12, w12, w9, lo
sub	w9, w9, w12
and	w9, w9, #0xffff
subs	w9, w9, w11
csel	w9, wzr, w9, lo
orr	x10, x10, x12, lsl #16
ldr	x1, [x27, #0x8]
and	w8, w8, #0xffff
lsl	x8, x8, #32
orr	x8, x8, x9, lsl #48
orr	x8, x8, x10
str	x8, [x13, #0x28]
sub	x2, x29, #0xd8
mov	x0, x24
bl	<_panes.pane_resize.resizeAttachedPanes>
ands	w0, w0, #0xffff
b.ne	<_main.timed__anon>
mov	w8, #0x4                ; =4
strb	w8, [sp, #0x48]
strb	wzr, [sp, #0x46]
and	w20, w8, #0xff
and	w8, wzr, #0xff
ldr	x9, [x24, x23]
and	x8, x8, #0x1
add	x8, x9, x8
str	x8, [x24, x23]
mov	x0, x21
bl	<_ClientEventContext.finishEvent>
tst	w0, #0xffff
b.ne	<_main.timed__anon>
and	x8, x20, #0x7
add	x25, x25, x8
add	x19, x19, #0x1
cmp	x19, x22
b.ne	<_main.timed__anon>
b	<_main.timed__anon>
mov	x25, #0x0               ; =0
ldr	x8, [x21, #0x2270]
add	x19, x8, x25
ldp	x8, x0, [sp, #0x28]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0xb0
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [sp, #0xb0]
ldr	x9, [sp, #0x20]
sub	x8, x8, x9
ldr	x9, [sp, #0x38]
strh	wzr, [x9, #0x8]
str	x8, [x9]
add	sp, sp, #0x1b0
ldp	x29, x30, [sp, #0x50]
ldp	x20, x19, [sp, #0x40]
ldp	x22, x21, [sp, #0x30]
ldp	x24, x23, [sp, #0x20]
ldp	x26, x25, [sp, #0x10]
ldp	x28, x27, [sp], #0x60
ret
ldr	x8, [sp, #0x38]
strh	w0, [x8, #0x8]
b	<_main.timed__anon>

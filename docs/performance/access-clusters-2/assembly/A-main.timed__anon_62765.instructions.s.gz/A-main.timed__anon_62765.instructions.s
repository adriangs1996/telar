stp	x28, x27, [sp, #-0x60]!
stp	x26, x25, [sp, #0x10]
stp	x24, x23, [sp, #0x20]
stp	x22, x21, [sp, #0x30]
stp	x20, x19, [sp, #0x40]
stp	x29, x30, [sp, #0x50]
add	x29, sp, #0x50
sub	sp, sp, #0x4, lsl #12   ; =0x4000
sub	sp, sp, #0x110
mov	x19, x2
str	x0, [sp, #0x20]
ldp	x0, x8, [x1]
ldr	x25, [x1, #0x68]
stp	x8, x0, [sp, #0x10]
ldr	x9, [x8, #0x2c0]
add	x20, sp, #0xac0
add	x8, sp, #0xac0
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [sp, #0xac0]
str	x8, [sp, #0x8]
str	x19, [sp, #0x38]
cbz	x19, <_main.timed__anon>
mov	x9, #0x0                ; =0
mov	x19, #0x0               ; =0
add	x8, sp, #0x3, lsl #12   ; =0x3000
add	x8, x8, #0xd8
add	x10, sp, #0x2, lsl #12  ; =0x2000
add	x10, x10, #0x280
add	x10, x10, #0x20
str	x10, [sp, #0x50]
add	x11, x8, #0x38
add	x10, x20, #0x938
str	x10, [sp, #0x158]
add	x10, x20, #0x948
stp	x11, x10, [sp, #0x28]
add	x8, x8, #0x20
str	x8, [sp, #0x40]
str	x25, [sp, #0x170]
stp	x9, x19, [sp, #0x58]
ldr	x13, [x25, #0x20]
mov	w8, #0x50b8             ; =20664
movk	w8, #0x13, lsl #16
add	x24, x13, x8
ldrh	w8, [x24, #0x80]
ldrh	w9, [x24, #0x82]
ldrb	w10, [x24, #0x89]
cmp	w10, #0x1
b.ne	<_main.timed__anon>
mov	w10, #0x0               ; =0
mov	w11, #0xfba2            ; =64418
movk	w11, #0x26, lsl #16
add	x11, x13, x11
ldrb	w12, [x11, #0x1d9]
cmp	w12, #0x1
b.ne	<_main.timed__anon>
cmp	w8, #0x3e
b.lo	<_main.timed__anon>
ldrh	w10, [x11]
sub	w11, w8, #0x14
and	w11, w11, #0xffff
cmp	w10, w11
csel	w10, w10, w11, lo
cmp	w10, #0x2a
mov	w11, #0x2a              ; =42
csel	w10, w10, w11, hi
cmp	w9, #0x1
cset	w11, hi
cmp	w9, #0x0
cset	w12, ne
cmp	w10, w8
csel	w10, w10, w8, lo
sub	w8, w8, w10
cmp	w12, w9
csel	w12, w12, w9, lo
sub	w9, w9, w12
and	w9, w9, #0xffff
subs	w9, w9, w11
csel	w9, wzr, w9, lo
orr	x10, x10, x12, lsl #16
b	<_main.timed__anon>
mov	x10, #0x0               ; =0
mov	w11, #0xeb80            ; =60288
movk	w11, #0x26, lsl #16
add	x25, x13, x11
mov	w11, #0x908             ; =2312
movk	w11, #0x23, lsl #16
add	x22, x13, x11
mov	w11, #0x5ef0            ; =24304
movk	w11, #0x20, lsl #16
add	x15, x13, x11
mov	w11, #0xfcb8            ; =64696
movk	w11, #0x1d, lsl #16
add	x20, x13, x11
mov	w11, #0x99d8            ; =39384
movk	w11, #0x17, lsl #16
add	x11, x13, x11
str	x11, [sp, #0x130]
mov	w11, #0x9600            ; =38400
movk	w11, #0x16, lsl #16
add	x11, x13, x11
str	x11, [sp, #0x148]
mov	w11, #0x11c0            ; =4544
movk	w11, #0x16, lsl #16
add	x11, x13, x11
str	x11, [sp, #0x138]
mov	w11, #0xaeb0            ; =44720
movk	w11, #0x14, lsl #16
add	x28, x13, x11
mov	w11, #0x9bc8            ; =39880
movk	w11, #0x14, lsl #16
add	x11, x13, x11
str	x11, [sp, #0x128]
mov	w11, #0xda70            ; =55920
movk	w11, #0x12, lsl #16
add	x5, x13, x11
mov	w11, #0x9340            ; =37696
movk	w11, #0x12, lsl #16
add	x12, x13, x11
mov	w11, #0x5ba8            ; =23464
movk	w11, #0xf, lsl #16
add	x6, x13, x11
mov	w11, #0x30f0            ; =12528
movk	w11, #0xc, lsl #16
add	x11, x13, x11
str	x11, [sp, #0x120]
mov	w11, #0xf0b8            ; =61624
movk	w11, #0xb, lsl #16
add	x23, x13, x11
ldr	x14, [x24, #0x8]
ldr	x21, [x28]
and	w8, w8, #0xffff
lsl	x8, x8, #32
orr	x8, x8, x9, lsl #48
add	x9, x14, x21
add	x9, x9, #0x1
str	x9, [sp, #0x180]
orr	x8, x8, x10
ldr	x9, [x12]
str	x13, [sp, #0x160]
str	x9, [sp, #0x150]
str	x12, [sp, #0x48]
str	x8, [sp, #0x80]
cbz	x9, <_main.timed__anon>
ldr	x1, [x12, #0x8]
str	x8, [sp, #0x2280]
add	x2, sp, #0x2, lsl #12   ; =0x2000
add	x2, x2, #0x280
mov	x0, x23
str	x1, [sp, #0x168]
mov	x19, x15
mov	x21, x5
mov	x26, x6
bl	<_workspace.tab_layout.snapshot>
mov	x6, x26
mov	x5, x21
mov	x15, x19
ldr	x14, [x24, #0x8]
ldr	x21, [x28]
ldr	x8, [sp, #0x170]
ldr	x8, [x8, #0x20]
str	x8, [sp, #0x140]
b	<_main.timed__anon>
str	x13, [sp, #0x140]
ldr	x7, [x20]
ldr	x30, [x20, #0x50]
ldr	x26, [x20, #0x460]
ldr	x19, [x24, #0x68]
ldr	x12, [x15]
ldr	x13, [x22]
ldr	x15, [x22, #0x28]
ldr	x16, [x22, #0x60]
ldr	x17, [x22, #0x88]
ldr	x0, [x23]
ldp	x1, x2, [x25]
ldr	x8, [x25, #0x10]
str	x8, [sp, #0x178]
ldr	x3, [x5]
ldr	x4, [x24]
ldr	x27, [x5, #0xc38]
ldr	x5, [x6, #0x858]
ldr	x6, [x6]
ldp	x8, x10, [sp, #0x128]
ldr	x8, [x8]
ldr	x9, [x23, #0x28]
ldr	x10, [x10]
add	x8, x9, x8
mov	x11, x24
add	x24, x8, x10
ldr	x8, [x28, #0x8]
ldr	x10, [sp, #0x138]
ldr	x9, [x10]
ldr	x10, [x10, #0x418]
ldr	x20, [sp, #0x148]
ldr	x23, [x20]
ldr	x28, [x22, #0x48]
ldr	x22, [sp, #0x120]
ldp	x20, x25, [x22]
ldr	x22, [x22, #0x228]
ldr	x11, [x11, #0x80]
str	x11, [sp, #0x78]
stp	x30, x7, [sp, #0xc8]
stp	x7, x30, [sp, #0x188]
str	x26, [sp, #0xc0]
stp	x26, x14, [sp, #0x198]
stp	x12, x14, [sp, #0x130]
mov	x26, x19
stp	x19, x12, [sp, #0x1a8]
ldr	x11, [sp, #0x178]
stp	x15, x13, [sp, #0x120]
stp	x13, x15, [sp, #0x1b8]
stp	x17, x16, [sp, #0x110]
stp	x16, x17, [sp, #0x1c8]
stp	x1, x0, [sp, #0x100]
stp	x0, x1, [sp, #0x1d8]
stp	x3, x2, [sp, #0xf0]
stp	x2, x11, [sp, #0x1e8]
stp	x3, x4, [sp, #0x1f8]
stp	x5, x4, [sp, #0xe0]
str	x27, [sp, #0x208]
str	x5, [sp, #0x210]
str	x6, [sp, #0xd8]
str	x6, [sp, #0x218]
stp	x25, x20, [sp, #0x88]
str	x25, [sp, #0x220]
str	x21, [sp, #0x148]
str	x21, [sp, #0x228]
str	x24, [sp, #0x230]
stp	x9, x8, [sp, #0xb0]
str	x8, [sp, #0x238]
str	x9, [sp, #0x240]
stp	x23, x10, [sp, #0xa0]
str	x10, [sp, #0x248]
str	x23, [sp, #0x250]
str	x28, [sp, #0x98]
str	x28, [sp, #0x258]
str	x20, [sp, #0x260]
add	x8, sp, #0x188
stp	xzr, xzr, [x8, #0xe8]
str	x22, [sp, #0x268]
ldr	x9, [sp, #0x180]
str	x9, [sp, #0x280]
stp	xzr, xzr, [x8, #0x100]
mov	w8, #0x4f38             ; =20280
movk	w8, #0x27, lsl #16
ldr	x20, [sp, #0x140]
add	x0, x20, x8
add	x1, sp, #0x188
bl	<_meta.eql__anon>
tbnz	w0, #0x0, <_main.timed__anon>
mov	w8, #0x4f38             ; =20280
movk	w8, #0x27, lsl #16
add	x0, x20, x8
add	x1, sp, #0x188
mov	w2, #0x110              ; =272
bl	<_memcpy>
ldr	x9, [sp, #0x170]
add	x21, sp, #0x2, lsl #12  ; =0x2000
add	x21, x21, #0x280
ldr	x23, [sp, #0x160]
ldr	x8, [sp, #0x150]
cbz	x8, <_main.timed__anon>
ldr	x28, [sp, #0x78]
stp	x24, x22, [sp, #0x68]
str	x27, [sp, #0x140]
str	x26, [sp, #0x150]
mov	w8, #0x8b50             ; =35664
movk	w8, #0xf, lsl #16
add	x19, x23, x8
ldr	x22, [x9, #0x20]
mov	w8, #0x58b8             ; =22712
movk	w8, #0x27, lsl #16
add	x20, x22, x8
mov	w8, #0x18               ; =24
ldr	x9, [sp, #0x168]
madd	x8, x9, x8, x23
mov	w9, #0x8b40             ; =35648
movk	w9, #0xf, lsl #16
add	x25, x8, x9
ldr	x27, [x25, #0x10]
add	x0, sp, #0x2, lsl #12   ; =0x2000
add	x0, x0, #0x280
mov	w1, #0x828              ; =2088
bl	<dyld_stub_binder>
mov	x8, #0x0                ; =0
mov	w9, #0x0                ; =0
mov	x10, #0x0               ; =0
mov	w11, #0xc050            ; =49232
movk	w11, #0x12, lsl #16
add	x24, x23, x11
b	<_main.timed__anon>
add	x10, x10, #0x1
cmp	x10, #0x100
b.eq	<_main.timed__anon>
ldr	x11, [x24, x10, lsl #3]
cbz	x11, <_main.timed__anon>
ldr	x12, [x11, #0x28]
cmp	x12, x27
b.ne	<_main.timed__anon>
ldr	q0, [x25]
str	q0, [x21]
ldr	x9, [sp, #0x50]
add	x9, x9, x8, lsl #5
ldr	x12, [x11, #0x10]
ldr	x13, [x11, #0xc8]
stp	x12, x13, [x9]
ldrb	w12, [x11, #0x106]
strb	w12, [x9, #0x18]
ldr	x11, [x11, #0xb8]
str	x11, [x9, #0x10]
add	x8, x8, #0x1
mov	w9, #0x1                ; =1
cmp	x10, #0xff
add	x10, x10, #0x1
b.lo	<_main.timed__anon>
str	x27, [sp, #0x2290]
strb	w9, [x21, #0x18]
strb	w8, [x21, #0x820]
add	x0, sp, #0x298
add	x1, sp, #0x2, lsl #12   ; =0x2000
add	x1, x1, #0x280
mov	w2, #0x828              ; =2088
bl	<_memcpy>
ldr	x8, [sp, #0x180]
str	x8, [sp, #0x30d8]
ldr	x8, [sp, #0x80]
str	x8, [sp, #0x30e0]
str	x28, [sp, #0x3710]
add	x28, sp, #0x3, lsl #12  ; =0x3000
add	x28, x28, #0xd8
strb	wzr, [x28, #0x640]
add	x0, sp, #0x2, lsl #12   ; =0x2000
add	x0, x0, #0x280
mov	x1, x24
mov	w2, #0x800              ; =2048
bl	<_memcpy>
mov	x9, #0x0                ; =0
mov	x8, #0x0                ; =0
b	<_main.timed__anon>
add	x9, x9, #0x8
cmp	x9, #0x800
b.eq	<_main.timed__anon>
ldr	x10, [x21, x9]
cbz	x10, <_main.timed__anon>
ldr	x10, [x10, #0x28]
cmp	x10, x27
cinc	x8, x8, eq
b	<_main.timed__anon>
cbz	x8, <_main.timed__anon>
ldr	q0, [x25]
str	q0, [x21]
ldr	x8, [x25, #0x10]
str	x8, [sp, #0x2290]
mov	w8, #0x1                ; =1
strb	w8, [x21, #0x18]
add	x10, sp, #0x2, lsl #12  ; =0x2000
add	x10, x10, #0x280
b	<_main.timed__anon>
adrp x10, RELOC_PAGE
add	x10, x10, #RELOC_OFFSET
ldr	x26, [sp, #0x178]
mov	x9, #0x0                ; =0
mov	x8, #0x0                ; =0
ldp	q0, q1, [x10]
stp	q0, q1, [x28, #0x10]
mov	w10, #0xc00             ; =3072
ldr	x11, [sp, #0x168]
madd	x10, x11, x10, x23
add	x11, x10, #0xf8, lsl #12 ; =0xf8000
ldr	x10, [x11, #0x1d30]
str	x10, [sp, #0x3108]
b	<_main.timed__anon>
add	x8, x8, #0x1
cmp	x8, #0x100
b.eq	<_main.timed__anon>
ldr	x10, [x24, x8, lsl #3]
cbz	x10, <_main.timed__anon>
ldr	x11, [x10, #0x28]
cmp	x11, x27
b.ne	<_main.timed__anon>
ldr	x11, [sp, #0x28]
mov	w12, #0x18              ; =24
madd	x9, x9, x12, x11
ldr	x11, [x10, #0x10]
ldr	x12, [x10, #0xb8]
stp	x11, x12, [x9]
ldr	w10, [x10, #0x50]
str	w10, [x9, #0x10]
ldrb	w9, [x28, #0x640]
add	x9, x9, #0x1
strb	w9, [x28, #0x640]
cmp	x8, #0xff
add	x8, x8, #0x1
b.lo	<_main.timed__anon>
add	x1, sp, #0x3, lsl #12   ; =0x3000
add	x1, x1, #0xd8
ldr	x0, [sp, #0x158]
mov	w2, #0x648              ; =1608
bl	<_memcpy>
ldp	x8, x9, [sp, #0xc8]
str	x9, [sp, #0xac0]
str	x8, [sp, #0xac8]
ldr	x8, [sp, #0xc0]
str	x8, [sp, #0xad0]
ldr	x8, [sp, #0x138]
str	x8, [sp, #0xad8]
ldr	x8, [sp, #0x150]
str	x8, [sp, #0xae0]
ldp	x8, x9, [sp, #0x128]
str	x9, [sp, #0xae8]
str	x8, [sp, #0xaf0]
ldp	x8, x9, [sp, #0x118]
str	x9, [sp, #0xaf8]
str	x8, [sp, #0xb00]
ldp	x8, x9, [sp, #0x108]
str	x9, [sp, #0xb08]
str	x8, [sp, #0xb10]
ldp	x8, x9, [sp, #0xf8]
str	x9, [sp, #0xb18]
str	x8, [sp, #0xb20]
str	x26, [sp, #0xb28]
ldp	x8, x9, [sp, #0xe8]
str	x9, [sp, #0xb30]
str	x8, [sp, #0xb38]
ldr	x8, [sp, #0x140]
str	x8, [sp, #0xb40]
ldp	x8, x9, [sp, #0xd8]
str	x9, [sp, #0xb48]
str	x8, [sp, #0xb50]
ldr	x8, [sp, #0x88]
str	x8, [sp, #0xb58]
ldr	x8, [sp, #0x148]
str	x8, [sp, #0xb60]
ldr	x8, [sp, #0x68]
str	x8, [sp, #0xb68]
ldp	x8, x9, [sp, #0xb0]
str	x9, [sp, #0xb70]
str	x8, [sp, #0xb78]
ldp	x8, x9, [sp, #0xa0]
str	x9, [sp, #0xb80]
str	x8, [sp, #0xb88]
ldp	x8, x9, [sp, #0x90]
str	x9, [sp, #0xb90]
str	x8, [sp, #0xb98]
add	x21, sp, #0xac0
stp	xzr, xzr, [x21, #0xe8]
ldr	x8, [sp, #0x70]
str	x8, [sp, #0xba0]
ldr	x8, [sp, #0x180]
str	x8, [sp, #0xbb8]
stp	xzr, xzr, [x21, #0x100]
add	x0, x21, #0x110
add	x1, sp, #0x298
mov	w2, #0x828              ; =2088
bl	<_memcpy>
strb	wzr, [x21, #0xf80]
add	x0, sp, #0x2, lsl #12   ; =0x2000
add	x0, x0, #0x280
add	x1, x21, #0x130
mov	w2, #0xe58              ; =3672
bl	<_memcpy>
ldrb	w8, [x20, #0xf98]
cbnz	w8, <_main.timed__anon>
add	x0, sp, #0xac0
mov	w8, #0x4f38             ; =20280
movk	w8, #0x27, lsl #16
add	x1, x22, x8
bl	<_meta.eql__anon>
tbz	w0, #0x0, <_main.timed__anon>
ldr	x21, [x20]
cmn	x21, #0x1
b.eq	<_main.timed__anon>
add	x27, sp, #0x2, lsl #12  ; =0x2000
add	x27, x27, #0x280
ldrb	w23, [x27, #0x800]
cmp	x23, #0x41
b.hs	<_main.timed__anon>
add	x8, x21, #0x1
str	x8, [x20]
mov	w8, #0x5048             ; =20552
movk	w8, #0x27, lsl #16
add	x0, x22, x8
add	x1, sp, #0xac0
mov	w2, #0x110              ; =272
bl	<_memcpy>
strb	wzr, [x20, #0xfa0]
mov	w8, #0x1                ; =1
strb	w8, [x20, #0xf98]
str	x21, [x20, #0x8]
mov	w8, #0x58c8             ; =22728
movk	w8, #0x27, lsl #16
add	x0, x22, x8
add	x1, sp, #0xac0
mov	w2, #0x110              ; =272
bl	<_memcpy>
mov	w8, #0x6020             ; =24608
movk	w8, #0x27, lsl #16
add	x25, x22, x8
ldrb	w8, [x27, #0xe50]
strb	w8, [x20, #0xf90]
ldr	x8, [sp, #0x158]
ldr	q0, [x8]
mov	w8, #0x59d8             ; =23000
movk	w8, #0x27, lsl #16
str	q0, [x22, x8]
mov	w8, #0x59e8             ; =23016
movk	w8, #0x27, lsl #16
add	x8, x22, x8
ldr	x9, [sp, #0x30]
ldp	q0, q1, [x9]
stp	q0, q1, [x8]
ldr	x8, [sp, #0x2ab8]
str	x8, [x20, #0x150]
ldr	x8, [sp, #0x30c0]
str	x8, [x20, #0x758]
ldrb	w8, [x27, #0xe48]
strb	w8, [x20, #0x760]
add	x8, x8, x8, lsl #1
lsl	x2, x8, #3
mov	w8, #0x5a10             ; =23056
movk	w8, #0x27, lsl #16
add	x0, x22, x8
add	x1, x27, #0x840
bl	<_memcpy>
add	x8, sp, #0x199
ldur	q0, [x8, #0xff]
add	x8, sp, #0x1a9
ldur	q1, [x8, #0xff]
stp	q0, q1, [x25]
strb	w23, [x20, #0xf88]
lsl	x2, x23, #5
mov	w23, #0x6040            ; =24640
movk	w23, #0x27, lsl #16
add	x0, x22, x23
add	x1, sp, #0x2, lsl #12   ; =0x2000
add	x1, x1, #0x280
bl	<_memcpy>
ldr	x25, [sp, #0x170]
ldr	x20, [x25, #0x20]
mov	w8, #0x6840             ; =26688
movk	w8, #0x27, lsl #16
add	x22, x20, x8
ldrb	w8, [x22, #0x10]
cbz	w8, <_main.timed__anon>
add	x8, x20, #0x270, lsl #12 ; =0x270000
ldr	x8, [x8, #0x58c0]
cmp	x8, x21
b.ne	<_main.timed__anon>
mov	w8, #0x5298             ; =21144
movk	w8, #0x27, lsl #16
add	x21, x20, x8
mov	w8, #0x5158             ; =20824
movk	w8, #0x27, lsl #16
add	x0, x20, x8
mov	w8, #0x58c8             ; =22728
movk	w8, #0x27, lsl #16
add	x1, x20, x8
mov	w2, #0x110              ; =272
bl	<_memcpy>
ldrb	w8, [x21, #0x618]
cbnz	w8, <_main.timed__anon>
mov	w8, #0x52a0             ; =21152
movk	w8, #0x27, lsl #16
add	x0, x20, x8
mov	w1, #0x1                ; =1
mov	w2, #0x618              ; =1560
bl	<_memset>
mov	w8, #0x59d8             ; =23000
movk	w8, #0x27, lsl #16
ldr	q0, [x20, x8]
mov	w8, #0x5268             ; =21096
movk	w8, #0x27, lsl #16
str	q0, [x20, x8]
mov	w8, #0x5278             ; =21112
movk	w8, #0x27, lsl #16
add	x8, x20, x8
mov	w9, #0x59e8             ; =23016
movk	w9, #0x27, lsl #16
add	x9, x20, x9
ldp	q0, q1, [x9]
stp	q0, q1, [x8]
ldr	x8, [x21, #0x770]
str	x8, [x21]
ldr	x8, [x21, #0xd78]
str	x8, [x21, #0x608]
ldrb	w8, [x21, #0xd80]
strb	w8, [x21, #0x610]
add	x8, x8, x8, lsl #1
lsl	x2, x8, #3
mov	w8, #0x52a0             ; =21152
movk	w8, #0x27, lsl #16
add	x0, x20, x8
mov	w8, #0x5a10             ; =23056
movk	w8, #0x27, lsl #16
add	x1, x20, x8
bl	<_memcpy>
mov	w8, #0x6020             ; =24608
movk	w8, #0x27, lsl #16
add	x8, x20, x8
ldrb	w9, [x22, #0x8]
strb	w9, [x28, #0x808]
ldp	q0, q1, [x8]
add	x21, sp, #0x2, lsl #12  ; =0x2000
stp	q0, q1, [x21, #0x280]!
ldrb	w8, [x22]
strb	w8, [x28, #0x800]
lsl	x2, x8, #5
add	x0, sp, #0x3, lsl #12   ; =0x3000
add	x0, x0, #0xd8
add	x1, x20, x23
bl	<_memcpy>
mov	w8, #0x58c0             ; =22720
movk	w8, #0x27, lsl #16
add	x0, x20, x8
mov	w1, #0xf98              ; =3992
bl	<dyld_stub_binder>
add	x1, sp, #0x3, lsl #12   ; =0x3000
add	x1, x1, #0xd8
ldr	x0, [sp, #0x50]
mov	w2, #0x810              ; =2064
bl	<_memcpy>
add	x0, sp, #0x1, lsl #12   ; =0x1000
add	x0, x0, #0xa50
add	x1, sp, #0x2, lsl #12   ; =0x2000
add	x1, x1, #0x280
mov	w2, #0x830              ; =2096
bl	<_memcpy>
add	x0, sp, #0x3, lsl #12   ; =0x3000
add	x0, x0, #0xd8
add	x1, sp, #0x1, lsl #12   ; =0x1000
add	x1, x1, #0xa50
mov	w2, #0x828              ; =2088
bl	<_memcpy>
ldrb	w8, [x28, #0x18]
cbz	w8, <_main.timed__anon>
ldr	x8, [sp, #0x48]
ldr	x8, [x8]
mov	w22, #0xffff            ; =65535
cbz	x8, <_main.timed__anon>
ldrb	w10, [x28, #0x8]
ldr	x9, [sp, #0x30d8]
ldr	x20, [sp, #0x30e8]
ldr	x23, [sp, #0x160]
ldr	x11, [x19]
cmp	x11, x20
b.eq	<_main.timed__anon>
add	x19, x19, #0x18
subs	x8, x8, #0x1
b.ne	<_main.timed__anon>
b	<_main.timed__anon>
mov	x8, #0x0                ; =0
ldr	x19, [sp, #0x60]
add	x19, x8, x19
ldr	x9, [sp, #0x58]
add	x9, x9, #0x1
ldr	x8, [sp, #0x38]
cmp	x9, x8
b.ne	<_main.timed__anon>
b	<_main.timed__anon>
mov	x8, #0x0                ; =0
ldurb	w11, [x19, #-0x8]
eor	w10, w11, w10
tbnz	w10, #0x0, <_main.timed__anon>
ldur	x10, [x19, #-0x10]
cmp	x10, x9
ldr	x19, [sp, #0x60]
b.ne	<_main.timed__anon>
add	x0, sp, #0x3, lsl #12   ; =0x3000
add	x0, x0, #0x900
mov	x1, x24
mov	w2, #0x800              ; =2048
bl	<_memcpy>
mov	x9, #0x0                ; =0
mov	x8, #0x0                ; =0
add	x11, sp, #0x3, lsl #12  ; =0x3000
add	x11, x11, #0x900
b	<_main.timed__anon>
add	x9, x9, #0x8
cmp	x9, #0x800
b.eq	<_main.timed__anon>
ldr	x10, [x11, x9]
cbz	x10, <_main.timed__anon>
ldr	x10, [x10, #0x28]
cmp	x10, x20
cinc	x8, x8, eq
b	<_main.timed__anon>
cbz	x8, <_main.timed__anon>
strb	wzr, [x21, #0x820]
ldrb	w9, [x28, #0x820]
cbz	x9, <_main.timed__anon>
mov	x8, #0x0                ; =0
mov	x10, #0x0               ; =0
mov	w11, #0xc850            ; =51280
movk	w11, #0x12, lsl #16
add	x11, x23, x11
mov	w12, #0xd850            ; =55376
movk	w12, #0x12, lsl #16
add	x12, x23, x12
b	<_main.timed__anon>
mov	x8, #0x0                ; =0
b	<_main.timed__anon>
str	xzr, [x0, #0xc8]
ldr	x0, [sp, #0x50]
add	x8, x0, x8, lsl #5
stp	x14, x15, [x8]
str	x16, [x8, #0x10]
strb	w17, [x8, #0x18]
ldur	w14, [x13, #0x19]
stur	w14, [x8, #0x19]
ldur	w13, [x13, #0x1c]
str	w13, [x8, #0x1c]
ldrb	w8, [x21, #0x820]
add	x8, x8, #0x1
strb	w8, [x21, #0x820]
add	x10, x10, #0x1
cmp	x10, x9
b.eq	<_main.timed__anon>
ldr	x13, [sp, #0x40]
add	x13, x13, x10, lsl #5
ldr	x14, [x13]
cbz	x14, <_main.timed__anon>
ldp	x15, x16, [x13, #0x8]
ldrb	w17, [x13, #0x18]
eor	x0, x14, x14, lsr #32
mov	x1, #0x556d             ; =21869
movk	x1, #0xeb34, lsl #16
movk	x1, #0x25f9, lsl #32
movk	x1, #0xbea2, lsl #48
mul	x0, x0, x1
eor	x0, x0, x0, lsr #29
mul	x0, x0, x1
eor	x0, x0, x0, lsr #32
mul	x0, x0, x1
eor	x1, x0, x0, lsr #29
mov	w0, #0x200              ; =512
and	x1, x1, #0x1ff
ldr	x2, [x11, x1, lsl #3]
cmp	x2, x14
b.eq	<_main.timed__anon>
cbz	x2, <_main.timed__anon>
add	x1, x1, #0x1
subs	x0, x0, #0x1
b.ne	<_main.timed__anon>
b	<_main.timed__anon>
ldrb	w0, [x12, x1]
ldr	x0, [x24, x0, lsl #3]
cbz	x0, <_main.timed__anon>
ldr	x1, [x0, #0x28]
cmp	x1, x20
b.ne	<_main.timed__anon>
and	w1, w17, #0x1
ldrb	w2, [x0, #0x106]
cmp	w2, w1
b.ne	<_main.timed__anon>
ldr	x1, [x0, #0xb8]
cmp	x1, x16
b.ne	<_main.timed__anon>
ldr	x1, [x0, #0xc8]
cmp	x1, x15
b.ne	<_main.timed__anon>
ldr	x1, [x0, #0xb0]
cbz	x1, <_main.timed__anon>
mov	x2, #0x0                ; =0
ldr	x3, [x0, #0xa8]
str	w22, [x3, x2, lsl #2]
add	x2, x2, #0x1
cmp	x2, x1
b.lo	<_main.timed__anon>
b	<_main.timed__anon>
ldp	x8, x0, [sp, #0x10]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0xac0
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [sp, #0xac0]
ldr	x9, [sp, #0x8]
sub	x8, x8, x9
ldr	x9, [sp, #0x20]
strh	wzr, [x9, #0x8]
str	x8, [x9]
b	<_main.timed__anon>
mov	w8, #0x267              ; =615
b	<_main.timed__anon>
mov	w8, #0x1b8              ; =440
b	<_main.timed__anon>
mov	w8, #0x263              ; =611
b	<_main.timed__anon>
mov	w8, #0x264              ; =612
b	<_main.timed__anon>
mov	w8, #0x265              ; =613
b	<_main.timed__anon>
mov	w8, #0x266              ; =614
ldr	x9, [sp, #0x20]
strh	w8, [x9, #0x8]
add	sp, sp, #0x4, lsl #12   ; =0x4000
add	sp, sp, #0x110
ldp	x29, x30, [sp, #0x50]
ldp	x20, x19, [sp, #0x40]
ldp	x22, x21, [sp, #0x30]
ldp	x24, x23, [sp, #0x20]
ldp	x26, x25, [sp, #0x10]
ldp	x28, x27, [sp], #0x60
ret

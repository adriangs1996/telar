
/tmp/telar-access-clusters-2.QhXJGE/A/bin/telar-benchmarks:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010023eb10 <_main.timed__anon_62765>:
10023eb10:     	stp	x28, x27, [sp, #-0x60]!
10023eb14:     	stp	x26, x25, [sp, #0x10]
10023eb18:     	stp	x24, x23, [sp, #0x20]
10023eb1c:     	stp	x22, x21, [sp, #0x30]
10023eb20:     	stp	x20, x19, [sp, #0x40]
10023eb24:     	stp	x29, x30, [sp, #0x50]
10023eb28:     	add	x29, sp, #0x50
10023eb2c:     	sub	sp, sp, #0x4, lsl #12   ; =0x4000
10023eb30:     	sub	sp, sp, #0x110
10023eb34:     	mov	x19, x2
10023eb38:     	str	x0, [sp, #0x20]
10023eb3c:     	ldp	x0, x8, [x1]
10023eb40:     	ldr	x25, [x1, #0x68]
10023eb44:     	stp	x8, x0, [sp, #0x10]
10023eb48:     	ldr	x9, [x8, #0x2c0]
10023eb4c:     	add	x20, sp, #0xac0
10023eb50:     	add	x8, sp, #0xac0
10023eb54:     	mov	w1, #0x1                ; =1
10023eb58:     	blr	x9
10023eb5c:     	ldr	x8, [sp, #0xac0]
10023eb60:     	str	x8, [sp, #0x8]
10023eb64:     	str	x19, [sp, #0x38]
10023eb68:     	cbz	x19, 0x10023f714 <_main.timed__anon_62765+0xc04>
10023eb6c:     	mov	x9, #0x0                ; =0
10023eb70:     	mov	x19, #0x0               ; =0
10023eb74:     	add	x8, sp, #0x3, lsl #12   ; =0x3000
10023eb78:     	add	x8, x8, #0xd8
10023eb7c:     	add	x10, sp, #0x2, lsl #12  ; =0x2000
10023eb80:     	add	x10, x10, #0x280
10023eb84:     	add	x10, x10, #0x20
10023eb88:     	str	x10, [sp, #0x50]
10023eb8c:     	add	x11, x8, #0x38
10023eb90:     	add	x10, x20, #0x938
10023eb94:     	str	x10, [sp, #0x158]
10023eb98:     	add	x10, x20, #0x948
10023eb9c:     	stp	x11, x10, [sp, #0x28]
10023eba0:     	add	x8, x8, #0x20
10023eba4:     	str	x8, [sp, #0x40]
10023eba8:     	str	x25, [sp, #0x170]
10023ebac:     	stp	x9, x19, [sp, #0x58]
10023ebb0:     	ldr	x13, [x25, #0x20]
10023ebb4:     	mov	w8, #0x50b8             ; =20664
10023ebb8:     	movk	w8, #0x13, lsl #16
10023ebbc:     	add	x24, x13, x8
10023ebc0:     	ldrh	w8, [x24, #0x80]
10023ebc4:     	ldrh	w9, [x24, #0x82]
10023ebc8:     	ldrb	w10, [x24, #0x89]
10023ebcc:     	cmp	w10, #0x1
10023ebd0:     	b.ne	0x10023ec54 <_main.timed__anon_62765+0x144>
10023ebd4:     	mov	w10, #0x0               ; =0
10023ebd8:     	mov	w11, #0xfba2            ; =64418
10023ebdc:     	movk	w11, #0x26, lsl #16
10023ebe0:     	add	x11, x13, x11
10023ebe4:     	ldrb	w12, [x11, #0x1d9]
10023ebe8:     	cmp	w12, #0x1
10023ebec:     	b.ne	0x10023ec18 <_main.timed__anon_62765+0x108>
10023ebf0:     	cmp	w8, #0x3e
10023ebf4:     	b.lo	0x10023ec18 <_main.timed__anon_62765+0x108>
10023ebf8:     	ldrh	w10, [x11]
10023ebfc:     	sub	w11, w8, #0x14
10023ec00:     	and	w11, w11, #0xffff
10023ec04:     	cmp	w10, w11
10023ec08:     	csel	w10, w10, w11, lo
10023ec0c:     	cmp	w10, #0x2a
10023ec10:     	mov	w11, #0x2a              ; =42
10023ec14:     	csel	w10, w10, w11, hi
10023ec18:     	cmp	w9, #0x1
10023ec1c:     	cset	w11, hi
10023ec20:     	cmp	w9, #0x0
10023ec24:     	cset	w12, ne
10023ec28:     	cmp	w10, w8
10023ec2c:     	csel	w10, w10, w8, lo
10023ec30:     	sub	w8, w8, w10
10023ec34:     	cmp	w12, w9
10023ec38:     	csel	w12, w12, w9, lo
10023ec3c:     	sub	w9, w9, w12
10023ec40:     	and	w9, w9, #0xffff
10023ec44:     	subs	w9, w9, w11
10023ec48:     	csel	w9, wzr, w9, lo
10023ec4c:     	orr	x10, x10, x12, lsl #16
10023ec50:     	b	0x10023ec58 <_main.timed__anon_62765+0x148>
10023ec54:     	mov	x10, #0x0               ; =0
10023ec58:     	mov	w11, #0xeb80            ; =60288
10023ec5c:     	movk	w11, #0x26, lsl #16
10023ec60:     	add	x25, x13, x11
10023ec64:     	mov	w11, #0x908             ; =2312
10023ec68:     	movk	w11, #0x23, lsl #16
10023ec6c:     	add	x22, x13, x11
10023ec70:     	mov	w11, #0x5ef0            ; =24304
10023ec74:     	movk	w11, #0x20, lsl #16
10023ec78:     	add	x15, x13, x11
10023ec7c:     	mov	w11, #0xfcb8            ; =64696
10023ec80:     	movk	w11, #0x1d, lsl #16
10023ec84:     	add	x20, x13, x11
10023ec88:     	mov	w11, #0x99d8            ; =39384
10023ec8c:     	movk	w11, #0x17, lsl #16
10023ec90:     	add	x11, x13, x11
10023ec94:     	str	x11, [sp, #0x130]
10023ec98:     	mov	w11, #0x9600            ; =38400
10023ec9c:     	movk	w11, #0x16, lsl #16
10023eca0:     	add	x11, x13, x11
10023eca4:     	str	x11, [sp, #0x148]
10023eca8:     	mov	w11, #0x11c0            ; =4544
10023ecac:     	movk	w11, #0x16, lsl #16
10023ecb0:     	add	x11, x13, x11
10023ecb4:     	str	x11, [sp, #0x138]
10023ecb8:     	mov	w11, #0xaeb0            ; =44720
10023ecbc:     	movk	w11, #0x14, lsl #16
10023ecc0:     	add	x28, x13, x11
10023ecc4:     	mov	w11, #0x9bc8            ; =39880
10023ecc8:     	movk	w11, #0x14, lsl #16
10023eccc:     	add	x11, x13, x11
10023ecd0:     	str	x11, [sp, #0x128]
10023ecd4:     	mov	w11, #0xda70            ; =55920
10023ecd8:     	movk	w11, #0x12, lsl #16
10023ecdc:     	add	x5, x13, x11
10023ece0:     	mov	w11, #0x9340            ; =37696
10023ece4:     	movk	w11, #0x12, lsl #16
10023ece8:     	add	x12, x13, x11
10023ecec:     	mov	w11, #0x5ba8            ; =23464
10023ecf0:     	movk	w11, #0xf, lsl #16
10023ecf4:     	add	x6, x13, x11
10023ecf8:     	mov	w11, #0x30f0            ; =12528
10023ecfc:     	movk	w11, #0xc, lsl #16
10023ed00:     	add	x11, x13, x11
10023ed04:     	str	x11, [sp, #0x120]
10023ed08:     	mov	w11, #0xf0b8            ; =61624
10023ed0c:     	movk	w11, #0xb, lsl #16
10023ed10:     	add	x23, x13, x11
10023ed14:     	ldr	x14, [x24, #0x8]
10023ed18:     	ldr	x21, [x28]
10023ed1c:     	and	w8, w8, #0xffff
10023ed20:     	lsl	x8, x8, #32
10023ed24:     	orr	x8, x8, x9, lsl #48
10023ed28:     	add	x9, x14, x21
10023ed2c:     	add	x9, x9, #0x1
10023ed30:     	str	x9, [sp, #0x180]
10023ed34:     	orr	x8, x8, x10
10023ed38:     	ldr	x9, [x12]
10023ed3c:     	str	x13, [sp, #0x160]
10023ed40:     	str	x9, [sp, #0x150]
10023ed44:     	str	x12, [sp, #0x48]
10023ed48:     	str	x8, [sp, #0x80]
10023ed4c:     	cbz	x9, 0x10023ed9c <_main.timed__anon_62765+0x28c>
10023ed50:     	ldr	x1, [x12, #0x8]
10023ed54:     	str	x8, [sp, #0x2280]
10023ed58:     	add	x2, sp, #0x2, lsl #12   ; =0x2000
10023ed5c:     	add	x2, x2, #0x280
10023ed60:     	mov	x0, x23
10023ed64:     	str	x1, [sp, #0x168]
10023ed68:     	mov	x19, x15
10023ed6c:     	mov	x21, x5
10023ed70:     	mov	x26, x6
10023ed74:     	bl	0x10029fd78 <_workspace.tab_layout.snapshot>
10023ed78:     	mov	x6, x26
10023ed7c:     	mov	x5, x21
10023ed80:     	mov	x15, x19
10023ed84:     	ldr	x14, [x24, #0x8]
10023ed88:     	ldr	x21, [x28]
10023ed8c:     	ldr	x8, [sp, #0x170]
10023ed90:     	ldr	x8, [x8, #0x20]
10023ed94:     	str	x8, [sp, #0x140]
10023ed98:     	b	0x10023eda0 <_main.timed__anon_62765+0x290>
10023ed9c:     	str	x13, [sp, #0x140]
10023eda0:     	ldr	x7, [x20]
10023eda4:     	ldr	x30, [x20, #0x50]
10023eda8:     	ldr	x26, [x20, #0x460]
10023edac:     	ldr	x19, [x24, #0x68]
10023edb0:     	ldr	x12, [x15]
10023edb4:     	ldr	x13, [x22]
10023edb8:     	ldr	x15, [x22, #0x28]
10023edbc:     	ldr	x16, [x22, #0x60]
10023edc0:     	ldr	x17, [x22, #0x88]
10023edc4:     	ldr	x0, [x23]
10023edc8:     	ldp	x1, x2, [x25]
10023edcc:     	ldr	x8, [x25, #0x10]
10023edd0:     	str	x8, [sp, #0x178]
10023edd4:     	ldr	x3, [x5]
10023edd8:     	ldr	x4, [x24]
10023eddc:     	ldr	x27, [x5, #0xc38]
10023ede0:     	ldr	x5, [x6, #0x858]
10023ede4:     	ldr	x6, [x6]
10023ede8:     	ldp	x8, x10, [sp, #0x128]
10023edec:     	ldr	x8, [x8]
10023edf0:     	ldr	x9, [x23, #0x28]
10023edf4:     	ldr	x10, [x10]
10023edf8:     	add	x8, x9, x8
10023edfc:     	mov	x11, x24
10023ee00:     	add	x24, x8, x10
10023ee04:     	ldr	x8, [x28, #0x8]
10023ee08:     	ldr	x10, [sp, #0x138]
10023ee0c:     	ldr	x9, [x10]
10023ee10:     	ldr	x10, [x10, #0x418]
10023ee14:     	ldr	x20, [sp, #0x148]
10023ee18:     	ldr	x23, [x20]
10023ee1c:     	ldr	x28, [x22, #0x48]
10023ee20:     	ldr	x22, [sp, #0x120]
10023ee24:     	ldp	x20, x25, [x22]
10023ee28:     	ldr	x22, [x22, #0x228]
10023ee2c:     	ldr	x11, [x11, #0x80]
10023ee30:     	str	x11, [sp, #0x78]
10023ee34:     	stp	x30, x7, [sp, #0xc8]
10023ee38:     	stp	x7, x30, [sp, #0x188]
10023ee3c:     	str	x26, [sp, #0xc0]
10023ee40:     	stp	x26, x14, [sp, #0x198]
10023ee44:     	stp	x12, x14, [sp, #0x130]
10023ee48:     	mov	x26, x19
10023ee4c:     	stp	x19, x12, [sp, #0x1a8]
10023ee50:     	ldr	x11, [sp, #0x178]
10023ee54:     	stp	x15, x13, [sp, #0x120]
10023ee58:     	stp	x13, x15, [sp, #0x1b8]
10023ee5c:     	stp	x17, x16, [sp, #0x110]
10023ee60:     	stp	x16, x17, [sp, #0x1c8]
10023ee64:     	stp	x1, x0, [sp, #0x100]
10023ee68:     	stp	x0, x1, [sp, #0x1d8]
10023ee6c:     	stp	x3, x2, [sp, #0xf0]
10023ee70:     	stp	x2, x11, [sp, #0x1e8]
10023ee74:     	stp	x3, x4, [sp, #0x1f8]
10023ee78:     	stp	x5, x4, [sp, #0xe0]
10023ee7c:     	str	x27, [sp, #0x208]
10023ee80:     	str	x5, [sp, #0x210]
10023ee84:     	str	x6, [sp, #0xd8]
10023ee88:     	str	x6, [sp, #0x218]
10023ee8c:     	stp	x25, x20, [sp, #0x88]
10023ee90:     	str	x25, [sp, #0x220]
10023ee94:     	str	x21, [sp, #0x148]
10023ee98:     	str	x21, [sp, #0x228]
10023ee9c:     	str	x24, [sp, #0x230]
10023eea0:     	stp	x9, x8, [sp, #0xb0]
10023eea4:     	str	x8, [sp, #0x238]
10023eea8:     	str	x9, [sp, #0x240]
10023eeac:     	stp	x23, x10, [sp, #0xa0]
10023eeb0:     	str	x10, [sp, #0x248]
10023eeb4:     	str	x23, [sp, #0x250]
10023eeb8:     	str	x28, [sp, #0x98]
10023eebc:     	str	x28, [sp, #0x258]
10023eec0:     	str	x20, [sp, #0x260]
10023eec4:     	add	x8, sp, #0x188
10023eec8:     	stp	xzr, xzr, [x8, #0xe8]
10023eecc:     	str	x22, [sp, #0x268]
10023eed0:     	ldr	x9, [sp, #0x180]
10023eed4:     	str	x9, [sp, #0x280]
10023eed8:     	stp	xzr, xzr, [x8, #0x100]
10023eedc:     	mov	w8, #0x4f38             ; =20280
10023eee0:     	movk	w8, #0x27, lsl #16
10023eee4:     	ldr	x20, [sp, #0x140]
10023eee8:     	add	x0, x20, x8
10023eeec:     	add	x1, sp, #0x188
10023eef0:     	bl	0x100287b8c <_meta.eql__anon_78340>
10023eef4:     	tbnz	w0, #0x0, 0x10023ef10 <_main.timed__anon_62765+0x400>
10023eef8:     	mov	w8, #0x4f38             ; =20280
10023eefc:     	movk	w8, #0x27, lsl #16
10023ef00:     	add	x0, x20, x8
10023ef04:     	add	x1, sp, #0x188
10023ef08:     	mov	w2, #0x110              ; =272
10023ef0c:     	bl	0x1004b6c5c <_memcpy>
10023ef10:     	ldr	x9, [sp, #0x170]
10023ef14:     	add	x21, sp, #0x2, lsl #12  ; =0x2000
10023ef18:     	add	x21, x21, #0x280
10023ef1c:     	ldr	x23, [sp, #0x160]
10023ef20:     	ldr	x8, [sp, #0x150]
10023ef24:     	cbz	x8, 0x10023f74c <_main.timed__anon_62765+0xc3c>
10023ef28:     	ldr	x28, [sp, #0x78]
10023ef2c:     	stp	x24, x22, [sp, #0x68]
10023ef30:     	str	x27, [sp, #0x140]
10023ef34:     	str	x26, [sp, #0x150]
10023ef38:     	mov	w8, #0x8b50             ; =35664
10023ef3c:     	movk	w8, #0xf, lsl #16
10023ef40:     	add	x19, x23, x8
10023ef44:     	ldr	x22, [x9, #0x20]
10023ef48:     	mov	w8, #0x58b8             ; =22712
10023ef4c:     	movk	w8, #0x27, lsl #16
10023ef50:     	add	x20, x22, x8
10023ef54:     	mov	w8, #0x18               ; =24
10023ef58:     	ldr	x9, [sp, #0x168]
10023ef5c:     	madd	x8, x9, x8, x23
10023ef60:     	mov	w9, #0x8b40             ; =35648
10023ef64:     	movk	w9, #0xf, lsl #16
10023ef68:     	add	x25, x8, x9
10023ef6c:     	ldr	x27, [x25, #0x10]
10023ef70:     	add	x0, sp, #0x2, lsl #12   ; =0x2000
10023ef74:     	add	x0, x0, #0x280
10023ef78:     	mov	w1, #0x828              ; =2088
10023ef7c:     	bl	0x1004bc474 <dyld_stub_binder+0x1004bc474>
10023ef80:     	mov	x8, #0x0                ; =0
10023ef84:     	mov	w9, #0x0                ; =0
10023ef88:     	mov	x10, #0x0               ; =0
10023ef8c:     	mov	w11, #0xc050            ; =49232
10023ef90:     	movk	w11, #0x12, lsl #16
10023ef94:     	add	x24, x23, x11
10023ef98:     	b	0x10023efa8 <_main.timed__anon_62765+0x498>
10023ef9c:     	add	x10, x10, #0x1
10023efa0:     	cmp	x10, #0x100
10023efa4:     	b.eq	0x10023effc <_main.timed__anon_62765+0x4ec>
10023efa8:     	ldr	x11, [x24, x10, lsl #3]
10023efac:     	cbz	x11, 0x10023ef9c <_main.timed__anon_62765+0x48c>
10023efb0:     	ldr	x12, [x11, #0x28]
10023efb4:     	cmp	x12, x27
10023efb8:     	b.ne	0x10023ef9c <_main.timed__anon_62765+0x48c>
10023efbc:     	ldr	q0, [x25]
10023efc0:     	str	q0, [x21]
10023efc4:     	ldr	x9, [sp, #0x50]
10023efc8:     	add	x9, x9, x8, lsl #5
10023efcc:     	ldr	x12, [x11, #0x10]
10023efd0:     	ldr	x13, [x11, #0xc8]
10023efd4:     	stp	x12, x13, [x9]
10023efd8:     	ldrb	w12, [x11, #0x106]
10023efdc:     	strb	w12, [x9, #0x18]
10023efe0:     	ldr	x11, [x11, #0xb8]
10023efe4:     	str	x11, [x9, #0x10]
10023efe8:     	add	x8, x8, #0x1
10023efec:     	mov	w9, #0x1                ; =1
10023eff0:     	cmp	x10, #0xff
10023eff4:     	add	x10, x10, #0x1
10023eff8:     	b.lo	0x10023efa8 <_main.timed__anon_62765+0x498>
10023effc:     	str	x27, [sp, #0x2290]
10023f000:     	strb	w9, [x21, #0x18]
10023f004:     	strb	w8, [x21, #0x820]
10023f008:     	add	x0, sp, #0x298
10023f00c:     	add	x1, sp, #0x2, lsl #12   ; =0x2000
10023f010:     	add	x1, x1, #0x280
10023f014:     	mov	w2, #0x828              ; =2088
10023f018:     	bl	0x1004b6c5c <_memcpy>
10023f01c:     	ldr	x8, [sp, #0x180]
10023f020:     	str	x8, [sp, #0x30d8]
10023f024:     	ldr	x8, [sp, #0x80]
10023f028:     	str	x8, [sp, #0x30e0]
10023f02c:     	str	x28, [sp, #0x3710]
10023f030:     	add	x28, sp, #0x3, lsl #12  ; =0x3000
10023f034:     	add	x28, x28, #0xd8
10023f038:     	strb	wzr, [x28, #0x640]
10023f03c:     	add	x0, sp, #0x2, lsl #12   ; =0x2000
10023f040:     	add	x0, x0, #0x280
10023f044:     	mov	x1, x24
10023f048:     	mov	w2, #0x800              ; =2048
10023f04c:     	bl	0x1004b6c5c <_memcpy>
10023f050:     	mov	x9, #0x0                ; =0
10023f054:     	mov	x8, #0x0                ; =0
10023f058:     	b	0x10023f068 <_main.timed__anon_62765+0x558>
10023f05c:     	add	x9, x9, #0x8
10023f060:     	cmp	x9, #0x800
10023f064:     	b.eq	0x10023f080 <_main.timed__anon_62765+0x570>
10023f068:     	ldr	x10, [x21, x9]
10023f06c:     	cbz	x10, 0x10023f05c <_main.timed__anon_62765+0x54c>
10023f070:     	ldr	x10, [x10, #0x28]
10023f074:     	cmp	x10, x27
10023f078:     	cinc	x8, x8, eq
10023f07c:     	b	0x10023f05c <_main.timed__anon_62765+0x54c>
10023f080:     	cbz	x8, 0x10023f0a8 <_main.timed__anon_62765+0x598>
10023f084:     	ldr	q0, [x25]
10023f088:     	str	q0, [x21]
10023f08c:     	ldr	x8, [x25, #0x10]
10023f090:     	str	x8, [sp, #0x2290]
10023f094:     	mov	w8, #0x1                ; =1
10023f098:     	strb	w8, [x21, #0x18]
10023f09c:     	add	x10, sp, #0x2, lsl #12  ; =0x2000
10023f0a0:     	add	x10, x10, #0x280
10023f0a4:     	b	0x10023f0b0 <_main.timed__anon_62765+0x5a0>
10023f0a8:     	adrp	x10, 0x100794000 <___anon_13184+0xff08>
10023f0ac:     	add	x10, x10, #0x8b8
10023f0b0:     	ldr	x26, [sp, #0x178]
10023f0b4:     	mov	x9, #0x0                ; =0
10023f0b8:     	mov	x8, #0x0                ; =0
10023f0bc:     	ldp	q0, q1, [x10]
10023f0c0:     	stp	q0, q1, [x28, #0x10]
10023f0c4:     	mov	w10, #0xc00             ; =3072
10023f0c8:     	ldr	x11, [sp, #0x168]
10023f0cc:     	madd	x10, x11, x10, x23
10023f0d0:     	add	x11, x10, #0xf8, lsl #12 ; =0xf8000
10023f0d4:     	ldr	x10, [x11, #0x1d30]
10023f0d8:     	str	x10, [sp, #0x3108]
10023f0dc:     	b	0x10023f0ec <_main.timed__anon_62765+0x5dc>
10023f0e0:     	add	x8, x8, #0x1
10023f0e4:     	cmp	x8, #0x100
10023f0e8:     	b.eq	0x10023f138 <_main.timed__anon_62765+0x628>
10023f0ec:     	ldr	x10, [x24, x8, lsl #3]
10023f0f0:     	cbz	x10, 0x10023f0e0 <_main.timed__anon_62765+0x5d0>
10023f0f4:     	ldr	x11, [x10, #0x28]
10023f0f8:     	cmp	x11, x27
10023f0fc:     	b.ne	0x10023f0e0 <_main.timed__anon_62765+0x5d0>
10023f100:     	ldr	x11, [sp, #0x28]
10023f104:     	mov	w12, #0x18              ; =24
10023f108:     	madd	x9, x9, x12, x11
10023f10c:     	ldr	x11, [x10, #0x10]
10023f110:     	ldr	x12, [x10, #0xb8]
10023f114:     	stp	x11, x12, [x9]
10023f118:     	ldr	w10, [x10, #0x50]
10023f11c:     	str	w10, [x9, #0x10]
10023f120:     	ldrb	w9, [x28, #0x640]
10023f124:     	add	x9, x9, #0x1
10023f128:     	strb	w9, [x28, #0x640]
10023f12c:     	cmp	x8, #0xff
10023f130:     	add	x8, x8, #0x1
10023f134:     	b.lo	0x10023f0ec <_main.timed__anon_62765+0x5dc>
10023f138:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
10023f13c:     	add	x1, x1, #0xd8
10023f140:     	ldr	x0, [sp, #0x158]
10023f144:     	mov	w2, #0x648              ; =1608
10023f148:     	bl	0x1004b6c5c <_memcpy>
10023f14c:     	ldp	x8, x9, [sp, #0xc8]
10023f150:     	str	x9, [sp, #0xac0]
10023f154:     	str	x8, [sp, #0xac8]
10023f158:     	ldr	x8, [sp, #0xc0]
10023f15c:     	str	x8, [sp, #0xad0]
10023f160:     	ldr	x8, [sp, #0x138]
10023f164:     	str	x8, [sp, #0xad8]
10023f168:     	ldr	x8, [sp, #0x150]
10023f16c:     	str	x8, [sp, #0xae0]
10023f170:     	ldp	x8, x9, [sp, #0x128]
10023f174:     	str	x9, [sp, #0xae8]
10023f178:     	str	x8, [sp, #0xaf0]
10023f17c:     	ldp	x8, x9, [sp, #0x118]
10023f180:     	str	x9, [sp, #0xaf8]
10023f184:     	str	x8, [sp, #0xb00]
10023f188:     	ldp	x8, x9, [sp, #0x108]
10023f18c:     	str	x9, [sp, #0xb08]
10023f190:     	str	x8, [sp, #0xb10]
10023f194:     	ldp	x8, x9, [sp, #0xf8]
10023f198:     	str	x9, [sp, #0xb18]
10023f19c:     	str	x8, [sp, #0xb20]
10023f1a0:     	str	x26, [sp, #0xb28]
10023f1a4:     	ldp	x8, x9, [sp, #0xe8]
10023f1a8:     	str	x9, [sp, #0xb30]
10023f1ac:     	str	x8, [sp, #0xb38]
10023f1b0:     	ldr	x8, [sp, #0x140]
10023f1b4:     	str	x8, [sp, #0xb40]
10023f1b8:     	ldp	x8, x9, [sp, #0xd8]
10023f1bc:     	str	x9, [sp, #0xb48]
10023f1c0:     	str	x8, [sp, #0xb50]
10023f1c4:     	ldr	x8, [sp, #0x88]
10023f1c8:     	str	x8, [sp, #0xb58]
10023f1cc:     	ldr	x8, [sp, #0x148]
10023f1d0:     	str	x8, [sp, #0xb60]
10023f1d4:     	ldr	x8, [sp, #0x68]
10023f1d8:     	str	x8, [sp, #0xb68]
10023f1dc:     	ldp	x8, x9, [sp, #0xb0]
10023f1e0:     	str	x9, [sp, #0xb70]
10023f1e4:     	str	x8, [sp, #0xb78]
10023f1e8:     	ldp	x8, x9, [sp, #0xa0]
10023f1ec:     	str	x9, [sp, #0xb80]
10023f1f0:     	str	x8, [sp, #0xb88]
10023f1f4:     	ldp	x8, x9, [sp, #0x90]
10023f1f8:     	str	x9, [sp, #0xb90]
10023f1fc:     	str	x8, [sp, #0xb98]
10023f200:     	add	x21, sp, #0xac0
10023f204:     	stp	xzr, xzr, [x21, #0xe8]
10023f208:     	ldr	x8, [sp, #0x70]
10023f20c:     	str	x8, [sp, #0xba0]
10023f210:     	ldr	x8, [sp, #0x180]
10023f214:     	str	x8, [sp, #0xbb8]
10023f218:     	stp	xzr, xzr, [x21, #0x100]
10023f21c:     	add	x0, x21, #0x110
10023f220:     	add	x1, sp, #0x298
10023f224:     	mov	w2, #0x828              ; =2088
10023f228:     	bl	0x1004b6c5c <_memcpy>
10023f22c:     	strb	wzr, [x21, #0xf80]
10023f230:     	add	x0, sp, #0x2, lsl #12   ; =0x2000
10023f234:     	add	x0, x0, #0x280
10023f238:     	add	x1, x21, #0x130
10023f23c:     	mov	w2, #0xe58              ; =3672
10023f240:     	bl	0x1004b6c5c <_memcpy>
10023f244:     	ldrb	w8, [x20, #0xf98]
10023f248:     	cbnz	w8, 0x10023f754 <_main.timed__anon_62765+0xc44>
10023f24c:     	add	x0, sp, #0xac0
10023f250:     	mov	w8, #0x4f38             ; =20280
10023f254:     	movk	w8, #0x27, lsl #16
10023f258:     	add	x1, x22, x8
10023f25c:     	bl	0x100287b8c <_meta.eql__anon_78340>
10023f260:     	tbz	w0, #0x0, 0x10023f75c <_main.timed__anon_62765+0xc4c>
10023f264:     	ldr	x21, [x20]
10023f268:     	cmn	x21, #0x1
10023f26c:     	b.eq	0x10023f764 <_main.timed__anon_62765+0xc54>
10023f270:     	add	x27, sp, #0x2, lsl #12  ; =0x2000
10023f274:     	add	x27, x27, #0x280
10023f278:     	ldrb	w23, [x27, #0x800]
10023f27c:     	cmp	x23, #0x41
10023f280:     	b.hs	0x10023f76c <_main.timed__anon_62765+0xc5c>
10023f284:     	add	x8, x21, #0x1
10023f288:     	str	x8, [x20]
10023f28c:     	mov	w8, #0x5048             ; =20552
10023f290:     	movk	w8, #0x27, lsl #16
10023f294:     	add	x0, x22, x8
10023f298:     	add	x1, sp, #0xac0
10023f29c:     	mov	w2, #0x110              ; =272
10023f2a0:     	bl	0x1004b6c5c <_memcpy>
10023f2a4:     	strb	wzr, [x20, #0xfa0]
10023f2a8:     	mov	w8, #0x1                ; =1
10023f2ac:     	strb	w8, [x20, #0xf98]
10023f2b0:     	str	x21, [x20, #0x8]
10023f2b4:     	mov	w8, #0x58c8             ; =22728
10023f2b8:     	movk	w8, #0x27, lsl #16
10023f2bc:     	add	x0, x22, x8
10023f2c0:     	add	x1, sp, #0xac0
10023f2c4:     	mov	w2, #0x110              ; =272
10023f2c8:     	bl	0x1004b6c5c <_memcpy>
10023f2cc:     	mov	w8, #0x6020             ; =24608
10023f2d0:     	movk	w8, #0x27, lsl #16
10023f2d4:     	add	x25, x22, x8
10023f2d8:     	ldrb	w8, [x27, #0xe50]
10023f2dc:     	strb	w8, [x20, #0xf90]
10023f2e0:     	ldr	x8, [sp, #0x158]
10023f2e4:     	ldr	q0, [x8]
10023f2e8:     	mov	w8, #0x59d8             ; =23000
10023f2ec:     	movk	w8, #0x27, lsl #16
10023f2f0:     	str	q0, [x22, x8]
10023f2f4:     	mov	w8, #0x59e8             ; =23016
10023f2f8:     	movk	w8, #0x27, lsl #16
10023f2fc:     	add	x8, x22, x8
10023f300:     	ldr	x9, [sp, #0x30]
10023f304:     	ldp	q0, q1, [x9]
10023f308:     	stp	q0, q1, [x8]
10023f30c:     	ldr	x8, [sp, #0x2ab8]
10023f310:     	str	x8, [x20, #0x150]
10023f314:     	ldr	x8, [sp, #0x30c0]
10023f318:     	str	x8, [x20, #0x758]
10023f31c:     	ldrb	w8, [x27, #0xe48]
10023f320:     	strb	w8, [x20, #0x760]
10023f324:     	add	x8, x8, x8, lsl #1
10023f328:     	lsl	x2, x8, #3
10023f32c:     	mov	w8, #0x5a10             ; =23056
10023f330:     	movk	w8, #0x27, lsl #16
10023f334:     	add	x0, x22, x8
10023f338:     	add	x1, x27, #0x840
10023f33c:     	bl	0x1004b6c5c <_memcpy>
10023f340:     	add	x8, sp, #0x199
10023f344:     	ldur	q0, [x8, #0xff]
10023f348:     	add	x8, sp, #0x1a9
10023f34c:     	ldur	q1, [x8, #0xff]
10023f350:     	stp	q0, q1, [x25]
10023f354:     	strb	w23, [x20, #0xf88]
10023f358:     	lsl	x2, x23, #5
10023f35c:     	mov	w23, #0x6040            ; =24640
10023f360:     	movk	w23, #0x27, lsl #16
10023f364:     	add	x0, x22, x23
10023f368:     	add	x1, sp, #0x2, lsl #12   ; =0x2000
10023f36c:     	add	x1, x1, #0x280
10023f370:     	bl	0x1004b6c5c <_memcpy>
10023f374:     	ldr	x25, [sp, #0x170]
10023f378:     	ldr	x20, [x25, #0x20]
10023f37c:     	mov	w8, #0x6840             ; =26688
10023f380:     	movk	w8, #0x27, lsl #16
10023f384:     	add	x22, x20, x8
10023f388:     	ldrb	w8, [x22, #0x10]
10023f38c:     	cbz	w8, 0x10023f744 <_main.timed__anon_62765+0xc34>
10023f390:     	add	x8, x20, #0x270, lsl #12 ; =0x270000
10023f394:     	ldr	x8, [x8, #0x58c0]
10023f398:     	cmp	x8, x21
10023f39c:     	b.ne	0x10023f744 <_main.timed__anon_62765+0xc34>
10023f3a0:     	mov	w8, #0x5298             ; =21144
10023f3a4:     	movk	w8, #0x27, lsl #16
10023f3a8:     	add	x21, x20, x8
10023f3ac:     	mov	w8, #0x5158             ; =20824
10023f3b0:     	movk	w8, #0x27, lsl #16
10023f3b4:     	add	x0, x20, x8
10023f3b8:     	mov	w8, #0x58c8             ; =22728
10023f3bc:     	movk	w8, #0x27, lsl #16
10023f3c0:     	add	x1, x20, x8
10023f3c4:     	mov	w2, #0x110              ; =272
10023f3c8:     	bl	0x1004b6c5c <_memcpy>
10023f3cc:     	ldrb	w8, [x21, #0x618]
10023f3d0:     	cbnz	w8, 0x10023f3ec <_main.timed__anon_62765+0x8dc>
10023f3d4:     	mov	w8, #0x52a0             ; =21152
10023f3d8:     	movk	w8, #0x27, lsl #16
10023f3dc:     	add	x0, x20, x8
10023f3e0:     	mov	w1, #0x1                ; =1
10023f3e4:     	mov	w2, #0x618              ; =1560
10023f3e8:     	bl	0x1004b67f8 <_memset>
10023f3ec:     	mov	w8, #0x59d8             ; =23000
10023f3f0:     	movk	w8, #0x27, lsl #16
10023f3f4:     	ldr	q0, [x20, x8]
10023f3f8:     	mov	w8, #0x5268             ; =21096
10023f3fc:     	movk	w8, #0x27, lsl #16
10023f400:     	str	q0, [x20, x8]
10023f404:     	mov	w8, #0x5278             ; =21112
10023f408:     	movk	w8, #0x27, lsl #16
10023f40c:     	add	x8, x20, x8
10023f410:     	mov	w9, #0x59e8             ; =23016
10023f414:     	movk	w9, #0x27, lsl #16
10023f418:     	add	x9, x20, x9
10023f41c:     	ldp	q0, q1, [x9]
10023f420:     	stp	q0, q1, [x8]
10023f424:     	ldr	x8, [x21, #0x770]
10023f428:     	str	x8, [x21]
10023f42c:     	ldr	x8, [x21, #0xd78]
10023f430:     	str	x8, [x21, #0x608]
10023f434:     	ldrb	w8, [x21, #0xd80]
10023f438:     	strb	w8, [x21, #0x610]
10023f43c:     	add	x8, x8, x8, lsl #1
10023f440:     	lsl	x2, x8, #3
10023f444:     	mov	w8, #0x52a0             ; =21152
10023f448:     	movk	w8, #0x27, lsl #16
10023f44c:     	add	x0, x20, x8
10023f450:     	mov	w8, #0x5a10             ; =23056
10023f454:     	movk	w8, #0x27, lsl #16
10023f458:     	add	x1, x20, x8
10023f45c:     	bl	0x1004b6c5c <_memcpy>
10023f460:     	mov	w8, #0x6020             ; =24608
10023f464:     	movk	w8, #0x27, lsl #16
10023f468:     	add	x8, x20, x8
10023f46c:     	ldrb	w9, [x22, #0x8]
10023f470:     	strb	w9, [x28, #0x808]
10023f474:     	ldp	q0, q1, [x8]
10023f478:     	add	x21, sp, #0x2, lsl #12  ; =0x2000
10023f47c:     	stp	q0, q1, [x21, #0x280]!
10023f480:     	ldrb	w8, [x22]
10023f484:     	strb	w8, [x28, #0x800]
10023f488:     	lsl	x2, x8, #5
10023f48c:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
10023f490:     	add	x0, x0, #0xd8
10023f494:     	add	x1, x20, x23
10023f498:     	bl	0x1004b6c5c <_memcpy>
10023f49c:     	mov	w8, #0x58c0             ; =22720
10023f4a0:     	movk	w8, #0x27, lsl #16
10023f4a4:     	add	x0, x20, x8
10023f4a8:     	mov	w1, #0xf98              ; =3992
10023f4ac:     	bl	0x1004bc474 <dyld_stub_binder+0x1004bc474>
10023f4b0:     	add	x1, sp, #0x3, lsl #12   ; =0x3000
10023f4b4:     	add	x1, x1, #0xd8
10023f4b8:     	ldr	x0, [sp, #0x50]
10023f4bc:     	mov	w2, #0x810              ; =2064
10023f4c0:     	bl	0x1004b6c5c <_memcpy>
10023f4c4:     	add	x0, sp, #0x1, lsl #12   ; =0x1000
10023f4c8:     	add	x0, x0, #0xa50
10023f4cc:     	add	x1, sp, #0x2, lsl #12   ; =0x2000
10023f4d0:     	add	x1, x1, #0x280
10023f4d4:     	mov	w2, #0x830              ; =2096
10023f4d8:     	bl	0x1004b6c5c <_memcpy>
10023f4dc:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
10023f4e0:     	add	x0, x0, #0xd8
10023f4e4:     	add	x1, sp, #0x1, lsl #12   ; =0x1000
10023f4e8:     	add	x1, x1, #0xa50
10023f4ec:     	mov	w2, #0x828              ; =2088
10023f4f0:     	bl	0x1004b6c5c <_memcpy>
10023f4f4:     	ldrb	w8, [x28, #0x18]
10023f4f8:     	cbz	w8, 0x10023f538 <_main.timed__anon_62765+0xa28>
10023f4fc:     	ldr	x8, [sp, #0x48]
10023f500:     	ldr	x8, [x8]
10023f504:     	mov	w22, #0xffff            ; =65535
10023f508:     	cbz	x8, 0x10023f53c <_main.timed__anon_62765+0xa2c>
10023f50c:     	ldrb	w10, [x28, #0x8]
10023f510:     	ldr	x9, [sp, #0x30d8]
10023f514:     	ldr	x20, [sp, #0x30e8]
10023f518:     	ldr	x23, [sp, #0x160]
10023f51c:     	ldr	x11, [x19]
10023f520:     	cmp	x11, x20
10023f524:     	b.eq	0x10023f55c <_main.timed__anon_62765+0xa4c>
10023f528:     	add	x19, x19, #0x18
10023f52c:     	subs	x8, x8, #0x1
10023f530:     	b.ne	0x10023f51c <_main.timed__anon_62765+0xa0c>
10023f534:     	b	0x10023f53c <_main.timed__anon_62765+0xa2c>
10023f538:     	mov	x8, #0x0                ; =0
10023f53c:     	ldr	x19, [sp, #0x60]
10023f540:     	add	x19, x8, x19
10023f544:     	ldr	x9, [sp, #0x58]
10023f548:     	add	x9, x9, #0x1
10023f54c:     	ldr	x8, [sp, #0x38]
10023f550:     	cmp	x9, x8
10023f554:     	b.ne	0x10023ebac <_main.timed__anon_62765+0x9c>
10023f558:     	b	0x10023f714 <_main.timed__anon_62765+0xc04>
10023f55c:     	mov	x8, #0x0                ; =0
10023f560:     	ldurb	w11, [x19, #-0x8]
10023f564:     	eor	w10, w11, w10
10023f568:     	tbnz	w10, #0x0, 0x10023f53c <_main.timed__anon_62765+0xa2c>
10023f56c:     	ldur	x10, [x19, #-0x10]
10023f570:     	cmp	x10, x9
10023f574:     	ldr	x19, [sp, #0x60]
10023f578:     	b.ne	0x10023f540 <_main.timed__anon_62765+0xa30>
10023f57c:     	add	x0, sp, #0x3, lsl #12   ; =0x3000
10023f580:     	add	x0, x0, #0x900
10023f584:     	mov	x1, x24
10023f588:     	mov	w2, #0x800              ; =2048
10023f58c:     	bl	0x1004b6c5c <_memcpy>
10023f590:     	mov	x9, #0x0                ; =0
10023f594:     	mov	x8, #0x0                ; =0
10023f598:     	add	x11, sp, #0x3, lsl #12  ; =0x3000
10023f59c:     	add	x11, x11, #0x900
10023f5a0:     	b	0x10023f5b0 <_main.timed__anon_62765+0xaa0>
10023f5a4:     	add	x9, x9, #0x8
10023f5a8:     	cmp	x9, #0x800
10023f5ac:     	b.eq	0x10023f5c8 <_main.timed__anon_62765+0xab8>
10023f5b0:     	ldr	x10, [x11, x9]
10023f5b4:     	cbz	x10, 0x10023f5a4 <_main.timed__anon_62765+0xa94>
10023f5b8:     	ldr	x10, [x10, #0x28]
10023f5bc:     	cmp	x10, x20
10023f5c0:     	cinc	x8, x8, eq
10023f5c4:     	b	0x10023f5a4 <_main.timed__anon_62765+0xa94>
10023f5c8:     	cbz	x8, 0x10023f540 <_main.timed__anon_62765+0xa30>
10023f5cc:     	strb	wzr, [x21, #0x820]
10023f5d0:     	ldrb	w9, [x28, #0x820]
10023f5d4:     	cbz	x9, 0x10023f5fc <_main.timed__anon_62765+0xaec>
10023f5d8:     	mov	x8, #0x0                ; =0
10023f5dc:     	mov	x10, #0x0               ; =0
10023f5e0:     	mov	w11, #0xc850            ; =51280
10023f5e4:     	movk	w11, #0x12, lsl #16
10023f5e8:     	add	x11, x23, x11
10023f5ec:     	mov	w12, #0xd850            ; =55376
10023f5f0:     	movk	w12, #0x12, lsl #16
10023f5f4:     	add	x12, x23, x12
10023f5f8:     	b	0x10023f644 <_main.timed__anon_62765+0xb34>
10023f5fc:     	mov	x8, #0x0                ; =0
10023f600:     	b	0x10023f540 <_main.timed__anon_62765+0xa30>
10023f604:     	str	xzr, [x0, #0xc8]
10023f608:     	ldr	x0, [sp, #0x50]
10023f60c:     	add	x8, x0, x8, lsl #5
10023f610:     	stp	x14, x15, [x8]
10023f614:     	str	x16, [x8, #0x10]
10023f618:     	strb	w17, [x8, #0x18]
10023f61c:     	ldur	w14, [x13, #0x19]
10023f620:     	stur	w14, [x8, #0x19]
10023f624:     	ldur	w13, [x13, #0x1c]
10023f628:     	str	w13, [x8, #0x1c]
10023f62c:     	ldrb	w8, [x21, #0x820]
10023f630:     	add	x8, x8, #0x1
10023f634:     	strb	w8, [x21, #0x820]
10023f638:     	add	x10, x10, #0x1
10023f63c:     	cmp	x10, x9
10023f640:     	b.eq	0x10023f540 <_main.timed__anon_62765+0xa30>
10023f644:     	ldr	x13, [sp, #0x40]
10023f648:     	add	x13, x13, x10, lsl #5
10023f64c:     	ldr	x14, [x13]
10023f650:     	cbz	x14, 0x10023f638 <_main.timed__anon_62765+0xb28>
10023f654:     	ldp	x15, x16, [x13, #0x8]
10023f658:     	ldrb	w17, [x13, #0x18]
10023f65c:     	eor	x0, x14, x14, lsr #32
10023f660:     	mov	x1, #0x556d             ; =21869
10023f664:     	movk	x1, #0xeb34, lsl #16
10023f668:     	movk	x1, #0x25f9, lsl #32
10023f66c:     	movk	x1, #0xbea2, lsl #48
10023f670:     	mul	x0, x0, x1
10023f674:     	eor	x0, x0, x0, lsr #29
10023f678:     	mul	x0, x0, x1
10023f67c:     	eor	x0, x0, x0, lsr #32
10023f680:     	mul	x0, x0, x1
10023f684:     	eor	x1, x0, x0, lsr #29
10023f688:     	mov	w0, #0x200              ; =512
10023f68c:     	and	x1, x1, #0x1ff
10023f690:     	ldr	x2, [x11, x1, lsl #3]
10023f694:     	cmp	x2, x14
10023f698:     	b.eq	0x10023f6b0 <_main.timed__anon_62765+0xba0>
10023f69c:     	cbz	x2, 0x10023f638 <_main.timed__anon_62765+0xb28>
10023f6a0:     	add	x1, x1, #0x1
10023f6a4:     	subs	x0, x0, #0x1
10023f6a8:     	b.ne	0x10023f68c <_main.timed__anon_62765+0xb7c>
10023f6ac:     	b	0x10023f638 <_main.timed__anon_62765+0xb28>
10023f6b0:     	ldrb	w0, [x12, x1]
10023f6b4:     	ldr	x0, [x24, x0, lsl #3]
10023f6b8:     	cbz	x0, 0x10023f638 <_main.timed__anon_62765+0xb28>
10023f6bc:     	ldr	x1, [x0, #0x28]
10023f6c0:     	cmp	x1, x20
10023f6c4:     	b.ne	0x10023f638 <_main.timed__anon_62765+0xb28>
10023f6c8:     	and	w1, w17, #0x1
10023f6cc:     	ldrb	w2, [x0, #0x106]
10023f6d0:     	cmp	w2, w1
10023f6d4:     	b.ne	0x10023f638 <_main.timed__anon_62765+0xb28>
10023f6d8:     	ldr	x1, [x0, #0xb8]
10023f6dc:     	cmp	x1, x16
10023f6e0:     	b.ne	0x10023f638 <_main.timed__anon_62765+0xb28>
10023f6e4:     	ldr	x1, [x0, #0xc8]
10023f6e8:     	cmp	x1, x15
10023f6ec:     	b.ne	0x10023f608 <_main.timed__anon_62765+0xaf8>
10023f6f0:     	ldr	x1, [x0, #0xb0]
10023f6f4:     	cbz	x1, 0x10023f604 <_main.timed__anon_62765+0xaf4>
10023f6f8:     	mov	x2, #0x0                ; =0
10023f6fc:     	ldr	x3, [x0, #0xa8]
10023f700:     	str	w22, [x3, x2, lsl #2]
10023f704:     	add	x2, x2, #0x1
10023f708:     	cmp	x2, x1
10023f70c:     	b.lo	0x10023f700 <_main.timed__anon_62765+0xbf0>
10023f710:     	b	0x10023f604 <_main.timed__anon_62765+0xaf4>
10023f714:     	ldp	x8, x0, [sp, #0x10]
10023f718:     	ldr	x9, [x8, #0x2c0]
10023f71c:     	add	x8, sp, #0xac0
10023f720:     	mov	w1, #0x1                ; =1
10023f724:     	blr	x9
10023f728:     	ldr	x8, [sp, #0xac0]
10023f72c:     	ldr	x9, [sp, #0x8]
10023f730:     	sub	x8, x8, x9
10023f734:     	ldr	x9, [sp, #0x20]
10023f738:     	strh	wzr, [x9, #0x8]
10023f73c:     	str	x8, [x9]
10023f740:     	b	0x10023f778 <_main.timed__anon_62765+0xc68>
10023f744:     	mov	w8, #0x267              ; =615
10023f748:     	b	0x10023f770 <_main.timed__anon_62765+0xc60>
10023f74c:     	mov	w8, #0x1b8              ; =440
10023f750:     	b	0x10023f770 <_main.timed__anon_62765+0xc60>
10023f754:     	mov	w8, #0x263              ; =611
10023f758:     	b	0x10023f770 <_main.timed__anon_62765+0xc60>
10023f75c:     	mov	w8, #0x264              ; =612
10023f760:     	b	0x10023f770 <_main.timed__anon_62765+0xc60>
10023f764:     	mov	w8, #0x265              ; =613
10023f768:     	b	0x10023f770 <_main.timed__anon_62765+0xc60>
10023f76c:     	mov	w8, #0x266              ; =614
10023f770:     	ldr	x9, [sp, #0x20]
10023f774:     	strh	w8, [x9, #0x8]
10023f778:     	add	sp, sp, #0x4, lsl #12   ; =0x4000
10023f77c:     	add	sp, sp, #0x110
10023f780:     	ldp	x29, x30, [sp, #0x50]
10023f784:     	ldp	x20, x19, [sp, #0x40]
10023f788:     	ldp	x22, x21, [sp, #0x30]
10023f78c:     	ldp	x24, x23, [sp, #0x20]
10023f790:     	ldp	x26, x25, [sp, #0x10]
10023f794:     	ldp	x28, x27, [sp], #0x60
10023f798:     	ret

sub	sp, sp, #0x170
stp	x28, x27, [sp, #0x110]
stp	x26, x25, [sp, #0x120]
stp	x24, x23, [sp, #0x130]
stp	x22, x21, [sp, #0x140]
stp	x20, x19, [sp, #0x150]
stp	x29, x30, [sp, #0x160]
add	x29, sp, #0x160
mov	x19, x0
ldr	x8, [x0, #0x38]
add	x8, x8, #0x1
str	x8, [x0, #0x38]
add	x21, x0, #0x58
bl	<dyld_stub_binder>
mov	x20, x0
mov	x23, #0x0               ; =0
ldr	x22, [x19, #0x38]
adrp x25, RELOC_PAGE
add	x25, x25, #RELOC_OFFSET
stp	x25, x21, [sp, #0x90]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [sp, #0xa0]
adrp x24, RELOC_PAGE
add	x24, x24, #RELOC_OFFSET
mov	w26, #0x9               ; =9
add	x1, x24, x23
ldp	x9, x8, [sp, #0xa0]
sub	x21, x26, x23
add	x10, x8, x21
cmp	x10, x9
b.hi	<_SharedFrameContext.publish>
ldr	x9, [sp, #0x98]
add	x0, x9, x8
mov	x2, x21
bl	<_memcpy>
ldr	x8, [sp, #0xa8]
add	x8, x8, x21
str	x8, [sp, #0xa8]
add	x23, x21, x23
cmp	x23, #0x9
b.lo	<_SharedFrameContext.publish>
b	<_SharedFrameContext.publish>
ldr	x8, [sp, #0x90]
ldr	x9, [x8]
stp	x1, x21, [x29, #-0x68]
add	x8, sp, #0xb0
add	x0, sp, #0x90
sub	x1, x29, #0x68
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w8, [sp, #0xb8]
cbnz	w8, <_SharedFrameContext.publish>
ldr	x21, [sp, #0xb0]
add	x23, x21, x23
cmp	x23, #0x9
b.lo	<_SharedFrameContext.publish>
mov	x8, #0x0                ; =0
mov	w9, w20
add	x10, sp, #0xb0
and	x11, x9, #0xf
add	x12, x10, x8
orr	w13, w11, #0x30
add	w14, w11, #0x57
cmp	x11, #0xa
csel	w11, w13, w14, lo
strb	w11, [x12, #0x40]
sub	x8, x8, #0x1
cmp	x9, #0xf
lsr	x9, x9, #4
b.hi	<_SharedFrameContext.publish>
add	x9, sp, #0xb0
add	x9, x9, x8
neg	x2, x8
adrp x8, RELOC_PAGE
ldrb	w21, [x8, #RELOC_OFFSET]
add	x0, sp, #0x90
add	x1, x9, #0x41
mov	x3, x2
mov	x4, x21
mov	w5, #0x20               ; =32
bl	<_Io.Writer.alignBuffer>
tst	w0, #0xffff
b.ne	<_SharedFrameContext.publish>
adrp x20, RELOC_PAGE
add	x20, x20, #RELOC_OFFSET
mov	w23, #0x1               ; =1
ldp	x9, x8, [sp, #0xa0]
cmp	x8, x9
b.lo	<_SharedFrameContext.publish>
ldr	x8, [sp, #0x90]
ldr	x9, [x8]
stp	x20, x23, [x29, #-0x68]
add	x8, sp, #0xb0
add	x0, sp, #0x90
sub	x1, x29, #0x68
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w8, [sp, #0xb8]
cbnz	w8, <_SharedFrameContext.publish>
ldr	x8, [sp, #0xb0]
cbz	x8, <_SharedFrameContext.publish>
b	<_SharedFrameContext.publish>
ldr	x9, [sp, #0x98]
mov	w10, #0x2d              ; =45
strb	w10, [x9, x8]
ldr	x8, [sp, #0xa8]
add	x8, x8, #0x1
str	x8, [sp, #0xa8]
mov	x8, #0x0                ; =0
add	x9, sp, #0xb0
and	x10, x22, #0xf
add	x11, x9, x8
orr	w12, w10, #0x30
add	w13, w10, #0x57
cmp	x10, #0xa
csel	w10, w12, w13, lo
strb	w10, [x11, #0x40]
sub	x8, x8, #0x1
cmp	x22, #0xf
lsr	x22, x22, #4
b.hi	<_SharedFrameContext.publish>
add	x9, sp, #0xb0
add	x9, x9, x8
neg	x2, x8
add	x0, sp, #0x90
add	x1, x9, #0x41
mov	x3, x2
mov	x4, x21
mov	w5, #0x20               ; =32
bl	<_Io.Writer.alignBuffer>
tst	w0, #0xffff
b.ne	<_SharedFrameContext.publish>
adrp x20, RELOC_PAGE
add	x20, x20, #RELOC_OFFSET
mov	w22, #0x1               ; =1
ldp	x9, x8, [sp, #0xa0]
cmp	x8, x9
b.lo	<_SharedFrameContext.publish>
ldr	x8, [sp, #0x90]
ldr	x9, [x8]
stp	x20, x22, [x29, #-0x68]
add	x8, sp, #0xb0
add	x0, sp, #0x90
sub	x1, x29, #0x68
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w8, [sp, #0xb8]
cbnz	w8, <_SharedFrameContext.publish>
ldr	x8, [sp, #0xb0]
cbz	x8, <_SharedFrameContext.publish>
ldr	x8, [sp, #0xa8]
sub	x23, x8, #0x1
b	<_SharedFrameContext.publish>
ldr	x9, [sp, #0x98]
strb	wzr, [x9, x8]
ldr	x23, [sp, #0xa8]
ldr	x24, [sp, #0x98]
str	x23, [x19, #0x40]
mov	w8, #0x180              ; =384
str	x8, [sp]
mov	x0, x24
mov	w1, #0xa02              ; =2562
bl	<dyld_stub_binder>
mov	x20, x0
cmn	w0, #0x1
b.eq	<_SharedFrameContext.publish>
mov	x0, x20
mov	w1, #0x4000             ; =16384
movk	w1, #0x1fa, lsl #16
bl	<dyld_stub_binder>
cbz	w0, <_SharedFrameContext.publish>
mov	x0, x20
bl	<dyld_stub_binder>
mov	w0, #0x420              ; =1056
b	<_SharedFrameContext.publish>
bl	<dyld_stub_binder>
ldr	w8, [x0]
cbz	w8, <_SharedFrameContext.publish>
mov	w0, #0x420              ; =1056
b	<_SharedFrameContext.publish>
mov	x0, #0x0                ; =0
mov	w1, #0x4000             ; =16384
movk	w1, #0x1fa, lsl #16
mov	w2, #0x3                ; =3
mov	w3, #0x1                ; =1
mov	x4, x20
mov	x5, #0x0                ; =0
bl	<dyld_stub_binder>
cmn	x0, #0x1
b.eq	<_SharedFrameContext.publish>
mov	x22, x0
ldr	x1, [x19, #0x20]
mov	w2, #0x4000             ; =16384
movk	w2, #0x1fa, lsl #16
bl	<_memcpy>
add	x8, x23, #0x2
mov	x9, #-0x5555555555555556 ; =-6148914691236517206
movk	x9, #0xaaab
umulh	x8, x8, x9
lsl	x8, x8, #1
adrp x0, RELOC_PAGE
add	x0, x0, #RELOC_OFFSET
add	x1, sp, #0x10
and	x2, x8, #0xfffffffffffffffc
mov	x3, x24
mov	x4, x23
bl	<_base64.Base64Encoder.encode>
mov	x24, x0
mov	x23, x1
mov	x26, #0x0               ; =0
add	x8, x19, #0x98
stp	x25, x8, [sp, #0xb0]
adrp x8, RELOC_PAGE
ldr	q0, [x8, #RELOC_OFFSET]
str	q0, [sp, #0xc0]
adrp x27, RELOC_PAGE
add	x27, x27, #RELOC_OFFSET
mov	w28, #0x39              ; =57
add	x1, x27, x26
ldp	x9, x8, [sp, #0xc0]
sub	x25, x28, x26
add	x10, x8, x25
cmp	x10, x9
b.hi	<_SharedFrameContext.publish>
ldr	x9, [sp, #0xb8]
add	x0, x9, x8
mov	x2, x25
bl	<_memcpy>
ldr	x8, [sp, #0xc8]
add	x8, x8, x25
str	x8, [sp, #0xc8]
add	x26, x25, x26
cmp	x26, #0x39
b.lo	<_SharedFrameContext.publish>
b	<_SharedFrameContext.publish>
ldr	x8, [sp, #0xb0]
ldr	x9, [x8]
stp	x1, x25, [x29, #-0x68]
add	x8, sp, #0x90
add	x0, sp, #0xb0
sub	x1, x29, #0x68
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w8, [sp, #0x98]
cbnz	w8, <_SharedFrameContext.publish>
ldr	x25, [sp, #0x90]
add	x26, x25, x26
cmp	x26, #0x39
b.lo	<_SharedFrameContext.publish>
add	x0, sp, #0xb0
mov	x1, x24
mov	x2, x23
mov	x3, x23
mov	x4, x21
mov	w5, #0x20               ; =32
bl	<_Io.Writer.alignBuffer>
tst	w0, #0xffff
b.ne	<_SharedFrameContext.publish>
mov	x23, #0x0               ; =0
adrp x24, RELOC_PAGE
add	x24, x24, #RELOC_OFFSET
mov	w25, #0xa               ; =10
add	x1, x24, x23
ldp	x9, x8, [sp, #0xc0]
sub	x21, x25, x23
add	x10, x8, x21
cmp	x10, x9
b.hi	<_SharedFrameContext.publish>
ldr	x9, [sp, #0xb8]
add	x0, x9, x8
mov	x2, x21
bl	<_memcpy>
ldr	x8, [sp, #0xc8]
add	x8, x8, x21
str	x8, [sp, #0xc8]
add	x23, x21, x23
cmp	x23, #0xa
b.lo	<_SharedFrameContext.publish>
b	<_SharedFrameContext.publish>
ldr	x8, [sp, #0xb0]
ldr	x9, [x8]
stp	x1, x21, [x29, #-0x68]
add	x8, sp, #0x90
add	x0, sp, #0xb0
sub	x1, x29, #0x68
mov	w2, #0x1                ; =1
mov	w3, #0x1                ; =1
blr	x9
ldrh	w8, [sp, #0x98]
cbnz	w8, <_SharedFrameContext.publish>
ldr	x21, [sp, #0x90]
add	x23, x21, x23
cmp	x23, #0xa
b.lo	<_SharedFrameContext.publish>
ldr	x8, [sp, #0xc8]
str	x8, [x19, #0x48]
mov	x0, x22
mov	w1, #0x4000             ; =16384
movk	w1, #0x1fa, lsl #16
bl	<dyld_stub_binder>
cmn	w0, #0x1
b.ne	<_SharedFrameContext.publish>
bl	<dyld_stub_binder>
mov	x0, x20
bl	<dyld_stub_binder>
mov	w0, #0x0                ; =0
b	<_SharedFrameContext.publish>
bl	<dyld_stub_binder>
ldr	w8, [x0]
mov	w19, #0x4               ; =4
cmp	w8, #0x12
b.le	<_SharedFrameContext.publish>
cmp	w8, #0x17
b.le	<_SharedFrameContext.publish>
cmp	w8, #0x18
b.eq	<_SharedFrameContext.publish>
cmp	w8, #0x23
b.eq	<_SharedFrameContext.publish>
cmp	w8, #0x1a
b.eq	<_SharedFrameContext.publish>
b	<_SharedFrameContext.publish>
cmp	w8, #0xc
b.gt	<_SharedFrameContext.publish>
mov	w9, #0x1                ; =1
mov	w10, #0x1a              ; =26
csel	w10, w10, w19, eq
cmp	w8, #0x1
csel	w19, w9, w10, eq
b	<_SharedFrameContext.publish>
cmp	w8, #0xd
b.eq	<_SharedFrameContext.publish>
mov	w9, #0x247              ; =583
cmp	w8, #0x11
csel	w19, w9, w19, eq
b	<_SharedFrameContext.publish>
mov	w9, #0x246              ; =582
mov	w10, #0xa5              ; =165
csel	w10, w10, w19, eq
cmp	w8, #0x13
csel	w19, w9, w10, eq
b	<_SharedFrameContext.publish>
mov	w19, #0xa               ; =10
b	<_SharedFrameContext.publish>
mov	w19, #0xa4              ; =164
b	<_SharedFrameContext.publish>
mov	w19, #0x21c             ; =540
mov	x0, x20
bl	<dyld_stub_binder>
mov	x0, x19
ldp	x29, x30, [sp, #0x160]
ldp	x20, x19, [sp, #0x150]
ldp	x22, x21, [sp, #0x140]
ldp	x24, x23, [sp, #0x130]
ldp	x26, x25, [sp, #0x120]
ldp	x28, x27, [sp, #0x110]
add	sp, sp, #0x170
ret
mov	x0, x22
mov	w1, #0x4000             ; =16384
movk	w1, #0x1fa, lsl #16
bl	<dyld_stub_binder>
cmn	w0, #0x1
b.ne	<_SharedFrameContext.publish>
bl	<dyld_stub_binder>
mov	x0, x20
bl	<dyld_stub_binder>
mov	w0, #0x8                ; =8
b	<_SharedFrameContext.publish>

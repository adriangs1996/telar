ldr	x9, [x1, #0x28]
adrp x8, RELOC_PAGE
ldrb	w8, [x8, #RELOC_OFFSET]
cbz	x9, <_damage.collectSpans__anon>
sub	sp, sp, #0xd0
stp	x28, x27, [sp, #0x70]
stp	x26, x25, [sp, #0x80]
stp	x24, x23, [sp, #0x90]
stp	x22, x21, [sp, #0xa0]
stp	x20, x19, [sp, #0xb0]
stp	x29, x30, [sp, #0xc0]
add	x29, sp, #0xc0
str	w8, [sp, #0x4]
str	x0, [sp, #0x8]
mov	x15, #0x0               ; =0
stp	xzr, xzr, [sp, #0x58]
mov	x12, #0x0               ; =0
mov	x13, #0x0               ; =0
mov	x16, #0x0               ; =0
ldr	x17, [x1]
ldr	x4, [x1, #0x10]
ldr	x10, [x1, #0x20]
ldr	x8, [x1, #0x30]
stp	x8, xzr, [sp, #0x48]
add	x14, x8, #0xe
add	x0, x17, #0x10
ldrh	w1, [x1, #0x38]
add	x22, x4, #0x10
add	x8, x17, #0x3e
stp	x9, x8, [sp, #0x18]
mov	w7, #0x18               ; =24
adrp x23, RELOC_PAGE
add	x23, x23, #RELOC_OFFSET
adrp x24, RELOC_PAGE
add	x24, x24, #RELOC_OFFSET
mov	x25, x1
stp	x0, x14, [sp, #0x38]
str	x10, [sp, #0x10]
b	<_damage.collectSpans__anon>
ldp	x13, x12, [sp, #0x28]
ldp	x10, x9, [sp, #0x10]
add	x15, x15, #0x1
add	x25, x25, x1
cmp	x15, x9
b.eq	<_damage.collectSpans__anon>
ldrb	w8, [x10, x15]
cmp	w8, #0x1
b.ne	<_damage.collectSpans__anon>
add	x13, x13, #0x1
add	x12, x12, x1
stp	x13, x12, [sp, #0x28]
mul	x28, x15, x1
add	x26, x28, x1
b	<_damage.collectSpans__anon>
add	x27, x28, #0x1
mov	x28, x27
cmp	x27, x26
b.hs	<_damage.collectSpans__anon>
lsl	x9, x28, #5
add	x30, x17, x9
add	x8, x4, x9
ldp	q1, q0, [x30]
ldp	q2, q3, [x8]
eor.16b	v2, v2, v1
eor.16b	v3, v3, v0
orr.16b	v2, v3, v2
umaxv.16b	b2, v2
fmov	w8, s2
cbz	w8, <_damage.collectSpans__anon>
mov	x27, x28
cmp	x28, x26
b.hs	<_damage.collectSpans__anon>
add	x8, x0, x9
add	x9, x22, x9
mov	x27, x28
ldp	q2, q3, [x8, #-0x10]
ldp	q4, q5, [x9, #-0x10]
eor.16b	v2, v4, v2
eor.16b	v3, v5, v3
orr.16b	v2, v3, v2
umaxv.16b	b2, v2
fmov	w10, s2
cbz	w10, <_damage.collectSpans__anon>
add	x8, x8, #0x20
add	x9, x9, #0x20
add	x27, x27, #0x1
cmp	x25, x27
b.ne	<_damage.collectSpans__anon>
mov	x27, x25
cbz	x16, <_damage.collectSpans__anon>
madd	x8, x16, x7, x2
ldur	w21, [x8, #-0x8]
ldur	x10, [x8, #-0x10]
add	x11, x10, x21
subs	x5, x28, x11
b.ne	<_damage.collectSpans__anon>
add	x9, x17, x21, lsl #5
sub	x10, x27, x21
stp	x9, x10, [x8, #-0x18]
b	<_damage.collectSpans__anon>
udiv	x9, x11, x1
udiv	x12, x28, x1
cmp	x9, x12
ccmp	x5, x14, #0x2, eq
b.hi	<_damage.collectSpans__anon>
add	x9, x17, x11, lsl #5
ldur	x12, [x8, #-0x18]
add	x10, x12, x10, lsl #5
ldurh	w12, [x10, #-0x20]
ldrh	w7, [x9]
ldur	w19, [x9, #0x2]
ldur	w0, [x9, #0x6]
ldur	w20, [x9, #0xa]
cmp	w12, w7
b.ne	<_damage.collectSpans__anon>
ldur	w12, [x10, #-0x1e]
cmp	w12, w19
b.ne	<_damage.collectSpans__anon>
ldur	w12, [x10, #-0x1a]
cmp	w12, w0
b.ne	<_damage.collectSpans__anon>
ldur	w10, [x10, #-0x16]
cmp	w10, w20
b.ne	<_damage.collectSpans__anon>
mov	x10, #0x0               ; =0
ldrb	w9, [x9, #0x1e]
add	x9, x9, x10
add	x14, x9, #0x1
cmp	x5, #0x1
b.eq	<_damage.collectSpans__anon>
b	<_damage.collectSpans__anon>
and	x10, x19, #0x3
ldr	x10, [x23, x10, lsl #3]
and	x12, x0, #0xff
ldr	x12, [x24, x12, lsl #3]
and	x13, x20, #0x3
ldr	x13, [x24, x13, lsl #3]
add	x10, x12, x10
add	x10, x10, x13
ldrb	w9, [x9, #0x1e]
add	x9, x9, x10
add	x14, x9, #0x1
cmp	x5, #0x1
b.ne	<_damage.collectSpans__anon>
fmov	x11, d1
ldurh	w9, [x30, #-0x20]
cmp	w9, w11, uxth
mov.d	x12, v1[1]
ubfx	x9, x11, #48, #8
ubfx	x10, x12, #16, #8
b.ne	<_damage.collectSpans__anon>
lsr	x13, x11, #16
ldur	w0, [x30, #-0x1e]
cmp	w0, w13
b.ne	<_damage.collectSpans__anon>
extr	x13, x12, x11, #0x30
ldur	w0, [x30, #-0x1a]
cmp	w0, w13
b.ne	<_damage.collectSpans__anon>
lsr	x13, x12, #16
ldur	w0, [x30, #-0x16]
cmp	w0, w13
b.ne	<_damage.collectSpans__anon>
mov	x13, #0x0               ; =0
b	<_damage.collectSpans__anon>
ubfx	x13, x11, #16, #8
ldr	x13, [x23, x13, lsl #3]
ldr	x0, [x24, x9, lsl #3]
ldr	x6, [x24, x10, lsl #3]
add	x13, x0, x13
add	x13, x13, x6
mov	w7, #0x18               ; =24
umov.b	w0, v0[14]
extr	x11, x12, x11, #0x10
add	w12, w0, #0x1
and	x11, x11, #0xff
ldr	x11, [x23, x11, lsl #3]
and	x12, x12, #0xff
ldr	x0, [x24, x9, lsl #3]
ldr	x10, [x24, x10, lsl #3]
add	x9, x14, x12
add	x9, x9, x13
ldp	x14, x13, [sp, #0x40]
add	x12, x13, x12
add	x12, x12, x0
add	x10, x12, x10
add	x10, x10, x11
cmp	x9, x10
ldr	x0, [sp, #0x38]
b.ls	<_damage.collectSpans__anon>
cmp	x16, x3
b.eq	<_damage.collectSpans__anon>
madd	x8, x16, x7, x2
str	w28, [x8, #0x10]
sub	x9, x27, x28
stp	x30, x9, [x8]
add	x16, x16, #0x1
b	<_damage.collectSpans__anon>
mvn	x9, x11
add	x10, x9, x28
ldr	x9, [sp, #0x20]
add	x11, x9, x11, lsl #5
b	<_damage.collectSpans__anon>
and	x0, x6, #0x3
ldr	x0, [x23, x0, lsl #3]
and	x7, x13, #0xff
ldr	x7, [x24, x7, lsl #3]
and	x19, x12, #0x3
ldr	x19, [x24, x19, lsl #3]
add	x0, x7, x0
add	x0, x0, x19
ldrb	w7, [x11], #0x20
add	x14, x7, x14
add	x14, x14, x0
add	x14, x14, #0x1
mov	x20, x12
mov	x0, x13
mov	x19, x6
mov	x7, x9
subs	x10, x10, #0x1
b.eq	<_damage.collectSpans__anon>
ldurh	w9, [x11, #-0x1e]
ldp	w6, w13, [x11, #-0x1c]
ldur	w12, [x11, #-0x14]
cmp	w7, w9
ccmp	w19, w6, #0x0, eq
ccmp	w0, w13, #0x0, eq
ccmp	w20, w12, #0x0, eq
b.ne	<_damage.collectSpans__anon>
mov	x0, #0x0                ; =0
b	<_damage.collectSpans__anon>
add	x11, x17, x21, lsl #5
sub	x12, x27, x21
stp	x11, x12, [x8, #-0x18]
ldr	x8, [sp, #0x50]
add	x11, x8, #0x1
ldr	x8, [sp, #0x60]
add	x8, x5, x8
str	x8, [sp, #0x60]
ldr	x8, [sp, #0x58]
sub	x8, x8, x9
add	x8, x8, x10
stp	x11, x8, [sp, #0x50]
b	<_damage.collectSpans__anon>
mov	w8, #0x1                ; =1
sturb	w8, [x29, #-0x58]
ldr	x0, [sp, #0x8]
ldp	x10, x9, [sp, #0x58]
ldr	x11, [sp, #0x50]
ldp	x13, x12, [sp, #0x28]
ldp	x29, x30, [sp, #0xc0]
ldp	x20, x19, [sp, #0xb0]
ldp	x22, x21, [sp, #0xa0]
ldp	x24, x23, [sp, #0x90]
ldp	x26, x25, [sp, #0x80]
ldp	x28, x27, [sp, #0x70]
add	sp, sp, #0xd0
b	<_damage.collectSpans__anon>
mov	x3, #0x0                ; =0
mov	x13, #0x0               ; =0
mov	x12, #0x0               ; =0
mov	x11, #0x0               ; =0
mov	x10, #0x0               ; =0
stp	x3, x13, [x0]
stp	x12, x11, [x0, #0x10]
stp	x9, x10, [x0, #0x20]
str	xzr, [x0, #0x30]
strb	w8, [x0, #0x38]
stur	wzr, [x0, #0x39]
str	wzr, [x0, #0x3c]
ret
mov	x3, x16
ldr	x0, [sp, #0x8]
ldr	w8, [sp, #0x4]
ldp	x10, x9, [sp, #0x58]
ldr	x11, [sp, #0x50]
b	<_damage.collectSpans__anon>

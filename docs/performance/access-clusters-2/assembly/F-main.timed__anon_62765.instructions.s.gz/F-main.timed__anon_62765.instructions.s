stp	x28, x27, [sp, #-0x60]!
stp	x26, x25, [sp, #0x10]
stp	x24, x23, [sp, #0x20]
stp	x22, x21, [sp, #0x30]
stp	x20, x19, [sp, #0x40]
stp	x29, x30, [sp, #0x50]
add	x29, sp, #0x50
sub	sp, sp, #0x4, lsl #12   ; =0x4000
sub	sp, sp, #0x110
mov	x19, x2
str	x0, [sp, #0x20]
ldp	x0, x8, [x1]
ldr	x22, [x1, #0x68]
stp	x8, x0, [sp, #0x10]
ldr	x9, [x8, #0x2c0]
add	x20, sp, #0xac0
add	x8, sp, #0xac0
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [sp, #0xac0]
str	x8, [sp, #0x8]
str	x19, [sp, #0x38]
cbz	x19, <_main.timed__anon>
mov	x23, #0x0               ; =0
mov	x21, #0x0               ; =0
add	x8, sp, #0x3, lsl #12   ; =0x3000
add	x8, x8, #0xd8
add	x9, sp, #0x2, lsl #12   ; =0x2000
add	x9, x9, #0x280
add	x10, x9, #0x20
str	x10, [sp, #0x50]
add	x10, x9, #0x38
add	x9, x20, #0x938
str	x9, [sp, #0x160]
add	x9, x20, #0x948
stp	x10, x9, [sp, #0x28]
add	x8, x8, #0x20
str	x8, [sp, #0x40]
str	x22, [sp, #0x178]
ldr	x14, [x22, #0x20]
mov	w8, #0x50b8             ; =20664
movk	w8, #0x13, lsl #16
add	x20, x14, x8
ldrh	w8, [x20, #0x80]
ldrh	w9, [x20, #0x82]
ldrb	w10, [x20, #0x89]
cmp	w10, #0x1
stp	x23, x21, [sp, #0x58]
b.ne	<_main.timed__anon>
mov	w10, #0x0               ; =0
mov	w11, #0xfba2            ; =64418
movk	w11, #0x26, lsl #16
add	x11, x14, x11
ldrb	w12, [x11, #0x1d9]
cmp	w12, #0x1
b.ne	<_main.timed__anon>
cmp	w8, #0x3e
b.lo	<_main.timed__anon>
ldrh	w10, [x11]
sub	w11, w8, #0x14
and	w11, w11, #0xffff
cmp	w10, w11
csel	w10, w10, w11, lo
cmp	w10, #0x2a
mov	w11, #0x2a              ; =42
csel	w10, w10, w11, hi
cmp	w9, #0x1
cset	w11, hi
cmp	w9, #0x0
cset	w12, ne
cmp	w10, w8
csel	w10, w10, w8, lo
sub	w8, w8, w10
cmp	w12, w9
csel	w12, w12, w9, lo
sub	w9, w9, w12
and	w9, w9, #0xffff
subs	w9, w9, w11
csel	w9, wzr, w9, lo
orr	x10, x10, x12, lsl #16
b	<_main.timed__anon>
mov	x10, #0x0               ; =0
mov	w11, #0xeb80            ; =60288
movk	w11, #0x26, lsl #16
add	x28, x14, x11
mov	w11, #0x908             ; =2312
movk	w11, #0x23, lsl #16
add	x21, x14, x11
mov	w11, #0x5ef0            ; =24304
movk	w11, #0x20, lsl #16
add	x15, x14, x11
mov	w11, #0xfcb8            ; =64696
movk	w11, #0x1d, lsl #16
add	x19, x14, x11
mov	w11, #0x99d8            ; =39384
movk	w11, #0x17, lsl #16
add	x11, x14, x11
str	x11, [sp, #0x130]
mov	w11, #0x9600            ; =38400
movk	w11, #0x16, lsl #16
add	x11, x14, x11
str	x11, [sp, #0x148]
mov	w11, #0x11c0            ; =4544
movk	w11, #0x16, lsl #16
add	x11, x14, x11
str	x11, [sp, #0x138]
mov	w11, #0xaeb0            ; =44720
movk	w11, #0x14, lsl #16
add	x26, x14, x11
mov	w11, #0x9bc8            ; =39880
movk	w11, #0x14, lsl #16
add	x11, x14, x11
str	x11, [sp, #0x128]
mov	w11, #0xda70            ; =55920
movk	w11, #0x12, lsl #16
add	x6, x14, x11
mov	w11, #0x9340            ; =37696
movk	w11, #0x12, lsl #16
add	x12, x14, x11
mov	w11, #0x5ba8            ; =23464
movk	w11, #0xf, lsl #16
add	x25, x14, x11
mov	w11, #0x30f0            ; =12528
movk	w11, #0xc, lsl #16
add	x11, x14, x11
str	x11, [sp, #0x120]
mov	w11, #0xf0b8            ; =61624
movk	w11, #0xb, lsl #16
add	x24, x14, x11
ldr	x13, [x20, #0x8]
ldr	x11, [x26]
and	w8, w8, #0xffff
lsl	x8, x8, #32
orr	x8, x8, x9, lsl #48
add	x9, x13, x11
add	x9, x9, #0x1
str	x9, [sp, #0x180]
orr	x8, x8, x10
ldr	x9, [x12]
stp	x9, x14, [sp, #0x150]
str	x12, [sp, #0x48]
str	x8, [sp, #0x80]
cbz	x9, <_main.timed__anon>
ldr	x1, [x12, #0x8]
str	x8, [sp, #0x2280]
add	x2, sp, #0x2, lsl #12   ; =0x2000
add	x2, x2, #0x280
mov	x0, x24
str	x1, [sp, #0x168]
mov	x22, x15
mov	x23, x6
bl	<_workspace.tab_layout.snapshot>
mov	x6, x23
mov	x15, x22
ldr	x13, [x20, #0x8]
ldr	x11, [x26]
ldr	x8, [sp, #0x178]
ldr	x8, [x8, #0x20]
str	x8, [sp, #0x140]
b	<_main.timed__anon>
str	x14, [sp, #0x140]
ldr	x30, [x19]
ldr	x22, [x19, #0x50]
ldr	x19, [x19, #0x460]
ldr	x8, [x20, #0x68]
str	x8, [sp, #0x170]
ldr	x12, [x15]
ldr	x14, [x21]
ldr	x15, [x21, #0x28]
ldr	x16, [x21, #0x60]
ldr	x17, [x21, #0x88]
ldr	x0, [x24]
ldp	x1, x2, [x28]
ldr	x3, [x28, #0x10]
ldr	x4, [x6]
ldr	x5, [x20]
ldr	x23, [x6, #0xc38]
ldr	x6, [x25, #0x858]
ldr	x7, [x25]
ldp	x8, x10, [sp, #0x128]
ldr	x8, [x8]
ldr	x9, [x24, #0x28]
ldr	x10, [x10]
add	x8, x9, x8
add	x27, x8, x10
ldr	x24, [x26, #0x8]
ldr	x9, [sp, #0x138]
ldr	x8, [x9]
ldr	x9, [x9, #0x418]
ldr	x10, [sp, #0x148]
ldr	x10, [x10]
ldr	x25, [x21, #0x48]
ldr	x21, [sp, #0x120]
ldp	x28, x26, [x21]
ldr	x21, [x21, #0x228]
ldr	x20, [x20, #0x80]
str	x20, [sp, #0x78]
ldr	x20, [sp, #0x170]
stp	x22, x30, [sp, #0xc0]
stp	x30, x22, [sp, #0x188]
str	x19, [sp, #0xb8]
stp	x19, x13, [sp, #0x198]
stp	x12, x13, [sp, #0x130]
stp	x20, x12, [sp, #0x1a8]
stp	x15, x14, [sp, #0x120]
stp	x14, x15, [sp, #0x1b8]
stp	x17, x16, [sp, #0x110]
stp	x16, x17, [sp, #0x1c8]
stp	x1, x0, [sp, #0x100]
stp	x0, x1, [sp, #0x1d8]
stp	x3, x2, [sp, #0xf0]
stp	x2, x3, [sp, #0x1e8]
stp	x5, x4, [sp, #0xe0]
stp	x4, x5, [sp, #0x1f8]
str	x23, [sp, #0x208]
stp	x7, x6, [sp, #0xd0]
str	x6, [sp, #0x210]
str	x7, [sp, #0x218]
stp	x26, x28, [sp, #0x88]
str	x26, [sp, #0x220]
mov	x26, x27
str	x11, [sp, #0x148]
str	x11, [sp, #0x228]
str	x27, [sp, #0x230]
str	x24, [sp, #0x238]
stp	x9, x8, [sp, #0xa8]
str	x8, [sp, #0x240]
str	x9, [sp, #0x248]
stp	x25, x10, [sp, #0x98]
str	x10, [sp, #0x250]
str	x25, [sp, #0x258]
str	x28, [sp, #0x260]
add	x8, sp, #0x188
stp	xzr, xzr, [x8, #0xe8]
str	x21, [sp, #0x268]
ldr	x9, [sp, #0x180]
str	x9, [sp, #0x280]
stp	xzr, xzr, [x8, #0x100]
mov	w8, #0x4f38             ; =20280
movk	w8, #0x27, lsl #16
ldr	x19, [sp, #0x140]
add	x0, x19, x8
add	x1, sp, #0x188
bl	<_meta.eql__anon>
tbnz	w0, #0x0, <_main.timed__anon>
mov	w8, #0x4f38             ; =20280
movk	w8, #0x27, lsl #16
add	x0, x19, x8
add	x1, sp, #0x188
mov	w2, #0x110              ; =272
bl	<_memcpy>
ldr	x9, [sp, #0x178]
add	x25, sp, #0xac0
add	x28, sp, #0x2, lsl #12  ; =0x2000
add	x28, x28, #0x280
ldp	x8, x22, [sp, #0x150]
cbz	x8, <_main.timed__anon>
ldr	x27, [sp, #0x78]
stp	x24, x26, [sp, #0x68]
str	x21, [sp, #0x140]
str	x23, [sp, #0x150]
mov	w8, #0x8b50             ; =35664
movk	w8, #0xf, lsl #16
add	x26, x22, x8
ldr	x23, [x9, #0x20]
mov	w8, #0x58b8             ; =22712
movk	w8, #0x27, lsl #16
add	x20, x23, x8
mov	w8, #0x18               ; =24
ldr	x9, [sp, #0x168]
madd	x8, x9, x8, x22
mov	w9, #0x8b40             ; =35648
movk	w9, #0xf, lsl #16
add	x21, x8, x9
ldr	x19, [x21, #0x10]
add	x0, sp, #0x2, lsl #12   ; =0x2000
add	x0, x0, #0x280
mov	w1, #0x828              ; =2088
bl	<dyld_stub_binder>
mov	x8, #0x0                ; =0
mov	w9, #0x0                ; =0
mov	x10, #0x0               ; =0
mov	w11, #0xc050            ; =49232
movk	w11, #0x12, lsl #16
add	x24, x22, x11
b	<_main.timed__anon>
add	x10, x10, #0x1
cmp	x10, #0x100
b.eq	<_main.timed__anon>
ldr	x11, [x24, x10, lsl #3]
cbz	x11, <_main.timed__anon>
ldr	x12, [x11, #0x28]
cmp	x12, x19
b.ne	<_main.timed__anon>
ldr	q0, [x21]
str	q0, [x28]
ldr	x9, [sp, #0x50]
add	x9, x9, x8, lsl #5
ldr	x12, [x11, #0x10]
ldr	x13, [x11, #0xc8]
stp	x12, x13, [x9]
ldrb	w12, [x11, #0x106]
strb	w12, [x9, #0x18]
ldr	x11, [x11, #0xb8]
str	x11, [x9, #0x10]
add	x8, x8, #0x1
mov	w9, #0x1                ; =1
cmp	x10, #0xff
add	x10, x10, #0x1
b.lo	<_main.timed__anon>
str	x19, [sp, #0x2290]
strb	w9, [x28, #0x18]
strb	w8, [x28, #0x820]
add	x0, sp, #0x298
add	x1, sp, #0x2, lsl #12   ; =0x2000
add	x1, x1, #0x280
mov	w2, #0x828              ; =2088
bl	<_memcpy>
mov	x9, #0x0                ; =0
mov	x8, #0x0                ; =0
ldr	x10, [sp, #0x180]
str	x10, [sp, #0x2280]
ldr	x10, [sp, #0x80]
str	x10, [sp, #0x2288]
strb	wzr, [x28, #0x640]
movi.2d	v0, #0000000000000000
stp	q0, q0, [x28, #0x10]
mov	w10, #0xc00             ; =3072
ldr	x11, [sp, #0x168]
madd	x10, x11, x10, x22
add	x11, x10, #0xf8, lsl #12 ; =0xf8000
ldr	x10, [x11, #0x1d30]
str	x27, [sp, #0x28b8]
str	x10, [sp, #0x22b0]
b	<_main.timed__anon>
add	x8, x8, #0x1
cmp	x8, #0x100
b.eq	<_main.timed__anon>
ldr	x10, [x24, x8, lsl #3]
cbz	x10, <_main.timed__anon>
ldr	x11, [x10, #0x28]
cmp	x11, x19
b.ne	<_main.timed__anon>
ldr	x11, [sp, #0x28]
mov	w12, #0x18              ; =24
madd	x9, x9, x12, x11
ldr	x11, [x10, #0x10]
ldr	x12, [x10, #0xb8]
stp	x11, x12, [x9]
ldr	w10, [x10, #0x50]
str	w10, [x9, #0x10]
ldrb	w9, [x28, #0x640]
add	x9, x9, #0x1
strb	w9, [x28, #0x640]
cmp	x8, #0xff
add	x8, x8, #0x1
b.lo	<_main.timed__anon>
b	<_main.timed__anon>
cbz	x9, <_main.timed__anon>
ldr	q0, [x21]
stur	q0, [x28, #0x10]
ldr	x8, [x21, #0x10]
stur	x8, [x28, #0x20]
mov	w8, #0x1                ; =1
strb	w8, [x28, #0x28]
add	x1, sp, #0x2, lsl #12   ; =0x2000
add	x1, x1, #0x280
ldr	x0, [sp, #0x160]
mov	w2, #0x648              ; =1608
bl	<_memcpy>
ldp	x8, x9, [sp, #0xc0]
str	x9, [sp, #0xac0]
str	x8, [sp, #0xac8]
ldr	x8, [sp, #0xb8]
str	x8, [sp, #0xad0]
ldr	x8, [sp, #0x138]
str	x8, [sp, #0xad8]
ldr	x8, [sp, #0x170]
str	x8, [sp, #0xae0]
ldp	x8, x9, [sp, #0x128]
str	x9, [sp, #0xae8]
str	x8, [sp, #0xaf0]
ldp	x8, x9, [sp, #0x118]
str	x9, [sp, #0xaf8]
str	x8, [sp, #0xb00]
ldp	x8, x9, [sp, #0x108]
str	x9, [sp, #0xb08]
str	x8, [sp, #0xb10]
ldp	x8, x9, [sp, #0xf8]
str	x9, [sp, #0xb18]
str	x8, [sp, #0xb20]
ldp	x8, x9, [sp, #0xe8]
str	x9, [sp, #0xb28]
str	x8, [sp, #0xb30]
ldr	x8, [sp, #0xe0]
str	x8, [sp, #0xb38]
ldr	x8, [sp, #0x150]
str	x8, [sp, #0xb40]
ldp	x8, x9, [sp, #0xd0]
str	x9, [sp, #0xb48]
str	x8, [sp, #0xb50]
ldr	x8, [sp, #0x88]
str	x8, [sp, #0xb58]
ldr	x8, [sp, #0x148]
str	x8, [sp, #0xb60]
ldp	x8, x9, [sp, #0x68]
str	x9, [sp, #0xb68]
str	x8, [sp, #0xb70]
ldp	x8, x9, [sp, #0xa8]
str	x9, [sp, #0xb78]
str	x8, [sp, #0xb80]
ldp	x8, x9, [sp, #0x98]
str	x9, [sp, #0xb88]
str	x8, [sp, #0xb90]
ldr	x8, [sp, #0x90]
str	x8, [sp, #0xb98]
stp	xzr, xzr, [x25, #0xe8]
ldr	x8, [sp, #0x140]
str	x8, [sp, #0xba0]
ldr	x8, [sp, #0x180]
str	x8, [sp, #0xbb8]
stp	xzr, xzr, [x25, #0x100]
add	x0, x25, #0x110
add	x1, sp, #0x298
mov	w2, #0x828              ; =2088
bl	<_memcpy>
strb	wzr, [x25, #0xf80]
add	x0, sp, #0x2, lsl #12   ; =0x2000
add	x0, x0, #0x280
add	x1, x25, #0x130
mov	w2, #0xe58              ; =3672
bl	<_memcpy>
ldrb	w8, [x20, #0xf98]
cbnz	w8, <_main.timed__anon>
add	x0, sp, #0xac0
mov	w8, #0x4f38             ; =20280
movk	w8, #0x27, lsl #16
add	x1, x23, x8
bl	<_meta.eql__anon>
tbz	w0, #0x0, <_main.timed__anon>
ldr	x21, [x20]
cmn	x21, #0x1
b.eq	<_main.timed__anon>
ldrb	w19, [x28, #0x800]
cmp	x19, #0x41
b.hs	<_main.timed__anon>
add	x8, x21, #0x1
str	x8, [x20]
mov	w8, #0x5048             ; =20552
movk	w8, #0x27, lsl #16
add	x0, x23, x8
add	x1, sp, #0xac0
mov	w2, #0x110              ; =272
bl	<_memcpy>
strb	wzr, [x20, #0xfa0]
mov	w8, #0x1                ; =1
strb	w8, [x20, #0xf98]
str	x21, [x20, #0x8]
mov	w8, #0x58c8             ; =22728
movk	w8, #0x27, lsl #16
add	x0, x23, x8
add	x1, sp, #0xac0
mov	w2, #0x110              ; =272
bl	<_memcpy>
mov	w8, #0x6020             ; =24608
movk	w8, #0x27, lsl #16
add	x25, x23, x8
ldrb	w8, [x28, #0xe50]
strb	w8, [x20, #0xf90]
ldr	x8, [sp, #0x160]
ldr	q0, [x8]
mov	w8, #0x59d8             ; =23000
movk	w8, #0x27, lsl #16
str	q0, [x23, x8]
mov	w8, #0x59e8             ; =23016
movk	w8, #0x27, lsl #16
add	x8, x23, x8
ldr	x9, [sp, #0x30]
ldp	q0, q1, [x9]
stp	q0, q1, [x8]
ldr	x8, [sp, #0x2ab8]
str	x8, [x20, #0x150]
ldr	x8, [sp, #0x30c0]
str	x8, [x20, #0x758]
ldrb	w8, [x28, #0xe48]
strb	w8, [x20, #0x760]
add	x8, x8, x8, lsl #1
lsl	x2, x8, #3
mov	w8, #0x5a10             ; =23056
movk	w8, #0x27, lsl #16
add	x0, x23, x8
add	x1, x28, #0x840
bl	<_memcpy>
add	x8, sp, #0x199
ldur	q0, [x8, #0xff]
add	x8, sp, #0x1a9
ldur	q1, [x8, #0xff]
stp	q0, q1, [x25]
strb	w19, [x20, #0xf88]
lsl	x2, x19, #5
mov	w25, #0x6040            ; =24640
movk	w25, #0x27, lsl #16
add	x0, x23, x25
add	x1, sp, #0x2, lsl #12   ; =0x2000
add	x1, x1, #0x280
bl	<_memcpy>
ldr	x8, [sp, #0x178]
ldr	x19, [x8, #0x20]
mov	w8, #0x6840             ; =26688
movk	w8, #0x27, lsl #16
add	x20, x19, x8
ldrb	w8, [x20, #0x10]
cbz	w8, <_main.timed__anon>
add	x8, x19, #0x270, lsl #12 ; =0x270000
ldr	x8, [x8, #0x58c0]
cmp	x8, x21
b.ne	<_main.timed__anon>
mov	w8, #0x5298             ; =21144
movk	w8, #0x27, lsl #16
add	x21, x19, x8
mov	w8, #0x5158             ; =20824
movk	w8, #0x27, lsl #16
add	x0, x19, x8
mov	w8, #0x58c8             ; =22728
movk	w8, #0x27, lsl #16
add	x1, x19, x8
mov	w2, #0x110              ; =272
bl	<_memcpy>
ldrb	w8, [x21, #0x618]
cbnz	w8, <_main.timed__anon>
mov	w8, #0x52a0             ; =21152
movk	w8, #0x27, lsl #16
add	x0, x19, x8
mov	w1, #0x1                ; =1
mov	w2, #0x618              ; =1560
bl	<_memset>
mov	w8, #0x59d8             ; =23000
movk	w8, #0x27, lsl #16
ldr	q0, [x19, x8]
mov	w8, #0x5268             ; =21096
movk	w8, #0x27, lsl #16
str	q0, [x19, x8]
mov	w8, #0x5278             ; =21112
movk	w8, #0x27, lsl #16
add	x8, x19, x8
mov	w9, #0x59e8             ; =23016
movk	w9, #0x27, lsl #16
add	x9, x19, x9
ldp	q0, q1, [x9]
stp	q0, q1, [x8]
ldr	x8, [x21, #0x770]
str	x8, [x21]
ldr	x8, [x21, #0xd78]
str	x8, [x21, #0x608]
ldrb	w8, [x21, #0xd80]
strb	w8, [x21, #0x610]
add	x8, x8, x8, lsl #1
lsl	x2, x8, #3
mov	w8, #0x52a0             ; =21152
movk	w8, #0x27, lsl #16
add	x0, x19, x8
mov	w8, #0x5a10             ; =23056
movk	w8, #0x27, lsl #16
add	x1, x19, x8
bl	<_memcpy>
mov	w8, #0x6020             ; =24608
movk	w8, #0x27, lsl #16
add	x8, x19, x8
ldrb	w9, [x20, #0x8]
add	x21, sp, #0x3, lsl #12  ; =0x3000
add	x21, x21, #0xd8
strb	w9, [x21, #0x808]
ldp	q0, q1, [x8]
stp	q0, q1, [x28]
ldrb	w8, [x20]
strb	w8, [x21, #0x800]
lsl	x2, x8, #5
add	x0, sp, #0x3, lsl #12   ; =0x3000
add	x0, x0, #0xd8
add	x1, x19, x25
bl	<_memcpy>
mov	w8, #0x58c0             ; =22720
movk	w8, #0x27, lsl #16
add	x0, x19, x8
mov	w1, #0xf98              ; =3992
bl	<dyld_stub_binder>
add	x1, sp, #0x3, lsl #12   ; =0x3000
add	x1, x1, #0xd8
ldr	x0, [sp, #0x50]
mov	w2, #0x810              ; =2064
bl	<_memcpy>
add	x0, sp, #0x1, lsl #12   ; =0x1000
add	x0, x0, #0xa50
add	x1, sp, #0x2, lsl #12   ; =0x2000
add	x1, x1, #0x280
mov	w2, #0x830              ; =2096
bl	<_memcpy>
add	x0, sp, #0x3, lsl #12   ; =0x3000
add	x0, x0, #0xd8
add	x1, sp, #0x1, lsl #12   ; =0x1000
add	x1, x1, #0xa50
mov	w2, #0x828              ; =2088
bl	<_memcpy>
add	x20, sp, #0x3, lsl #12  ; =0x3000
add	x20, x20, #0xd8
ldrb	w8, [x21, #0x18]
cbz	w8, <_main.timed__anon>
ldr	x8, [sp, #0x48]
ldr	x8, [x8]
cbz	x8, <_main.timed__anon>
ldrb	w10, [x20, #0x8]
ldr	x9, [sp, #0x30d8]
ldr	x19, [sp, #0x30e8]
ldr	x11, [x26]
cmp	x11, x19
b.eq	<_main.timed__anon>
add	x26, x26, #0x18
subs	x8, x8, #0x1
b.ne	<_main.timed__anon>
b	<_main.timed__anon>
mov	x8, #0x0                ; =0
ldp	x23, x21, [sp, #0x58]
add	x21, x8, x21
add	x23, x23, #0x1
ldr	x8, [sp, #0x38]
cmp	x23, x8
ldr	x22, [sp, #0x178]
b.ne	<_main.timed__anon>
b	<_main.timed__anon>
mov	x8, #0x0                ; =0
ldurb	w11, [x26, #-0x8]
eor	w10, w11, w10
tbnz	w10, #0x0, <_main.timed__anon>
ldur	x10, [x26, #-0x10]
cmp	x10, x9
ldp	x23, x21, [sp, #0x58]
b.ne	<_main.timed__anon>
add	x0, sp, #0x3, lsl #12   ; =0x3000
add	x0, x0, #0x900
mov	x1, x24
mov	w2, #0x800              ; =2048
bl	<_memcpy>
mov	x9, #0x0                ; =0
mov	x8, #0x0                ; =0
add	x11, sp, #0x3, lsl #12  ; =0x3000
add	x11, x11, #0x900
b	<_main.timed__anon>
add	x9, x9, #0x8
cmp	x9, #0x800
b.eq	<_main.timed__anon>
ldr	x10, [x11, x9]
cbz	x10, <_main.timed__anon>
ldr	x10, [x10, #0x28]
cmp	x10, x19
cinc	x8, x8, eq
b	<_main.timed__anon>
cbz	x8, <_main.timed__anon>
strb	wzr, [x28, #0x820]
ldrb	w9, [x20, #0x820]
cbz	x9, <_main.timed__anon>
mov	x8, #0x0                ; =0
mov	x10, #0x0               ; =0
mov	w11, #0xc850            ; =51280
movk	w11, #0x12, lsl #16
add	x11, x22, x11
mov	w12, #0xd850            ; =55376
movk	w12, #0x12, lsl #16
add	x12, x22, x12
b	<_main.timed__anon>
mov	x8, #0x0                ; =0
b	<_main.timed__anon>
str	xzr, [x0, #0xc8]
ldr	x0, [sp, #0x50]
add	x8, x0, x8, lsl #5
stp	x14, x15, [x8]
str	x16, [x8, #0x10]
strb	w17, [x8, #0x18]
ldur	w14, [x13, #0x19]
stur	w14, [x8, #0x19]
ldur	w13, [x13, #0x1c]
str	w13, [x8, #0x1c]
ldrb	w8, [x28, #0x820]
add	x8, x8, #0x1
strb	w8, [x28, #0x820]
add	x10, x10, #0x1
cmp	x10, x9
b.eq	<_main.timed__anon>
ldr	x13, [sp, #0x40]
add	x13, x13, x10, lsl #5
ldr	x14, [x13]
cbz	x14, <_main.timed__anon>
ldp	x15, x16, [x13, #0x8]
ldrb	w17, [x13, #0x18]
eor	x0, x14, x14, lsr #32
mov	x1, #0x556d             ; =21869
movk	x1, #0xeb34, lsl #16
movk	x1, #0x25f9, lsl #32
movk	x1, #0xbea2, lsl #48
mul	x0, x0, x1
eor	x0, x0, x0, lsr #29
mul	x0, x0, x1
eor	x0, x0, x0, lsr #32
mul	x0, x0, x1
eor	x1, x0, x0, lsr #29
mov	w0, #0x200              ; =512
and	x1, x1, #0x1ff
ldr	x2, [x11, x1, lsl #3]
cmp	x2, x14
b.eq	<_main.timed__anon>
cbz	x2, <_main.timed__anon>
add	x1, x1, #0x1
subs	x0, x0, #0x1
b.ne	<_main.timed__anon>
b	<_main.timed__anon>
ldrb	w0, [x12, x1]
ldr	x0, [x24, x0, lsl #3]
cbz	x0, <_main.timed__anon>
ldr	x1, [x0, #0x28]
cmp	x1, x19
b.ne	<_main.timed__anon>
and	w1, w17, #0x1
ldrb	w2, [x0, #0x106]
cmp	w2, w1
b.ne	<_main.timed__anon>
ldr	x1, [x0, #0xb8]
cmp	x1, x16
b.ne	<_main.timed__anon>
ldr	x1, [x0, #0xc8]
cmp	x1, x15
b.ne	<_main.timed__anon>
ldr	x1, [x0, #0xb0]
mov	w4, #0xffff             ; =65535
cbz	x1, <_main.timed__anon>
mov	x2, #0x0                ; =0
ldr	x3, [x0, #0xa8]
str	w4, [x3, x2, lsl #2]
add	x2, x2, #0x1
cmp	x2, x1
b.lo	<_main.timed__anon>
b	<_main.timed__anon>
mov	x21, #0x0               ; =0
ldp	x8, x0, [sp, #0x10]
ldr	x9, [x8, #0x2c0]
add	x8, sp, #0xac0
mov	w1, #0x1                ; =1
blr	x9
ldr	x8, [sp, #0xac0]
ldr	x9, [sp, #0x8]
sub	x8, x8, x9
ldr	x9, [sp, #0x20]
strh	wzr, [x9, #0x8]
str	x8, [x9]
b	<_main.timed__anon>
mov	w8, #0x267              ; =615
b	<_main.timed__anon>
mov	w8, #0x1b8              ; =440
b	<_main.timed__anon>
mov	w8, #0x263              ; =611
b	<_main.timed__anon>
mov	w8, #0x264              ; =612
b	<_main.timed__anon>
mov	w8, #0x265              ; =613
b	<_main.timed__anon>
mov	w8, #0x266              ; =614
ldr	x9, [sp, #0x20]
strh	w8, [x9, #0x8]
add	sp, sp, #0x4, lsl #12   ; =0x4000
add	sp, sp, #0x110
ldp	x29, x30, [sp, #0x50]
ldp	x20, x19, [sp, #0x40]
ldp	x22, x21, [sp, #0x30]
ldp	x24, x23, [sp, #0x20]
ldp	x26, x25, [sp, #0x10]
ldp	x28, x27, [sp], #0x60
ret

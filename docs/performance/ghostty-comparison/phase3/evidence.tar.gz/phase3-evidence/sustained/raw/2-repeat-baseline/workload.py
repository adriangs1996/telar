import sys
from pathlib import Path
sys.path.insert(0, '/private/tmp/tgb-p3-sustained/harness/tools')
import terminal_bench_fixture as fixture
fixture.PAYLOAD_BYTES = 64 * 1024 * 1024
fixture.LIFETIME_SECONDS = 180
fixture.Fixture(Path('/private/tmp/tgb-p3-sustained/raw/2-repeat-baseline/fixture')).run()

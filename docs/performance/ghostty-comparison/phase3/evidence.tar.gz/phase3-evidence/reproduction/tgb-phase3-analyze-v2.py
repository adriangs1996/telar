#!/usr/bin/env python3
"""Audit saved native AB/BA runs without launching any measured process.

Example: python3 /tmp/tgb-phase3-analyze-v2.py /tmp/variable /tmp/repeat --output /tmp/analysis.json
Only baseline/candidate GUI runs enter comparisons. Ghostty controls are counted
but ignored. Distinct directories must contain distinct text patterns, so an
exploratory series cannot silently be pooled with its later confirmation.
"""
import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import sys


BOOTSTRAP_SAMPLES = 10000
BOOTSTRAP_SEED = 20260918
THROUGHPUT_MARGIN = .95
RATE_TOLERANCE = .05
VERSIONS = ('baseline', 'candidate')
FOCUS_FIELDS = ('app_active_start', 'app_active_end', 'window_key_start', 'window_key_end')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text())


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def equivalent(actual, expected):
    if isinstance(actual, dict) and isinstance(expected, dict):
        return actual.keys() == expected.keys() and all(equivalent(actual[k], expected[k]) for k in actual)
    if isinstance(actual, list) and isinstance(expected, list):
        return len(actual) == len(expected) and all(equivalent(a, b) for a, b in zip(actual, expected))
    if finite(actual) and finite(expected):
        return math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-10)
    return actual == expected


def percentile(values, fraction):
    values = sorted(values)
    offset = (len(values) - 1) * fraction
    lower = int(offset)
    upper = min(lower + 1, len(values) - 1)
    return values[lower] + (values[upper] - values[lower]) * (offset - lower)


def summarize(values):
    return dict(n=len(values), p50_ms=statistics.median(values), p95_ms=percentile(values, .95),
                p99_ms=percentile(values, .99), max_ms=max(values))


def bootstrap_means(values):
    if len(values) < 2:
        return None
    generator = random.Random(BOOTSTRAP_SEED)
    return [sum(values[generator.randrange(len(values))] for _ in values) / len(values)
            for _ in range(BOOTSTRAP_SAMPLES)]


def paired_latency(before, after):
    require(before.keys() == after.keys(), 'unpaired latency rounds')
    rounds = sorted(before)
    result = dict(rounds=rounds, n_rounds=len(rounds), quantiles={})
    for name in ('p50', 'p95'):
        deltas = [after[i][name + '_ms'] - before[i][name + '_ms'] for i in rounds]
        boot = bootstrap_means(deltas)
        interval = [percentile(boot, .025), percentile(boot, .975)] if boot else None
        result['quantiles'][name] = dict(paired_deltas_ms=deltas, mean_delta_ms=statistics.mean(deltas),
            median_delta_ms=statistics.median(deltas), mean_delta_ci95_ms=interval,
            interpretation=('insufficient_pairs' if interval is None else
                            'lower_latency' if interval[1] < 0 else
                            'higher_latency' if interval[0] > 0 else 'inconclusive'))
    return result


def paired_throughput(before, after):
    require(before.keys() == after.keys(), 'unpaired throughput rounds')
    rounds = sorted(before)
    ratios = [after[i] / before[i] for i in rounds]
    logs = [math.log(ratio) for ratio in ratios]
    boot = bootstrap_means(logs)
    bootstrap_ratios = [math.exp(value) for value in boot] if boot else None
    lower = percentile(bootstrap_ratios, .05) if bootstrap_ratios else None
    upper = percentile(bootstrap_ratios, .95) if bootstrap_ratios else None
    result = dict(rounds=[dict(round=i, baseline_mib_per_second=before[i],
                              candidate_mib_per_second=after[i], ratio=after[i] / before[i]) for i in rounds],
                  n_rounds=len(rounds), paired_geometric_mean_ratio=math.exp(statistics.mean(logs)),
                  one_sided_95_lower_p5=lower, one_sided_95_upper_p95=upper, criterion_lower_at_least=THROUGHPUT_MARGIN,
                  criterion_met=lower >= THROUGHPUT_MARGIN if lower is not None else None,
                  protocol_four_pairs=len(rounds) == 4,
                  interpretation=('insufficient_pairs' if lower is None else
                                  'meets_operational_noninferiority_rule' if lower >= THROUGHPUT_MARGIN else
                                  'regression_exceeds_margin' if upper < THROUGHPUT_MARGIN else 'inconclusive'))
    for version, values in [('baseline', before), ('candidate', after)]:
        rates = list(values.values())
        result[version] = dict(median=statistics.median(rates), minimum=min(rates), maximum=max(rates),
                               rounds_meeting_80=sum(rate >= 80 for rate in rates))
    return result


def geometry(run):
    names = ('viewport', 'scene_pixels', 'primary_view_pixels', 'window_content_pixels',
             'native_view_pixels', 'pty_cells', 'backing_scale', 'display_max_fps')
    return dict(**{name: run[name] for name in names},
                fixtures=sorted((f['role'], f['cols'], f['rows']) for f in run['fixtures']))


def background_observation(run):
    target = run['background_mib_per_second']
    if target is None:
        return None
    require(finite(target) and target > 0, 'invalid background target')
    fixtures, rejected = [], []
    for fixture in run['fixtures']:
        if fixture['role'] != 'background':
            continue
        checkpoints = fixture['background_progress']
        require(len(checkpoints) >= 2, 'background needs two complete checkpoints')
        rates = []
        for index, (left, right) in enumerate(zip(checkpoints, checkpoints[1:])):
            elapsed = right['at_ns'] - left['at_ns']
            size = right['emitted_bytes'] - left['emitted_bytes']
            require(elapsed > 0 and size > 0, 'nonmonotonic background checkpoints')
            actual = size / elapsed * 1e9 / 1048576
            rates.append(actual)
            if abs(actual / target - 1) > RATE_TOLERANCE:
                rejected.append(dict(pid=fixture['pid'], interval=index, elapsed_seconds=elapsed / 1e9,
                                     bytes=size, requested_mib_per_second=target, actual_mib_per_second=actual))
        fixtures.append(dict(pid=fixture['pid'], requested_mib_per_second=target,
                             observed_mib_per_second=rates,
                             rate_met=all(abs(rate / target - 1) <= RATE_TOLERANCE for rate in rates),
                             max_write_ms=fixture['background_max_write_ms']))
    require(len(fixtures) == len(run['fixtures']) - 1, 'background observation count')
    expected = dict(endpoint='bytes accepted by background PTY writes',
                    scope='periodic background checkpoints, not synchronized to echo samples',
                    rate_scope='per background producer/pane', relative_tolerance=RATE_TOLERANCE,
                    rate_met=bool(fixtures) and not rejected, fixtures=fixtures)
    require(equivalent(expected, run['background_load']), 'background metadata differs from checkpoints')
    require(run['rate_miss_retained'] is (not expected['rate_met']), 'rate miss was not retained accurately')
    return dict(directory=run['directory'], case=run['case'], version=run['version'], round=run['round'],
                requested_mib_per_second_per_producer=target, rate_met=expected['rate_met'],
                fixtures=fixtures, failed_intervals=rejected)


def analyze_directory(directory):
    manifest, runs, reported = (read(directory / name) for name in ('manifest.json', 'runs.json', 'summary.json'))
    complete = read(directory / 'complete.json')
    pattern = manifest['text_pattern']
    latency_eligible = manifest['samples'] > 1
    require(pattern in ('repeat', 'variable'), 'unknown text pattern')
    require(manifest['mode'] == 'gui', 'this analyzer handles GUI strata only')
    require(complete['runs'] == len(runs), 'completion count differs from indexed runs')
    selected = [run for run in runs if run['version'] in VERSIONS]
    require(all(run['version'] in (*VERSIONS, 'ghostty') for run in runs), 'unknown version')
    expected_order = [(i, case, version) for i in range(manifest['rounds']) for case in manifest['cases']
                      for version in (VERSIONS if i % 2 == 0 else VERSIONS[::-1])]
    require([(r['round'], r['case'], r['version']) for r in selected] == expected_order, 'AB/BA order or run count differs')
    per_run = collections.defaultdict(lambda: {version: {} for version in VERSIONS})
    samples = collections.defaultdict(lambda: {version: [] for version in VERSIONS})
    rates = collections.defaultdict(lambda: {version: {} for version in VERSIONS})
    geometries, payloads, loads, retained = {}, {}, [], []
    focus_count = cleanup_count = measured_count = 0
    for run in selected:
        where = directory / run['directory']
        case, version, index = (run[k] for k in ('case', 'version', 'round'))
        require(read(where / 'result.json') == run, f'raw/index mismatch: {where}')
        require(run['failed'] == 0 and run['setup_complete'] is True, f'failed probe: {where}')
        require(run['input_method'] == 'key' and run['mode'] == 'gui' and run['foreground_required'] is True, 'input endpoint changed')
        require(run['text_pattern'] == pattern, 'run text pattern differs')
        raw, warmup = run['gpu_ms'], run['warmup']
        require(warmup == manifest['warmup'] and len(raw) == warmup + manifest['samples'], 'sample count or warmup differs')
        require(all(finite(value) and value >= 0 for value in raw), 'invalid latency value')
        for field in FOCUS_FIELDS:
            require(len(run[field]) == len(raw) and all(value is True for value in run[field]), f'invalid focus: {where}/{field}')
            focus_count += len(raw)
        actual = summarize(raw[warmup:])
        require(equivalent(actual, run['summary']), 'per-run summary differs from samples')
        per_run[case][version][index] = actual
        samples[case][version].extend(raw[warmup:])
        measured_count += len(raw) - warmup
        require(run['requested_viewport'] == manifest['viewport'] == run['scene_pixels'] == run['viewport'], 'viewport differs')
        requested_panes = 1 if case == 'single' else manifest['panes']
        require(run['panes_requested'] == run['panes_created'] == len(run['fixtures']) == requested_panes, 'pane count differs')
        require(sum(f['role'] == 'primary' for f in run['fixtures']) == 1, 'primary fixture count')
        requested_rate = manifest['background_mib_per_second'] if case.endswith('-load') else None
        require(run['background_mib_per_second'] == requested_rate, 'requested background rate differs')
        for fixture in run['fixtures']:
            require(fixture['role'] in ('primary', 'background') and fixture['error'] is None and
                    fixture['phase'] in ('ready', 'finished') and min(fixture['cols'], fixture['rows']) > 0, 'invalid fixture')
            require(fixture['text_pattern'] == pattern and fixture['background_mib_per_second'] == requested_rate and
                    fixture['background'] == ('flood' if case.endswith('-load') else 'idle'), 'fixture workload differs')
            if fixture['role'] == 'primary':
                require([fixture['cols'], fixture['rows']] == run['pty_cells'], 'primary geometry differs')
        current_geometry = geometry(run)
        require(case not in geometries or geometries[case] == current_geometry, 'geometry differs across paired versions/rounds')
        geometries[case] = current_geometry
        shutdown = read(where / 'shutdown.json')
        require(all(shutdown.get(field) is True for field in ('exited', 'children_exited', 'socket_removed', 'cleanup_complete'))
                and shutdown['returncode'] == 0, 'runtime cleanup failed')
        cleanup_count += 1
        require(run['binary_sha256'] == manifest['binaries'][version]['sha256'], 'recorded binary identity differs')
        load = background_observation(run)
        if load:
            loads.append(load)
            if not load['rate_met']:
                retained.append(dict(**{k: run[k] for k in ('round', 'case', 'version', 'attempt', 'directory')},
                                     background_load=run['background_load']))
        if case == 'single':
            throughput = run['throughput']
            require(read(where / 'throughput.json') == throughput, 'throughput raw/index mismatch')
            require(throughput['failed'] is False and throughput['endpoint'] == 'pty_write_to_dsr_response'
                    and throughput['text_pattern'] == pattern and throughput['bytes_per_case'] == 8388608, 'throughput endpoint/pattern/size differs')
            require([c['name'] for c in throughput['cases']] == ['ascii', 'ansi'], 'throughput cases differ')
            for item in throughput['cases']:
                name, rate, elapsed = item['name'], item['mib_per_second'], item['elapsed_ms']
                require(item['bytes'] == 8388608 and item['text_pattern'] == pattern and
                        [item['cols'], item['rows']] == run['pty_cells'], 'throughput geometry or payload size differs')
                require(finite(rate) and rate > 0 and finite(elapsed) and elapsed > 0 and
                        math.isclose(rate, 8000 / elapsed, rel_tol=1e-12), 'throughput rate does not match bytes/time')
                digest = item['payload_sha256']
                require(len(digest) == 64 and all(c in '0123456789abcdef' for c in digest), 'invalid payload digest')
                require(name not in payloads or payloads[name] == digest, 'payload changed across paired versions/rounds')
                payloads[name] = digest
                rates[name][version][index] = rate
    require(equivalent(retained, reported['rate_misses']), 'reported rate misses differ from raw')
    require(complete['retained_rate_misses'] == len(retained), 'completion rate miss count differs')
    if (directory / 'rate-misses.json').exists():
        require(equivalent(retained, read(directory / 'rate-misses.json')), 'rate-misses artifact differs')
    rejected = read(directory / 'rejected.json') if (directory / 'rejected.json').exists() else []
    require(len(rejected) == complete['rejected_startups'], 'startup rejection count differs')
    require(all(r['result']['failed'] == 10 and r['result'].get('panes_created') == 0 and
                not r['result']['gpu_ms'] for r in rejected), 'rejected startup contains measured observations')
    latency = {}
    for case in per_run:
        pooled = {version: summarize(samples[case][version]) for version in VERSIONS}
        for version in VERSIONS:
            require(equivalent(pooled[version], reported['pooled_latency_ms'][case][version]), 'pooled summary differs')
        latency[case] = dict(pooled=pooled, per_round=per_run[case],
                             eligible=latency_eligible,
                             usage='latency_comparison' if latency_eligible else 'throughput_companion_only',
                             paired=paired_latency(per_run[case]['baseline'], per_run[case]['candidate'])
                                    if latency_eligible else None)
    throughput = {name: paired_throughput(values['baseline'], values['candidate']) for name, values in rates.items()}
    for name, values in rates.items():
        for version in VERSIONS:
            expected = [values[version][i] for i in sorted(values[version])]
            require(equivalent(expected, reported['throughput_mib_per_second'][version][name]['rounds']), 'reported throughput rounds differ')
    return dict(source=str(directory), pattern=pattern,
                evidence=dict(gui_runs=len(selected), ignored_ghostty_controls=len(runs) - len(selected),
                              measured_samples=measured_count, latency_eligible=latency_eligible,
                              latency_samples_for_inference=measured_count if latency_eligible else 0,
                              throughput_companion_samples=0 if latency_eligible else measured_count,
                              true_focus_flags=focus_count, runtime_cleanups=cleanup_count,
                              rejected_startups=len(rejected), retained_rate_misses=len(retained),
                              raw_and_summary_checked=True, binary_identity='Recorded run hashes checked against manifest; external binaries not reread.',
                              payload_sha256=payloads, geometry=geometries),
                latency=latency, gui_throughput=throughput, background_load=loads)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directories', type=Path, nargs='+')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    report = dict(valid=False, sources=[], bootstrap=dict(samples=BOOTSTRAP_SAMPLES, seed=BOOTSTRAP_SEED,
                  unit='complete paired round', latency_interval='two-sided percentile 95%', throughput_lower='one-sided percentile 5%'),
                  limits=['Four-pair bootstrap coverage is fragile; this is an operational rule for measured workloads, not population equivalence.',
                          'No multiple-comparison correction. Pooled p99 is descriptive. All post-warmup values and rate misses remain included.',
                          'Runs with manifest samples <= 1 have throughput-companion latency only: descriptive percentiles are retained, paired latency inference is disabled.',
                          'A rate miss prevents claiming identical observed background load in the affected intervals. Checkpoints are not synchronized to echo samples.',
                          'Native GPU completion and PTY/DSR throughput are distinct endpoints. No claim about physical presentation or all memory allocations.',
                          'External binary files are not required to remain at their original paths; this validates saved evidence, not current executable contents.'])
    try:
        patterns = set()
        for directory in args.directories:
            source = analyze_directory(directory.resolve())
            require(source['pattern'] not in patterns, 'multiple sources for one pattern would mix independent series')
            patterns.add(source['pattern'])
            report['sources'].append(source)
        strata = {source['pattern'] + '/' + workload: values for source in report['sources']
                  for workload, values in source['gui_throughput'].items()}
        required = {'repeat/ascii', 'repeat/ansi', 'variable/ascii', 'variable/ansi'}
        observed = set(strata)
        report['gui_throughput_rule'] = dict(margin=THROUGHPUT_MARGIN, observed_strata=sorted(observed),
            missing_strata=sorted(required - observed), all_four_strata_present=observed == required,
            all_observed_strata_meet_rule=all(s['criterion_met'] is True for s in strata.values()) if strata else None,
            all_four_strata_meet_rule=observed == required and all(s['criterion_met'] is True for s in strata.values()),
            four_pairs_in_every_stratum=bool(strata) and all(s['protocol_four_pairs'] for s in strata.values()))
        report['valid'] = True
    except (OSError, ValueError, KeyError, TypeError, ZeroDivisionError) as error:
        report['error'] = str(error)
    report['analyzer_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    encoded = json.dumps(report, indent=2, allow_nan=False) + '\n'
    if args.output:
        temporary = args.output.with_suffix(args.output.suffix + '.tmp')
        temporary.write_text(encoded)
        temporary.replace(args.output)
    print(encoded, end='')
    return 0 if report['valid'] else 2


if __name__ == '__main__':
    sys.exit(main())

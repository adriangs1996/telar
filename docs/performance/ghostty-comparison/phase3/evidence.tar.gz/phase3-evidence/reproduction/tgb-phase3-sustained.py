#!/usr/bin/env python3
"""Run the predeclared phase-three sustained comparison, serially.

Example: python3 /tmp/tgb-phase3-sustained.py
No compilation, native applications, profiler, or detached workload is used.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import random
import shutil
import statistics
import subprocess
import sys
import time

MIB = 1024 * 1024
PAYLOAD_MIB = 64
ROUNDS = 4
BOOTSTRAP_SAMPLES = 10000
BOOTSTRAP_SEED = 20260918
NONINFERIORITY_MARGIN = 0.95
BINARIES = {
    'baseline': Path('/tmp/tgb-phase2-stable/bin/telar'),
    'candidate': Path('/tmp/tgb-phase3-candidate/bin/telar'),
}
TOOLS = ('terminal_runtime_bench.py', 'terminal_bench_fixture.py', 'perf_e2e.py',
         'flood.py', 'echo_latency.py', 'load_latency.py', 'graphics_roundtrip.py')
CONFIG = Path('docs/performance/ghostty-comparison/config.lua')
PROTOCOL = Path('/tmp/tgb-phase3-protocol.md')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(MIB), b''):
            digest.update(block)
    return digest.hexdigest()


def plan(output):
    specs = []
    for round_index in range(ROUNDS):
        variants = ('baseline', 'candidate') if round_index % 2 == 0 else ('candidate', 'baseline')
        patterns = ('repeat', 'variable') if round_index % 2 == 0 else ('variable', 'repeat')
        for pattern in patterns:
            for variant in variants:
                name = f'{round_index}-{pattern}-{variant}'
                directory = output / 'raw' / name
                binary = BINARIES[variant].resolve()
                specs.append(dict(name=name, round=round_index, pattern=pattern, variant=variant,
                    directory=str(directory), binary=str(binary), mib=PAYLOAD_MIB,
                    command=[sys.executable, str(output / 'harness/tools/terminal_runtime_bench.py'),
                             '--binary', str(binary), '--output', str(directory),
                             '--mib', str(PAYLOAD_MIB)]))
    return specs


def validate(record, expected_hashes):
    result, shutdown = record['result'], record['shutdown']
    require(record['returncode'] == 0, 'workload process failed')
    require(result.get('failed') is False, 'fixture did not report successful completion')
    require(result.get('endpoint') == 'pty_write_to_dsr_response', 'DSR endpoint changed')
    require(result.get('text_pattern') == record['pattern'], 'text pattern changed')
    require(result.get('bytes_per_case') == PAYLOAD_MIB * MIB, 'payload size changed')
    require(result.get('outer_pty') == [111, 35], 'outer PTY geometry changed')
    require(result.get('sampled') is False and result.get('detached') is False,
            'workload must remain attached and unprofiled')
    require(Path(result['binary']).resolve() == Path(record['binary']), 'binary path changed')
    require([case['name'] for case in result['cases']] == ['ascii', 'ansi'],
            'expected exactly one ASCII and one ANSI payload, in order')
    for case in result['cases']:
        require(case.get('text_pattern') == record['pattern'], 'case pattern changed')
        require(case['bytes'] == PAYLOAD_MIB * MIB, 'case payload length changed')
        require([case['cols'], case['rows']] == [111, 33], 'inner PTY geometry changed')
        rate, elapsed = case['mib_per_second'], case['elapsed_ms']
        require(math.isfinite(rate) and rate > 0 and math.isfinite(elapsed) and elapsed > 0,
                'invalid throughput or duration')
        require(math.isclose(rate, PAYLOAD_MIB * 1000 / elapsed, rel_tol=1e-9),
                'throughput does not match bytes and duration')
        digest = case['payload_sha256']
        require(len(digest) == 64 and all(char in '0123456789abcdef' for char in digest),
                'invalid payload SHA-256')
        key = record['pattern'], case['name']
        require(expected_hashes.setdefault(key, digest) == digest, 'same-case payload hash changed')
    require(shutdown.get('returncode') == 0 and all(shutdown.get(key) is True for key in
            ('exited', 'children_exited', 'socket_removed', 'cleanup_complete')),
            'runtime cleanup was not graceful and complete')


def percentile(values, fraction):
    ordered = sorted(values)
    position = (len(ordered) - 1) * fraction
    lower = math.floor(position)
    upper = math.ceil(position)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def summarize(records):
    groups = {}
    for record in records:
        if not record.get('valid'):
            continue
        for case in record['result']['cases']:
            key = f"{record['pattern']}/{case['name']}"
            rounds = groups.setdefault(key, {})
            pair = rounds.setdefault(record['round'], {})
            require(record['variant'] not in pair, 'duplicate pattern/workload/round/variant')
            pair[record['variant']] = case['mib_per_second']
    stats = {}
    for key, rounds in sorted(groups.items()):
        pairs = [dict(round=index, baseline=values['baseline'], candidate=values['candidate'],
                      ratio=values['candidate'] / values['baseline'])
                 for index, values in sorted(rounds.items()) if set(values) == set(BINARIES)]
        rates = {}
        for variant in BINARIES:
            values = [pair[variant] for pair in pairs]
            if values:
                rates[variant] = dict(median=statistics.median(values), minimum=min(values), maximum=max(values))
        row = dict(pairs=pairs, paired_rounds=len(pairs), mib_per_second=rates,
                   status='incomplete', margin=NONINFERIORITY_MARGIN)
        if len(pairs) == ROUNDS:
            logs = [math.log(pair['ratio']) for pair in pairs]
            rng = random.Random(BOOTSTRAP_SEED)
            boot = [math.exp(sum(logs[rng.randrange(ROUNDS)] for _ in logs) / ROUNDS)
                    for _ in range(BOOTSTRAP_SAMPLES)]
            lower, upper = percentile(boot, .05), percentile(boot, .95)
            row.update(geometric_paired_ratio=math.exp(statistics.mean(logs)),
                       ratio_ci95=[percentile(boot, .025), percentile(boot, .975)],
                       lower_one_sided_95=lower, upper_one_sided_95=upper,
                       status='passes_margin' if lower >= NONINFERIORITY_MARGIN else
                              'regression_beyond_margin' if upper < NONINFERIORITY_MARGIN else 'inconclusive')
        stats[key] = row
    complete = len(records) == ROUNDS * len(BINARIES) * 2 and all(row.get('valid') for row in records)
    return dict(completed_runs=len(records), valid_runs=sum(row.get('valid', False) for row in records),
        complete=complete, strata=stats,
        all_strata_pass_margin=complete and len(stats) == 4 and all(row['status'] == 'passes_margin' for row in stats.values()),
        estimator='Geometric mean of candidate/baseline ratios within complete paired rounds.',
        bootstrap=dict(samples=BOOTSTRAP_SAMPLES, seed=BOOTSTRAP_SEED, unit='paired round',
                       method='percentile; p5 is the one-sided 95% lower bound'),
        endpoint='PTY write to DSR response; not GPU completion or presentation.',
        limitations=['Four pairs give a discrete bootstrap with fragile coverage; this is a limited operational criterion.',
                     'An interval including one is not equivalence; crossing the 0.95 margin is inconclusive.',
                     'Headless attached TUI throughput is not the native GUI endpoint.'])


def recover(proc, spec, env, perf_e2e):
    cleanup_env = dict(env, TELAR_SOCKET_PATH=str(Path(spec['directory']) / 'runtime.sock'))
    roots = [proc.pid] + perf_e2e.runtime_pids(cleanup_env['TELAR_SOCKET_PATH'])
    sessions = perf_e2e.owned_sessions(perf_e2e.descendants(roots))
    if proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
    shutdown = perf_e2e.stop_runtime(spec['binary'], cleanup_env)
    survivors = perf_e2e.session_members(sessions)
    perf_e2e.cleanup_sessions(sessions)
    return dict(shutdown=shutdown, forced_cleanup=survivors, remaining=perf_e2e.session_members(sessions))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path('/Users/adriangonzalez/sandbox/telar'))
    parser.add_argument('--output', type=Path, default=Path('/tmp/tgb-p3-sustained'))
    parser.add_argument('--provenance', type=Path, help='optional existing build-provenance JSON to archive')
    parser.add_argument('--summarize-only', action='store_true')
    args = parser.parse_args()
    repo, output = args.repo.resolve(), args.output.resolve()
    if args.summarize_only:
        summary = summarize(json.loads((output / 'runs.json').read_text()))
        manifest = json.loads((output / 'manifest.json').read_text())
        summary['series_valid'] = summary['complete'] and manifest.get('artifacts_unchanged') is True and not (output / 'failure.json').exists()
        if not summary['series_valid']:
            summary['all_strata_pass_margin'] = False
        save(output / 'summary.json', summary)
        return 0
    require(not output.exists(), f'output already exists: {output}')
    sources = {f'tools/{name}': repo / 'tools' / name for name in TOOLS}
    sources[str(CONFIG)] = repo / CONFIG
    for path in (*BINARIES.values(), *sources.values(), PROTOCOL):
        require(path.is_file(), f'missing artifact: {path}')
    if args.provenance:
        require(args.provenance.is_file(), 'build provenance file does not exist')
    specs = plan(output)
    require(all(len(os.fsencode(Path(spec['directory']) / 'runtime.sock')) < 104 for spec in specs),
            'output path is too long for a macOS Unix socket')
    output.mkdir(mode=0o700)
    (output / 'raw').mkdir()
    (output / 'logs').mkdir()
    copied = {}
    for relative, source in sources.items():
        target = output / 'harness' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        copied[str(target)] = sha256(target)
    shutil.copy2(Path(__file__), output / 'runner.py')
    shutil.copy2(PROTOCOL, output / 'protocol.md')
    if args.provenance:
        shutil.copy2(args.provenance, output / 'build-provenance.json')
    manifest = dict(created_unix_ns=time.time_ns(), platform=platform.platform(), python=sys.version,
        command_line=sys.argv, plan=specs, all_workloads_serial=True,
        binaries={key: dict(path=str(path.resolve()), sha256=sha256(path)) for key, path in BINARIES.items()},
        original_tools={str(path): sha256(path) for path in sources.values()}, copied_tools=copied,
        runner_sha256=sha256(output / 'runner.py'), protocol_sha256=sha256(output / 'protocol.md'),
        build_provenance_sha256=sha256(output / 'build-provenance.json') if args.provenance else None,
        source_provenance_note='Binary SHA identifies the executable. Source-to-build attribution requires the separate build provenance.',
        endpoint='pty_write_to_dsr_response', outer_pty=[111, 35], expected_inner_pty=[111, 33],
        paired_order=['AB', 'BA', 'AB', 'BA'], pattern_order='repeat/variable on even rounds, variable/repeat on odd rounds',
        payload_mib=PAYLOAD_MIB, rounds=ROUNDS, sampled=False, detached=False,
        bootstrap_samples=BOOTSTRAP_SAMPLES, bootstrap_seed=BOOTSTRAP_SEED, ratio_margin=NONINFERIORITY_MARGIN)
    save(output / 'manifest.json', manifest)
    sys.path.insert(0, str(output / 'harness/tools'))
    import perf_e2e
    records, expected_hashes = [], {}
    failure = None
    for spec in specs:
        env = {key: value for key, value in os.environ.items()
               if not key.startswith(('TELAR_', 'BENCH_', 'TMUX', 'HERDR', 'TGB_')) and key != 'DYLD_INSERT_LIBRARIES'}
        env.update(BENCH_TEXT_PATTERN=spec['pattern'], TGB_DRAW_DIAGNOSTICS='0')
        record = dict(spec, started_unix_ns=time.time_ns(), valid=False)
        started = time.perf_counter()
        proc = None
        try:
            require(sha256(spec['binary']) == manifest['binaries'][spec['variant']]['sha256'], 'binary changed before run')
            with (output / 'logs' / f"{spec['name']}.log").open('wb') as log:
                proc = subprocess.Popen(spec['command'], cwd=repo, env=env, stdout=log,
                                        stderr=subprocess.STDOUT, start_new_session=True)
                record['returncode'] = proc.wait(timeout=240)
            directory = Path(spec['directory'])
            record['result'] = json.loads((directory / 'result.json').read_text())
            record['shutdown'] = json.loads((directory / 'shutdown.json').read_text())
            validate(record, expected_hashes)
            require(sha256(spec['binary']) == manifest['binaries'][spec['variant']]['sha256'], 'binary changed during run')
            record['valid'] = True
        except BaseException as error:
            failure = f'{type(error).__name__}: {error}'
            record['error'] = failure
            if proc is not None:
                try:
                    record['recovery'] = recover(proc, spec, env, perf_e2e)
                except BaseException as cleanup_error:
                    record['recovery_error'] = f'{type(cleanup_error).__name__}: {cleanup_error}'
            if proc is not None:
                record.setdefault('returncode', proc.returncode)
        record.update(finished_unix_ns=time.time_ns(), elapsed_seconds=time.perf_counter() - started)
        records.append(record)
        save(output / 'runs.json', records)
        print(json.dumps({key: record[key] for key in ('name', 'valid', 'elapsed_seconds')}), flush=True)
        if failure:
            break
    final_hashes = {}
    paths = [value['path'] for value in manifest['binaries'].values()]
    paths += list(manifest['original_tools']) + list(manifest['copied_tools'])
    for path in paths:
        final_hashes[path] = sha256(path) if Path(path).is_file() else None
    expected = {value['path']: value['sha256'] for value in manifest['binaries'].values()}
    expected.update(manifest['original_tools'])
    expected.update(manifest['copied_tools'])
    manifest.update(completed_unix_ns=time.time_ns(), final_sha256=final_hashes,
                    artifacts_unchanged=all(final_hashes[path] == digest for path, digest in expected.items()))
    save(output / 'manifest.json', manifest)
    if not manifest['artifacts_unchanged']:
        failure = failure or 'binary or tool hash changed during the series'
    summary = summarize(records)
    summary['series_valid'] = failure is None and summary['complete']
    if not summary['series_valid']:
        summary['all_strata_pass_margin'] = False
        save(output / 'failure.json', dict(error=failure, completed_runs=len(records)))
    save(output / 'summary.json', summary)
    if failure:
        print(failure, file=sys.stderr, flush=True)
        return 1
    save(output / 'complete.json', dict(runs=len(records), payloads=len(records) * 2, artifacts_unchanged=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
